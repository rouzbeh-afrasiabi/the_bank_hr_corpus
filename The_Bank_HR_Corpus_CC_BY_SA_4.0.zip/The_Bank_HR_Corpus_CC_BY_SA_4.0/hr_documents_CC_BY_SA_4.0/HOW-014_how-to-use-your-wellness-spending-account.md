# How to use your wellness spending account

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-014 |
| Title | How to use your wellness spending account |
| Document type | How-to article |
| Version | 1.1 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-10-20 |
| Next review | 2027-10-20 |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-001, HR-PLN-004, HR-PLN-007 |

## 1. The short answer

Submit your receipts in MyHR > Benefits by 31 March of the following year to be reimbursed from your wellness spending account: $500 CAD (Canada) or $400 USD (US) per calendar year.

## 2. Who this applies to

Employees who are eligible for health and insurance benefits: regular full-time, regular part-time and fixed-term employees of 6 months or more, from day 1. Casual, student, co-op, intern and fixed-term (under 6 months) employees have the Wellspring Support Program only. Quebec employees follow the same rules and may ask for French materials. The US account is separate from your health savings account or flexible spending accounts, which are managed through the account administrator linked from MyHR.

## 3. Steps

1. Check that the expense is a health or wellness expense, such as a fitness membership, equipment, nutrition counselling or a mindfulness program.
2. Pay for it and keep the receipt showing the date, the provider and the amount.
3. Go to MyHR > Benefits > Wellness Spending Account and select **New claim**.
4. Enter the date and amount, and attach the receipt.
5. Submit. You can check the balance and claim status on the same page.

## 4. Deadlines and what happens next

| Plan year | Last day to submit claims |
| --- | --- |
| 2026 (1 January to 31 December 2026) | 31 March 2027 |
| 2027 | 31 March 2028 |

Eligible claims are reimbursed up to your remaining balance. Unused balances are forfeited and do not carry over to the next year. This deadline is different from the 12-month rule for ordinary health and dental claims, so do not wait for it.

If you leave the Bank, you can still claim expenses incurred up to your last day, by 31 March of the following year (see HR-POL-015 Resignation and Offboarding Policy).

## 5. Common mistakes

- Submitting a 2026 receipt after 31 March 2027. Late claims are not paid.
- Assuming the balance carries over. It does not.
- Sending health and dental receipts here. Those go through the Maplewood Benefits member portal (linked from MyHR).
- Submitting a receipt without proof of payment or with the amount unreadable.
- Expecting the Canadian amount in the US, or the reverse. The amount follows your country of employment.

## 6. Who to call

- HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, or live chat in MyHR.
- Maplewood Benefits claims line: 1-800-555-0190, for a claim that looks wrong.
- Wellspring Support Program: 1-800-555-0166, 24 hours a day, for confidential counselling (up to 8 sessions per issue per calendar year, free).

## 7. Related documents

- HR-GDE-001 Employee Benefits Guide (section 9, the owning document)
- HR-PLN-004 Group Benefits Booklet (Canada)
- HR-PLN-007 Benefits Claims and Appeals Guide

Where applicable law gives a greater right, the law applies.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.1 | 2026-01-01 | Updated for plan year 2026 and the 31 March claim deadline. |
| 1.0 | 2025-01-01 | First version. |
