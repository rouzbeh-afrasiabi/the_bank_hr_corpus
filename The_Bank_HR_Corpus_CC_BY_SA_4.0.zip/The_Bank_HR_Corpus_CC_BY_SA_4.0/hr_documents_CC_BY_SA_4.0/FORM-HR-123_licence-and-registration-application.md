# Licence and Registration Application

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-123 |
| Title | Licence and Registration Application |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | Chief Compliance Officer |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-029, HR-POL-012, HR-POL-030, FORM-HR-061 |

## 1. Purpose and when to use this form

Use this form to apply for a licence or registration your role requires, to register for an exam, or to report a change in status (HR-POL-029 Licensing, Registration and Qualification Policy). Licensed roles include:

| Country | Licences and registrations |
| --- | --- |
| Canada | Mutual fund dealing representative (Personal Banking Advisors, Senior Personal Banking Advisors, Wealth Advisors); provincial mortgage brokerage licence (Mortgage Specialists); securities registrations (Capital Markets, Portfolio Managers) |
| US | Series 6, 7, 63, 65 or 66 as the role needs (Wealth Advisor, Portfolio Manager, Capital Markets); NMLS registration (Mortgage Specialists) |

You may not carry out licensed duties until the licence is active.

## 2. Who completes it and who approves

You complete it. Your manager confirms the role requirement. Compliance approves and files the application.

## 3. Where and when to submit (deadline, channel, processing time)

Submit in MyHR (Career and Learning > Licensing) within 5 business days of your start date or of moving to a licensed role. Report any change in registration status, regulatory inquiry, complaint, sanction, bankruptcy, criminal charge or conviction to Compliance within 2 business days, using the Change of status section. Annual licence review is each 1 September.

## 4. Form fields

| Field | Required | Notes |
| --- | --- | --- |
| Name, employee ID, role, band, manager | Yes | Pre-filled |
| Request type | Yes | New licence, exam registration, renewal or continuing education, change of status |
| Licence, registration or exam name and regulator | Yes | |
| Province or state | Yes | |
| Exam date and attempt number (1, 2 or 3) | For exams | |
| Fees and continuing education costs | Yes | Attach invoice |
| Study days requested (5 per exam) | No | See HR-POL-012 Learning and Development Policy |
| Current licence status and expiry date | For renewals | |
| Change of status details | If applicable | Describe the event and date |

## 5. Declarations and signatures

I confirm that the information is accurate. I understand that:

- the Bank pays 100% of exam fees for two attempts, plus licence and registration fees and required continuing education;
- a third attempt is at my cost unless Compliance approves;
- if I have not passed after 3 attempts or 9 months after hire, a redeployment review applies;
- if my licence lapses, I am removed from licensed duties immediately and have up to 60 days to restore it, followed by a review by the HRBP and Compliance.

Signature and date: ____________.

## 6. What happens next

Compliance confirms the application and the Bank pays eligible fees directly or reimburses them (see FORM-HR-061 Professional Designation Reimbursement Request for designations). A lapse caused by missed continuing education is a conduct matter under HR-POL-030 Fit and Proper and Conduct Standards Policy.

## 7. Related documents

- HR-POL-029 Licensing, Registration and Qualification Policy
- HR-POL-030 Fit and Proper and Conduct Standards Policy
- FORM-HR-061 Professional Designation Reimbursement Request

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-09-01 | Added change-of-status section and the lapse and exam attempt rules. |
| 1.0 | 2023-06-01 | Initial form. |
