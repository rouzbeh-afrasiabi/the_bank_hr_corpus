# Mortgage Specialist

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1006 |
| Title | Mortgage Specialist |
| Document type | Job description |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-09-30 |
| Next review | 2027-09-30 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-PLN-002, HR-POL-029, HR-POL-003, HR-POL-018 |

## 1. Role summary

The Mortgage Specialist guides customers through home purchase, renewal, refinance and equity borrowing, from the first conversation to funded loan. The Specialist works with branch advisors and referral partners, assesses affordability and risk, structures suitable mortgage solutions, and explains terms, rate options and obligations clearly. The role is accountable for sound, compliant lending and a smooth customer experience through the application process. This is a Band 4 (Senior Professional) role in the Retail Banking family; see HR-GDE-006 Job Architecture and Pay Bands Guide.

## 2. Key responsibilities

- Meet customers at branches, by phone or by video to understand their housing goals and financial position.
- Complete mortgage applications, collecting income, asset, liability and property documentation.
- Assess affordability, credit history and collateral, and structure terms within delegated authority.
- Explain rate types, terms, prepayment options, insurance requirements and renewal choices.
- Collaborate with appraisers, lawyers, notaries and title and closing agents to meet closing dates.
- Submit complex or above-authority files for independent credit review, and communicate decisions and conditions to customers.
- Contact customers ahead of renewal and review options before maturity.
- Detect and report fraud indicators such as altered documents or misrepresented income, and apply anti-money-laundering procedures.
- Build referral relationships with Personal Banking Advisors and local real estate professionals in line with the Bank's conduct standards.
- Meet quarterly scorecard goals for customer experience, growth, and risk and conduct.

## 3. Qualifications

### 3.1 Required

- Post-secondary education in business, finance or a related field, or equivalent experience.
- Five to eight years of experience in residential lending, mortgage origination or underwriting.
- Strong knowledge of residential lending regulations, affordability testing and property valuation.
- Excellent consultative, negotiation and documentation skills.
- Ability to obtain and maintain the licences below.

### 3.2 Preferred

- Experience in mortgage underwriting or as a Personal Banking Advisor.
- Fluency in English and French.
- Completion of an accredited mortgage professional program.

### 3.3 Licences and certifications

Under HR-POL-029 Licensing, Registration and Qualification Policy, the Mortgage Specialist in Canada must hold an active provincial mortgage brokerage licence for the province in which they work. In the US, the role must hold an active NMLS registration. No licensed duties may be performed until the licence or registration is active. A lapse is reported to Compliance and removes the employee from licensed duties immediately.

## 4. Competencies

Competencies are defined in HR-FWK-001 Competency and Leadership Model; this role works at the Practitioner level.

- **Customer Obsession**: guides customers through one of their largest financial decisions with clarity.
- **Judgement and Decision Quality**: weighs affordability, collateral and risk in each structure.
- **Risk and Conduct Awareness**: complies with lending, licensing and fair-treatment rules.
- **Drive for Results**: moves files to funding on time and meets scorecard goals.
- **Collaboration**: works with branches, credit and external partners.
- **Adaptability**: responds to changing rates, regulation and market conditions.

## 5. Compensation and classification

| Item | Detail |
| --- | --- |
| Band | 4 (Senior Professional) |
| Canada salary range | $72,000 to $108,000 CAD per year |
| US salary range | $70,000 to $106,000 USD per year |
| Incentive target | Advisor and Sales Incentive Plan (HR-PLN-002): 12% of base salary, paid quarterly; replaces the Annual Incentive Plan |
| Overtime eligibility (Canada) | Yes (non-managerial Band 1 to 4 role) |
| FLSA classification (US) | Non-exempt |
| Work arrangement | On-site in assigned branches |

## 6. Working conditions and accessibility

This is an on-site, customer-facing role based in assigned branches, with appointments that may fall in the evening or on Saturdays. Overtime is pre-approved and follows HR-POL-003 Working Hours and Overtime Policy. The Bank provides accommodation to the point of undue hardship (Canada) or reasonable accommodation (US); see HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to the Regional Manager, Retail.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-01-01 | Moved to the Advisor and Sales Incentive Plan scorecard; added NMLS requirement for the US |
| 1.0 | 2024-01-08 | First issue |
