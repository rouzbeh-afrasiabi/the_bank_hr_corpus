# Senior Personal Banking Advisor

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1007 |
| Title | Senior Personal Banking Advisor |
| Document type | Job description |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-09-30 |
| Next review | 2027-09-30 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-PLN-002, HR-POL-029, HR-POL-018 |

## 1. Role summary

The Senior Personal Banking Advisor looks after the branch's most complex and highest-value personal customers, including households with several borrowing and investment needs, business owners with personal needs, and customers in life transitions such as retirement, inheritance or separation. The role is a recognized expert in the branch, coaches Personal Banking Advisors on difficult files, and holds delegated credit authority above the Advisor level. This is a Band 4 (Senior Professional) role in the Retail Banking family; see HR-GDE-006 Job Architecture and Pay Bands Guide.

## 2. Key responsibilities

- Manage a portfolio of complex personal customers with full-picture planning conversations covering credit, savings, investing and protection.
- Structure larger personal lending, secured lines of credit and investment lending within delegated authority and refer beyond it for independent credit review.
- Recommend suitable mutual fund and registered plan solutions, with complete suitability, know-your-client and disclosure documentation.
- Coach Personal Banking Advisors and Financial Services Representatives through joint appointments and file reviews.
- Handle escalated customer concerns and complaints in the branch and lead resolution.
- Partner with Mortgage Specialists, Wealth Advisors and Commercial Banking colleagues on shared customers and warm referrals.
- Apply anti-money-laundering, privacy and fair-treatment standards and act as the branch's go-to colleague for questions on them.
- Review customer portfolios regularly and reach out proactively around life events and maturing products.
- Support the Branch Manager in branch planning and community partnerships.
- Meet quarterly scorecard goals for customer experience, growth, and risk and conduct.

## 3. Qualifications

### 3.1 Required

- Post-secondary education in business, finance or a related field, or equivalent experience.
- Five to eight years of experience in retail banking advisory, lending or wealth roles.
- Proven record of sound credit decisions and compliant, needs-based advice.
- Strong coaching, communication and relationship skills.
- Ability to obtain and maintain the licence below.

### 3.2 Preferred

- CFP or similar designation, or progress towards one.
- Experience mentoring or training colleagues.
- Fluency in English and French.

### 3.3 Licences and certifications

Under HR-POL-029 Licensing, Registration and Qualification Policy, the Senior Personal Banking Advisor in Canada must hold an active mutual fund dealing representative licence. In the US, the role must hold any registration the role requires. No licensed duties may be performed until the licence is active, and the annual licence review applies.

## 4. Competencies

Competencies are defined in HR-FWK-001 Competency and Leadership Model; this role works at the Practitioner level.

- **Customer Obsession**: becomes the trusted adviser for customers' most important financial decisions.
- **Judgement and Decision Quality**: makes sound credit and suitability decisions in ambiguous situations.
- **Risk and Conduct Awareness**: models fair selling and escalates concerns without hesitation.
- **Developing Others**: raises advisor capability through coaching and example.
- **Drive for Results**: delivers growth with a strong conduct record.
- **Collaboration**: coordinates specialists around the customer.

## 5. Compensation and classification

| Item | Detail |
| --- | --- |
| Band | 4 (Senior Professional) |
| Canada salary range | $72,000 to $108,000 CAD per year |
| US salary range | $70,000 to $106,000 USD per year |
| Incentive target | Advisor and Sales Incentive Plan (HR-PLN-002): 10% of base salary, paid quarterly; replaces the Annual Incentive Plan |
| Overtime eligibility (Canada) | Yes (non-managerial Band 1 to 4 role) |
| FLSA classification (US) | Exempt |
| Work arrangement | On-site at the assigned branch |

## 6. Working conditions and accessibility

This is an on-site, customer-facing role in a branch, with scheduled appointments and a posted schedule that may include Saturdays. The Bank provides accommodation to the point of undue hardship (Canada) or reasonable accommodation (US); see HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to the Branch Manager.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-01-01 | Moved to the Advisor and Sales Incentive Plan scorecard; added coaching duties |
| 1.0 | 2024-01-08 | First issue |
