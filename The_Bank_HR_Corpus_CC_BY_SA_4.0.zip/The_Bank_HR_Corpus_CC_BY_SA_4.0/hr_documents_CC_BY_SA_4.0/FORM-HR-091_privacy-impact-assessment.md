# Privacy Impact Assessment

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-091 |
| Title | Privacy Impact Assessment |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-02-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | Chief Privacy Officer |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-016, HR-POL-017, HR-REF-002, FORM-HR-092, HR-MEMO-2026-004, HR-PRC-008 |

## 1. Purpose and when to use this form

A Privacy Impact Assessment (PIA) is required before launching or materially changing any HR system, process, vendor or tool that collects, uses or discloses employee personal information (HR-POL-016 Employee Data Privacy Policy). Complete it early, because a system may not go live without a Privacy Office decision. If the processing is high-risk, also complete FORM-HR-092 Data Protection Impact Assessment.

## 2. Who completes it and who approves

The system owner completes it. The Privacy Office reviews it and decides. Vendor and contract terms are checked as part of the review.

## 3. Where and when to submit (deadline, channel, processing time)

Submit in the HR Case Portal (Privacy > Impact Assessment) or email privacy@bank.example. The Privacy Office reviews within 15 business days of a complete submission. Reassess every 3 years or on any material change. For Quebec, a PIA is required before information is transferred outside Quebec.

## 4. Form fields

### 4.1 Project details

| Field | Required | Notes |
| --- | --- | --- |
| Project name, system owner, business unit | Yes | |
| Description and business purpose | Yes | What problem it solves |
| Planned go-live date | Yes | Allow for the 15-business-day review |
| New system or material change | Yes | Describe the change |
| Vendor name and contract status | If a vendor is involved | Third parties must be bound by written terms |

### 4.2 Questions

Answer every question. Write "Not applicable" with a reason where it does not apply.

| No. | Question | Required |
| --- | --- | --- |
| 1 | Which categories of employee personal information are collected (identity, pay, performance, health, attendance, technology, self-identification)? | Yes |
| 2 | Is any information sensitive (health, disability, biometric, diversity, financial account, government identifier)? | Yes |
| 3 | Whose information is it: employees, former employees, applicants, dependants or beneficiaries? | Yes |
| 4 | Why is each item needed, and was the purpose stated to individuals at or before collection? | Yes |
| 5 | Can the purpose be met with less information? | Yes |
| 6 | Is consent required? How is it recorded, and can it be withdrawn? | Yes |
| 7 | Who inside the Bank can see the information, and how is access limited and logged? | Yes |
| 8 | Is information shared with third parties? Which, and why? | Yes |
| 9 | In which countries and provinces or states is it stored or accessed? | Yes |
| 10 | Does any information leave Canada or Quebec? | Yes |
| 11 | How are information security controls aligned with HR-POL-017 IT Acceptable Use and Information Security Policy (encryption, access reviews)? | Yes |
| 12 | How long is the information kept, per HR-REF-002 Employee Records Retention Schedule, and how is it destroyed? | Yes |
| 13 | How can individuals see and correct their information? | Yes |
| 14 | How will a privacy breach be detected and reported within 24 hours? | Yes |
| 15 | Does the project involve monitoring, biometrics, automated or AI-assisted decisions, large-scale sensitive data or cross-border transfers? If yes, a DPIA is also required. | Yes |
| 16 | Which privacy risks remain, and how will each be reduced? | Yes |

## 5. Declarations and signatures

I confirm that the answers are complete and accurate and that the system will not go live before a decision is issued. System owner signature and date: ____________. Business unit head signature and date: ____________.

## 6. What happens next

The Privacy Office acknowledges the submission, may ask follow-up questions, and issues a written decision: approved, approved with conditions, or not approved. Conditions must be met before go-live. The Privacy Office schedules the next reassessment and logs the decision. Since 13 April 2026, a PIA is also required before any AI tool is used in an HR process (see HR-MEMO-2026-004).

## 7. Related documents

- HR-POL-016 Employee Data Privacy Policy
- FORM-HR-092 Data Protection Impact Assessment
- HR-REF-002 Employee Records Retention Schedule

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-02-01 | Expanded the question set and added the Quebec transfer step. |
| 1.0 | 2021-10-01 | Initial form. |
