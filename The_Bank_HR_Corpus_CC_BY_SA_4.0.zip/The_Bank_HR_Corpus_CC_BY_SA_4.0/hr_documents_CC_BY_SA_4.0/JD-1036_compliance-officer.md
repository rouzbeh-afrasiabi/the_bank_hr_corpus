# Compliance Officer

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1036 |
| Title | Compliance Officer |
| Document type | Job description |
| Version | 3.0 |
| Status | Current |
| Effective date | 2026-09-01 |
| Last reviewed | 2026-10-14 |
| Next review | 2027-10-14 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-POL-002, HR-POL-029, HR-POL-030, HR-POL-032 |

## 1. Role summary

The Compliance Officer helps the Bank's business units meet legal, regulatory and conduct obligations. The officer interprets regulatory requirements, advises business partners, tests controls and monitors for breaches. A Band 4 officer handles complex advisory and monitoring work, guides junior colleagues and is recognized for depth in an area such as conduct, licensing, personal trading or sales practices.

## 2. Key responsibilities

- Advise business partners on the application of regulations and Bank policy to products, processes and client communications.
- Carry out compliance risk assessments and design monitoring and testing programs for the business areas covered.
- Operate the pre-clearance and surveillance process for personal trading, restricted and watch lists (HR-POL-032 Personal Trading and Restricted Lists Policy).
- Administer licensing and registration records, track continuing education and licence reviews (HR-POL-029 Licensing, Registration and Qualification Policy).
- Review marketing, disclosure and sales material for regulatory compliance before release.
- Investigate potential breaches, conduct matters and complaints, and recommend remediation.
- Report breaches and regulatory-change impacts to the Senior Manager, Compliance, in the required time frame.
- Support regulatory examinations and audits with evidence and responses.
- Deliver compliance training and briefings to employees and managers.
- Monitor the annual Code and fit-and-proper attestations and follow up on outstanding items.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in business, law, finance or a related field.
- Typically 5 to 8 years of experience in compliance, legal, regulatory or risk functions in financial services.
- Sound knowledge of the Canadian and US regulatory frameworks relevant to banking and securities.
- Excellent analytical, writing and influencing skills.

### 3.2 Preferred

- Law degree or a recognized compliance designation.
- Experience supporting Capital Markets or Wealth Management.
- Bilingual English and French.

### 3.3 Licences and certifications

Compliance Officers supporting Capital Markets or Wealth Management may be required to hold or obtain securities registration as set out in HR-POL-029 Licensing, Registration and Qualification Policy; the Bank pays the exam and registration fees. All officers are subject to HR-POL-030 Fit and Proper and Conduct Standards Policy and are covered persons for personal trading under HR-POL-032.

## 4. Competencies

Measured against HR-FWK-001 Competency and Leadership Model at the Practitioner level:

- Risk and Conduct Awareness
- Judgement and Decision Quality
- Collaboration
- Customer Obsession
- Developing Others
- Drive for Results

## 5. Compensation and classification

| Item | Value |
| --- | --- |
| Band | 4 (Senior Professional) |
| Canada range | $72,000 to $108,000 CAD |
| US range | $70,000 to $106,000 USD |
| Incentive target | 8% of base salary (Annual Incentive Plan) |
| Overtime eligibility, Canada | Yes (non-managerial Band 4) |
| FLSA classification, US | Exempt |
| Work arrangement | Hybrid (at least 3 days a week in the office) |

Band definitions are in HR-GDE-006 Job Architecture and Pay Bands Guide.

## 6. Working conditions and accessibility

This is an office role with a hybrid arrangement under HR-POL-002 Remote and Hybrid Work Policy: at least 3 days a week in the office, including the Tuesday and Thursday anchor days. Officers supporting a trading floor may sit on site for part of the week. The role requires strict confidentiality and independence from the business it monitors. The Bank provides accommodation to the point of undue hardship; see HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to: Senior Manager, Compliance. Direct reports: none.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 3.0 | 2026-09-01 | Updated licensing and personal trading duties to current policy |
| 2.0 | 2024-09-01 | Added monitoring and testing duties |
| 1.0 | 2023-09-01 | First issue |
