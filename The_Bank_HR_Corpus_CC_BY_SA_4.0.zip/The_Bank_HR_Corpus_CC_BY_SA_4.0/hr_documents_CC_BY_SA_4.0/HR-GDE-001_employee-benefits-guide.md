# Employee Benefits Guide

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-GDE-001 |
| Title | Employee Benefits Guide |
| Document type | Guide |
| Version | 2026.1 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-10-20 |
| Next review | 2027-10-20 |
| Policy owner | SVP Total Rewards |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Applies to | All Canadian and US employees (see Scope) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-007, HR-POL-008, HR-POL-014, HR-GDE-002, HR-GDE-004, HR-POL-015 |

## 1. Purpose

This guide explains the health, insurance and wellness benefits that the Bank offers to employees in Canada and the US for plan year 2026 (1 January to 31 December 2026). It tells you who is eligible, when and how to enrol, what each plan covers, what it costs, how to claim, and what happens to your coverage when your circumstances change.

Retirement and savings plans are described in HR-GDE-002 Retirement and Savings Plan Guide. Disability benefits are owned by HR-POL-007 Sick Leave and Personal Leave Policy. Where a plan contract and this guide differ, the Maplewood Benefits plan contract governs claims decisions. Where applicable law gives a greater right, the law applies.

## 2. Scope and eligibility

### 2.1 Who is eligible

| Employment category | Health, dental, vision and insurance benefits | Eligible from |
| --- | --- | --- |
| Regular full-time | Yes | Day 1 |
| Regular part-time | Yes | Day 1 |
| Fixed-term, 6 months or more | Yes | Day 1 |
| Fixed-term, under 6 months | Wellspring Support Program (EAP) only | Day 1 |
| Casual (on call) | Wellspring Support Program (EAP) only | Day 1 |
| Student, co-op, intern | Wellspring Support Program (EAP) only | Day 1 |

Contractors and agency workers are not employees and are not eligible. The full employment-status table is in HR-POL-014 Employment Status and Classification Policy.

### 2.2 Insurance carrier and administrators

Maplewood Benefits is the insurance carrier and claims administrator in both countries. Benefits Administration, part of HR Operations, manages enrolment, premium deductions and eligibility. The Wellspring Support Program provides the employee and family assistance program (EAP).

## 3. Enrolment windows and qualifying life events

### 3.1 New hire enrolment

You must enrol within 31 days of your start date in MyHR (Benefits, then Enrol). Coverage starts on your first day of employment, provided your election is made within the 31 days. If you make no election, you are enrolled by default as follows:

| Country | Default plan |
| --- | --- |
| Canada | Standard, employee-only coverage |
| US | Choice PPO, employee-only coverage |

A default election stays in place until the next annual enrolment or a qualifying life event.

### 3.2 Annual enrolment

Annual enrolment for plan year 2027 runs from 2 November to 16 November 2026, and elections take effect on 1 January 2027. If you do nothing, your current elections roll over, except for the flexible spending accounts in the US, which must be re-elected each year. Elections made during annual enrolment can be changed until 17:00 Eastern Time on 16 November 2026; after that they are locked for the plan year unless you have a qualifying life event.

### 3.3 Qualifying life events

You may change your elections outside annual enrolment only within 31 days of a qualifying life event. The change must be consistent with the event. Qualifying life events are:

| Event | Examples of permitted change |
| --- | --- |
| Marriage, common-law or domestic partnership | Add spouse or partner and stepchildren |
| Birth or adoption of a child | Add the child; move to family coverage |
| Loss of other coverage | Add yourself or a dependant who lost coverage elsewhere |
| Change in dependant status | Remove a dependant who ceases to be eligible; change tier |
| Divorce, separation or death of a covered person | Remove the person; change tier |

Submit the event date and supporting documents (for example a marriage certificate or birth record) in MyHR. Coverage for the new dependant starts on the date of the event if you apply within the 31 days. If you miss the 31-day window, you must wait for the next annual enrolment.

## 4. Dependants

| Dependant | Canada | US |
| --- | --- | --- |
| Spouse, common-law partner or domestic partner | Eligible | Eligible |
| Children | To age 21 (to 26 if a full-time student) | To age 26 |

Benefits Administration may ask for proof of eligibility. Providing false dependant information is a breach of HR-POL-001 Code of Conduct and Ethics.

## 5. Canada plans

Canadian employees choose one of three plan options administered by Maplewood Benefits. Premiums are deducted monthly from pay (shown per month).

| Item | Essential | Standard | Enhanced |
| --- | --- | --- | --- |
| Employee premium per month, employee only | $0 | $22 | $48 |
| Employee premium per month, family | $65 | $138 | $205 |
| Prescription drugs | 70% | 80% | 90% |
| Dental basic | 70% | 80% | 90% |
| Dental major | not covered | 50% | 60% |
| Annual dental maximum | $1,500 | $2,500 | $3,500 |
| Orthodontics | not covered | not covered | 50%, $2,500 lifetime |
| Vision, per 24 months | $150 | $250 | $400 |
| Paramedical combined, per year | $500 | $1,000 | $2,000 |
| Mental health practitioners, per year | $1,500 | $2,500 | $4,000 |

All amounts are in CAD. The following features apply to every Canadian plan:

- Semi-private hospital coverage.
- Unlimited virtual care visits.
- Emergency travel medical coverage: 60 days per trip, with a $5,000,000 lifetime maximum.
- Mandatory generic substitution: if you choose a brand-name drug when a generic is available, you pay the difference in cost.
- Dental recall examinations every 9 months.
- Quebec employees use the public drug plan or the Bank plan as the law requires.

## 6. US plans

US employees choose between the Choice PPO and the Saver HDHP (a high-deductible health plan paired with a health savings account). Premiums are deducted biweekly (26 pay periods).

| Item | Choice PPO | Saver HDHP |
| --- | --- | --- |
| Employee cost per pay period, employee only | $58 | $14 |
| Employee cost per pay period, family | $236 | $118 |
| Deductible (individual / family) | $500 / $1,000 | $3,300 / $6,600 |
| In-network coinsurance (plan pays / you pay) | 80 / 20 | 90 / 10 |
| Out-of-pocket maximum (individual / family) | $3,500 / $7,000 | $5,000 / $10,000 |
| Bank HSA deposit | Not applicable | $750 individual / $1,500 family |

The Bank deposits the HSA amount in January; for employees who join during the year the deposit is pro-rated by month. All amounts are in USD.

### 6.1 Dental and vision (US)

| Item | Coverage |
| --- | --- |
| Preventive dental | 100% |
| Basic dental | 80% |
| Major dental | 50% |
| Annual dental maximum | $2,000 |
| Orthodontics | 50%, $2,000 lifetime |
| Vision exam | One annual exam |
| Frame or lens allowance | $200 per 12 months |

### 6.2 Other US benefits (employee-paid)

Healthcare and dependent-care flexible spending accounts, commuter benefits, an optional legal plan, pet insurance and identity protection are available at the employee's own cost through payroll deduction.

## 7. Life, accidental death and critical illness insurance

These benefits apply in both countries.

| Benefit | Amount | Who pays |
| --- | --- | --- |
| Basic life insurance | 2x annual base salary | Bank |
| Accidental death and dismemberment (AD&D) | 2x annual base salary | Bank |
| Optional employee life | 1x to 6x annual base salary, maximum $2,000,000 | Employee |
| Optional spouse life | $25,000 | Employee |
| Dependent child life | $10,000 | Employee |
| Optional critical illness | $25,000, $50,000 or $100,000 | Employee |

Evidence of insurability (a health questionnaire reviewed by Maplewood Benefits) is required for optional employee life above 4x salary or above $750,000. Name and review your beneficiaries in MyHR; if no beneficiary is on file, the plan contract determines who is paid.

## 8. Disability benefits

Short-term and long-term disability benefits are provided by Maplewood Benefits and are employer-paid. The waiting period, benefit percentages, maximums and the application process (within 5 business days of going off work) are described only in HR-POL-007 Sick Leave and Personal Leave Policy. They are not repeated here.

## 9. Wellness spending account

Each eligible employee has a wellness spending account of $500 CAD or $400 USD per calendar year. It reimburses eligible health and wellness expenses such as fitness memberships, equipment, nutrition counselling and mindfulness programs. Submit receipts in MyHR; claims for a plan year must be submitted by 31 March of the following year (for plan year 2026, by 31 March 2027). Unused balances are forfeited and do not carry over.

## 10. Employee and family assistance program

The Wellspring Support Program is free, confidential and available 24 hours a day, 7 days a week at 1-800-555-0166. It provides up to 8 counselling sessions per issue per calendar year for employees and household members, plus legal, financial and elder-care referrals. It is open to all employees, including those who are not eligible for the other benefits in this guide. Your manager is not told that you have used it.

## 11. How to claim

### 11.1 Canada

1. Present your Maplewood Benefits card at a pharmacy or dental office that offers direct billing; you pay only your share.
2. Otherwise pay the provider and submit the receipt through the Maplewood Benefits member portal (linked from MyHR) within 12 months of the date of service.
3. For major dental work estimated above $500, request a predetermination first so that you know what will be paid.
4. Direct deposit of claim payments uses the account in your Maplewood Benefits profile.

### 11.2 US

1. Show your card at the time of service and use in-network providers to receive the coinsurance rates in this guide.
2. Out-of-network claims are filed through the Maplewood Benefits member portal; you will receive an explanation of benefits showing what was paid.
3. HSA and flexible spending account claims are submitted through the account administrator linked from MyHR.

### 11.3 Help with claims

The Maplewood Benefits claims line is 1-800-555-0190. For enrolment problems or premium errors, raise a case in the HR Case Portal in MyHR. Service levels are explained in HR-GDE-004 HR Service and Support Guide.

## 12. When coverage ends

Coverage ends at the end of the month in which employment ends. For example, if your last day is 14 July, coverage ends on 31 July.

| Item | Canada | US |
| --- | --- | --- |
| Continuation | Life insurance conversion: apply to Maplewood Benefits within 31 days | COBRA: election notice sent within 14 days; 60 days to elect; up to 18 months |
| Cost of continuation | Set by the carrier | Up to the full premium plus an administration fee, unless the Bank pays under a severance arrangement |

Offboarding steps are in HR-POL-015 Resignation and Offboarding Policy; severance-related premium support is described in HR-POL-025 Involuntary Termination and Severance Policy.

### 12.1 Retiree health access

Employees who leave at age 55 or older with at least 10 years of service may continue health access through the retiree plan. Retirees pay 100% of the premium. Contact Benefits Administration before your last day to arrange it.

## 13. Coordination with leaves

| Situation | Effect on benefits |
| --- | --- |
| Bank-paid parental leave | The Bank continues its share of premiums; see HR-POL-008 Parental and Family Leave Policy |
| Canadian job-protected parental leave (up to 18 months) | The Bank continues its share throughout |
| Personal leave of absence (unpaid) | Benefits continue if the employee pays both shares |
| Short-term and long-term disability | See HR-POL-007 for how benefits continue |

If you are on an unpaid leave, Benefits Administration will send an invoice for your required premiums. Missed premiums can cause coverage to lapse after 60 days.

## 14. Plan year 2026 notes

- Plan year 2026 runs from 1 January to 31 December 2026.
- The premiums, deductibles and HSA deposits in this guide apply for the full plan year.
- Annual enrolment for plan year 2027 is 2 to 16 November 2026; 2027 rates and any plan changes are published in MyHR before the window opens.
- The wellness spending account for plan year 2026 can be claimed until 31 March 2027.
- Sick days available under HR-POL-007 are separate from benefits plans and do not depend on enrolment.

## 15. Worked cost examples

### 15.1 Canada, family coverage

An employee in Ontario with a spouse and two children chooses Standard family coverage at $138 per month. Annual cost: $138 x 12 = $1,656 CAD. A dental claim for basic work of $400 is paid at 80%, so the plan pays $320 and the employee pays $80. A prescription costing $100 is reimbursed at 80%; if a generic is available, the employee who chooses the brand pays the difference in addition.

### 15.2 Canada, single employee

An employee choosing Enhanced employee-only coverage pays $48 x 12 = $576 CAD per year. Compared with Essential at $0, the additional $576 buys, for example, an annual dental maximum of $3,500 instead of $1,500 and $4,000 of mental health practitioner coverage instead of $1,500.

### 15.3 US, family PPO

An employee with family PPO coverage pays $236 x 26 = $6,136 USD per year. If the family has $5,000 of in-network claims, the deductible of $1,000 is paid first; the family then shares the 20% coinsurance on the remaining $4,000 ($800), for a total cost of $1,800 before premiums, which is below the $7,000 out-of-pocket maximum.

### 15.4 US, individual HDHP

An employee with Saver HDHP employee-only coverage pays $14 x 26 = $364 USD per year. The Bank deposits $750 into the HSA in January. Medical costs up to the $3,300 deductible can be paid from the HSA, which belongs to the employee, so the Bank deposit covers about 23% of the deductible.

### 15.5 Life insurance

An employee with a $90,000 base salary has basic life of 2 x $90,000 = $180,000 and AD&D of $180,000, both paid by the Bank. Choosing optional life of 4x gives an additional $360,000 with no evidence of insurability; choosing 6x gives $540,000 and requires evidence of insurability.

## 16. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Employee | Enrol on time, keep dependants and beneficiaries current, retain receipts |
| Manager | Direct questions to Benefits Administration; do not give benefits advice |
| Benefits Administration | Process elections, qualifying life events and premium deductions |
| Maplewood Benefits | Decide claims and administer plans |
| SVP Total Rewards | Owns this guide and the plan design |

## 17. Contacts

| Need | Contact |
| --- | --- |
| General benefits questions | HR Connect, 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time, hrconnect@bank.example |
| Claims | Maplewood Benefits claims line, 1-800-555-0190 |
| EAP | Wellspring Support Program, 1-800-555-0166, 24/7 |

## 18. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2026.1 | 2026-01-01 | Plan year 2026 edition: premiums, HSA deposits and enrolment dates refreshed; worked cost examples added |
| 2025.1 | 2025-01-01 | Plan year 2025 edition |
