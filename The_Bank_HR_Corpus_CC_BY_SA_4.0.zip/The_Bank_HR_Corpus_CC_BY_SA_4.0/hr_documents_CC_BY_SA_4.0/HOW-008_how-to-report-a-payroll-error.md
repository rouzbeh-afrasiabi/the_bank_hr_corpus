# How to report a payroll error

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-008 |
| Title | How to report a payroll error |
| Document type | How-to article |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-09-28 |
| Next review | 2027-09-28 |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-009, FORM-HR-021, HR-GDE-004, HOW-007 |

## 1. The short answer

Submit FORM-HR-021 Payroll Correction Request through the HR Case Portal in MyHR as soon as you see the error; a missed pay is a P1 urgent case with a first response within 4 business hours.

## 2. Who this applies to

All employees in Canada (including Quebec) and the US. It covers a missed or short payment, missing overtime or premium, or a wrong deduction. For bank or tax changes use FORM-HR-022 (see HOW-005). Amounts are in CAD in Canada and USD in the US.

## 3. Steps

1. Gather evidence: the pay statement, your Time Tracker entries and any approval message.
2. Select **MyHR > HR Case Portal > New case**, choose category **Pay**, and attach FORM-HR-021.
3. Enter the pay date and pay period (periods end on the Saturday before the pay date), the type of error, the estimated net amount and a short explanation.
4. Check the suggested priority and submit. You receive a case number by email.
5. Track the case under **MyHR > HR Case Portal > My cases** and reply if it shows "Waiting for you". Your manager may be asked to confirm hours.

## 4. Deadlines to remember

| Item | Rule |
| --- | --- |
| Missed pay (P1) | First response within 4 business hours |
| Other pay requests | First response within 2 business days |
| Net underpayment of $250 or more | Paid off-cycle within 3 business days of confirmation |
| Net underpayment under $250 | Corrected on the next regular pay date |
| Retroactive corrections | Back up to 24 months |

If you raise a case outside HR Connect hours, the 4-business-hour clock starts when HR Connect next opens.

## 5. What happens next

Payroll Services confirms the error and corrects it as above. If you were overpaid, Payroll Services writes to you with the amount, dates and cause. You may repay by lump sum, payroll deduction of at most 15% of net pay per pay period, or a plan of up to 12 months. Where the law requires written consent first (for example in California), it is obtained before any deduction.

## 6. Common mistakes

- Waiting several pay periods before reporting.
- Sending no evidence.
- Using this form for bank or tax changes, which have a separate form and cut-off.
- Not reporting an overpayment you know about, which breaches the Code of Conduct and Ethics.

If a service level is missed, the case escalates to the HR Operations manager after 1 missed deadline, then to the VP HR Operations (see HR-GDE-004 HR Service and Support Guide).

## 7. Who to call

HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, or live chat in MyHR; English and French.

## 8. Related documents

- HR-POL-009 Compensation and Payroll Policy
- FORM-HR-021 Payroll Correction Request
- HR-GDE-004 HR Service and Support Guide
- HOW-007 How to read your pay statement

## 9. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-03-01 | Off-cycle threshold raised from $200 to $250 (HR-POL-009 version 7.2). |
| 1.0 | 2025-03-01 | First edition with the $200 threshold. |
