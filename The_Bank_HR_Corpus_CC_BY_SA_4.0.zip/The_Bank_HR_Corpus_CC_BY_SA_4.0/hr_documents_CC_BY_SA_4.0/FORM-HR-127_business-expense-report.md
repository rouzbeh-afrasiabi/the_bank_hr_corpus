# Business Expense Report

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-127 |
| Title | Business Expense Report |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-12-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-038, HR-POL-001, HR-POL-009, FORM-HR-101 |

## 1. Purpose and when to use this form

Use this form, or the MyHR expense report, to claim reimbursement of business travel and client expenses (HR-POL-038 Business Travel and Expense Policy). Book travel through the Bank Travel Desk and use the corporate card for travel and client expenses where you have one.

| Item | Limit (CAD / USD) |
| --- | --- |
| Hotel per night | $250 / $200; $350 / $300 in designated high-cost cities |
| Meals per day while travelling | $75 / $60 (breakfast $15 / $12, lunch $20 / $16, dinner $40 / $32) |
| Mileage, approved personal vehicle | $0.70 per km / $0.67 per mile |
| Air travel | Economy under 6 hours; premium economy for 6 to 8 hours; business class only for Band 8 and above on flights over 8 hours, or with SVP approval |

Alcohol is reimbursed only at pre-approved client events.

## 2. Who completes it and who approves

You complete it. Your manager approves. A report totalling over $2,500 needs Director approval.

## 3. Where and when to submit (deadline, channel, processing time)

Submit in MyHR (Pay > Expenses) within 30 days of the expense. Attach a receipt for every expense over $25. Approved claims are reimbursed within 7 business days by direct deposit (FORM-HR-022 Direct Deposit and Tax Withholding Update).

## 4. Form fields

| Field | Required | Notes |
| --- | --- | --- |
| Name, employee ID, cost centre | Yes | Pre-filled |
| Trip or event name and dates | Yes | |
| Expense date and category | Yes | Air, hotel, meals, mileage, ground transport, client entertainment, other |
| Amount and currency (CAD or USD) | Yes | |
| Paid by | Yes | Corporate card or personal funds; card items are not reimbursed |
| Receipt attached | Over $25 | Required for every expense over $25 |
| Business purpose | Yes | |
| Client or guest names and organizations | For client expenses | Gifts given must be modest and accurately recorded (HR-POL-001 Code of Conduct and Ethics) |
| Kilometres or miles and route | For mileage | |
| Pre-approval reference | For air above economy, alcohol, over-limit items | |

## 5. Declarations and signatures

I certify that these expenses were incurred for Bank business, that they are accurate, and that I have not claimed them elsewhere. I understand that falsifying an expense is serious misconduct. Signature and date: ____________. Manager approval and date: ____________. Director approval, if over $2,500: ____________.

## 6. What happens next

Your manager approves or returns the report with comments. Payroll Services then pays it by direct deposit. A report submitted more than 30 days after an expense needs Director approval, and a claim more than 90 days after an expense is reimbursed only with SVP Total Rewards approval. Gifts or entertainment received must be disclosed separately (FORM-HR-101 Gift and Entertainment Disclosure).

## 7. Related documents

- HR-POL-038 Business Travel and Expense Policy
- FORM-HR-101 Gift and Entertainment Disclosure
- HR-POL-009 Compensation and Payroll Policy

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-12-01 | Added meal, hotel and mileage limits and the Director threshold. |
| 1.0 | 2022-03-01 | Initial form. |
