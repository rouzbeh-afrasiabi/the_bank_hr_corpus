# HR Business Partner I

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1047 |
| Title | HR Business Partner I |
| Document type | Job description |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-08-12 |
| Next review | 2027-08-12 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-004, HR-GDE-006, HR-FWK-001, HR-FWK-003, HR-POL-002, HR-POL-013 |

## 1. Role summary

The HR Business Partner I (HRBP I) is the HR advisor to a department or smaller business unit and a Tier 3 resource for complex people matters. The HRBP I translates the business plan into workforce actions: organization design, engagement, talent and performance. The role is Band 5 (Team Lead / Manager I): it is accountable for team results and day-to-day operations of the HR service in its area. See HR-GDE-006 Job Architecture and Pay Bands Guide.

## 2. Key responsibilities

- Advise business leaders on workforce planning, hiring needs, structure and role design.
- Approve, as HRBP, steps required by policy: performance improvement plans before the meeting (HR-POL-013 Performance Improvement Policy), exception days above 12 under HR-POL-002 Remote and Hybrid Work Policy and offers above the midpoint with Total Rewards.
- Handle Tier 3 cases from the HR Case Portal within the 10 business day target in HR-GDE-004 HR Service and Support Guide.
- Review rating-dispute requests received within 10 business days of a rating and decide with the manager's manager within 15 business days.
- Run the talent review for the business unit: 9-box discussions between 15 January and 28 February and succession slates, as described in HR-FWK-003 Talent Review and Succession Process.
- Support managers through calibration (11 December to 10 January) with data and rating-distribution guidance.
- Interpret engagement survey results and help leaders write action plans by 31 January.
- Partner with Employee Relations on conduct matters and with Total Rewards on pay questions.
- Support restructuring, including termination meetings: attend as HRBP and arrange Corporate Security standby when needed.
- Coach managers and develop the HR Generalist in the assigned unit.
- Use HR analytics to spot turnover, absence and equity trends and recommend action.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in human resources, business, psychology or a related field.
- Seven to ten years of HR experience, with at least 3 years in a business-partnering or generalist role.
- Strong knowledge of employment law in Canada and the US, performance management and organizational effectiveness.
- Ability to influence leaders and handle confidential, sensitive matters.

### 3.2 Preferred

- A recognized HR designation and a master's degree.
- Experience supporting a business unit in a regulated financial institution.
- Experience leading a small team.

## 4. Competencies

Competency names follow HR-FWK-001 Competency and Leadership Model (Leader level, Bands 5 to 6).

- Collaboration
- Judgement and Decision Quality
- Inclusive Leadership
- Developing Others
- Drive for Results
- Adaptability

## 5. Compensation and classification

| Item | Detail |
| --- | --- |
| Band | 5 (Team Lead / Manager I) |
| Canada range | $90,000 to $134,000 CAD per year |
| US range | $88,000 to $132,000 USD per year |
| Incentive target | 10% of base salary (Annual Incentive Plan) |
| Overtime eligibility, Canada | No |
| FLSA classification, US | Exempt |
| Work arrangement | Hybrid |

## 6. Working conditions and accessibility

Office-based and hybrid by default, with at least 3 days a week in the office; Tuesday and Thursday are anchor days (HR-POL-002 Remote and Hybrid Work Policy; FORM-HR-030). Travel to supported sites is expected. The role handles sensitive personal information. The Bank provides accommodation to the point of undue hardship (HR-POL-018 Workplace Accommodation and Accessibility Policy).

## 7. Reporting line

Reports to the Senior Manager, HR Business Partnering. Direct reports may include an HR Generalist.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-03-01 | Pay band aligned with the 2026 pay bands; Tier 3 service level added |
| 1.0 | 2025-01-01 | First issue |
