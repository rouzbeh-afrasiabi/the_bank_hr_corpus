# Portfolio Manager

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1017 |
| Title | Portfolio Manager |
| Document type | Job description |
| Version | 1.1 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-09-22 |
| Next review | 2027-09-22 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-POL-029, HR-POL-032, HR-POL-033, HR-POL-018 |

## 1. Role summary

The Portfolio Manager makes discretionary investment decisions for client portfolios managed by Wealth Management. The role designs and implements investment strategies in line with each mandate, manages risk, monitors performance against benchmarks and objectives, and explains outcomes to clients and advisors. The Portfolio Manager is a fiduciary with responsibility to act in clients' best interests, and is held to strict conduct, trading and record-keeping standards. This is a Band 6 (Manager II / Senior Manager) role in the Wealth Management family; see HR-GDE-006 Job Architecture and Pay Bands Guide.

## 2. Key responsibilities

- Manage discretionary portfolios in accordance with investment policy statements, mandates and risk limits.
- Research and select securities and funds, with documented rationale for each investment decision.
- Set strategic and tactical asset allocation, and rebalance portfolios as markets and client circumstances change.
- Monitor risk, liquidity, concentration and compliance limits, and report breaches to Compliance immediately.
- Review performance against benchmarks with the Director, Wealth Management and the investment committee.
- Meet clients and Wealth Advisors to explain strategy, results and market conditions in plain language.
- Place trades with approved counterparties, ensuring best execution and complete trade records.
- Follow personal trading pre-clearance, restricted lists and holdings disclosure under HR-POL-032 Personal Trading and Restricted Lists Policy.
- Safeguard material non-public information and respect information barriers between business units.
- Mentor junior analysts and contribute to the team's research and investment process.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in finance, economics, business or a related field.
- Nine to thirteen years of investment management, portfolio management or equity or fixed-income research experience.
- Demonstrated ability to manage portfolios with disciplined risk control.
- Strong quantitative, analytical and communication skills.
- Ability to obtain and maintain the registrations below.

### 3.2 Preferred

- CFA charter.
- Master's degree in finance or an MBA.
- Fluency in English and French.

### 3.3 Licences and certifications

Under HR-POL-029 Licensing, Registration and Qualification Policy, the Portfolio Manager in Canada holds the securities registrations the role requires. In the US, the role holds the Series registrations needed (such as Series 7, 63 and 65 or 66). No licensed duties may be performed until the registration is active. The annual licence review is each 1 September. A registration lapse removes the employee from licensed duties immediately.

## 4. Competencies

Competencies are defined in HR-FWK-001 Competency and Leadership Model; this role works at the Leader level.

- **Judgement and Decision Quality**: makes disciplined investment decisions under uncertainty.
- **Risk and Conduct Awareness**: protects clients through fiduciary conduct and strict trading rules.
- **Drive for Results**: delivers risk-adjusted performance against mandate objectives.
- **Customer Obsession**: keeps client objectives central to every portfolio decision.
- **Developing Others**: develops junior analysts' investment skills.
- **Adaptability**: updates the investment view as markets and regulation change.

## 5. Compensation and classification

| Item | Detail |
| --- | --- |
| Band | 6 (Manager II / Senior Manager) |
| Canada salary range | $112,000 to $168,000 CAD per year |
| US salary range | $110,000 to $166,000 USD per year |
| Incentive target | Annual Incentive Plan (AIP): 15% of base salary |
| Overtime eligibility (Canada) | No |
| FLSA classification (US) | Exempt |
| Work arrangement | Hybrid: at least 3 days a week in the office |

## 6. Working conditions and accessibility

This is a hybrid office role. Trade-related communications are recorded and retained as disclosed in HR-POL-033 Electronic Monitoring and Right to Disconnect Policy, and the role is a covered person under the Bank's personal trading rules. Hybrid arrangements follow HR-POL-002 Remote and Hybrid Work Policy, with at least 3 days a week in the office and anchor days on Tuesday and Thursday. The Bank provides accommodation to the point of undue hardship (Canada) or reasonable accommodation (US); see HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to the Director, Wealth Management.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.1 | 2026-01-01 | Pay ranges updated to the 2026 pay bands; added recording and trading disclosures |
| 1.0 | 2025-03-03 | First issue |
