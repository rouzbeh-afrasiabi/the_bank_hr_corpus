# Pay Ranges in Every Job Posting and Open Pay Conversations

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-MEMO-2026-001 |
| Title | Pay Ranges in Every Job Posting and Open Pay Conversations |
| Document type | Memo |
| Version | 1.0 |
| Status | Current |
| Effective date | 2026-01-12 |
| Last reviewed | Not applicable |
| Next review | Not applicable |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-037, HR-GDE-006, HR-POL-019, HR-POL-009 |

**Pay is transparent: ranges in every posting, and you may talk about your pay.**

**From:** SVP Total Rewards

**To:** All employees and people managers in Canada and the US

**Date:** 12 January 2026

**Subject:** HR-POL-037 Pay Transparency Policy, version 1.2, effective today

## 1. What is changing

Every internal and external job posting now shows the pay range: the minimum and maximum of the band range for the role's jurisdiction. Employees may discuss and disclose their own pay. There is no pay-secrecy rule, and the Bank does not ask candidates for salary history.

## 2. Who is affected

All employees, hiring managers, recruiters and candidates.

## 3. Effective date

12 January 2026.

## 4. What to do

1. Hiring managers: confirm the range on each requisition in line with HR-POL-019 Recruitment and Selection Policy before posting.
2. Recruiters: show the range to a candidate on request before the first interview.
3. Employees: see the range for your own band in MyHR. Band definitions are in HR-GDE-006 Job Architecture and Pay Bands Guide.
4. Managers: never discourage or penalize pay discussions.

## 5. Who to call

HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, or live chat in MyHR. Managers: Manager Hotline 1-800-555-0143.

## 6. Related documents

- HR-POL-037 Pay Transparency Policy
- HR-GDE-006 Job Architecture and Pay Bands Guide
- HR-POL-009 Compensation and Payroll Policy
