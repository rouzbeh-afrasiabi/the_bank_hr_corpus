# How to book your volunteer day

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-035 |
| Title | How to book your volunteer day |
| Document type | How-to article |
| Version | 1.1 |
| Status | Current |
| Effective date | 2025-12-01 |
| Last reviewed | 2026-09-15 |
| Next review | 2027-09-15 |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-026, HR-POL-001, FORM-HR-102, HR-POL-006 |

## 1. Short answer

Request your 1 paid volunteer day in Time Tracker at least 10 business days ahead, naming an approved organization; it does not carry over into the next calendar year.

## 2. Who this applies to

Regular full-time, regular part-time and fixed-term employees in Canada and the US, from the first day of employment. Each person gets 1 paid day per calendar year, in both countries. Casual employees receive the leaves required by law. Where applicable law gives a greater right, the law applies.

## 3. Steps

1. **Pick an approved organization.** It must be a registered charity or a non-profit organization. Political campaigns and for-profit activities do not qualify.
2. **Choose the date** and make sure it is at least 10 business days away.
3. **Submit the request** in MyHR > Time and Absence (Time Tracker) under the volunteer leave type, naming the organization and the date.
4. **Confirm coverage** with your manager so your work is covered.
5. **Take the day** and volunteer. If your plans change, ask your manager to cancel it in Time Tracker, so the day stays in your balance for the year.

## 4. Deadlines

| Item | Rule |
| --- | --- |
| Request | At least 10 business days ahead |
| Manager decision | Within 5 business days |
| Use by | 31 December of the calendar year; no carryover |

## 5. What happens next

Your manager approves within 5 business days, and the day is paid as a normal day. It does not use any vacation, personal or sick days, and it is a protected absence that never counts in an attendance review (see HR-POL-004 Attendance and Absenteeism Policy). If your manager is unsure whether the organization qualifies, the Leaves team can confirm.

## 6. Common mistakes

- Requesting fewer than 10 business days ahead.
- Choosing a political campaign or a for-profit activity.
- Planning to carry the day into next year.
- Assuming you need ethics approval: charitable or community volunteering needs no approval under HR-POL-001 Code of Conduct and Ethics, unless you will handle money or hold a director or officer role, in which case submit FORM-HR-102.
- Treating the day as vacation. It is separate from your vacation entitlement.

## 7. Who to call

Your manager first. HR Connect, 1-800-555-0142 (Monday to Friday 8:00 to 20:00 Eastern Time), hrconnect@bank.example, for the Leaves team. Managers: Manager Hotline, 1-800-555-0143.

## 8. Related documents

- HR-POL-026 Bereavement, Jury Duty and Other Leaves Policy
- HR-POL-001 Code of Conduct and Ethics
- HR-POL-006 Vacation and Paid Time Off Policy

## 9. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.1 | 2025-12-01 | Aligned with HR-POL-026 version 2.1. |
| 1.0 | 2025-01-01 | First issue. |
