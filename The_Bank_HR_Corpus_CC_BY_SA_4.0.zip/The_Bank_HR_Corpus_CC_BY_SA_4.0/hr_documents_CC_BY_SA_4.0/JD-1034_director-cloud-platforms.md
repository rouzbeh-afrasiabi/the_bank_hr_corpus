# Director, Cloud Platforms

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1034 |
| Title | Director, Cloud Platforms |
| Document type | Job description |
| Version | 1.1 |
| Status | Current |
| Effective date | 2026-01-05 |
| Last reviewed | 2026-10-13 |
| Next review | 2027-10-13 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-POL-002, HR-POL-031, HR-PLN-003 |

## 1. Role summary

The Director, Cloud Platforms leads the function that provides the Bank's cloud, platform engineering and infrastructure services to all business units. The role shapes cloud strategy, architecture and budget, ensures the platforms are secure, resilient and cost-efficient and leads a large organization of managers and engineers. The Director is accountable for service levels and for the Bank's regulatory and risk obligations on technology resilience and third-party cloud providers.

## 2. Key responsibilities

- Set the multi-year cloud and platform strategy and roadmap with the Vice President, Technology.
- Own the function's budget, cost management and vendor relationships with cloud and infrastructure providers.
- Lead Senior Managers and their teams, and build succession and diverse talent pipelines.
- Establish platform standards for security, resilience, observability and automation.
- Make sure the platforms meet regulatory expectations on operational resilience, outsourcing and data location, including those of OSFI.
- Oversee major incident response and ensure high-quality post-incident reviews and remediation.
- Partner with business unit technology leaders to onboard applications and migrate workloads safely.
- Govern architecture and risk decisions; approve exceptions to platform standards.
- Report service performance, risks and cost to senior executives and governance committees.
- Represent the function in enterprise planning, audit and regulatory discussions.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in computer science, engineering or a related field; advanced degree an asset.
- Typically 12 to 16 years of technology experience, including at least 5 years leading large engineering or infrastructure teams.
- Deep experience designing and operating enterprise cloud platforms at scale.
- Proven ability to manage large budgets, vendors and regulated-environment risk.

### 3.2 Preferred

- Experience migrating a regulated institution's workloads to public cloud.
- Cloud architecture or security certification.
- Completion of a Bank leadership program for Band 5 and above.

### 3.3 Licences and certifications

None required.

## 4. Competencies

Measured against HR-FWK-001 Competency and Leadership Model at the Enterprise Leader level:

- Judgement and Decision Quality
- Drive for Results
- Risk and Conduct Awareness
- Inclusive Leadership
- Developing Others
- Collaboration
- Adaptability

## 5. Compensation and classification

| Item | Value |
| --- | --- |
| Band | 7 (Director) |
| Canada range | $140,000 to $210,000 CAD |
| US range | $138,000 to $206,000 USD |
| Incentive target | 20% of base salary (Annual Incentive Plan) |
| Overtime eligibility, Canada | No |
| FLSA classification, US | Exempt |
| Work arrangement | Hybrid (at least 3 days a week in the office) |

Band 7 roles are subject to deferral of 40% of an Annual Incentive Plan payout above $100,000 and to clawback under HR-POL-031 Incentive Deferral and Clawback Policy, and are eligible for the Long-Term Incentive Plan at 25% of base salary (HR-PLN-003 Long-Term Incentive Plan Document). Band definitions are in HR-GDE-006 Job Architecture and Pay Bands Guide.

## 6. Working conditions and accessibility

This is an office role with a hybrid arrangement under HR-POL-002 Remote and Hybrid Work Policy: at least 3 days a week in the office, including the Tuesday and Thursday anchor days. Occasional travel to other Bank sites and to supplier locations is expected, and the Director may be required during major incidents. The Bank provides accommodation to the point of undue hardship; see HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to: Vice President, Technology. Direct reports: Senior Managers, Technology Delivery and other managers in the cloud and platform organization.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.1 | 2026-01-05 | Added deferral, clawback and long-term incentive references |
| 1.0 | 2024-03-01 | First issue |
