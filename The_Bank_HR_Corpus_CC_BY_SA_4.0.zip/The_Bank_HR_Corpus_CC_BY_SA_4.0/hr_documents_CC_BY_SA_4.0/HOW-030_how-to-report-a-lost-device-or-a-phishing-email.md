# How to report a lost device or a phishing email

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-030 |
| Title | How to report a lost device or a phishing email |
| Document type | How-to article |
| Version | 1.1 |
| Status | Current |
| Effective date | 2026-04-01 |
| Last reviewed | 2026-10-12 |
| Next review | 2027-10-12 |
| Policy owner | Chief Information Security Officer |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-017, HR-POL-016, HR-POL-001 |

## 1. Short answer

Click the Report Phishing button for a suspicious email, and report a lost or stolen device, a phishing click or any suspected incident to the Security Operations Centre (SOC) immediately and no later than 1 hour after you discover it.

## 2. Who this applies to

All employees in Canada and the US, and contractors, agency workers, students and interns who use Bank systems, at the office, at home or while travelling. It covers Bank-issued devices and any personal phone enrolled in mobile device management.

## 3. Steps

### 3.1 Phishing email

1. Do not click links, open attachments or reply.
2. Select the **Report Phishing** button in your email. This is enough for an email you did not open.
3. If you clicked, opened an attachment, entered a password or approved a multi-factor authentication prompt you did not start, also call the SOC straight away.
4. Verify unusual payment or data requests by phone using a known number.

### 3.2 Lost or stolen device

1. Call the SOC at 1-800-555-0155 (24/7) or email soc@bank.example, with the device type, when and where it went missing, and what it held.
2. Do not wait to look for it first, and do not delete anything.
3. If employee or client personal information may be involved, also notify the Privacy Office at privacy@bank.example within 24 hours.
4. Tell your manager. Travelling? Say where you are.

## 4. Deadlines

| Event | Deadline |
| --- | --- |
| Lost device, phishing click, malware, data sent to the wrong person | Immediately, and no later than 1 hour after discovery (SOC) |
| Incident involving personal information | Privacy Office within 24 hours |
| Unopened phishing email | Report Phishing button immediately |

## 5. What happens next

The SOC contains the incident, and on an enrolled phone the Bank can remove its data. The Privacy Office decides whether regulators or individuals must be notified. Reporting in good faith never leads to discipline by itself. Phishing simulations run quarterly, and 3 failures in 12 months lead to remedial training in the Learning Hub (MyHR > Career and Learning); failing a simulation is not misconduct, but ignoring the training is.

## 6. Common mistakes

- Waiting to see whether the device turns up.
- Reporting to your manager only; the SOC must hear within 1 hour.
- Deleting the email or investigating yourself.
- Forgetting the Privacy Office when personal information is involved.

## 7. Who to call

Security Operations Centre, 1-800-555-0155, soc@bank.example (24/7). Privacy Office, privacy@bank.example. If the loss is a theft with a threat to anyone's safety, call 911 first, then Corporate Security, 1-800-555-0119. HR Connect, 1-800-555-0142, for other questions.

## 8. Related documents

- HR-POL-017 IT Acceptable Use and Information Security Policy
- HR-POL-016 Employee Data Privacy Policy
- HR-POL-001 Code of Conduct and Ethics

## 9. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.1 | 2026-04-01 | Aligned with HR-POL-017 version 8.1. |
| 1.0 | 2025-01-01 | First issue. |
