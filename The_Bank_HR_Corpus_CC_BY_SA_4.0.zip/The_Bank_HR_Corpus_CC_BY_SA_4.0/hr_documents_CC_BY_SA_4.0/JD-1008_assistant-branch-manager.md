# Assistant Branch Manager

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1008 |
| Title | Assistant Branch Manager |
| Document type | Job description |
| Version | 1.1 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-09-14 |
| Next review | 2027-09-14 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-SUP-004, HR-POL-011, HR-POL-018 |

## 1. Role summary

The Assistant Branch Manager supports the Branch Manager in running a safe, compliant and customer-focused branch. The role leads the daily operation of the teller and service teams, manages schedules and cash controls, and acts as the Branch Manager's delegate when they are away. The Assistant Branch Manager is accountable for day-to-day branch operations and for the performance and development of the front-line team. This is a Band 5 (Team Lead / Manager I) role in the Retail Banking family; see HR-GDE-006 Job Architecture and Pay Bands Guide.

## 2. Key responsibilities

- Lead the daily opening, closing, cash and vault procedures, including dual control and surprise cash counts.
- Build and post compliant staff schedules at least 14 days ahead, as set out in HR-SUP-004 Branch Operations Scheduling Supplement.
- Coach tellers, Financial Services Representatives and advisors, and run daily huddles.
- Conduct goal-setting, check-ins and feedback conversations for assigned employees under HR-POL-011 Performance Management Policy.
- Resolve customer escalations and complaints and review service quality and queue times.
- Monitor branch controls and audit findings, and close actions on time.
- Review and approve routine exceptions within delegated authority and escalate beyond it.
- Lead the response to incidents such as robbery, fire alarm and severe weather, following branch emergency procedures.
- Support recruitment, onboarding and training of new branch employees.
- Act for the Branch Manager during planned absences and contribute to branch business planning.

## 3. Qualifications

### 3.1 Required

- Post-secondary education in business or a related field, or equivalent experience.
- Seven to ten years of retail banking experience, including supervising or leading a team.
- Thorough knowledge of branch operations, cash controls and fraud prevention.
- Strong coaching, scheduling and conflict-resolution skills.
- Satisfactory results in pre-employment screening, including re-screening for roles with financial authority.

### 3.2 Preferred

- Experience as a Senior Personal Banking Advisor or Financial Services Representative.
- Completion of a Bank leadership program.
- Fluency in English and French.

### 3.3 Licences and certifications

No licence is required. Where the Assistant Branch Manager supervises licensed advisors, a working understanding of HR-POL-029 Licensing, Registration and Qualification Policy is expected.

## 4. Competencies

Competencies are defined in HR-FWK-001 Competency and Leadership Model; this role works at the Leader level.

- **Developing Others**: coaches and develops front-line colleagues.
- **Risk and Conduct Awareness**: enforces cash, fraud and conduct controls.
- **Customer Obsession**: sets the standard for service in the branch.
- **Drive for Results**: delivers branch operating and service goals.
- **Inclusive Leadership**: builds a welcoming team and treats colleagues and customers fairly.
- **Judgement and Decision Quality**: acts decisively on exceptions and incidents.

## 5. Compensation and classification

| Item | Detail |
| --- | --- |
| Band | 5 (Team Lead / Manager I) |
| Canada salary range | $90,000 to $134,000 CAD per year |
| US salary range | $88,000 to $132,000 USD per year |
| Incentive target | Annual Incentive Plan (AIP): 10% of base salary |
| Overtime eligibility (Canada) | No |
| FLSA classification (US) | Exempt |
| Work arrangement | On-site at the assigned branch |

## 6. Working conditions and accessibility

This is an on-site role in a branch, with an opening or closing responsibility on a rota and some Saturday work. The role may be called out for alarms and incidents. The Bank provides accommodation to the point of undue hardship (Canada) or reasonable accommodation (US); see HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to the Branch Manager.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.1 | 2026-03-01 | Pay ranges updated to the 2026 pay bands |
| 1.0 | 2025-04-01 | First issue |
