# Annual Incentive Plan Document

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-PLN-001 |
| Title | Annual Incentive Plan Document |
| Document type | Plan document |
| Version | 2026.1 |
| Status | Current |
| Effective date | 2025-11-01 |
| Last reviewed | 2026-09-30 |
| Next review | 2027-09-30 |
| Policy owner | SVP Total Rewards |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-009, HR-POL-011, HR-POL-031, HR-GDE-006, HR-POL-008, HR-POL-014, HR-PLN-002, HR-PLN-003 |

## 1. Purpose and status of this document

1.1 This document sets out the formal terms of the Bank's Annual Incentive Plan (the "Plan"). The Plan rewards employees for the Bank's results and for their own individual performance in a fiscal year.

1.2 This version applies to fiscal 2026, the fiscal year from 1 November 2025 to 31 October 2026. The payroll mechanics of the Plan are summarised in HR-POL-009 Compensation and Payroll Policy; where this document and HR-POL-009 describe the same rule, they are intended to say the same thing, and the target percentages, formula and multipliers below are identical to those in HR-POL-009 and HR-GDE-006 Job Architecture and Pay Bands Guide.

1.3 Employees in the roles covered by HR-PLN-002 Advisor and Sales Incentive Plan Document are paid under that plan and not under this Plan for the period of coverage. Where applicable law gives a greater right, the law applies.

## 2. Definitions

| Term | Meaning |
| --- | --- |
| Base salary earned | Base salary actually earned in the fiscal year, excluding incentive pay, overtime, premiums and allowances. It already reflects pro-ration for approved unpaid leave and for part-time schedules. |
| Business funding factor | A number from 0 to 1.5 set by the Board HR Committee after year-end results. |
| Fiscal year | 1 November to 31 October; also the performance year. |
| Individual multiplier | The number linked to the year-end rating under HR-POL-011 Performance Management Policy (section 10.1). |
| Payment date | The first pay date in February after the fiscal year ends. |
| Target award | Base salary earned multiplied by the target percentage for the band. |
| Band | The job band from 1 to 9 under HR-GDE-006. |

## 3. Eligibility

3.1 **Conditions.** To receive a payout an employee must:

- (a) have been hired on or before 31 July of the fiscal year;
- (b) be on payroll on 31 October and on the payment date; and
- (c) not have a last rating of Unsatisfactory.

3.2 **Employment categories.** Eligibility follows HR-POL-014 Employment Status and Classification Policy.

| Category | Participation |
| --- | --- |
| Regular full-time | Eligible |
| Regular part-time | Eligible, pro-rated (base salary earned reflects the schedule) |
| Fixed-term, 6 months or more | Eligible, pro-rated |
| Fixed-term, under 6 months; casual; student, co-op and intern | Not eligible |
| Contractors and agency workers | Not employees; not eligible |

3.3 **Mandatory training.** Completing mandatory training is a condition of good standing. Training that is 30 days overdue can affect AIP eligibility (see HR-POL-012 Learning and Development Policy).

3.4 Employees hired after 31 July are not eligible for that fiscal year and are first eligible for the following fiscal year.

## 4. Target awards

4.1 The target percentage is applied to base salary earned and is set by band. It does not vary by country.

| Band | Level title | Target (% of base salary earned) |
| --- | --- | --- |
| 1 | Associate Support | 5% |
| 2 | Associate | 5% |
| 3 | Professional | 5% |
| 4 | Senior Professional | 8% |
| 5 | Team Lead / Manager I | 10% |
| 6 | Manager II / Senior Manager | 15% |
| 7 | Director | 20% |
| 8 | Senior Director / Vice President | 30% |
| 9 | Senior Vice President | 45% |

4.2 If an employee's band changes during the fiscal year, the target percentage for each band is applied to the base salary earned while in that band. Promotions and transfers are handled separately and are not described in this document.

## 5. Funding and individual multipliers

5.1 **Business funding factor.** After year-end results are known, the Board HR Committee sets the business funding factor between 0 and 1.5. A factor below 1.0 reduces every payout; a factor above 1.0 increases it. The factor is communicated to employees before the payment date.

5.2 **Individual multiplier.**

| Year-end rating | Multiplier |
| --- | --- |
| 1 Outstanding | 1.5 |
| 2 Exceeds Expectations | 1.2 |
| 3 Meets Expectations | 1.0 |
| 4 Needs Improvement | 0.5 |
| 5 Unsatisfactory | 0 |

## 6. Calculation and worked examples

6.1 **Formula.** Payout = base salary earned x target % x business funding factor x individual multiplier.

6.2 **Example A (Band 4, Exceeds Expectations).** Base salary earned $90,000; target 8%; funding factor 1.1; rating Exceeds Expectations (1.2). Payout = 90,000 x 0.08 x 1.1 x 1.2 = **$9,504**.

6.3 **Example B (Band 6, Outstanding and Unsatisfactory).** Two employees in Band 6, each with base salary earned of $140,000 CAD. The target is 15%, so the target award is $21,000. The funding factor is 1.2.

| Employee | Rating | Multiplier | Calculation | Payout |
| --- | --- | --- | --- | --- |
| Employee 1 | Outstanding | 1.5 | 140,000 x 0.15 x 1.2 x 1.5 | $37,800 |
| Employee 2 | Unsatisfactory | 0 | 140,000 x 0.15 x 1.2 x 0 | $0 |

Employee 2 is also ineligible under section 3.1(c) because the last rating is Unsatisfactory.

6.4 **Example C (deferral).** A Band 8 employee has base salary earned of $225,000, a 30% target ($67,500), a funding factor of 1.2 and a rating of Outstanding: 67,500 x 1.2 x 1.5 = $121,500. Because the payout is above $100,000, 40% ($48,600) is deferred under HR-POL-031 Incentive Deferral and Clawback Policy and $72,900 is paid on the payment date. The deferred amount vests in three equal parts of $16,200.

6.5 Amounts are rounded to the nearest dollar in the currency of pay (CAD in Canada, USD in the US).

## 7. Payment

7.1 The payout is paid through payroll on the payment date. For fiscal 2025 that date was 2026-02-05 in Canada and 2026-02-06 in the US.

7.2 The payout is subject to statutory deductions. Incentive pay is not matched under the retirement plans (see HR-GDE-002 Retirement and Savings Plan Guide).

7.3 **Deferral.** Employees in Band 7 and above, and Designated Material Risk Takers, are subject to deferral where the payout is above $100,000. Bands 7 and 8 defer 40%; Band 9 and Material Risk Takers defer 50%. Deferred amounts are delivered in share units and vest equally over 3 years. The full rules are in HR-POL-031.

## 8. Leave and changes in pay

8.1 Approved unpaid leave reduces base salary earned and therefore the payout in proportion.

8.2 Bank-paid parental leave counts as earned salary (see HR-POL-008 Parental and Family Leave Policy). Other Bank-paid leave counts as earned salary at the rate paid.

8.3 An employee on leave is rated on the period worked under HR-POL-011.

## 9. Termination of employment

| Reason employment ends | Treatment |
| --- | --- |
| Resignation, or termination for cause, before the payment date | Payout forfeited. |
| Retirement (age 55 with 10 years of service) | Payout is paid on the payment date, calculated on base salary earned to the retirement date, using the year-end rating if one has been assigned and otherwise a multiplier of 1.0. |
| Death | Paid to the estate on the same basis as retirement. |
| Involuntary termination without cause | If the employee was on payroll on 31 October, the payout is pro-rated for the part of the year worked and paid on the payment date. Otherwise forfeited. |

9.1 Severance entitlements are set by HR-POL-025 Involuntary Termination and Severance Policy; the Plan does not extend notice periods for the purpose of earning a payout.

9.2 Final pay rules and the forfeiture of AIP by voluntary leavers before the payment date are also described in HR-POL-015 Resignation and Offboarding Policy.

## 10. Clawback and malus

10.1 For employees within the scope of HR-POL-031 (Band 7 and above, and Designated Material Risk Takers), paid incentives may be recovered, and unvested deferred amounts reduced, under HR-POL-031: recovery is possible for up to 3 years after payment (5 years for Material Risk Takers) for misconduct, a material misstatement or a material risk-management failure. The Board HR Committee decides on the recommendation of the CHRO, after written notice and 15 business days for the employee to respond.

10.2 Overpayments caused by a calculation error are recovered under HR-POL-009 section 8.2.

## 11. Administration and discretion

11.1 The SVP Total Rewards administers the Plan day to day. The Board HR Committee approves the funding factor and has final authority over the Plan.

11.2 The Bank may, in exceptional circumstances and with the approval of the Board HR Committee, reduce or withhold an individual payout where a payout would be inconsistent with risk, conduct or financial-soundness outcomes. The Plan is discretionary and does not create a guaranteed entitlement or a contract of employment for any period.

11.3 Questions about a calculation are raised through the HR Case Portal. A rating dispute follows HR-POL-011 section 12 and does not delay payment; any correction is paid on the next regular pay date.

## 12. Amendment and termination of the Plan

12.1 The Bank may amend, suspend or end the Plan for a future fiscal year at any time, with notice to participants. A change that affects a fiscal year already under way requires the approval of the HR Policy Committee and the Board HR Committee and does not reduce amounts already earned under the Plan terms in force at the start of that year, except as section 10 permits.

12.2 Interpretation of the Plan is by the SVP Total Rewards, whose decision may be reviewed by the CHRO.

## 13. Related documents and contacts

HR-POL-009 Compensation and Payroll Policy; HR-POL-011 Performance Management Policy; HR-POL-031 Incentive Deferral and Clawback Policy; HR-GDE-006 Job Architecture and Pay Bands Guide; HR-PLN-002 Advisor and Sales Incentive Plan Document; HR-PLN-003 Long-Term Incentive Plan Document. Questions: HR Connect, 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time, hrconnect@bank.example, or live chat in MyHR.

## 14. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2026.1 | 2025-11-01 | Re-issued for fiscal 2026; added worked examples, deferral cross-reference and termination table. |
| 2025.1 | 2024-11-01 | Re-issued for fiscal 2025. |
