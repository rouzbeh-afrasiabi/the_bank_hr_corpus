# Teller

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1001 |
| Title | Teller |
| Document type | Job description |
| Version | 3.0 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-09-14 |
| Next review | 2027-09-14 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-SUP-004, HR-POL-018 |

## 1. Role summary

The Teller is the first face of the Bank for most branch customers. The role processes everyday cash and cheque transactions accurately, protects the Bank and its customers from fraud and loss, and introduces customers to the digital and advice services that suit their needs. The Teller works under close guidance from the Branch Manager and follows set procedures for cash handling, identity verification and balancing. This is a Band 1 (Associate Support) role in the Retail Banking family; see HR-GDE-006 Job Architecture and Pay Bands Guide.

## 2. Key responsibilities

- Process deposits, withdrawals, cash and cheque cashing, bill payments, foreign currency exchange and bank draft requests.
- Verify customer identity and the authenticity of cheques, bills and documents, and record transactions completely and accurately.
- Follow dual-control procedures for cash and vault access as set out in HR-SUP-004 Branch Operations Scheduling Supplement.
- Balance the cash drawer at the end of each shift and report any variance to the Branch Manager the same day.
- Recognize and escalate unusual or suspicious activity under the Bank's anti-money-laundering and sanctions procedures.
- Follow the branch robbery protocol and emergency procedures described in HR-POL-023 Workplace Health, Safety and Wellness Policy.
- Help customers enrol in online and mobile banking and use branch self-service equipment.
- Refer customers to a Personal Banking Advisor or Financial Services Representative when a need for advice is identified.
- Keep the teller line, counter and customer area tidy and compliant with the brand and uniform guidelines.
- Complete all mandatory Learning Hub training within the required windows.

## 3. Qualifications

### 3.1 Required

- High school diploma or equivalent.
- Comfort handling cash and using a computer-based teller system with a high degree of accuracy.
- Clear verbal communication and a courteous, calm manner with customers.
- Ability to stand for most of a shift and to work a posted schedule that may include Saturdays.
- Satisfactory results in pre-employment screening (HR-POL-020 Pre-Employment Screening Policy).

### 3.2 Preferred

- Six months or more of cash-handling or customer-facing retail experience.
- Ability to serve customers in both English and French, or in another community language.
- Completed or in-progress post-secondary courses in business or finance.

### 3.3 Licences and certifications

No licence is required. Employees who later move into licensed advisory roles follow HR-POL-029 Licensing, Registration and Qualification Policy.

## 4. Competencies

Competencies are defined in HR-FWK-001 Competency and Leadership Model; this role works at the Foundation level.

- **Customer Obsession**: serves each customer quickly, respectfully and accurately.
- **Risk and Conduct Awareness**: follows cash, fraud and anti-money-laundering controls without shortcuts.
- **Drive for Results**: keeps the line moving and meets accuracy and balancing standards.
- **Collaboration**: works with the branch team to cover the line and support colleagues.
- **Adaptability**: adjusts to changing volumes, procedures and technology.

## 5. Compensation and classification

| Item | Detail |
| --- | --- |
| Band | 1 (Associate Support) |
| Canada salary range | $38,000 to $54,000 CAD per year |
| US salary range | $36,000 to $52,000 USD per year |
| Incentive target | Annual Incentive Plan (AIP): 5% of base salary |
| Overtime eligibility (Canada) | Yes (non-managerial Band 1 to 4 role) |
| FLSA classification (US) | Non-exempt |
| Work arrangement | On-site at the assigned branch |

## 6. Working conditions and accessibility

This is an on-site, customer-facing role in a branch. Hours follow a posted schedule, and extended-hours branches may include evening shifts. The role involves extended standing, handling cash and operating counter equipment. The Bank provides uniforms under HR-POL-040 Dress Code Policy. The Bank is committed to an inclusive workplace and provides accommodation to the point of undue hardship (Canada) or reasonable accommodation (US); see HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to the Branch Manager.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 3.0 | 2026-03-01 | Pay ranges updated to the 2026 pay bands; competencies aligned to HR-FWK-001 v3.0 |
| 2.0 | 2025-01-01 | Added fraud and sanctions escalation duties |
| 1.0 | 2023-03-01 | First issue |
