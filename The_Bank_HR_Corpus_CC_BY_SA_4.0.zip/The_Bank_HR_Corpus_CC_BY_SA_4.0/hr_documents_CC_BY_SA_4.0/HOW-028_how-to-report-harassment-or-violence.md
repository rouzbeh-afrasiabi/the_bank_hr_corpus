# How to report harassment or violence

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-028 |
| Title | How to report harassment or violence |
| Document type | How-to article |
| Version | 1.1 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-07-08 |
| Next review | 2027-07-08 |
| Policy owner | VP Employee Relations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-005, FORM-HR-050, HR-POL-022, HOW-029 |

## 1. Short answer

Report to your manager, your HR Business Partner, Employee Relations through the HR Case Portal, the Speak-Up Line or Corporate Security, ideally on FORM-HR-050; if anyone is in immediate danger, call 911 first, then Corporate Security at 1-800-555-0119.

## 2. Who this applies to

All employees in Canada and the US, including managers, for conduct at work, in remote or hybrid settings, at events, on business travel and online. It also covers harassment or violence by customers, suppliers and visitors. Where applicable law gives a greater right, the law applies. You may also file with a human rights commission, the EEOC or another agency at any time.

## 3. Steps

1. **Get safe.** In immediate danger, call 911, then Corporate Security (24 hours).
2. **Write down the facts:** who, when, where, what happened, witnesses and any messages or images.
3. **Choose a channel.** You do not need to tell the person involved first. Anonymous reports go through the Speak-Up Line, 1-800-555-0177 (see HOW-029 How to use the Speak-Up Line).
4. **Submit FORM-HR-050** in MyHR > HR Case Portal, or give it to your manager or HRBP. A verbal report is also accepted and the designated recipient completes the form with you.
5. **Ask for interim measures** if you need them, such as a change of seating or schedule.

## 4. Deadlines and timeline

| Step | Timeline |
| --- | --- |
| First response (P1 urgent) | Within 4 business hours |
| Acknowledgement | Within 2 business days |
| Interim measures | Within 5 business days |
| Investigation | Completed within 60 calendar days |
| Written outcome to both parties | Within 10 business days after the report |
| Request for review | Within 10 business days of the outcome, to the VP Employee Relations |

There is no hard deadline to report, but complaints are encouraged within 12 months of the last incident.

## 5. What happens next

A trained, impartial investigator interviews you, the respondent and witnesses. You and the respondent may each bring a support person who is not legal counsel. Retaliation is prohibited; report it as a new complaint. Investigation files are kept for 10 years after closing. Managers who hear of a concern must refer it to Employee Relations the same business day.

## 6. Common mistakes

- Waiting because you think there is a deadline.
- Confronting the person first; you are not required to.
- Using the Ombuds Office for a formal complaint; it gives informal, confidential advice only.
- Making a knowingly false complaint; that is misconduct.

## 7. Who to call

Corporate Security, 1-800-555-0119 (24 hours). Speak-Up Line, 1-800-555-0177 (24 hours, anonymous option). HR Connect, 1-800-555-0142. Wellspring Support Program, 1-800-555-0166: up to 8 free counselling sessions per issue per calendar year.

## 8. Related documents

- HR-POL-005 Workplace Harassment and Violence Prevention Policy
- FORM-HR-050 Harassment and Violence Complaint Intake
- HR-POL-022 Whistleblower and Speak-Up Policy

## 9. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.1 | 2025-09-01 | Aligned with HR-POL-005 version 5.0. |
| 1.0 | 2025-01-01 | First issue. |
