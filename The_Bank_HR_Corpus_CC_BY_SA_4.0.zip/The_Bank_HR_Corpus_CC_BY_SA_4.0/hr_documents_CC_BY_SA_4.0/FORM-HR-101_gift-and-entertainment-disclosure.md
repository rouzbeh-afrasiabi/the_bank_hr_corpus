# Gift and Entertainment Disclosure

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-101 |
| Title | Gift and Entertainment Disclosure |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | Head of Ethics Office |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-001, HR-POL-022, FORM-HR-100, FORM-HR-127, HOW-032 |

## 1. Purpose and when to use this form

Use this form to ask for pre-approval of a gift or entertainment above the limits in HR-POL-001 Code of Conduct and Ethics, or to record a gift that arrived unannounced. You may accept a gift or entertainment of reasonable value without this form if all the following are true:

| Test | Limit |
| --- | --- |
| Value per occasion | Up to $100 |
| Cumulative value from one source | Up to $250 per calendar year |
| Form of gift | Never cash or cash equivalents, including gift cards |
| Source | Never from a regulator or public official |
| Business context | Not while the Bank is selecting a supplier or deciding on a transaction involving the source |

Amounts are in the currency of the country where you work (CAD or USD). Gifts and entertainment may never be given to public officials.

## 2. Who completes it and who approves

You complete it. The Ethics Office approves or declines. Your manager is informed.

## 3. Where and when to submit (deadline, channel, processing time)

Submit before you accept, in MyHR (Ethics > Gifts and Entertainment) or by email to ethics@bank.example. If an above-limit gift arrives unannounced, return it politely or hand it to the Ethics Office within 5 business days and submit this form.

## 4. Form fields

| Field | Required | Notes |
| --- | --- | --- |
| Name, employee ID, manager | Yes | Pre-filled |
| Received, offered or given | Yes | Received requests pre-approval; given gifts must be modest and recorded in an expense report (FORM-HR-127) |
| Giver or recipient and organization | Yes | A source includes its affiliates |
| Description and estimated value (CAD or USD) | Yes | Include meals, tickets, travel and services |
| Date of the occasion | Yes | |
| Total received from this source this calendar year | Yes | Checks the $250 cumulative limit |
| Business relationship and any pending decision | Yes | Supplier selection or transaction |
| Is the source a regulator or public official? | Yes | If Yes, it cannot be accepted |
| Business reason | Yes | |

## 5. Declarations and signatures

I confirm that the information is accurate, that I did not ask for the gift, that it is not cash or a gift card, and that it was not intended to influence a Bank decision. Signature and date: ____________.

## 6. What happens next

The Ethics Office replies in writing: approved, approved with conditions (for example sharing a gift with the team), or declined with instructions to return it. Records are reviewed at your annual attestation, due by 31 October. Failure to disclose may lead to action under HR-POL-021 Employee Relations and Progressive Discipline Policy. Concerns about improper offers can go to the Speak-Up Line (1-800-555-0177).

## 7. Related documents

- HR-POL-001 Code of Conduct and Ethics
- FORM-HR-100 Conflict of Interest Disclosure
- FORM-HR-127 Business Expense Report

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-01-01 | Added the cumulative cap per source and the 5-business-day return rule. |
| 1.0 | 2022-01-01 | Initial form. |
