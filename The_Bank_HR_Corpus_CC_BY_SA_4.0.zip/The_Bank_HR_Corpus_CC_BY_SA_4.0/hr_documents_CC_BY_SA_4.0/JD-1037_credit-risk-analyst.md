# Credit Risk Analyst

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1037 |
| Title | Credit Risk Analyst |
| Document type | Job description |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-09-14 |
| Next review | 2027-09-14 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-POL-002, HR-POL-018, HR-POL-030 |

## 1. Role summary

The Credit Risk Analyst supports the Credit Risk team in the Risk and Compliance family by assessing the credit quality of commercial and retail lending portfolios. The analyst prepares risk ratings, monitors exposures against limits and produces the analysis that senior credit officers and portfolio committees use to decide. The role is Band 3 (Professional): it applies professional knowledge to solve problems and works independently on assigned portfolios. See HR-GDE-006 Job Architecture and Pay Bands Guide.

## 2. Key responsibilities

- Analyze borrower financial statements, cash flow and industry conditions, and recommend internal risk ratings.
- Monitor assigned portfolios weekly for early-warning signals such as covenant breaches, delinquency movement and concentration limits.
- Prepare monthly portfolio dashboards and commentary for the Senior Manager, Credit Risk.
- Run stress-testing scenarios and document the assumptions and results.
- Review credit memos prepared by the business for completeness and consistency with the credit risk appetite.
- Validate data feeding risk models and report data quality defects to the data owners.
- Support regulatory and internal audit requests, including reporting aligned with OSFI expectations.
- Escalate limit excesses and policy exceptions to the Senior Manager, Credit Risk on the day they are identified.
- Maintain accurate analysis files so another analyst can reproduce any rating within 5 business days.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in finance, economics, accounting, statistics or a related field.
- Two to five years of experience in credit analysis, lending, audit or financial analysis.
- Advanced spreadsheet skills and working knowledge of SQL or a comparable query language.
- Clear written communication, including short, evidence-based credit commentary.

### 3.2 Preferred

- Progress toward a CFA charter; the Bank reimburses designation fees under HR-POL-012 Learning and Development Policy (FORM-HR-061).
- Experience with risk-rating models or portfolio analytics tools.

### 3.3 Licences, screening and conduct

No licence is required under HR-POL-029 Licensing, Registration and Qualification Policy. The role is subject to the annual fit-and-proper attestation under HR-POL-030 Fit and Proper and Conduct Standards Policy, due with the Code attestation by 31 October.

## 4. Competencies

Competency names follow HR-FWK-001 Competency and Leadership Model (Practitioner level, Bands 3 to 4).

- Judgement and Decision Quality
- Risk and Conduct Awareness
- Drive for Results
- Collaboration
- Adaptability

## 5. Compensation and classification

| Item | Detail |
| --- | --- |
| Band | 3 (Professional) |
| Canada range | $56,000 to $84,000 CAD per year |
| US range | $55,000 to $82,000 USD per year |
| Incentive target | 5% of base salary (Annual Incentive Plan) |
| Overtime eligibility, Canada | Yes (non-managerial) |
| FLSA classification, US | Exempt |
| Work arrangement | Hybrid |

## 6. Working conditions and accessibility

This is an office role. The default arrangement is hybrid, with at least 3 days a week in the office; Tuesday and Thursday are anchor days and the team chooses the third day (HR-POL-002 Remote and Hybrid Work Policy). The schedule is recorded in FORM-HR-030 in MyHR. Core hours are 10:00 to 15:00 local time. Work is desk-based with occasional peaks around month-end reporting. The Bank provides accommodation to the point of undue hardship (HR-POL-018 Workplace Accommodation and Accessibility Policy); contact accommodations@bank.example or HR Connect.

## 7. Reporting line

Reports to the Senior Manager, Credit Risk. The role has no direct reports.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-03-01 | Pay band ranges updated to the 2026 pay bands; hybrid arrangement aligned with three office days |
| 1.0 | 2025-01-01 | First issue |
