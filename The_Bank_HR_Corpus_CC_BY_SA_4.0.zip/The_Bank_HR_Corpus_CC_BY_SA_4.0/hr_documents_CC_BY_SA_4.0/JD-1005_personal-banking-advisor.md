# Personal Banking Advisor

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1005 |
| Title | Personal Banking Advisor |
| Document type | Job description |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-09-30 |
| Next review | 2027-09-30 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-PLN-002, HR-POL-029, HR-POL-030, HR-POL-018 |

## 1. Role summary

The Personal Banking Advisor helps individuals and families reach their financial goals through a needs-based conversation about everyday banking, borrowing, saving and investing. The Advisor reviews each customer's full picture, recommends suitable solutions in the customer's interest, and builds long-term relationships in the branch's community. Success is measured by customer experience, responsible growth and conduct, not by single-product sales. This is a Band 3 (Professional) role in the Retail Banking family; see HR-GDE-006 Job Architecture and Pay Bands Guide.

## 2. Key responsibilities

- Hold structured financial needs conversations with customers and document goals, circumstances and risk comfort.
- Recommend and arrange personal lending, lines of credit, credit cards, registered and non-registered savings, and mutual fund solutions suited to the customer.
- Assess credit applications within delegated authority and refer larger or more complex requests for independent credit review.
- Conduct annual reviews with an assigned portfolio of customers and proactively follow up on life events.
- Complete know-your-client, suitability and disclosure documentation accurately before any licensed transaction.
- Apply anti-money-laundering, privacy and fair-treatment standards in every interaction.
- Refer customers to Mortgage Specialists, Wealth Advisors and Commercial Banking colleagues when a need goes beyond the Advisor's scope.
- Resolve customer concerns promptly and escalate complaints under the Bank's complaint-handling process.
- Participate in branch community events and referral activity.
- Meet quarterly scorecard goals for customer experience, growth, and risk and conduct.

## 3. Qualifications

### 3.1 Required

- Post-secondary education in business, finance or a related field, or equivalent experience in retail banking.
- Two to five years of experience in a customer-facing financial services role.
- Working knowledge of personal lending and investment products.
- Strong consultative selling, listening and written communication skills.
- Ability to obtain and maintain the licence below.

### 3.2 Preferred

- Experience as a Financial Services Representative or in a similar branch role.
- Fluency in English and French.
- Progress towards a recognized designation such as the CFP.

### 3.3 Licences and certifications

Under HR-POL-029 Licensing, Registration and Qualification Policy, the Personal Banking Advisor in Canada must hold an active mutual fund dealing representative licence. In the US, the role must hold any registration the role requires. No licensed duties may be performed until the licence is active. The annual licence review is each 1 September, and licence or conduct changes must be reported to Compliance within 2 business days (see HR-POL-030 Fit and Proper and Conduct Standards Policy).

## 4. Competencies

Competencies are defined in HR-FWK-001 Competency and Leadership Model; this role works at the Practitioner level.

- **Customer Obsession**: recommends what is right for the customer, not what is easiest to sell.
- **Risk and Conduct Awareness**: meets suitability, disclosure and fair-treatment obligations.
- **Judgement and Decision Quality**: balances customer needs, credit risk and policy.
- **Drive for Results**: builds a book of customers and achieves scorecard goals.
- **Collaboration**: partners with branch, mortgage, wealth and commercial colleagues.
- **Adaptability**: adjusts advice as markets, rates and customer circumstances change.

## 5. Compensation and classification

| Item | Detail |
| --- | --- |
| Band | 3 (Professional) |
| Canada salary range | $56,000 to $84,000 CAD per year |
| US salary range | $55,000 to $82,000 USD per year |
| Incentive target | Advisor and Sales Incentive Plan (HR-PLN-002): 8% of base salary, paid quarterly; replaces the Annual Incentive Plan |
| Overtime eligibility (Canada) | Yes (non-managerial Band 1 to 4 role) |
| FLSA classification (US) | Non-exempt |
| Work arrangement | On-site at the assigned branch |

## 6. Working conditions and accessibility

This is an on-site, customer-facing role in a branch, with scheduled appointments and a posted schedule that may include Saturdays. Quarterly incentive payment depends on the HR-PLN-002 Advisor and Sales Incentive Plan Document scorecard and its conduct gate. The Bank provides accommodation to the point of undue hardship (Canada) or reasonable accommodation (US); see HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to the Branch Manager.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-01-01 | Moved to the Advisor and Sales Incentive Plan scorecard; added licence section |
| 1.0 | 2024-01-08 | First issue |
