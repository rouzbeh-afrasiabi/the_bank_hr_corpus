# Competency and Leadership Model

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-FWK-001 |
| Title | Competency and Leadership Model |
| Document type | Framework |
| Version | 3.0 |
| Status | Current |
| Effective date | 2025-11-01 |
| Last reviewed | 2026-09-22 |
| Next review | 2027-09-22 |
| Policy owner | SVP Talent and Learning |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-011, HR-POL-012, HR-GDE-006, HR-FWK-002, HR-FWK-003, HR-POL-001 |

## 1. Purpose

This framework describes what the Bank expects from every employee and leader: the five Bank values, eight competencies, and the behaviours expected at four proficiency levels. It gives employees and managers a common language for goals, feedback, development and hiring, and it feeds the "how" component of the year-end rating under HR-POL-011 Performance Management Policy.

## 2. Scope

The framework applies to all employees in Canada and the US. It is used alongside the job bands in HR-GDE-006 Job Architecture and Pay Bands Guide. Promotions and transfers are handled separately; this framework describes behaviours and does not set promotion rules. Where applicable law gives a greater right, the law applies.

## 3. The Bank values

| Value | What it means |
| --- | --- |
| Integrity | We do the right thing, tell the truth and keep our commitments. |
| Customer Focus | We put customers' interests at the centre of what we do. |
| Accountability | We own our results, our risks and our mistakes. |
| Collaboration | We succeed by working across teams and business units. |
| Inclusion | We value difference and make everyone able to contribute and belong. |

The values apply to everyone, at every level, and are the basis for the Code of Conduct and Ethics (HR-POL-001).

## 4. The eight competencies

| Competency | Description | Linked values |
| --- | --- | --- |
| Customer Obsession | Understands customers' needs and acts on them to deliver a service that earns trust | Customer Focus |
| Judgement and Decision Quality | Gathers facts, weighs options and makes timely, sound decisions | Integrity, Accountability |
| Drive for Results | Sets clear goals and delivers outcomes with pace and quality | Accountability |
| Collaboration | Builds partnerships and shares information and credit | Collaboration |
| Adaptability | Learns quickly and adjusts to change and ambiguity | Accountability, Collaboration |
| Risk and Conduct Awareness | Identifies and manages risk, follows policy and speaks up | Integrity, Accountability |
| Inclusive Leadership | Creates an environment where different views and backgrounds are heard | Inclusion |
| Developing Others | Coaches, gives feedback and builds the capability of others | Collaboration, Inclusion |

## 5. Proficiency levels

| Level | Bands | Focus |
| --- | --- | --- |
| Foundation | 1 and 2 | Doing the role well and learning the Bank's standards |
| Practitioner | 3 and 4 | Working independently and guiding others |
| Leader | 5 and 6 | Leading teams and functions |
| Enterprise Leader | 7 to 9 | Leading across the Bank and shaping its direction |

An employee is expected to show the behaviours of the level for their band and is developing towards the next level. Executive Committee roles follow the Enterprise Leader level.

## 6. Behaviours by competency and level

### 6.1 Customer Obsession

| Level | Behaviours |
| --- | --- |
| Foundation | Listens to customers, resolves requests accurately and refers issues on promptly |
| Practitioner | Anticipates customer needs, explains options clearly and follows through on complaints |
| Leader | Uses customer feedback to improve team processes and removes obstacles to good service |
| Enterprise Leader | Sets the customer strategy, sponsors changes that improve outcomes across business units |

### 6.2 Judgement and Decision Quality

| Level | Behaviours |
| --- | --- |
| Foundation | Follows procedures and asks when unsure |
| Practitioner | Analyses information and recommends sound solutions in own area |
| Leader | Makes timely decisions with incomplete information and explains the reasoning |
| Enterprise Leader | Makes decisions with enterprise-wide trade-offs and long-term consequences |

### 6.3 Drive for Results

| Level | Behaviours |
| --- | --- |
| Foundation | Completes tasks on time and to the expected quality |
| Practitioner | Plans own work, prioritises and delivers goals with little supervision |
| Leader | Aligns team goals to the business plan and removes blockers |
| Enterprise Leader | Sets ambitious goals and holds the organization to account for delivery |

### 6.4 Collaboration

| Level | Behaviours |
| --- | --- |
| Foundation | Supports teammates and shares information |
| Practitioner | Works across teams and resolves differences constructively |
| Leader | Builds partnerships between teams and business units |
| Enterprise Leader | Aligns leaders across the Bank around shared outcomes |

### 6.5 Adaptability

| Level | Behaviours |
| --- | --- |
| Foundation | Accepts change and learns new tools and procedures |
| Practitioner | Adjusts approach when priorities shift and helps others adjust |
| Leader | Leads a team through change and keeps people informed |
| Enterprise Leader | Anticipates market and regulatory shifts and guides the Bank's response |

### 6.6 Risk and Conduct Awareness

| Level | Behaviours |
| --- | --- |
| Foundation | Follows controls, completes mandatory training and reports concerns |
| Practitioner | Spots risks in own work, escalates early and keeps accurate records |
| Leader | Builds a culture where people raise concerns and checks that controls work |
| Enterprise Leader | Owns the risk appetite for the area, sets the tone from the top and acts on weaknesses |

### 6.7 Inclusive Leadership

| Level | Behaviours |
| --- | --- |
| Foundation | Treats everyone respectfully and is open to different views |
| Practitioner | Invites other views and challenges bias when seen |
| Leader | Builds diverse teams, fair processes and equal access to opportunity |
| Enterprise Leader | Sponsors inclusion goals and acts on pay-equity and representation results |

### 6.8 Developing Others

| Level | Behaviours |
| --- | --- |
| Foundation | Seeks feedback and shares what is learned with colleagues |
| Practitioner | Mentors newer colleagues and gives helpful feedback |
| Leader | Coaches, delegates to stretch people and holds regular development conversations |
| Enterprise Leader | Builds the leadership pipeline and sponsors future leaders (see HR-FWK-003 Talent Review and Succession Process) |

## 7. How the model is used

### 7.1 Performance

Managers use the competencies, with the five values, to assess the "how" of the rating. The model does not add a rating; the year-end rating remains a single score from 1 to 5 under HR-POL-011.

### 7.2 Development

Employees and managers choose one or two competencies for the development goal each year, and link learning to them in the Learning Hub (see HR-POL-012 Learning and Development Policy). Leadership programs are offered to Band 5 and above.

### 7.3 Hiring and role design

Job descriptions list the competencies most important for the role, and structured interviews use them. Career paths are in HR-FWK-002 Career Paths and Job Families Guide.

## 8. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Employee | Reflect on the behaviours, seek feedback and use the model in development goals |
| Manager | Give examples-based feedback against the model and avoid rating on personality or style |
| HRBP | Support calibration so behaviours are assessed consistently |
| SVP Talent and Learning | Owns the model and reviews it every year |

## 9. Contacts

Questions: HR Connect, 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time, hrconnect@bank.example, or your HRBP.

## 10. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 3.0 | 2025-11-01 | Aligned to five Bank values; eight competencies and four proficiency levels mapped to bands. |
| 2.0 | 2023-11-01 | Added Inclusive Leadership and Risk and Conduct Awareness. |
