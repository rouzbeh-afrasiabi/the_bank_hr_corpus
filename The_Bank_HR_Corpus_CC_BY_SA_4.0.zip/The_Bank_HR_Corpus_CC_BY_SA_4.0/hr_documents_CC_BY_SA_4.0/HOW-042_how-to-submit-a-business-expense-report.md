# How to submit a business expense report

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-042 |
| Title | How to submit a business expense report |
| Document type | How-to article |
| Version | 1.1 |
| Status | Current |
| Effective date | 2025-12-01 |
| Last reviewed | 2026-09-21 |
| Next review | 2027-09-21 |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-038, FORM-HR-127, HR-POL-009, HR-POL-001 |

## 1. Short answer

Submit FORM-HR-127 Business Expense Report in MyHR > Pay > Expenses within 30 days of the expense, with a receipt for every expense over $25; your manager approves it and you are reimbursed by direct deposit within 7 business days of final approval.

## 2. Who this applies to

All employees in Canada and the US who travel on Bank business or incur approved business expenses. Items paid on the corporate card are not reimbursed to you.

## 3. Steps

1. Get your manager's approval before you travel, and book through the Bank Travel Desk.
2. Keep every receipt. For mileage, record the date, start and end points and distance instead.
3. Sign in to MyHR and select Pay > Expenses > New expense report (FORM-HR-127).
4. Enter the trip name and dates, then each expense with its date, category, amount, currency (CAD or USD) and business purpose. Mark whether it was paid by corporate card or personal funds.
5. Attach the receipt for every expense over $25. Add client names for client expenses, and a pre-approval reference for air travel above economy, alcohol or any over-limit item.
6. Check the limits, then submit.

| Item | Limit (CAD / USD) |
| --- | --- |
| Hotel per night | $250 / $200; $350 / $300 in designated high-cost cities |
| Meals per day | $75 / $60 (dinner $40 / $32) |
| Mileage | $0.70 per km / $0.67 per mile |

## 4. Deadlines

| Step | Deadline |
| --- | --- |
| Employee submits | Within 30 days of the expense |
| Manager approves | Within 5 business days |
| Director approves (total over $2,500) | Within 5 business days of the manager |
| Reimbursement | Within 7 business days of final approval |

A report more than 30 days old needs Director approval; more than 90 days needs SVP Total Rewards approval.

## 5. What happens next

Your manager approves or returns the report with comments. A Director's report is approved by their own manager; nobody approves their own. Payroll Services pays the approved amount to the account in FORM-HR-022. Foreign-currency items are converted at the rate on the day of the expense and paid in your currency of pay.

## 6. Common mistakes

- Claiming alcohol, except at a client event a Director pre-approved.
- Claiming meals already provided by a conference, client or hotel.
- Splitting one expense to stay under a limit or approval level, or claiming an item twice: this is serious misconduct.
- Missing receipts. A lost receipt may be replaced by a signed statement approved by your manager.
- Waiting past 30 days.

## 7. Who to call

Reimbursement not received: open a case in MyHR > HR Case Portal (Payroll Services). Policy questions: HR Connect, 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time. Travel emergency: 911 first, then Corporate Security, 1-800-555-0119 (24/7). Managers: Manager Hotline, 1-800-555-0143.

## 8. Related documents

- HR-POL-038 Business Travel and Expense Policy
- FORM-HR-127 Business Expense Report
- HR-POL-001 Code of Conduct and Ethics

## 9. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.1 | 2025-12-01 | Updated limits and the Director threshold to match HR-POL-038 version 5.0. |
| 1.0 | 2024-01-15 | First edition. |
