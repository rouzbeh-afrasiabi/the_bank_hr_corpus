# Overtime Above 8 Hours a Week Now Needs Director Approval

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-MEMO-2025-001 |
| Title | Overtime Above 8 Hours a Week Now Needs Director Approval |
| Document type | Memo |
| Version | 1.0 |
| Status | Current |
| Effective date | 2025-05-20 |
| Last reviewed | Not applicable |
| Next review | Not applicable |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-003, FORM-HR-020, HR-GDE-005 |

**Lower overtime approval threshold: 8 hours, down from 10, from 1 July 2025.**

**From:** SVP Total Rewards

**To:** All employees and people managers in Canada and the US

**Date:** 20 May 2025

**Subject:** Change to the Director approval threshold for overtime

## 1. What is changing

Under HR-POL-003 Working Hours and Overtime Policy version 4.2, overtime above 8 hours in a week needs Director approval and HR notification. The previous limit (version 4.1) was 10 hours. Overtime up to 8 hours a week still needs your manager's pre-approval.

## 2. Who is affected

Overtime-eligible employees (Canada Bands 1 to 4 in non-managerial roles; US non-exempt employees) and the managers who approve their hours.

## 3. Effective date

1 July 2025.

## 4. What to do

1. Managers: approve planned or recurring overtime before it is worked, in Time Tracker, using FORM-HR-020.
2. If a week is likely to exceed 8 overtime hours, send the request to your Director and notify HR before the week starts.
3. Employees: enter hours in Time Tracker by Friday 17:00 local time; managers approve by Monday 12:00 local time.
4. Unplanned overtime above 8 hours still needs the Director's approval; raise it with your manager the same day.

Scheduling beyond 12 hours a day or 48 hours a week is unchanged and needs VP approval and written employee consent.

## 5. Who to call

HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, or live chat in MyHR. Managers: Manager Hotline 1-800-555-0143.

## 6. Related documents

- HR-POL-003 Working Hours and Overtime Policy
- FORM-HR-020 Overtime Pre-Approval and Time-in-Lieu Request
- HR-GDE-005 Manager's HR Procedures Guide
