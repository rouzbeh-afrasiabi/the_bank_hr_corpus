# Branch Manager

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1009 |
| Title | Branch Manager |
| Document type | Job description |
| Version | 2.1 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-09-14 |
| Next review | 2027-09-14 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-POL-011, HR-POL-021, HR-POL-018 |

## 1. Role summary

The Branch Manager is accountable for the performance, safety, compliance and culture of one branch. The role leads the branch team, grows customer relationships in the local market, and ensures that controls, conduct standards and service quality meet the Bank's expectations. The Branch Manager is the visible face of the Bank in the community and the first line of defence for branch risk. This is a Band 5 (Team Lead / Manager I) role in the Retail Banking family; see HR-GDE-006 Job Architecture and Pay Bands Guide.

## 2. Key responsibilities

- Lead branch staff, including the Assistant Branch Manager, advisors, Financial Services Representatives and tellers.
- Set and track branch goals for customer experience, growth and risk, and report results to the Regional Manager, Retail.
- Manage the performance cycle for the team: goals, check-ins, assessments and development plans under HR-POL-011 Performance Management Policy.
- Handle attendance, coaching and, with HR support, progressive discipline under HR-POL-021 Employee Relations and Progressive Discipline Policy.
- Ensure compliance with cash, security, privacy, anti-money-laundering and sales-practice controls, and act on audit findings.
- Hire, onboard and retain talent, using structured, fair and inclusive selection practices.
- Review and approve credit and operational exceptions within delegated authority.
- Own the branch's business continuity, emergency and robbery response procedures.
- Manage the branch expense budget and approve staff time in MyHR and Time Tracker.
- Build relationships with local community organizations, small businesses and referral partners.

## 3. Qualifications

### 3.1 Required

- Post-secondary education in business or a related field, or equivalent experience.
- Seven to ten years of retail banking experience, including at least two years leading a team.
- Strong knowledge of branch operations, personal lending and regulatory expectations.
- Proven coaching, performance management and conflict-resolution skills.
- Satisfactory results in pre-employment screening and periodic re-screening for roles with financial authority.

### 3.2 Preferred

- Experience as an Assistant Branch Manager in a multi-product branch.
- Completion of a Bank leadership program.
- Fluency in English and French, or another community language.

### 3.3 Licences and certifications

No licence is required for the role itself. Branch Managers who supervise licensed advisors need working knowledge of the requirements in HR-POL-029 Licensing, Registration and Qualification Policy.

## 4. Competencies

Competencies are defined in HR-FWK-001 Competency and Leadership Model; this role works at the Leader level.

- **Developing Others**: builds team capability and succession in the branch.
- **Inclusive Leadership**: creates a team where every employee can contribute.
- **Risk and Conduct Awareness**: maintains a strong control and conduct culture.
- **Drive for Results**: delivers branch targets sustainably.
- **Customer Obsession**: keeps customer outcomes at the centre of branch decisions.
- **Judgement and Decision Quality**: makes sound calls on credit, staffing and incidents.
- **Collaboration**: works with the region, specialists and community partners.

## 5. Compensation and classification

| Item | Detail |
| --- | --- |
| Band | 5 (Team Lead / Manager I) |
| Canada salary range | $90,000 to $134,000 CAD per year |
| US salary range | $88,000 to $132,000 USD per year |
| Incentive target | Annual Incentive Plan (AIP): 10% of base salary |
| Overtime eligibility (Canada) | No |
| FLSA classification (US) | Exempt |
| Work arrangement | On-site at the managed branch |

## 6. Working conditions and accessibility

This is an on-site role at the managed branch, with Saturday coverage on a rota and occasional after-hours call-outs for alarms or incidents. Managers are expected to understand and apply workplace accommodation obligations; the Bank provides accommodation to the point of undue hardship (Canada) or reasonable accommodation (US); see HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to the Regional Manager, Retail.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.1 | 2026-03-01 | Pay ranges updated to the 2026 pay bands |
| 2.0 | 2025-04-01 | Added performance-cycle and discipline duties |
| 1.0 | 2023-03-01 | First issue |
