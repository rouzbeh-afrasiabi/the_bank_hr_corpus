# Software Developer

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1026 |
| Title | Software Developer |
| Document type | Job description |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-07-01 |
| Last reviewed | 2026-08-11 |
| Next review | 2027-08-11 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-POL-002, HR-POL-017, HR-POL-018 |

## 1. Role summary

The Software Developer designs, builds, tests and supports applications that serve the Bank's customers and employees. The developer works as part of an agile team on well-defined features and defects, writes clean and secure code, takes part in code review and learns how the Bank's systems fit together. A Band 3 developer works independently on assigned work and seeks guidance on design choices with wider impact.

## 2. Key responsibilities

- Design, code and unit-test features from user stories and technical designs.
- Write automated tests (unit, integration and contract) and keep the build pipeline green.
- Review colleagues' code and respond constructively to review comments.
- Diagnose and fix defects found in testing or production, and help find root causes.
- Follow secure-coding practices and fix vulnerabilities flagged by scanning tools within agreed timeframes (see HR-POL-017 IT Acceptable Use and Information Security Policy).
- Use only Bank-approved tools, including approved AI coding assistants, and never put client or employee personal data into public tools.
- Document services, interfaces and operating procedures so others can support them.
- Take part in sprint planning, daily stand-ups and retrospectives, and estimate work honestly.
- Contribute to release activities and to the on-call rotation for the team's services when assigned.
- Keep up with the technologies the team uses through the learning budget and the Learning Hub.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in computer science, software engineering or a related field, or equivalent experience.
- Typically 2 to 5 years of professional software development experience.
- Proficiency in at least one modern object-oriented programming language, plus relational databases and web service design.
- Experience with version control, automated testing and continuous integration.

### 3.2 Preferred

- Experience building services on public cloud platforms.
- Knowledge of financial-services domains such as payments or lending.
- Contributions to engineering communities or open-source projects (with approval).

### 3.3 Licences and certifications

None required. Cloud or secure-development certifications are an asset.

## 4. Competencies

Measured against HR-FWK-001 Competency and Leadership Model at the Practitioner level:

- Judgement and Decision Quality
- Collaboration
- Adaptability
- Drive for Results
- Risk and Conduct Awareness

## 5. Compensation and classification

| Item | Value |
| --- | --- |
| Band | 3 (Professional) |
| Canada range | $56,000 to $84,000 CAD |
| US range | $55,000 to $82,000 USD |
| Incentive target | 5% of base salary (Annual Incentive Plan) |
| Overtime eligibility, Canada | Yes (non-managerial Band 3) |
| FLSA classification, US | Exempt |
| Work arrangement | Hybrid (at least 3 days a week in the office) |

Band definitions are in HR-GDE-006 Job Architecture and Pay Bands Guide.

## 6. Working conditions and accessibility

This is an office role with a hybrid arrangement: at least 3 days a week in the office, with Tuesday and Thursday as anchor days, as described in HR-POL-002 Remote and Hybrid Work Policy. When assigned to the on-call rotation, the on-call allowance and call-out minimum in HR-POL-003 Working Hours and Overtime Policy apply. The Bank provides accommodation to the point of undue hardship; see HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to: Technology Team Lead. Direct reports: none.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-07-01 | Added approved AI tools expectation and secure coding duties |
| 1.0 | 2023-07-01 | First issue |
