# Relocation Request and Approval

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-122 |
| Title | Relocation Request and Approval |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-039, HR-POL-002, HR-GDE-006, HR-POL-009 |

## 1. Purpose and when to use this form

Use this form to request and approve relocation support for a Bank-initiated, approved move (HR-POL-039 Relocation and Global Mobility Policy). The move must bring you at least 80 km closer to the new work location. Employee-initiated moves, including remote employees who choose to move, are not covered; they follow HR-POL-002 Remote and Hybrid Work Policy, which requires approval 30 days ahead.

## 2. Who completes it and who approves

You complete it with your manager. Approval depends on your band: Bands 1 to 4, the business unit SVP; Bands 5 and 6, a Vice President; Band 7 and above, an SVP (the CHRO is informed). The HRBP and Global Mobility also approve. Lump sums for Bands 1 to 4 require SVP approval. International assignments need approval by the SVP, Global Mobility and Legal at least 30 days ahead.

## 3. Where and when to submit (deadline, channel, processing time)

Submit in MyHR (Career and Learning > Relocation) at least 30 days before the planned move date and before you commit to any move expense. Costs incurred before written approval are not reimbursed. Global Mobility acknowledges within 2 business days and the approvers decide within 10 business days of the complete request; HR Operations confirms the decision in writing. Submit proof of the new address within 90 days of the move date.

## 4. Form fields

| Field | Required | Notes |
| --- | --- | --- |
| Name, employee ID, band | Yes | Pre-filled; band sets the lump sum |
| Current and new work location | Yes | |
| Current and new home address | Yes | |
| Distance closer to the new work location (km) | Yes | At least 80 km |
| Reason and approving business leader | Yes | Must be Bank-initiated |
| Planned move date | Yes | |
| Temporary housing needed (up to 60 days) | No | |
| House-hunting trip (one, up to 3 days) | No | |
| International assignment | Yes | If Yes, see section 2 |
| Lump sum requested | Yes | Per the table below |

| Band | Relocation lump sum |
| --- | --- |
| Bands 1 to 4 | $5,000 CAD / $4,000 USD |
| Bands 5 and 6 | $12,000 CAD / $9,500 USD |
| Band 7 and above | $20,000 CAD / $16,000 USD |

## 5. Declarations and signatures

I understand that relocation benefits are taxable, with a tax assistance payment for approved Bank-initiated moves. I will repay 100% if I resign within 12 months, and 50% if I resign between 12 and 24 months, after the lump sum is paid. Employee signature and date: ____________. Manager: ____________. HRBP: ____________. Approver: ____________.

## 6. What happens next

Payroll Services pays the lump sum and records the taxable amount on your pay statement and tax slip (see HR-POL-009 Compensation and Payroll Policy). Your reporting line and band are not changed by this form. Repayment, where it applies, is arranged with Payroll Services.

## 7. Related documents

- HR-POL-039 Relocation and Global Mobility Policy
- HR-POL-002 Remote and Hybrid Work Policy
- HR-GDE-006 Job Architecture and Pay Bands Guide

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-09-01 | Added 80 km test, band lump sums and repayment terms. |
| 1.0 | 2022-06-01 | Initial form. |
