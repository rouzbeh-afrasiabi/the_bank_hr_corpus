# Vice President, HR Operations

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1052 |
| Title | Vice President, HR Operations |
| Document type | Job description |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-03-16 |
| Last reviewed | 2026-09-29 |
| Next review | 2027-09-29 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-004, HR-GDE-006, HR-FWK-001, HR-POL-002, HR-POL-014, HR-POL-015 |

## 1. Role summary

The Vice President, HR Operations leads the Bank's HR service delivery: HR Connect, HR Operations, the HR Case Portal, MyHR, onboarding and offboarding, employment records and the work arrangement and classification policies. The VP sets service standards for employees and managers in Canada and the US and is the second step on the HR escalation path. The role is Band 8 (Senior Director / Vice President): it leads a major function and influences strategy across business units. See HR-GDE-006 Job Architecture and Pay Bands Guide.

## 2. Key responsibilities

- Own the HR service model and the service levels in HR-GDE-004 HR Service and Support Guide, including P1 first response within 4 business hours and the Tier 1, Tier 2 and Tier 3 structure.
- Act as escalation point when a service level is missed after the HR Operations manager step, and report significant breaches to the Office of the CHRO.
- Own the Remote and Hybrid Work Policy (HR-POL-002), the Employment Status and Classification Policy (HR-POL-014), the Resignation and Offboarding Policy (HR-POL-015) and the onboarding guide, and lead their annual review.
- Lead the HR technology roadmap for MyHR, the HR Case Portal, Time Tracker and the Learning Hub, including Privacy Impact Assessments (FORM-HR-091) and Data Protection Impact Assessments (FORM-HR-092) before any material system change.
- Chair, with the Chief Privacy Officer, the review of any AI-assisted tool used in an HR process; a person makes any final employment decision.
- Oversee HR Connect (1-800-555-0142) staffing, quality, bilingual coverage and Manager Hotline response of 4 business hours.
- Manage the approved employment-jurisdiction list with Payroll Services and Legal, and global mobility and relocation policy governance.
- Lead the HR Policy Committee's document programme, including document versions, review dates and change control.
- Manage the HR operations budget and vendor performance.
- Oversee the exit-interview programme and develop senior HR managers.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in business, human resources or a related field; MBA or master's degree preferred.
- Fifteen or more years of progressive HR or shared-services experience, including at least 5 years leading large teams.
- Proven experience designing service models, managing HR technology and driving process improvement.
- Strong command of Canadian and US employment law and privacy requirements.

### 3.2 Preferred

- Experience in a regulated financial institution with a contact centre and shared-services operations.
- Experience leading digital transformation and AI governance in HR.

## 4. Competencies

Competency names follow HR-FWK-001 Competency and Leadership Model (Enterprise Leader level, Bands 7 to 9).

- Drive for Results
- Judgement and Decision Quality
- Customer Obsession
- Adaptability
- Developing Others
- Inclusive Leadership
- Risk and Conduct Awareness

## 5. Compensation and classification

| Item | Detail |
| --- | --- |
| Band | 8 (Senior Director / Vice President) |
| Canada range | $180,000 to $270,000 CAD per year |
| US range | $175,000 to $265,000 USD per year |
| Incentive target | 30% of base salary (Annual Incentive Plan) |
| Overtime eligibility, Canada | No |
| FLSA classification, US | Exempt |
| Work arrangement | Hybrid |

Deferral and clawback rules for Band 7 and above apply (HR-POL-031 Incentive Deferral and Clawback Policy), as does Long-Term Incentive Plan eligibility (HR-PLN-003 Long-Term Incentive Plan Document).

## 6. Working conditions and accessibility

Office-based and hybrid by default, with at least 3 days a week in the office; Tuesday and Thursday are anchor days (HR-POL-002 Remote and Hybrid Work Policy; FORM-HR-030). Travel to operations centres and vendors is expected, and the role may be called on for urgent issues such as pay-run or system incidents. The Bank provides accommodation to the point of undue hardship (HR-POL-018 Workplace Accommodation and Accessibility Policy).

## 7. Reporting line

Reports to the Chief Human Resources Officer. Direct reports: Directors and Senior Managers in HR Operations, HR Connect and HR technology.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-03-16 | Aligned with HR-GDE-004 version 2.5 service model and the 2026 pay bands |
| 1.0 | 2025-01-01 | First issue |
