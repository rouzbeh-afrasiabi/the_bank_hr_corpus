# How to find a job description and your band

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-038 |
| Title | How to find a job description and your band |
| Document type | How-to article |
| Version | 1.1 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-09-28 |
| Next review | 2027-09-28 |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-POL-003, HR-POL-019, HR-POL-009 |

## 1. Short answer

Your band and pay range are in MyHR > Personal Information, and the job description for your role is in the job description library under MyHR > Career and Learning; the band tells you the pay range, incentive target and overtime eligibility.

## 2. Who this applies to

All employees in Canada and the US. Executive Committee roles sit outside the bands. Pay ranges are separate for Canada (CAD) and the US (USD), and you may discuss your own pay with anyone.

## 3. Steps

1. **Find your band.** Open MyHR > Personal Information and view your job, band and the pay range for your own band.
2. **Find your job description.** Open MyHR > Career and Learning, search the job description library by job title or by JD number (for example JD-1025 Business Analyst), and open the document for your role.
3. **Read the compensation table** in the job description: band, Canada range (CAD), US range (USD), incentive target, overtime eligibility in Canada, FLSA classification in the US, and work arrangement. The pay_bands.csv file is the source of truth for ranges.
4. **Compare with the band descriptions.** The nine bands run from Band 1 Associate Support to Band 9 Senior Vice President.
5. **Ask for a job review** if you think your job is in the wrong band: ask your manager to raise a case in MyHR > HR Case Portal.

For example, JD-1025 Business Analyst is Band 4: $72,000 to $108,000 CAD, $70,000 to $106,000 USD, Annual Incentive Plan target 8%, overtime-eligible in Canada, exempt in the US, hybrid work.

## 4. Deadlines

| Item | Timeline |
| --- | --- |
| Job review request | Raised by your manager in the HR Case Portal |
| Total Rewards response | Within 15 business days |
| Band and range changes | Effective 1 March with the annual salary review |

## 5. What happens next

The HRBP checks your job description against the band descriptions and sends the case to Total Rewards. A job review concerns the job, not the person, and does not create a promotion; promotions and transfers are handled separately. Overtime eligibility by band is in HR-POL-003 Working Hours and Overtime Policy.

## 6. Common mistakes

- Reading a range for the wrong country; use the CAD or USD column for where you work.
- Confusing the incentive target with a guaranteed payout.
- Expecting a job review to change your pay straight away.
- Assuming your title sets your overtime status; it depends on duties and pay.

## 7. Who to call

Your manager, then HR Connect, 1-800-555-0142 (Monday to Friday 8:00 to 20:00 Eastern Time), hrconnect@bank.example. Managers: Manager Hotline, 1-800-555-0143.

## 8. Related documents

- HR-GDE-006 Job Architecture and Pay Bands Guide
- HR-POL-003 Working Hours and Overtime Policy
- HR-POL-019 Recruitment and Selection Policy

## 9. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.1 | 2026-03-01 | Applied the 2026 pay bands from HR-GDE-006 version 2.0. |
| 1.0 | 2025-01-01 | First issue. |
