# Working Hours and Overtime Policy (version 4.1)

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

> **Archived version.** Kept for reference only. Do not rely on it. See HR-POL-003 Working Hours and Overtime Policy.

| Field | Value |
| --- | --- |
| Document ID | HR-ARC-005 |
| Title | Working Hours and Overtime Policy (version 4.1) |
| Document type | Archived version |
| Version | 4.1 |
| Status | Superseded |
| Superseded by | HR-POL-003 Working Hours and Overtime Policy, version 4.2 (effective 2025-07-01) |
| Effective date | 2024-07-01 |
| Last reviewed | Not applicable |
| Next review | Not applicable |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-003, HR-POL-009, HR-POL-014, HR-GDE-006, FORM-HR-020 |

## 1. Status of this version

Version 4.1 was in force from 1 July 2024 to 30 June 2025. Version 4.2 replaced it on 1 July 2025 and lowered the weekly overtime limit that needs Director approval. Only that limit differs from the current policy; the overtime tables, time in lieu, breaks, scheduling and all other rules shown here are the same as in HR-POL-003.

## 2. Purpose and scope

The policy set the Bank's standard hours, overtime and time in lieu, meal and rest breaks, scheduling, premiums, on-call duty and time entry. Where the Bank rule was more generous than the law, the Bank rule applied; where applicable law gave a greater right, the law applied. Time entry, overtime pay and time in lieu applied only to overtime-eligible (Canada) or non-exempt (US) employees. Contractors were outside the policy (HR-POL-014 Employment Status and Classification Policy).

## 3. Standard hours

| Item | Canada | US |
| --- | --- | --- |
| Weekly hours | 37.5 | 40 |
| Daily hours | 7.5 | 8 |
| Unpaid meal period | 60 minutes | 60 minutes |

Core hours for office-based staff were 10:00 to 15:00 local time. Extra hours in Canada (between 37.5 and 40 a week) were paid at straight time or banked 1:1.

## 4. Overtime rules by region

| Jurisdiction | Daily rule | Weekly rule |
| --- | --- | --- |
| Ontario | None | 1.5x after 40 hours (the provincial threshold is 44) |
| Quebec | None | 1.5x after 40 hours |
| British Columbia | 1.5x after 8 hours; 2x after 12 hours | 1.5x after 40 hours |
| Alberta | 1.5x after 8 hours | 1.5x after 40 hours; the greater of daily or weekly overtime is paid |
| Other provinces and territories | None | 1.5x after 40 hours |
| California | 1.5x after 8 hours; 2x after 12 hours | 1.5x after 40 hours |
| New York, New Jersey, Florida and other US states | None | 1.5x after 40 hours |

Non-exempt US employees were paid overtime in cash; compensatory time was not available in the US.

## 5. Time in lieu, breaks and scheduling

- **Time in lieu (Canada only):** with manager approval on FORM-HR-020, overtime could be banked at 1.5 hours per overtime hour, to a cap of 40 hours, taken within 3 months, with any unused balance paid at the overtime rate at expiry.
- **Breaks:** a 30-minute unpaid meal period after at most 5 consecutive hours, and two paid 15-minute rest breaks per full shift (California: a 30-minute meal break before the end of the 5th hour and a paid 10-minute break per 4 hours).
- **Scheduling:** schedules posted at least 14 days ahead; changes with less than 96 hours' notice needed consent; a shift added with less than 24 hours' notice could be declined; no scheduling beyond 12 hours a day or 48 hours a week without VP approval and written consent; at least 8 hours of rest between shifts and 24 consecutive hours off per week.

## 6. Overtime approval (version 4.1)

Overtime had to be pre-approved by the manager in Time Tracker, and planned or recurring overtime needed FORM-HR-020. More than **10 overtime hours in a week** needed Director approval and HR notification. Emergency overtime was approved by the manager by the next business day. Unapproved overtime was still paid, but repeated unapproved overtime could be addressed under HR-POL-021 Employee Relations and Progressive Discipline Policy. From 1 July 2025 the limit is 8 hours (see HR-POL-003).

## 7. Worked example (Ontario)

At $30 an hour, an employee worked 9 hours on each of 5 days (45 hours). The first 37.5 hours were regular, 2.5 hours were extra hours at straight time, and 5 hours over 40 were paid at 1.5x: 40 x $30 = $1,200 plus 5 x $45 = $225, for $1,425. Because the 5 overtime hours were fewer than 10, no Director approval was needed.

## 8. Classification, time entry, premiums and contacts

Canada Bands 1 to 4 non-managerial roles were overtime-eligible; Bands 5 and above were not. In the US, employees classified non-exempt under the Fair Labor Standards Act (generally Bands 1 to 3 and some Band 4) were overtime-eligible (HR-GDE-006 Job Architecture and Pay Bands Guide). Weekly time entry was due Friday 17:00 local time and manager approval Monday 12:00 local time. The shift premium was $2.00 per hour (CAD in Canada, USD in the US) for hours between 18:00 and 06:00; on-call allowance was $200 CAD / $150 USD per week with a 3-hour call-out minimum. HR Connect: 1-800-555-0142; Manager Hotline: 1-800-555-0143.

## 9. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 4.0 | 2023-07-01 | Added region-by-region overtime tables and time in lieu bank cap of 40 hours |
| 4.1 | 2024-07-01 | Set maximum weekly overtime without Director approval at 10 hours |
| 4.2 | 2025-07-01 | Superseded this version; limit lowered from 10 hours to 8 hours (see HR-POL-003) |
