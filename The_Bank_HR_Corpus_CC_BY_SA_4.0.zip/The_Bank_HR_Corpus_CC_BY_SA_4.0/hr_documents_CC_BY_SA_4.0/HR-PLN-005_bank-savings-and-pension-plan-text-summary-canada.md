# Bank Savings and Pension Plan Text Summary (Canada)

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-PLN-005 |
| Title | Bank Savings and Pension Plan Text Summary (Canada) |
| Document type | Plan document |
| Version | 3.0 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-09-17 |
| Next review | 2027-09-17 |
| Policy owner | SVP Total Rewards |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | Employees |
| Jurisdiction | Canada |
| Language | English |
| Related documents | HR-GDE-002, HR-PLN-006, HR-PLN-007, HR-POL-014, HR-POL-009, HR-POL-015, HR-POL-008 |

## 1. Purpose and status of this summary

This document summarizes, in plan-document form, the text of the Bank Savings and Pension Plan (the "Plan"), the defined contribution pension plan sponsored by the Bank for its employees in Canada. It states who may join, what is contributed, when Bank contributions belong to the member, when money may be withdrawn, and what happens on retirement, termination, death and the breakdown of a marriage or partnership.

HR-GDE-002 Retirement and Savings Plan Guide explains the Plan in plain language and in worked examples. If this summary and the registered plan text or applicable pension law differ, the plan text and the law govern. Statutory contribution and pension limits are set by the tax authorities and pension regulators each year and are not stated here; Evergreen Retirement Services publishes the current limits. Where applicable law gives a greater right, the law applies. The US plan is described in HR-PLN-006 US 401(k) Savings Plan Summary Plan Description.

## 2. Definitions

- **Base salary** means the member's annual rate of pay before deductions, excluding incentive pay under the Annual Incentive Plan, overtime, premiums and allowances.
- **Member** means an employee who has joined the Plan and who has, or is entitled to, an account balance.
- **Account** means the record of a member's contributions, the Bank's contributions and the investment earnings on them.
- **Base contribution** means the Bank contribution made whether or not the member contributes.
- **Match** means the Bank contribution that matches the member's own contributions.
- **Vesting** means the member's ownership of the Bank's contributions.
- **Locked in** means subject to the rule that money may not be withdrawn in cash before the age in section 8.
- **Normal retirement age** means 65.
- **Plan administrator** means the Bank, acting through the SVP Total Rewards.
- **Recordkeeper** means Evergreen Retirement Services.
- **Spouse** includes a common-law partner, as pension law defines the term.

## 3. Membership

### 3.1 Eligible employees

The following employees are eligible to join the Plan from their first day of employment: regular full-time employees, regular part-time employees, and fixed-term employees whose contract is 6 months or more. Fixed-term employees under 6 months, casual employees, and students, co-op students and interns are not eligible. Contractors and agency workers are not employees and are not eligible. The classification rules are in HR-POL-014 Employment Status and Classification Policy.

### 3.2 Automatic enrolment

An eligible employee who makes no election is enrolled automatically at a contribution rate of 4% of base salary on the first pay date after 30 days of employment. An employee may choose a different rate, or opt out, as described in section 4.3.

### 3.3 Optional savings accounts

The Group RRSP and the payroll TFSA are optional savings arrangements offered by payroll deduction. They are not part of the Plan, they receive no Bank contribution, and they are not locked in. Withdrawals have tax consequences that the member should consider first.

## 4. Member contributions

### 4.1 Contribution rate

A member may contribute from 2% to 10% of base salary by payroll deduction. Contributions are expressed as a percentage of base salary only; incentive pay is not subject to contribution.

### 4.2 Changing the rate

A member changes the rate in MyHR. A change takes effect at the next payroll cut-off, which is 17:00 Eastern Time five business days before the pay date (see HR-POL-009 Compensation and Payroll Policy). A change made after the cut-off applies from the following pay date.

### 4.3 Opting out

A member who was automatically enrolled may opt out within 90 days of enrolment, and the member's contributions will be refunded. After 90 days, contributions that have been made stay in the Plan, and the member may still reduce the rate to the minimum or stop future contributions only to the extent the plan text allows.

## 5. Bank contributions

### 5.1 Amounts

| Bank contribution | Amount |
| --- | --- |
| Base contribution | 2% of base salary, regardless of the member's contribution |
| Match | 100% of the member's contributions up to the first 4% of base salary |
| Maximum Bank total | 6% of base salary |

A member who contributes 4% of base salary therefore receives the full Bank contribution of 6%. Contributing more than 4% increases the member's own savings but not the match. For example, on a base salary of $90,000, a member contributing 4% contributes $3,600, the Bank contributes $5,400 in total, and $9,000 enters the Account.

### 5.2 Incentive pay

Incentive pay, including payouts under the Annual Incentive Plan, is not matched and is not pensionable.

### 5.3 Leaves of absence

During an unpaid leave no contributions are made, because there is no base salary on which to base them. During a Bank-paid leave, contributions continue on the pay received, including parental leave top-up pay (see HR-POL-008 Parental and Family Leave Policy). Part-time members contribute, and receive Bank contributions, on actual base salary.

## 6. Vesting

All Bank contributions, being the base contribution and the match, vest immediately. A member owns them from the day they are credited, regardless of length of service. The member's own contributions are always the member's. Vesting does not remove the locking-in rule in section 8.

## 7. Investments

Contributions are invested in the default target-date fund selected by the member's age, assuming retirement at 65, unless the member selects other funds from the investment menu. A member may change investment choices and transfer balances between funds at any time without charge except where the fund rules state otherwise. Investment returns, positive or negative, are credited to the Account. The member bears the investment risk; the Plan does not guarantee a level of pension.

Evergreen Retirement Services issues quarterly statements, which are also available in MyHR. A member should check the name, address and contribution rate on each statement and report an error to Benefits Administration within 30 days of receiving it. Each member is entitled to a free one-to-one financial advice session every year.

## 8. Locking in

Pension assets in the Plan are locked in until age 55. Before that age a member cannot withdraw them as cash, except in the limited cases that pension law permits, such as a transfer to another locked-in account or pension plan. From age 55, the member may take retirement benefits in a form permitted by pension law and the plan text.

## 9. Retirement

### 9.1 Retirement ages

| Item | Rule |
| --- | --- |
| Normal retirement age | 65 |
| Early retirement | From age 55 with at least 5 years in the Plan |
| Retirement notice | 3 months before the intended last day |

### 9.2 Procedure

A member who intends to retire gives 3 months' notice, submits the resignation form (FORM-HR-080 Resignation Notice) and tells HR Operations that the resignation is a retirement. Notice periods by band are in HR-POL-015 Resignation and Offboarding Policy. Evergreen Retirement Services sends the member the available options, which include leaving the money in the Plan, transferring it as pension law allows, or taking retirement income.

### 9.3 Retiree health access

Retiree health access at age 55 with 10 years of service is a feature of the group benefits plan and is described in HR-PLN-004 Group Benefits Booklet (Canada).

## 10. Termination of employment

A member whose employment ends keeps the full Account, including all Bank contributions, because they are vested. The Account remains locked in under section 8. Evergreen Retirement Services sends an options package within 30 days after employment ends. The member may:

1. leave the Account in the Plan;
2. transfer it to a locked-in account or to another registered pension arrangement as pension law permits; or
3. use another option that pension law makes available to the member.

A member who leaves before the first pay date after 30 days of employment is not enrolled. A member who opts out within the 90-day period under section 4.3 receives a refund of the member's own contributions.

## 11. Death

If a member dies before retirement income begins, the value of the Account is paid to the surviving spouse as pension law requires, unless the spouse has waived the entitlement in the form and manner the law allows. If there is no eligible spouse, the Account is paid to the beneficiary named by the member, or if there is none, to the member's estate. Members should name beneficiaries in MyHR or through Evergreen Retirement Services and review them after marriage, divorce, the birth or adoption of a child, or the death of a beneficiary. If no valid beneficiary is on file, the plan text and applicable law decide who receives the Account.

## 12. Marriage or partnership breakdown

On the breakdown of a marriage or partnership, a member's Account may be divided as pension law, a court order or a domestic contract requires. The plan administrator and Evergreen Retirement Services follow a valid order or agreement delivered to them. The member must inform Benefits Administration promptly and should not assume that a division has been made until Evergreen Retirement Services confirms it in writing. Fees for the division, if any, are set out in the plan text.

## 13. Transfers in and out

A member may ask Evergreen Retirement Services about transferring a previous employer's pension money into the Plan, where pension law and the plan text allow it. A member who moves to the US should contact HR Connect before the move because plan membership changes (see HR-PLN-006). Loans are not available under the Plan.

## 14. Administration

### 14.1 Roles

| Role | Responsibility |
| --- | --- |
| Member | Choose the contribution rate, investments and beneficiaries; check statements |
| Payroll Services | Deduct and remit contributions |
| Benefits Administration | Confirm eligibility and answer plan questions |
| Evergreen Retirement Services | Keep records, issue statements, process transactions and send option packages |
| Plan administrator (SVP Total Rewards) | Administers the Plan under the plan text and applicable law |
| HR Policy Committee | Approves amendments to the plan design |

### 14.2 Amendment and termination

The Bank may amend or wind up the Plan, subject to pension law and to the protection of benefits already earned. A member is notified of a material amendment.

### 14.3 Claims and complaints

A member who disagrees with a decision about the member's Account, eligibility or benefits may seek a review. The submission time limits, review steps and complaint routes are described in HR-PLN-007 Benefits Claims and Appeals Guide. Personal information in the Plan is handled under HR-POL-016 Employee Data Privacy Policy.

## 15. Contacts

| Need | Contact |
| --- | --- |
| Account balances, investments, advice sessions, option packages | Evergreen Retirement Services, 1-800-555-0188 |
| Eligibility, payroll deductions, policy | HR Connect, 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time, hrconnect@bank.example |

## 16. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 3.0 | 2026-01-01 | Plan text summary issued in plan-document form, aligned with HR-GDE-002 version 3.0 |
