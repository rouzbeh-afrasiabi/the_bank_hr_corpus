# Comment demander un congé parental au Québec

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

> **Document synthétique.** Contenu fictif produit pour des essais de recherche et de questions-réponses. Il ne constitue pas la politique d'une organisation réelle.

| Field | Value |
| --- | --- |
| Document ID | HOW-048 |
| Title | Comment demander un congé parental au Québec |
| Document type | How-to article |
| Version | 1.0 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-09-10 |
| Next review | 2027-09-10 |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Quebec |
| Language | French |
| Related documents | HR-SUP-001, HR-POL-008, FORM-HR-012, HR-GDE-001 |

## 1. Réponse courte

Remettez FORM-HR-012 dans MyHR > Temps et absences au moins 4 semaines avant le début du congé, si possible, et faites votre demande au Régime québécois d'assurance parentale (RQAP) dès que possible. L'équipe des congés confirme par écrit les dates, le complément et les conditions de retour dans les 5 jours ouvrables suivant une demande complète.

## 2. À qui s'adresse cet article

Aux employés réguliers, à temps partiel ou à durée déterminée de 6 mois ou plus travaillant au Québec. Le complément de la Banque exige 6 mois de service continu; avec moins de service, vous avez droit au congé prévu par la loi, sans complément. Lorsque la loi applicable accorde un droit plus grand, la loi s'applique.

## 3. Étapes

1. Vérifiez votre admissibilité au complément (6 mois de service continu) et informez votre gestionnaire pour planifier la relève.
2. Ouvrez MyHR > Temps et absences > Congé parental, choisissez le type de congé (maternité, parent non biologique, adoption ou gestation pour autrui) et remplissez FORM-HR-012.
3. Indiquez la date prévue de l'accouchement ou de placement, les dates de début et de retour souhaitées et votre date d'entrée en service. Le congé de maternité peut commencer jusqu'à 13 semaines avant la date prévue.
4. Joignez la preuve : certificat médical indiquant la date prévue, ou documents de placement ou d'adoption (dans les 30 jours suivant le placement), ou entente de gestation pour autrui. Ils sont confidentiels.
5. Faites votre demande de prestations au RQAP.
6. Remettez l'avis de prestation du RQAP à l'équipe des congés dans les 5 jours ouvrables suivant sa réception, par MyHR > Portail des cas RH.
7. Donnez un préavis de 4 semaines avant votre retour.

## 4. Échéances

| Élément | Échéance |
| --- | --- |
| Avis de congé (FORM-HR-012) | Au moins 4 semaines avant le début, si possible |
| Avis de prestation du RQAP | 5 jours ouvrables suivant sa réception |
| Confirmation écrite | 5 jours ouvrables suivant une demande complète |
| Début du congé parental | Dans les 78 semaines suivant la naissance ou le placement |
| Préavis de retour | 4 semaines |

## 5. Et ensuite

La Banque coordonne son complément avec la prestation du RQAP pour que votre rémunération totale soit égale à 100 % de votre salaire de base : 17 semaines pour le parent biologique, 8 semaines pour le parent non biologique, adoptif ou d'intention en cas de gestation pour autrui. Le RQAP est versé par le gouvernement; la Banque ne peut pas le garantir. Le congé protégé peut atteindre 18 mois au total pour un parent biologique. La Banque continue de payer sa part des avantages sociaux pendant le congé. À votre retour, vous retrouvez le même poste, ou un poste comparable dans la même bande salariale; un retour progressif d'au plus 4 semaines, à 80 % de l'horaire normal, est possible.

## 6. Erreurs fréquentes

- Attendre la réponse du RQAP avant de donner votre avis de congé.
- Oublier l'avis de prestation dans les 5 jours ouvrables.
- Remettre le certificat médical à votre gestionnaire plutôt qu'à l'équipe des congés.

## 7. Personnes-ressources

RH Connect : 1-800-555-0142, du lundi au vendredi, de 8 h à 20 h (heure de l'Est), hrconnect@bank.example, clavardage dans MyHR, en français ou en anglais. Mesures d'adaptation au retour : accommodations@bank.example.

## 8. Documents connexes

- HR-SUP-001 Supplément pour le Québec
- HR-POL-008 Parental and Family Leave Policy
- FORM-HR-012 Parental Leave Notice and Top-Up Application

## 9. Historique des modifications

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.0 | 2026-01-01 | Première version, conforme à HR-SUP-001 version 2.0. |
