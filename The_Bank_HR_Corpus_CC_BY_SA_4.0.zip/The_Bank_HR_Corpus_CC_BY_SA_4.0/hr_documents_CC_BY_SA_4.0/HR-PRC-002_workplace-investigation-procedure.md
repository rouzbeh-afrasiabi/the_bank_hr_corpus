# Workplace Investigation Procedure

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-PRC-002 |
| Title | Workplace Investigation Procedure |
| Document type | Procedure |
| Version | 4.0 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-07-08 |
| Next review | 2027-07-08 |
| Policy owner | VP Employee Relations |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | HR only |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-005, HR-POL-021, HR-POL-022, HR-PRC-001, HR-REF-002, FORM-HR-050 |

## 1. Purpose

This procedure sets out how HR runs a workplace investigation from intake to closure and how it monitors for retaliation afterwards. It implements the timelines in HR-POL-005 Workplace Harassment and Violence Prevention Policy and the fairness rules in HR-POL-021 Employee Relations and Progressive Discipline Policy. It adds operational detail only and never changes the employee-facing commitments.

## 2. Scope

The procedure applies to investigations of harassment, discrimination, violence, retaliation, and serious misconduct (theft, fraud, falsifying records, breach of confidentiality). It applies in Canada and the US. Whistleblower reports are triaged by the Ethics Office under HR-POL-022 Whistleblower and Speak-Up Policy; where a report also alleges harassment or misconduct involving employees, Employee Relations investigates that part under this procedure. Where applicable law gives a greater right, the law applies.

## 3. Roles

| Role | Responsibility |
| --- | --- |
| Designated recipient (Employee Relations) | Receives the complaint, acknowledges it, arranges interim measures, assigns the investigator. |
| ER consultant | Case owner in the HR Case Portal; writes the scoping memo; monitors timelines. |
| Investigator | Trained and impartial; internal or external; reports findings. |
| Decision-maker | The VP Employee Relations in serious cases; otherwise the ER consultant with the business unit Director. |
| HRBP | Supports the parties and helps with interim measures; is never the investigator. |
| Legal | Reviews external investigator engagements, reports in sensitive cases and any threat of litigation. |
| Corporate Security | Handles safety planning and evidence from building access and video where approved. |

## 4. Timeline at a glance

| Step | Timeline | Owner |
| --- | --- | --- |
| Acknowledge the complaint to the complainant | Within 2 business days of the report | Designated recipient |
| Scoping memo issued | Within 2 business days of the report | ER consultant |
| Interim measures in place where needed | Within 5 business days of the report | ER consultant and HRBP |
| Investigation completed | Within 60 calendar days of the report | Investigator |
| Written outcome to both parties | Within 10 business days after the investigator's report | Decision-maker |
| Request for review of the outcome | Within 10 business days of the outcome | Either party |
| Retaliation monitoring | 12 months after closure | ER consultant |

Harassment and safety matters are P1 urgent requests with a first response within 4 business hours (HR-GDE-004 HR Service and Support Guide). Calendar days run from the day the report is received; business days exclude weekends and Bank holidays.

## 5. Step-by-step procedure

### 5.1 Intake

1. Confirm the complaint is logged in the HR Case Portal as ER-HAR or ER-CND (HR-PRC-001 Employee Relations Case Handling Playbook). Complete FORM-HR-050 with the complainant if the report was verbal.
2. Set priority P1 for harassment, violence or retaliation. If anyone is in immediate danger, direct them to call 911 and then Corporate Security (1-800-555-0119).
3. Send the written acknowledgement within 2 business days. It names the process, the investigation target of 60 calendar days, the right to a support person who is not legal counsel, the ban on retaliation and the Wellspring Support Program (1-800-555-0166).

### 5.2 Decision point: is an investigation needed?

| Situation | Action |
| --- | --- |
| Allegation, if true, would breach HR-POL-005, HR-POL-001 or another policy | Investigate |
| Conduct is admitted and facts are not in dispute | Fact confirmation may replace a full investigation; the decision-maker records the reason |
| Complaint is a disagreement or reasonable management action (HR-POL-005, section 3.4) | Close as not a policy matter; offer coaching, mediation or the Ombuds Office |
| Complainant asks for informal resolution | Offer mediation only if the allegation is not serious, both parties agree and no safety risk exists; the formal option stays open |
| Anonymous report through the Speak-Up Line | Investigate as far as the information allows |

A complainant who withdraws does not end the Bank's duty to act where the allegation is serious.

### 5.3 Scoping memo (within 2 business days)

The ER consultant issues a scoping memo that sets out: the allegations in neutral words; the policy provisions in question; the parties and likely witnesses; the evidence to collect; any safety risk; the investigator proposed; and the target dates. The VP Employee Relations approves the memo where the respondent is Band 7 or above or the allegation is of violence or sexual harassment.

### 5.4 Interim measures (within 5 business days)

Consider separation, changed reporting lines, adjusted schedules or remote work, restricted system access, or suspension with pay. A suspension with pay pending investigation is up to 10 business days with HRBP and ER approval; the VP Employee Relations may extend it in writing with the reason and a new end date (HR-POL-021). Tell the respondent in writing why the suspension is applied, that pay and benefits continue and who to contact. Interim measures must not disadvantage the complainant and are not a finding.

### 5.5 Investigator assignment and independence

1. Assign a trained investigator who has no stake in the outcome, no reporting line to a party and no prior involvement.
2. Use an external investigator where the respondent is Band 7 or above, an ER consultant or HRBP is involved, the investigator would not be seen as independent, or the matter involves Legal exposure.
3. The investigator signs an independence and confidentiality statement and the ER consultant files it.
4. The investigator does not advise the decision-maker on the outcome; the decision-maker does not direct the findings.

### 5.6 Interview plan and evidence

1. Prepare an interview plan: order of interviews (complainant, respondent, witnesses), questions linked to each allegation, documents to review.
2. Collect evidence early: messages, emails, schedules, badge records and notes. Requests to Security or Technology need a documented reason. Requests to the SOC for message data go through the Privacy Office (HR-PRC-008 Privacy Request and Incident Handling Procedure).
3. Preserve evidence. Do not alter or delete anything; if litigation is possible, Legal issues a legal hold.

### 5.7 Interviews

- The complainant and respondent may bring a support person who is not legal counsel.
- The respondent receives the allegations in writing before the interview and has a fair chance to respond. The respondent may also respond in writing within 5 business days of receiving the allegations.
- Remind each person about confidentiality and the ban on retaliation. Confidentiality does not prevent speaking to a lawyer, union or employee representative where applicable, a regulator or a counsellor.
- Keep notes and have the interviewee confirm a summary where practical.
- Interview witnesses separately. Do not disclose more than needed.

### 5.8 Findings and report

The investigator writes a report with: allegations, process followed, evidence, credibility assessment where needed, a finding on each allegation on the balance of probabilities, and any policy breach found. The report does not recommend a specific penalty unless asked by the decision-maker. The ER consultant checks it for completeness and consistency, and Legal reviews it in sensitive cases.

If the 60 calendar days will not be met (many witnesses, leave absences), send written notice to both parties with the reason and a new date before the deadline.

### 5.9 Decision and outcome (within 10 business days of the report)

1. The decision-maker reviews the report and the consistency check against comparable cases (HR-POL-021, section 9).
2. Where a breach is substantiated, choose the outcome under HR-POL-021: coaching, training, a written warning, a final written warning, suspension, reassignment or termination. Serious cases may skip steps. Terminations follow HR-PRC-004 Termination Checklist and Protocol and need ER approval, VP Employee Relations and Legal approval.
3. Where an allegation is not substantiated and the complaint was made in good faith, the complainant is not penalized. A knowingly false complaint made in bad faith is misconduct.
4. Send the written outcome to the complainant and the respondent within 10 business days after the investigator's report. State the findings in summary, the outcome that affects each party, how to ask for a review and the retaliation reminder.
5. Offer restorative steps such as mediation where both parties agree.

### 5.10 Review of the outcome

A party may request a review in writing to the VP Employee Relations within 10 business days of the outcome. A reviewer who was not involved confirms or changes the outcome. The decision is final within the Bank's internal process. Record the request and decision in the Portal.

## 6. Retaliation monitoring (12 months)

On closure, the ER consultant sets a retaliation watch in the Portal for 12 months. Check in with the complainant, witnesses and manager at 30 days, 90 days, 6 months and 12 months, and look for changes in schedule, rating, pay, duties or access that follow the complaint. Treat any suspected retaliation as a new P1 complaint under HR-POL-005. Retaliation is serious misconduct.

## 7. Records

Keep the complaint, scoping memo, interview notes, evidence log, report, decision and outcome letters in a restricted investigation file in the Portal, separate from the general personnel file. Investigation files are kept for 10 years after closing (HR-REF-002 Employee Records Retention Schedule). Only people with a need to know have access, and access is logged. Disciplinary steps are recorded in the confidential employee file.

## 8. Closing checklist

- [ ] Acknowledgement within 2 business days.
- [ ] Scoping memo within 2 business days.
- [ ] Interim measures decided within 5 business days.
- [ ] Independence statement filed.
- [ ] Investigation closed within 60 calendar days, or extension notice sent.
- [ ] Outcome sent within 10 business days after the report.
- [ ] Review rights explained.
- [ ] Retaliation watch set for 12 months.
- [ ] File closed and retention date set.

## 9. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 4.0 | 2025-09-01 | Aligned with HR-POL-005 version 5.0: scoping memo, external investigator criteria, 12-month retaliation monitoring and the outcome timeline. |
| 3.0 | 2023-05-01 | Introduced the HR Case Portal investigation file and the independence statement. |
