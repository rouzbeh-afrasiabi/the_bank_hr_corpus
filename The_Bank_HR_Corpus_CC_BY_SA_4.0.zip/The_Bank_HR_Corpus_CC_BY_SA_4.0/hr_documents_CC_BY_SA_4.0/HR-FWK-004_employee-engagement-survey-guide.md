# Employee Engagement Survey Guide

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-FWK-004 |
| Title | Employee Engagement Survey Guide |
| Document type | Framework |
| Version | 2026.1 |
| Status | Current |
| Effective date | 2026-08-24 |
| Last reviewed | 2026-09-01 |
| Next review | 2027-09-01 |
| Policy owner | SVP Talent and Learning |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | Managers |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-016, HR-POL-024, HR-POL-022, HR-GDE-005, HR-POL-011 |

## 1. Purpose

This guide explains how the Bank listens to its employees through the annual engagement survey and shorter pulse surveys, how confidentiality is protected, and what leaders and managers must do with the results. Its aim is that employees see their feedback turn into action.

## 2. Scope

The guide covers the annual survey and pulse surveys for all employees in Canada and the US, including regular, fixed-term and casual employees. Contractors and agency workers are not surveyed. Participation is voluntary. Employees in Quebec receive the survey in French and English. Where applicable law gives a greater right, the law applies.

## 3. Survey overview

| Item | Annual survey | Pulse survey |
| --- | --- | --- |
| Timing | 8 to 22 September each year | February, May and August |
| Length | 48 questions | 12 questions |
| Vendor | Pulsepoint, an independent survey vendor | Pulsepoint |
| Anonymity | Anonymous; minimum reporting group of 10 respondents | Same |
| Participation target | 85% | Tracked, no formal target |

The annual survey for 2026 ran from 2026-09-08 to 2026-09-22.

## 4. Content of the annual survey

The 48 questions cover eight themes.

| Theme | Questions |
| --- | --- |
| Overall engagement | 6 |
| Leadership and strategy | 6 |
| Manager effectiveness | 8 |
| Inclusion and belonging | 6 |
| Growth and development | 6 |
| Recognition and pay | 4 |
| Wellbeing and workload | 6 |
| Ethics and speaking up | 6 |
| **Total** | **48** |

The pulse survey uses 12 questions drawn from these themes and may include one question on a topic chosen by the SVP Talent and Learning. Each question is answered on a five-point agreement scale, with an optional comment box.

## 5. Confidentiality and data protection

5.1 **Anonymous.** Responses are collected by Pulsepoint. Managers and HR do not see individual responses or names.

5.2 **Minimum reporting group of 10.** Results are reported only for groups of at least 10 respondents. A smaller group is combined with a larger one or is not reported. The same rule applies to any cut by demographic or location, so a person cannot be identified from a combination of cuts.

5.3 **Comments.** Comments are reviewed to remove names and identifying details before leaders see them. A comment that describes harassment, violence or a safety or legal risk is referred to Employee Relations or Corporate Security so that it can be investigated without identifying the writer; employees who want an issue to be dealt with individually should use the Speak-Up Line (HR-POL-022 Whistleblower and Speak-Up Policy) or HR-POL-005.

5.4 **Privacy.** The survey vendor and process were assessed under HR-POL-016 Employee Data Privacy Policy (Privacy Impact Assessment, FORM-HR-091). Survey data is used only for the purposes in this guide. It is not used to rate, discipline or select any individual, and no one may try to identify respondents.

5.5 **Retaliation.** The Bank prohibits retaliation against anyone for taking part or for what they say. A manager who pressures a team to answer in a particular way, or asks who wrote a comment, breaches the Code of Conduct and Ethics (HR-POL-001).

## 6. Annual timeline

| Step | Date |
| --- | --- |
| Survey opens | 8 September |
| Survey closes | 22 September |
| Results to leaders | By 15 November |
| Team results discussions | In the weeks after the results are released |
| Action plans completed in MyHR | By 31 January |
| Pulse surveys | February, May, August |

If a date falls on a weekend or Bank holiday it moves to the next business day.

## 7. Participation

7.1 The Bank's participation target is 85% of employees. Participation by team is shown to managers in real time during the survey, without any information about who has responded.

7.2 Managers may remind their teams of the survey and allow time during working hours to complete it (about 15 minutes). Managers must not offer rewards, give lists of those who have answered, or press anyone to take part.

7.3 Employees on leave may answer the survey if they have access and wish to do so, and are not contacted by their managers for this purpose.

## 8. Using the results

### 8.1 Leaders

Business unit heads and senior leaders receive results by 15 November. They review the strengths and gaps, set priorities for the business unit, and publish a short message to employees on what they heard and what they will do.

### 8.2 Managers

Managers with a reportable group (10 respondents or more) receive a team report and, with their HRBP, hold a results discussion with their team. The conversation should cover what is working, the one or two areas to improve, and who will do what. Managers should listen and not ask for explanations from individuals. See HR-GDE-005 Manager's HR Procedures Guide for facilitation tips.

### 8.3 Action plans

Every leader and manager with a report completes an action plan in MyHR by 31 January with up to three actions, owners and dates. HRBPs review plans for the business unit and escalate gaps to the SVP Talent and Learning. Progress is checked in the February, May and August pulse surveys.

### 8.4 Teams below the minimum

Managers of teams with fewer than 10 respondents receive their results as part of the larger group's report and are expected to take part in that group's action plan.

## 9. Link to other processes

Engagement results are a source of information for inclusion priorities (HR-POL-024 Diversity, Equity, Inclusion and Belonging Policy), workload and wellbeing planning and learning priorities. Results about leadership behaviours are discussed in leaders' development conversations. They are not an input to the individual year-end rating under HR-POL-011 Performance Management Policy; however, taking action on the feedback is an expectation of every leader.

## 10. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| SVP Talent and Learning | Owns this guide; sponsors the survey; reports company-wide results to the CHRO and Executive Committee |
| Business unit head | Reviews results, publishes priorities, ensures plans are done |
| Manager | Encourages participation, holds the results discussion, completes the action plan |
| HRBP | Supports managers, checks plans, protects confidentiality |
| Pulsepoint | Runs the survey, protects data, applies the minimum reporting group |
| Employee | Answers honestly if they choose and takes part in team follow-up |

## 11. Contacts

Questions: HR Connect, 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time, hrconnect@bank.example. Managers: Manager Hotline 1-800-555-0143.

## 12. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2026.1 | 2026-08-24 | 2026 edition: 48-question annual survey, three 12-question pulse surveys, minimum reporting group of 10 respondents, action plans due by 31 January. |
| 2025.1 | 2025-08-25 | 2025 edition. |
