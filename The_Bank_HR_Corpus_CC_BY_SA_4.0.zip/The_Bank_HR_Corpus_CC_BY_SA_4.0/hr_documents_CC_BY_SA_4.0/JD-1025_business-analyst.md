# Business Analyst

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1025 |
| Title | Business Analyst |
| Document type | Job description |
| Version | 1.3 |
| Status | Current |
| Effective date | 2025-05-01 |
| Last reviewed | 2026-07-21 |
| Next review | 2027-07-21 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-POL-002, HR-POL-016, HR-POL-018 |

## 1. Role summary

The Business Analyst links business teams and technology delivery teams. The analyst elicits and documents requirements, analyses current processes, shapes solutions with developers and testers and makes sure delivered changes meet the business need. A Band 4 analyst handles complex, cross-team initiatives, advises colleagues and is recognized for depth in a business domain such as payments, lending or onboarding.

## 2. Key responsibilities

- Run workshops and interviews with business stakeholders to define problems, goals and success measures.
- Document current and future processes, requirements and acceptance criteria clearly and traceably.
- Prioritize the backlog with product owners, balancing value, risk, effort and regulatory deadlines.
- Write user stories and detailed functional specifications for developers, and answer questions during build.
- Analyse data to size problems, test hypotheses and measure the benefits of change.
- Plan and support user acceptance testing, including test scenarios, defect triage and sign-off.
- Identify privacy, security and conduct implications early and involve the relevant Bank teams (see HR-POL-016 Employee Data Privacy Policy for employee-data processes).
- Prepare change-management and training material with business owners.
- Report progress, risks and dependencies to the Senior Manager, Technology Delivery.
- Coach Professional-level analysts on requirements practice.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in business, information systems, finance, engineering or a related field.
- Typically 5 to 8 years of experience in business analysis or product delivery, ideally in financial services.
- Skill in process modelling, requirements documentation and stakeholder facilitation.
- Working data skills, including querying and summarizing data sets.

### 3.2 Preferred

- Recognized business-analysis certification, or PMP.
- Experience with agile delivery in a regulated environment.
- Familiarity with banking products and regulatory change.

### 3.3 Licences and certifications

None required.

## 4. Competencies

Measured against HR-FWK-001 Competency and Leadership Model at the Practitioner level:

- Collaboration
- Judgement and Decision Quality
- Customer Obsession
- Drive for Results
- Adaptability
- Developing Others

## 5. Compensation and classification

| Item | Value |
| --- | --- |
| Band | 4 (Senior Professional) |
| Canada range | $72,000 to $108,000 CAD |
| US range | $70,000 to $106,000 USD |
| Incentive target | 8% of base salary (Annual Incentive Plan) |
| Overtime eligibility, Canada | Yes (non-managerial Band 4) |
| FLSA classification, US | Exempt |
| Work arrangement | Hybrid (at least 3 days a week in the office) |

Band definitions are in HR-GDE-006 Job Architecture and Pay Bands Guide.

## 6. Working conditions and accessibility

This is an office role with a hybrid arrangement: at least 3 days a week in the office, with Tuesday and Thursday as anchor days (HR-POL-002 Remote and Hybrid Work Policy). Occasional travel to other Bank sites for workshops may be required. Core hours are 10:00 to 15:00 local time. The Bank provides accommodation to the point of undue hardship; see HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to: Senior Manager, Technology Delivery. Direct reports: none.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.3 | 2025-05-01 | Added data and privacy responsibilities |
| 1.2 | 2024-03-01 | Hybrid wording updated |
| 1.0 | 2023-05-01 | First issue |
