# Payroll Correction Request

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-021 |
| Title | Payroll Correction Request |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-009, HR-POL-003, HR-GDE-004, FORM-HR-022 |

## 1. Purpose and when to use this form

Use this form to report a suspected pay error: a missed or short payment, missing overtime or premium, or a wrong deduction. Retroactive corrections go back up to 24 months. To change bank details or tax withholding, use FORM-HR-022 instead.

## 2. Who completes it and who approves

You complete it. Payroll Services reviews, confirms the error and corrects it. Your manager may be asked to confirm hours.

## 3. Where and when to submit

Submit through the HR Case Portal in MyHR as soon as you see the error. A missed pay is a P1 urgent case with a first response within 4 business hours. Other requests receive a first response within 2 business days.

## 4. Form fields

| Field | Required | Notes |
| --- | --- | --- |
| Pay date and pay period | Yes | Periods end on the Saturday before the pay date |
| Type of error | Yes | Underpayment, missed pay, overtime, deduction, other |
| Estimated net amount | Yes | In CAD (Canada) or USD (US) |
| Explanation | Yes | What you expected and why |
| Supporting evidence | Yes | Pay statement, Time Tracker entries, approval message |
| Manager | Yes | Pre-filled |

## 5. Declarations and signatures

- The information is accurate and complete.
- I understand that if I was overpaid I must tell Payroll Services; failing to report a known overpayment is a breach of HR-POL-001 Code of Conduct and Ethics.

## 6. What happens next

Once Payroll Services confirms the error:

| Net underpayment | Correction |
| --- | --- |
| $250 or more | Paid off-cycle within 3 business days of confirmation |
| Under $250 | Corrected on the next regular pay date |

Changes entered after the payroll cut-off (17:00 Eastern Time, five business days before the pay date) are processed on the next pay date. For an overpayment, Payroll Services writes to you with the amount, dates and cause. You may repay by lump sum, by payroll deduction of no more than 15% of net pay per pay period, or by a plan of up to 12 months. Where law requires written consent first (for example in California), it is obtained before any deduction. Where applicable law gives a greater right, the law applies.

## 7. Related documents

- HR-POL-009 Compensation and Payroll Policy
- HR-POL-003 Working Hours and Overtime Policy
- HR-GDE-004 HR Service and Support Guide

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-03-01 | Off-cycle correction threshold stated as $250 (HR-POL-009 version 7.2). |
