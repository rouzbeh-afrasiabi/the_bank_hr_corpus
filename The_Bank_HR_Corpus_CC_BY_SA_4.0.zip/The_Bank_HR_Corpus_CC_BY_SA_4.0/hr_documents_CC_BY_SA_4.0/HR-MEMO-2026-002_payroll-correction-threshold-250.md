# Payroll Correction Threshold Rises to $250 on 1 March 2026

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-MEMO-2026-002 |
| Title | Payroll Correction Threshold Rises to $250 on 1 March 2026 |
| Document type | Memo |
| Version | 1.0 |
| Status | Current |
| Effective date | 2026-02-10 |
| Last reviewed | Not applicable |
| Next review | Not applicable |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-009, FORM-HR-021, HR-POL-011, HR-GDE-004 |

**Off-cycle pay corrections now start at $250, up from $200.**

**From:** SVP Total Rewards

**To:** All employees in Canada and the US

**Date:** 10 February 2026

**Subject:** Payroll correction threshold and 2026 salary review, HR-POL-009 version 7.2

## 1. What is changing

| Item | Old (version 7.1) | New (version 7.2) |
| --- | --- | --- |
| Net underpayment paid off-cycle within 3 business days of confirmation | $200 or more | $250 or more |
| Net underpayment corrected on the next regular pay date | Under $200 | Under $250 |

The 2026 salary review is also effective 1 March 2026, based on your year-end rating (HR-POL-011).

## 2. Who is affected

All employees who are paid by Payroll Services.

## 3. Effective date

1 March 2026.

## 4. What to do

1. If you think you were underpaid, report it through the HR Case Portal in MyHR using FORM-HR-021 (Payroll Correction Request).
2. Check your pay statement in MyHR; it is posted 2 business days before the pay date.
3. Send changes such as bank details or tax forms by 17:00 Eastern five business days before the pay date so they are processed in that cycle.
4. Retroactive corrections go back up to 24 months.

An urgent matter such as a missed pay is a P1 case with a first response within 4 business hours.

## 5. Who to call

HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, or live chat in MyHR.

## 6. Related documents

- HR-POL-009 Compensation and Payroll Policy
- FORM-HR-021 Payroll Correction Request
- HR-GDE-004 HR Service and Support Guide
