# Trading Analyst

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1019 |
| Title | Trading Analyst |
| Document type | Job description |
| Version | 1.2 |
| Status | Current |
| Effective date | 2025-03-01 |
| Last reviewed | 2026-07-14 |
| Next review | 2027-07-14 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-POL-029, HR-POL-032, HR-SUP-003 |

## 1. Role summary

The Trading Analyst supports a Capital Markets trading desk by preparing pricing and risk information, monitoring positions and limits, and keeping trade records accurate from execution to settlement. The role works beside the Senior Trader throughout the trading day and is the desk's first line of control for trade capture, break resolution and end-of-day reporting. It is an entry point into a trading career at the Bank.

## 2. Key responsibilities

- Prepare pre-market briefings: overnight moves, economic calendar, new issuance and client flow expected for the day.
- Monitor desk positions, profit and loss, and exposure against approved limits; escalate any limit warning to the Senior Trader immediately.
- Maintain pricing curves and reference data used by the desk, and check them against independent market sources.
- Enter and amend trade tickets accurately and confirm them with counterparties and middle-office teams.
- Investigate and resolve trade breaks and settlement failures the same day, recording the cause and the fix.
- Produce end-of-day position and profit-and-loss reports and reconcile them with Finance and Risk.
- Build and maintain spreadsheets and small automation scripts that reduce manual work on the desk.
- Support client requests for indicative prices and market commentary under the guidance of a licensed trader.
- Keep the restricted list, watch list and personal trading rules front of mind and escalate possible conflicts to Compliance.
- Contribute to the desk's review of recorded-line and communication-surveillance alerts.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in finance, economics, mathematics, engineering or a related field, or equivalent experience.
- Typically 2 to 5 years of experience in a trading, treasury, risk or markets operations environment.
- Working knowledge of fixed income, equities, foreign exchange or derivatives products.
- Strong numeracy and the ability to work accurately under time pressure.

### 3.2 Preferred

- Progress toward the CFA designation.
- Experience with scripting for data analysis and with market data terminals in general.
- Bilingual English and French, for Canadian client coverage.

### 3.3 Licences and certifications

Under HR-POL-029 Licensing, Registration and Qualification Policy, securities registration is required before any licensed duties begin: the applicable provincial securities registration in Canada, and the Series 7 and Series 63 examinations (and others the desk requires) in the US. No licensed duties until the licence is active. The Bank pays the exam and registration fees.

## 4. Competencies

Measured against HR-FWK-001 Competency and Leadership Model at the Practitioner level:

- Judgement and Decision Quality
- Risk and Conduct Awareness
- Drive for Results
- Collaboration
- Adaptability

## 5. Compensation and classification

| Item | Value |
| --- | --- |
| Band | 3 (Professional) |
| Canada range | $56,000 to $84,000 CAD |
| US range | $55,000 to $82,000 USD |
| Incentive target | 5% of base salary (Annual Incentive Plan) |
| Overtime eligibility, Canada | Yes (non-managerial Band 3) |
| FLSA classification, US | Exempt |
| Work arrangement | On-site (trading floor) |

Band definitions and how pay is placed are in HR-GDE-006 Job Architecture and Pay Bands Guide.

## 6. Working conditions and accessibility

This is an on-site role on the Capital Markets trading floor; hybrid work does not apply. Trading-day hours are set by the desk, and calls and chats are recorded. Employees in this role are covered persons under HR-POL-032 Personal Trading and Restricted Lists Policy and are subject to the Capital Markets Addendum (HR-SUP-003). The Bank provides accommodation to the point of undue hardship; see HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to: Senior Trader. Direct reports: none.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.2 | 2025-03-01 | Updated licence wording and competencies |
| 1.1 | 2024-04-01 | Added control responsibilities |
| 1.0 | 2023-03-01 | First issue |
