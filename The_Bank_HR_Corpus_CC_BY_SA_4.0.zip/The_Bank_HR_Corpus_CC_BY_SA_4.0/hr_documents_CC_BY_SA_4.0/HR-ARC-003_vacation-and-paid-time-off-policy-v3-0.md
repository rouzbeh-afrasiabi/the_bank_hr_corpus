# Vacation and Paid Time Off Policy (version 3.0)

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

> **Archived version.** Kept for reference only. Do not rely on it. See HR-POL-006 Vacation and Paid Time Off Policy.

| Field | Value |
| --- | --- |
| Document ID | HR-ARC-003 |
| Title | Vacation and Paid Time Off Policy (version 3.0) |
| Document type | Archived version |
| Version | 3.0 |
| Status | Superseded |
| Superseded by | HR-POL-006 Vacation and Paid Time Off Policy, version 4.0 (effective 2026-01-01) |
| Effective date | 2024-01-01 |
| Last reviewed | Not applicable |
| Next review | Not applicable |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-006, HR-POL-007, HR-POL-010, FORM-HR-010 |

## 1. Status of this version

Version 3.0 was in force from 1 January 2024 to 31 December 2025. Version 4.0 replaced it on 1 January 2026 and raised the carryover limit. Only the carryover limit differs from the current policy; the entitlement table and all other rules shown here are the same as in HR-POL-006.

## 2. Purpose, scope and definitions

The policy set out how vacation was earned, requested, approved, carried over and paid out. It applied to regular full-time, regular part-time, fixed-term and casual employees in Canada and the US (HR-POL-014 Employment Status and Classification Policy). Where applicable law gave a greater right, the law applied.

- **Vacation year:** the calendar year, 1 January to 31 December.
- **Completed service:** whole years of continuous service on 1 January.
- **Vacation day:** one scheduled working day (7.5 hours in Canada, 8 hours in the US).
- **Block leave:** at least 10 consecutive business days of vacation.

## 3. Entitlement and accrual

| Completed service | Days per year (Canada and US) | Monthly accrual |
| --- | --- | --- |
| Less than 3 years | 15 | 1.25 |
| 3 to under 10 years | 20 | 1.67 |
| 10 to under 20 years | 25 | 2.08 |
| 20 years or more | 30 | 2.5 |

The tier applied for the whole calendar year. New hires accrued monthly from the start date, pro-rated and rounded up to the nearest half day, and could request vacation from day 1 but take it only after the first 3 months of service. Regular part-time employees accrued pro-rated by scheduled hours. Casual employees received 6% vacation pay in lieu on every paycheque and had no vacation days. Accrual continued during paid sick days, short-term disability and the Bank-paid top-up period of parental leave, and stopped after 30 days of a personal leave of absence (HR-POL-007 Sick Leave and Personal Leave Policy).

## 4. Requesting vacation

Requests were made in MyHR: at least 4 weeks ahead for 5 or more days, and at least 5 business days ahead for fewer than 5 days. The manager responded within 5 business days; if there was no response, MyHR escalated the request to the manager's manager. Business units could set blackout periods (the last 2 weeks of December for some branch roles; the fiscal year-end week for Capital Markets). A statutory holiday during vacation was not charged against the balance (HR-POL-010 Statutory Holidays Policy).

## 5. Mandatory block leave

Every employee had to take at least 10 consecutive business days of vacation once per calendar year. Capital Markets, Wealth Management and Finance roles were audited by the Chief Compliance Officer's office. The block was scheduled in MyHR by 30 June and completed by 31 December.

## 6. Carryover, advances and payout

### 6.1 Carryover (version 3.0)

Up to **3** unused vacation days could be carried into the next calendar year and had to be used by **31 March** of that year. All other unused days were forfeited, except where the employee was on an approved leave that prevented use, or where the law required payment.

### 6.2 Advance and payout

With manager approval an employee could take up to 5 days ahead of accrual; any advance outstanding at the end of employment was recovered from final pay. Vacation was not paid out during employment. On termination, unused earned vacation was paid in all Canadian provinces and territories and all US states.

## 7. Related paid days

Personal days: 3 per calendar year (HR-POL-007). Volunteer day: 1 paid day per calendar year (HR-POL-026 Bereavement, Jury Duty and Other Leaves Policy). Floating days: 2 per calendar year (HR-POL-010).

## 8. Worked example (version 3.0)

An employee with 20 days had taken 12 days by 31 December 2024, leaving 8 unused. Under version 3.0, 3 days carried over into 2025 (to be used by 31 March 2025) and 5 were forfeited. Under the current policy 5 days would carry over.

## 9. Exceptions and contacts

Exceptions needed the approval of the SVP Total Rewards. HR Connect: 1-800-555-0142, hrconnect@bank.example. Managers: 1-800-555-0143.

## 10. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.2 | 2022-01-01 | Previous version. Unused vacation was forfeited at year-end except where law required otherwise. |
| 3.0 | 2024-01-01 | Introduced carryover of 3 days, to be used by 31 March. Added mandatory 10-day block leave audit for Capital Markets, Wealth Management and Finance. |
| 4.0 | 2026-01-01 | Superseded this version; carryover increased to 5 days (see HR-POL-006) |
