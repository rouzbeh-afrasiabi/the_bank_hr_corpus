# Annual Benefits Enrolment: 2 to 16 November 2026

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-MEMO-2026-007 |
| Title | Annual Benefits Enrolment: 2 to 16 November 2026 |
| Document type | Memo |
| Version | 1.0 |
| Status | Current |
| Effective date | 2026-09-14 |
| Last reviewed | Not applicable |
| Next review | Not applicable |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-001, HR-PLN-004, HR-PLN-007, HOW-044 |

**Choose your 2027 benefits between 2 and 16 November 2026.**

**From:** SVP Total Rewards

**To:** All benefits-eligible employees in Canada and the US

**Date:** 14 September 2026

**Subject:** Annual benefits enrolment for the 2027 plan year

## 1. What is changing

Annual enrolment runs from 2 to 16 November 2026 for coverage from 1 January 2027. The 2027 premiums are posted in MyHR on 2 November 2026. If you make no election, you are enrolled by default in Standard (Canada) or Choice PPO employee-only (US), which may differ from your current choice.

## 2. Who is affected

Regular full-time and part-time employees, and fixed-term employees of 6 months or more. See HR-GDE-001 Employee Benefits Guide.

## 3. Effective date

Coverage begins 1 January 2027. The plan year is 1 January to 31 December.

## 4. What to do

1. From 2 November, review the 2027 premiums and plan details in MyHR.
2. Make or confirm your election, including dependants, in MyHR by 16 November 2026.
3. Check your dependants: in Canada, children to age 21 (26 if a full-time student); in the US, to age 26.
4. Claim your 2026 wellness spending account by 31 March 2027.
5. Read HOW-044 for a preparation checklist.

## 5. Who to call

HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, or live chat in MyHR. Maplewood Benefits claims line: 1-800-555-0190.

## 6. Related documents

- HR-GDE-001 Employee Benefits Guide
- HR-PLN-004 Group Benefits Booklet (Canada)
- HR-PLN-007 Benefits Claims and Appeals Guide
