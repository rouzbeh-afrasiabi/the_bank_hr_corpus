# Group Benefits Booklet (Canada)

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-PLN-004 |
| Title | Group Benefits Booklet (Canada) |
| Document type | Plan document |
| Version | 2026.1 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-10-20 |
| Next review | 2027-10-20 |
| Policy owner | SVP Total Rewards |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | Employees |
| Jurisdiction | Canada |
| Language | English |
| Related documents | HR-GDE-001, HR-PLN-007, HR-POL-007, HR-POL-014, HR-GDE-004, HR-POL-015 |

## 1. Purpose and status of this booklet

This booklet is the formal plan-document description of the group health, dental, vision, life and wellness benefits that the Bank provides to eligible employees in Canada for plan year 2026 (1 January to 31 December 2026). It sets out the definitions, the schedule of benefits, the exclusions, the rules for claiming and coordinating benefits, and the circumstances in which coverage ends.

HR-GDE-001 Employee Benefits Guide is the plain-language companion to this booklet and covers both countries. If the Maplewood Benefits group insurance contract and this booklet differ, the contract governs the decision on a claim. Where applicable law gives a greater right, the law applies. Claims and appeals mechanics are set out in HR-PLN-007 Benefits Claims and Appeals Guide.

## 2. Definitions

In this booklet:

- **Plan** means the Bank's group benefits plan for employees in Canada, insured and administered by Maplewood Benefits.
- **Plan year** means 1 January to 31 December.
- **Member** means an eligible employee who is enrolled in the Plan.
- **Dependant** means an eligible person described in section 4.
- **Eligible expense** means a reasonable and customary charge for a covered service or supply that is medically necessary, is not excluded under section 11, and is incurred while the person is covered.
- **Family coverage** means coverage for the member and at least one dependant; **employee-only coverage** means coverage for the member alone.
- **Predetermination** means a written statement from Maplewood Benefits, issued before treatment, of the amount the Plan would pay.
- **Benefits Administration** means the team in HR Operations that manages enrolment, premium deductions and eligibility.

## 3. Eligibility and enrolment

### 3.1 Eligible employees

The following employees in Canada are eligible for the health, dental, vision and insurance benefits in this booklet from their first day of employment: regular full-time employees, regular part-time employees, and fixed-term employees whose contract is 6 months or more. Fixed-term employees under 6 months, casual employees, and students, co-op students and interns are eligible only for the Wellspring Support Program. Contractors and agency workers are not employees and are not eligible. The classification rules are in HR-POL-014 Employment Status and Classification Policy.

### 3.2 When to enrol

A new employee must enrol in MyHR (Benefits, then Enrol) within 31 days of the start date or of a qualifying life event. A qualifying life event is marriage or a common-law partnership, birth or adoption of a child, loss of other coverage, or a change in dependant status. Outside those windows, elections may be changed only at annual enrolment. Annual enrolment for plan year 2027 runs from 2 to 16 November 2026, and elections take effect on 1 January 2027.

### 3.3 Default election

An employee who makes no election is enrolled in the Standard plan with employee-only coverage. The default stays in place until the next annual enrolment or a qualifying life event.

### 3.4 Premiums

Employee premiums are deducted monthly from pay.

## 4. Dependants

The following are eligible dependants of a member with family coverage:

- the member's spouse, common-law partner or domestic partner; and
- the member's children to age 21, or to age 26 if the child is a full-time student.

Benefits Administration may ask for proof of the relationship or student status. A member who gives false dependant information breaches HR-POL-001 Code of Conduct and Ethics, and benefits paid in error may be recovered.

## 5. Schedule of benefits

All amounts are in CAD. Employees choose one of three plan options.

| Item | Essential | Standard | Enhanced |
| --- | --- | --- | --- |
| Employee premium per month, employee only | $0 | $22 | $48 |
| Employee premium per month, family | $65 | $138 | $205 |
| Prescription drugs | 70% | 80% | 90% |
| Dental basic | 70% | 80% | 90% |
| Dental major | not covered | 50% | 60% |
| Annual dental maximum | $1,500 | $2,500 | $3,500 |
| Orthodontics | not covered | not covered | 50%, $2,500 lifetime |
| Vision, per 24 months | $150 | $250 | $400 |
| Paramedical combined, per year | $500 | $1,000 | $2,000 |
| Mental health practitioners, per year | $1,500 | $2,500 | $4,000 |

Percentages are the share of the eligible expense paid by the Plan; the member pays the remainder. Dollar maximums apply per covered person unless stated otherwise.

## 6. Features of every plan option

The following apply to Essential, Standard and Enhanced:

1. **Hospital:** semi-private hospital accommodation.
2. **Virtual care:** unlimited virtual care visits.
3. **Emergency travel medical:** coverage of 60 days per trip, with a lifetime maximum of $5,000,000.
4. **Generic substitution:** where a generic equivalent is available and the member chooses the brand-name drug, the Plan reimburses on the basis of the generic price and the member pays the difference.
5. **Dental recall:** one recall examination every 9 months.

## 7. Life, accidental death and critical illness insurance

| Benefit | Amount | Who pays |
| --- | --- | --- |
| Basic life insurance | 2x annual base salary | Bank |
| Accidental death and dismemberment | 2x annual base salary | Bank |
| Optional employee life | 1x to 6x annual base salary, maximum $2,000,000 | Employee |
| Optional spouse life | $25,000 | Employee |
| Dependent child life | $10,000 | Employee |
| Optional critical illness | $25,000, $50,000 or $100,000 | Employee |

Evidence of insurability, reviewed by Maplewood Benefits, is required for optional employee life above 4x annual base salary or above $750,000. The proceeds of life insurance are paid to the beneficiary named in MyHR; if no valid designation is on file, the group contract and applicable law determine the payee.

## 8. Disability benefits

Short-term and long-term disability benefits are employer-paid and administered by Maplewood Benefits. Their terms, the waiting period and the application deadline are set out only in HR-POL-007 Sick Leave and Personal Leave Policy. They are not part of the schedule in this booklet, but the claims and appeals process in HR-PLN-007 applies to them.

## 9. Wellness spending account and assistance program

### 9.1 Wellness spending account

Each eligible employee has a wellness spending account of $500 CAD per calendar year for eligible health and wellness expenses such as fitness memberships, equipment, nutrition counselling and mindfulness programs. Claims for a plan year must be submitted by 31 March of the following year; for plan year 2026 the deadline is 31 March 2027. Unused balances are forfeited and do not carry over.

### 9.2 Wellspring Support Program

The Wellspring Support Program provides confidential counselling at 1-800-555-0166, 24 hours a day, 7 days a week, with up to 8 sessions per issue per calendar year for employees and household members at no cost. It is open to every employee, whether or not enrolled in the Plan.

## 10. Predetermination of dental work

Before major dental work with an estimated cost above $500, the member should ask the dentist to submit a treatment plan to Maplewood Benefits for predetermination. Maplewood Benefits replies in writing with the amount the Plan would pay under the member's plan option. A predetermination is an estimate, valid only while the member remains covered and the maximums in section 5 have not been used up by other claims. Work performed without predetermination is still payable if it is otherwise an eligible expense.

## 11. Exclusions

No benefit is payable under the Plan for an expense that results from, or is incurred for:

1. cosmetic treatment or surgery, unless needed to repair damage from an accident or a covered surgery;
2. experimental or investigational treatment, being treatment that is not accepted as standard practice by the medical community in Canada;
3. an injury or illness arising from the member's or dependant's participation in a criminal act;
4. an injury or illness caused by war, whether declared or not, or by an act of armed conflict;
5. services or supplies that are free under a government plan or that a government plan is required by law to pay;
6. an injury or illness for which workers' compensation is payable;
7. services provided by the member's own relatives or by anyone living in the member's household; and
8. services that are not medically necessary.

Personal information used to apply an exclusion is handled under HR-POL-016 Employee Data Privacy Policy.

## 12. Coordination of benefits

### 12.1 General rule

If a person is covered under this Plan and also under another group plan, the plans coordinate so that the total reimbursement from all plans does not exceed 100% of the eligible expense. The plan covering the person as an employee or member pays first. For a dependent child covered under both parents' plans, the plan of the parent whose birthday falls earlier in the calendar year pays first.

### 12.2 Member's duty

A member must tell Maplewood Benefits about other coverage, claim from the primary plan first, and then submit the balance with the primary plan's statement to this Plan.

## 13. Making a claim

### 13.1 Time limit

A claim must be submitted within 12 months of the date of the expense. A claim submitted later is not payable unless law requires otherwise. Wellness spending account claims follow the separate deadline in section 9.1.

### 13.2 How to claim

Use a Maplewood Benefits card at a provider that offers direct billing and pay only your share. Otherwise pay the provider and submit the receipt through the Maplewood Benefits member portal, which is linked from MyHR. Claim payments are made by direct deposit to the account in the member's Maplewood Benefits profile. Maplewood Benefits decides a claim within 30 days of receiving the complete claim; see HR-PLN-007 for what to do when a claim is denied. The claims line is 1-800-555-0190.

## 14. Quebec public-plan integration

Employees in Quebec must be covered for prescription drugs under the public drug plan or under the Bank plan, as the law requires. A Quebec member covered by the public plan for prescription drugs remains eligible for every other benefit in this booklet, and this Plan coordinates with the public plan by paying only the amounts the public plan does not pay, up to the Plan's rate and maximum. A French version of this booklet is available on request.

## 15. When coverage ends

### 15.1 Employment ends

Coverage ends at the end of the month in which employment ends. For example, if the last day of employment is 14 July, coverage ends on 31 July.

### 15.2 Life insurance conversion

A member whose life insurance ends may apply to Maplewood Benefits to convert it to an individual policy within 31 days, without evidence of insurability. The cost of the individual policy is set by the carrier.

### 15.3 Retiree health access

An employee who leaves at age 55 or older with at least 10 years of service may continue health access through the retiree plan. The retiree pays 100% of the premium and should contact Benefits Administration before the last day of employment.

### 15.4 Leaves of absence

| Situation | Effect on coverage |
| --- | --- |
| Bank-paid parental leave | The Bank continues its share; see HR-POL-008 Parental and Family Leave Policy |
| Job-protected parental leave up to 18 months | The Bank continues its share throughout |
| Unpaid personal leave of absence | Coverage continues if the employee pays both shares |
| Short-term or long-term disability | See HR-POL-007 |

Benefits Administration invoices the premiums required during an unpaid leave. If they are not paid, coverage may lapse after 60 days. Offboarding steps are in HR-POL-015 Resignation and Offboarding Policy.

## 16. Disputes and appeals

A member who disagrees with a claims decision may appeal. The first-level appeal, the second-level review by the Benefits Appeals Committee, and the complaint routes available in Canada are described in HR-PLN-007 Benefits Claims and Appeals Guide. Enrolment, premium and eligibility disputes follow the service levels in HR-GDE-004 HR Service and Support Guide.

## 17. Roles and responsibilities

The member enrols on time, keeps dependants and beneficiaries current and reports other coverage. Benefits Administration processes elections and premium deductions. Maplewood Benefits decides claims and issues predeterminations. The SVP Total Rewards owns the Plan design and this booklet.

## 18. Contacts

| Need | Contact |
| --- | --- |
| General benefits questions | HR Connect, 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time, hrconnect@bank.example |
| Claims | Maplewood Benefits claims line, 1-800-555-0190 |
| Counselling | Wellspring Support Program, 1-800-555-0166, 24/7 |

## 19. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2026.1 | 2026-01-01 | Plan year 2026 edition issued as the formal plan document; definitions, exclusions, coordination of benefits and Quebec integration added |
