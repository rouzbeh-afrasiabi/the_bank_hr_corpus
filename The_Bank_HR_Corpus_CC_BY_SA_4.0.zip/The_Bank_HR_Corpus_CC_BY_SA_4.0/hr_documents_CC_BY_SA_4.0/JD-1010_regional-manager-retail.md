# Regional Manager, Retail

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1010 |
| Title | Regional Manager, Retail |
| Document type | Job description |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-09-22 |
| Next review | 2027-09-22 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-POL-002, HR-POL-038, HR-POL-018 |

## 1. Role summary

The Regional Manager, Retail leads a group of branches in a defined region and the Branch Managers and specialists who serve them, including Mortgage Specialists who report into the region. The role sets the regional operating plan, drives consistent customer experience and sales-practice standards, and oversees risk, controls and talent. The Regional Manager translates the Retail Distribution strategy into branch-level goals and removes obstacles for the branch network. This is a Band 6 (Manager II / Senior Manager) role in the Retail Banking family; see HR-GDE-006 Job Architecture and Pay Bands Guide.

## 2. Key responsibilities

- Lead, coach and evaluate the Branch Managers and Mortgage Specialists in the region.
- Build the regional operating and business plan, with goals for customer experience, growth, and risk and conduct.
- Review regional performance monthly with the Director, Retail Distribution and agree corrective actions.
- Oversee branch controls, audit and compliance results, and sales-practice monitoring across the region.
- Approve credit and operating exceptions above branch authority within delegated limits.
- Conduct regular branch visits and quality reviews.
- Manage regional staffing, hiring decisions, succession and development of branch leaders.
- Handle escalated employee relations and customer matters with the HR Business Partner and Employee Relations.
- Manage the regional budget and approve branch expenses and business travel under HR-POL-038 Business Travel and Expense Policy.
- Represent the Bank in local markets, community partnerships and regulator-facing activities as needed.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in business or a related field, or equivalent experience.
- Nine to thirteen years of retail banking experience, including at least three years managing branch managers or multiple teams.
- Demonstrated record of delivering growth while maintaining strong controls and conduct.
- Strong analytical, planning and people leadership skills.
- Satisfactory results in pre-employment screening and periodic re-screening for Band 6 roles.

### 3.2 Preferred

- Experience across both branch and specialist channels, such as mortgage or small business.
- MBA or a recognized leadership qualification.
- Fluency in English and French.

### 3.3 Licences and certifications

No licence is required for the role itself. A working understanding of HR-POL-029 Licensing, Registration and Qualification Policy is expected because licensed advisors and mortgage specialists report within the region.

## 4. Competencies

Competencies are defined in HR-FWK-001 Competency and Leadership Model; this role works at the Leader level.

- **Drive for Results**: delivers regional goals with sustainable pace.
- **Developing Others**: grows Branch Managers into future regional leaders.
- **Judgement and Decision Quality**: makes sound decisions with incomplete information.
- **Risk and Conduct Awareness**: holds the region to a high standard of conduct and control.
- **Inclusive Leadership**: builds diverse teams and an inclusive regional culture.
- **Collaboration**: aligns with specialist partners and other regions.

## 5. Compensation and classification

| Item | Detail |
| --- | --- |
| Band | 6 (Manager II / Senior Manager) |
| Canada salary range | $112,000 to $168,000 CAD per year |
| US salary range | $110,000 to $166,000 USD per year |
| Incentive target | Annual Incentive Plan (AIP): 15% of base salary |
| Overtime eligibility (Canada) | No |
| FLSA classification (US) | Exempt |
| Work arrangement | Hybrid: at least 3 days a week in the office, with branch visits scheduled around them |

## 6. Working conditions and accessibility

This is a hybrid office role with regular travel to branches within the region. Hybrid arrangements follow HR-POL-002 Remote and Hybrid Work Policy, with at least 3 days a week in the office and anchor days on Tuesday and Thursday. The Bank provides accommodation to the point of undue hardship (Canada) or reasonable accommodation (US); see HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to the Director, Retail Distribution.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-03-01 | Pay ranges updated to the 2026 pay bands; hybrid requirement aligned to HR-POL-002 v3.0 |
| 1.0 | 2023-03-01 | First issue |
