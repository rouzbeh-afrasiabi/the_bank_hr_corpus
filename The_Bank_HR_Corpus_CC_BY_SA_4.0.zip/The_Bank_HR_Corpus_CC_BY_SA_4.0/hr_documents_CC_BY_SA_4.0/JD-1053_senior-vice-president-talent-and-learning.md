# Senior Vice President, Talent and Learning

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1053 |
| Title | Senior Vice President, Talent and Learning |
| Document type | Job description |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-09-22 |
| Next review | 2027-09-22 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-POL-011, HR-POL-012, HR-POL-019, HR-FWK-001, HR-FWK-003 |

## 1. Role summary

The Senior Vice President, Talent and Learning is the enterprise leader for talent acquisition, performance, learning and development, succession and leadership programmes across the Bank. The SVP owns the competency model, the performance cycle and the recruitment framework, and is accountable for the strength of the talent pipeline. The role is Band 9 (Senior Vice President): it is accountable for an enterprise-wide function and reports into the Executive Committee through the CHRO. See HR-GDE-006 Job Architecture and Pay Bands Guide.

## 2. Key responsibilities

- Set the Bank's talent strategy, linking workforce needs, leadership pipeline and capability building to the business plan.
- Own HR-POL-011 Performance Management Policy and the annual performance cycle (1 November to 31 October), including calibration and the rating distribution guidance.
- Own HR-POL-012 Learning and Development Policy: the $2,000 annual professional development budget, tuition reimbursement, designation support and the Learning Hub mandatory-training programme.
- Own HR-POL-019 Recruitment and Selection Policy, including requisition approval levels, diverse slates for Band 5 and above and the 45-day time-to-fill target.
- Lead the annual talent review and succession process (HR-FWK-003 Talent Review and Succession Process), and report succession readiness for Band 6 and above and critical roles to the CHRO and the Board.
- Own the competency and leadership model (HR-FWK-001) and the career paths and job families guide, and the engagement survey programme.
- Sponsor leadership programmes for Band 5 and above and executive development.
- Oversee the performance improvement framework with the VP Employee Relations, and the HR Business Partnering model with the business units.
- Lead and develop a senior HR leadership team, including goals, ratings and succession for the function.
- Report talent, learning and engagement outcomes to the HR Policy Committee and the Board HR Committee.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in business, human resources, organizational psychology or a related field; MBA or master's degree preferred.
- Eighteen or more years of progressive experience in talent management, learning or HR leadership, including leading a large function.
- Proven record building talent and succession programmes in a large, regulated, multi-jurisdiction organization.
- Executive presence and ability to advise the Executive Committee and Board.

### 3.2 Preferred

- Experience in banking or financial services.
- Experience introducing AI-assisted talent tools with privacy safeguards.

## 4. Competencies

Competency names follow HR-FWK-001 Competency and Leadership Model (Enterprise Leader level, Bands 7 to 9).

- Developing Others
- Inclusive Leadership
- Judgement and Decision Quality
- Drive for Results
- Adaptability
- Collaboration
- Risk and Conduct Awareness

## 5. Compensation and classification

| Item | Detail |
| --- | --- |
| Band | 9 (Senior Vice President) |
| Canada range | $240,000 to $360,000 CAD per year |
| US range | $235,000 to $355,000 USD per year |
| Incentive target | 45% of base salary (Annual Incentive Plan) |
| Overtime eligibility, Canada | No |
| FLSA classification, US | Exempt |
| Work arrangement | Hybrid |

Deferral and clawback rules for Band 9 are in HR-POL-031 Incentive Deferral and Clawback Policy; the role is eligible for the Long-Term Incentive Plan (HR-PLN-003 Long-Term Incentive Plan Document).

## 6. Working conditions and accessibility

Office-based and hybrid by default, with at least 3 days a week in the office; Tuesday and Thursday are anchor days (HR-POL-002 Remote and Hybrid Work Policy; FORM-HR-030). Travel to business units, campuses and board meetings is expected. The Bank provides accommodation to the point of undue hardship (HR-POL-018 Workplace Accommodation and Accessibility Policy).

## 7. Reporting line

Reports to the Chief Human Resources Officer. Direct reports: Vice Presidents and Directors in talent acquisition, performance, learning and leadership development.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-03-01 | Pay band and incentive target aligned with the 2026 pay bands |
| 1.0 | 2025-01-01 | First issue |
