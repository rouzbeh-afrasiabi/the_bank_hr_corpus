# Personal Information Access Request

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-090 |
| Title | Personal Information Access Request |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-02-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | Chief Privacy Officer |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-016, HR-REF-002, HOW-031, HR-PRC-008 |

## 1. Purpose and when to use this form

Use this form to ask to see the personal information the Bank holds about you, or to ask for a correction. Current employees, former employees and job applicants may use it (HR-POL-016 Employee Data Privacy Policy). Much of your information is already visible in MyHR.

## 2. Who completes it and who approves

You complete it. The Privacy Office reviews and decides. It may withhold information about other people, privileged legal advice, investigation information protected by law, or information whose release could harm someone, and it explains any withholding.

## 3. Where and when to submit (deadline, channel, processing time)

Submit in MyHR (Privacy > Access Request) or email privacy@bank.example. Former employees and applicants may email the Privacy Office. The Privacy Office confirms your identity first. It responds within 30 days of a complete request. It may extend by up to a further 30 days, with written notice of the reasons. There is no fee for a standard request.

## 4. Form fields

| Field | Required | Notes |
| --- | --- | --- |
| Full name and employee ID (or applicant reference) | Yes | Former names if relevant |
| Relationship to the Bank | Yes | Employee, former employee or applicant |
| Province or state of residence | Yes | Helps apply the correct privacy law |
| Contact email and mailing address | Yes | Where the response is sent |
| Type of request | Yes | Access, correction, or both |
| Information requested | Yes | Be as specific as you can, for example payroll history, performance records or recruitment file |
| Date range | No | Narrows the search |
| Correction requested and supporting evidence | If correction | State the record and the correct information |
| Preferred format and language | No | Electronic or paper; English or French |
| Identity document | Yes | Uploaded securely; deleted after verification |

## 5. Declarations and signatures

I confirm that I am the person named above, or that I am acting with that person's written authority. Signature and date: ____________.

## 6. What happens next

The Privacy Office acknowledges your request, verifies identity, gathers the records and sends them securely with an explanation of anything withheld. An accepted correction is made; if the Bank does not agree that information is inaccurate, a note of your disagreement is added to the record. Records are kept according to HR-REF-002 Employee Records Retention Schedule. You may complain to the Privacy Office or a privacy regulator at any time.

## 7. Related documents

- HR-POL-016 Employee Data Privacy Policy
- HR-REF-002 Employee Records Retention Schedule
- HOW-031 How to request access to your personal information

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-02-01 | Added applicants and former employees, and identity verification step. |
| 1.0 | 2021-10-01 | Initial form. |
