# Resignation Acknowledgement Letter

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-TPL-010 |
| Title | Resignation Acknowledgement Letter |
| Document type | Template |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-06-30 |
| Next review | 2027-06-30 |
| Policy owner | VP HR Operations |
| Audience | HR only |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-015, FORM-HR-080, FORM-HR-081, FORM-HR-082 |

## 1. Purpose and when to use this template

HR Operations sends this letter to acknowledge a resignation received on FORM-HR-080 Resignation Notice. The rules for notice, final pay and offboarding are owned by HR-POL-015 Resignation and Offboarding Policy. The letter confirms the last day, what happens to pay and benefits, and what the employee must do before leaving.

## 2. How to use this template

1. Send the letter within 2 business days of receiving the notice.
2. Confirm the notice period for the band (Bands 1 to 4 two weeks; Bands 5 and 6 four weeks; Band 7 and above eight weeks). Where the Bank waives part of the notice, or places a Band 7 or above employee on paid garden leave, change the last day and say so.
3. Keep the Canada or US block and delete the other.
4. Attach FORM-HR-081 Offboarding Checklist and FORM-HR-082 Exit Interview Questionnaire.

## 3. Letter text

**[Date]**

**[Employee full name]**, [Job title], Band [Band]

**Subject: Acknowledgement of your resignation**

Dear [Employee first name],

We acknowledge receipt on **[Date received]** of your notice of resignation. Thank you for your service to the Bank.

**Last day.** Your notice period for Band **[Band]** is **[2 / 4 / 8] weeks**. Your last day of employment is **[Last day]**. **[Where applicable: The Bank has agreed to waive [number] days of the notice and pay you through the notice period / you will be on paid garden leave from [date].]** Your access to Bank systems ends at 17:00 on your last day.

**Final pay.** You will receive your final pay on the next regular pay date, and not later than the legal deadline for **[Work province or state]**. It includes your earned, unused vacation. Any vacation advance still outstanding will be recovered from your final pay. Annual Incentive Plan pay is paid only to employees who are on payroll on the payment date, so a voluntary leaver before that date does not receive it.

**Benefits and savings.** Your benefits end at the end of the month in which your employment ends. **[Canada]** You have 31 days to convert your life insurance. **[US]** You will receive a COBRA election notice within 14 days and have 60 days to elect. Evergreen Retirement Services (1-800-555-0188) will send your retirement plan options.

**Records.** **[Canada]** Your Record of Employment will be issued electronically within 5 calendar days after the end of the pay period in which your employment ends; your T4 and, in Quebec, Relevé 1 will be available by 28 February. **[US]** Your Form W-2 will be available by 31 January.

**Equipment.** Please return all Bank equipment within 5 business days of your last day (remote employees receive a prepaid shipping kit).

**Exit interview.** An exit interview with HR Operations (not your manager) is offered in your final week. It is voluntary, and the results are aggregated quarterly.

**Continuing obligations.** Your confidentiality and non-solicitation obligations continue after your employment ends.

If you have questions, contact HR Connect at 1-800-555-0142 or hrconnect@bank.example.

Sincerely,
**[HR Operations representative name]**, HR Operations

## 4. Required clauses checklist

| Clause | Required content |
| --- | --- |
| Timing | Sent within 2 business days of the notice |
| Notice by band | 2, 4 or 8 weeks, and any waiver or garden leave |
| Final pay | Next regular pay date, legal deadline, vacation paid, AIP rule |
| Benefits | End of month; Canada 31-day conversion; US COBRA |
| Equipment | Return within 5 business days |
| Exit interview | Voluntary, by HR Operations |

## 5. Drafting notes for HR

- Do not use this letter to accept a resignation under pressure; if the employee says the resignation is not voluntary, contact Employee Relations before replying.
- Rehire eligibility is coded Eligible or Not Eligible after the last day; it is not stated in this letter.
- Non-competition obligations apply only to Band 8 and above where law permits; add the wording for those employees only.
- The notice period may be shortened by mutual agreement; record the agreement in writing.

## 6. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.0 | 2023-04-03 | First resignation acknowledgement template |
| 2.0 | 2025-09-01 | Added the 2-business-day timing, notice by band and final pay and benefits wording |
