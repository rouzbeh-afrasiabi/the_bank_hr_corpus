# Personal Trading and Restricted Lists Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-032 |
| Title | Personal Trading and Restricted Lists Policy |
| Document type | Policy |
| Version | 4.0 |
| Status | Current |
| Effective date | 2025-08-01 |
| Last reviewed | 2026-07-27 |
| Next review | 2027-07-27 |
| Policy owner | Chief Compliance Officer |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-001, HR-POL-021, HR-SUP-003, HR-POL-030, FORM-HR-124, FORM-HR-125 |

## 1. Purpose

Employees may learn confidential information about the Bank, its clients and the companies the Bank deals with. Trading on that information, or even appearing to, harms customers and markets and the Bank's reputation. This policy sets out the rules for trading in personal accounts, the restricted and watch lists, pre-clearance, holding periods and disclosure of accounts and holdings. It adds detail to section 10 of HR-POL-001 Code of Conduct and Ethics.

## 2. Scope

The policy has two levels.

- **Covered persons** are employees in Capital Markets, Wealth Management and Treasury, and any other employee designated by Compliance because of their access to confidential information. They must follow all the rules in this policy.
- **All other employees** are bound by section 4 (restricted list and inside information) and by any blackout notice sent to them.

The rules apply to accounts of the employee, of a spouse or partner, of any household member and of any account over which the employee has control or influence. Capital Markets employees should also read HR-SUP-003 Capital Markets Addendum. Where applicable law gives a greater right or sets a stricter rule, the law applies.

## 3. Definitions

| Term | Meaning |
| --- | --- |
| Inside information | Non-public information about the Bank, a client or an issuer that a reasonable investor would consider important in deciding to buy or sell (see HR-POL-001). Also called material non-public information. |
| Restricted list | A confidential list kept by Compliance of issuers on which the Bank holds inside information or has a conflict. No employee may trade the securities of an issuer on it. |
| Watch list | A confidential internal list used by Compliance to monitor trading in issuers that may be about to become restricted. Covered persons may not trade on it. |
| Pre-clearance | Written approval from Compliance, given before a trade, on FORM-HR-124 Personal Trading Pre-Clearance Request. |
| Holding period | The minimum time a security must be held after purchase. |
| Individual securities | Shares, bonds, options, and other single-issuer securities. |
| Approved brokerage | A brokerage firm approved by Compliance for covered persons' accounts. |

## 4. Rules for every employee

1. **No trading with inside information.** Do not trade, or recommend, encourage or tip someone else to trade, while you hold inside information.
2. **Never trade on the restricted list.** The list is available to employees who need it through Compliance. Do not trade any security you have been told is restricted.
3. **Observe blackout notices.** If Compliance sends a blackout notice to you or your team, do not trade the securities it names until it ends.
4. **Keep inside information to yourself.** Share it only with colleagues who need to know it for their work.
5. **Ask when unsure.** Do not trade until Compliance has answered.

## 5. Rules for covered persons

### 5.1 Pre-clearance

- Obtain pre-clearance on FORM-HR-124 **before every trade in individual securities**.
- Compliance answers **within 1 business day**.
- Approval is valid for **the day it is given and the next business day**. After that the approval ends and a new request is needed.
- Pre-clearance is not a recommendation or a guarantee that the trade is acceptable to a regulator. You stay responsible for not trading on inside information.
- Compliance may refuse a request without giving reasons, to avoid disclosing confidential information.

### 5.2 Holding period and short-term trading

- Hold every security for at least **30 days** after purchase.
- Short-term trading (buying and selling, or selling and buying back, within the holding period) is not allowed.
- A request to sell inside the 30 days because of hardship may be made to the Chief Compliance Officer. Approvals are exceptional and are recorded.

### 5.3 Prohibited trading

You may not trade:

- any security on the restricted list or the watch list;
- any security while you hold material non-public information about the issuer;
- in a way that conflicts with the interests of a customer or with an order from a customer you are handling (front-running).

### 5.4 Securities that need no pre-clearance

Mutual funds, exchange-traded funds, government bonds and automatic investment plans do not need pre-clearance. They must still be disclosed under section 6.

## 6. Accounts and disclosure

| Requirement | Rule | Deadline |
| --- | --- | --- |
| Disclose all brokerage accounts | Include accounts of household members and accounts you control | Within 30 days of hire or of being designated a covered person |
| Use an approved brokerage | Covered persons may hold brokerage accounts only with a Bank-approved brokerage. Accounts held elsewhere at the date of designation must be moved or approved by Compliance. | Within 60 days of designation, unless Compliance approves otherwise |
| Duplicate statements | The brokerage sends duplicate statements and trade confirmations directly to Compliance | From the date the account is opened or disclosed |
| Annual holdings disclosure | Complete FORM-HR-125 Annual Personal Holdings Disclosure, listing every account and holding, including mutual funds, exchange-traded funds, government bonds and automatic investment plans | By **31 January** each year |
| Update on a new account | Notify Compliance of any new account | Within 5 business days of opening |

## 7. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Employee | Follows the rules, requests pre-clearance, discloses accounts and holdings, and reports any breach or suspected breach at once. |
| Manager | Reminds the team of the rules, never pressures an employee to trade or waive a rule, and refers questions to Compliance. |
| Compliance | Keeps the restricted and watch lists, answers pre-clearance requests, reviews statements, investigates and reports breaches. |
| Chief Compliance Officer | Owns the policy, designates covered persons, approves exceptions and reports to the Audit Committee. |
| Employee Relations | Applies HR-POL-021 Employee Relations and Progressive Discipline Policy to breaches. |

## 8. Procedures

### 8.1 Pre-clearance steps

1. Submit FORM-HR-124 in MyHR before you place the trade. State the security, buy or sell, size and whether you hold inside information.
2. Compliance responds within 1 business day.
3. Place the trade on the day of approval or the next business day.
4. If the trade is not placed within that window, submit a new request.
5. Record the trade date. The 30-day holding period runs from the purchase date.

### 8.2 Reporting a breach

Report a breach you commit or see to Compliance on the same business day. Voluntary, prompt reporting of your own error is taken into account in deciding the outcome. You can also use the Speak-Up Line (1-800-555-0177) or ethics@bank.example (see HR-POL-001 Code of Conduct and Ethics, section 15).

## 9. Worked examples

1. **Normal trade.** A Wealth Management employee submits FORM-HR-124 on Monday 2026-10-19 to buy shares of a listed company. Compliance approves the same day. The trade must be placed on Monday 2026-10-19 or Tuesday 2026-10-20. If it is placed on Monday, the earliest sale date is 30 days later, Wednesday 2026-11-18.
2. **Approval expires.** An approval is given on Friday. The valid days are that Friday and the next business day, Monday. A trade placed on Tuesday needs a new request.
3. **Restricted list.** A Capital Markets analyst learns that an issuer has been added to the restricted list. The analyst may not buy or sell its shares, and a family member's account in the same household is also covered.
4. **No pre-clearance needed.** A Treasury employee has an automatic plan that invests $200 USD every month in an exchange-traded fund. No pre-clearance is needed for each purchase, but the plan appears on FORM-HR-125 by 31 January.
5. **Non-covered employee.** A branch employee in a non-covered role may trade normally, but cannot trade a restricted issuer or while holding inside information. If a blackout notice reaches the branch, the employee must follow it.
6. **New designation.** An employee is designated a covered person on 2026-09-01. All brokerage accounts must be disclosed within 30 days (by 2026-10-01) and accounts held with a non-approved brokerage must be moved within 60 days unless Compliance agrees otherwise.

## 10. Exceptions

Exceptions need the written approval of the Chief Compliance Officer and are recorded. There are no exceptions to the ban on trading while holding inside information or on the restricted list.

## 11. Consequences

A breach of this policy is a conduct matter. It is handled under HR-POL-021 Employee Relations and Progressive Discipline Policy and, depending on the seriousness, may result in a final written warning or termination for cause. Insider trading and tipping are serious misconduct under HR-POL-001 Code of Conduct and Ethics. Compliance may report breaches to regulators, which may lead to personal civil or criminal liability. Incentive pay may also be reduced or recovered under HR-POL-031 Incentive Deferral and Clawback Policy, for employees within its scope, where the breach amounts to misconduct. A breach may also be assessed under HR-POL-030 Fit and Proper and Conduct Standards Policy.

## 12. Related documents and contacts

- HR-POL-001 Code of Conduct and Ethics
- HR-POL-021 Employee Relations and Progressive Discipline Policy
- HR-POL-030 Fit and Proper and Conduct Standards Policy
- HR-POL-031 Incentive Deferral and Clawback Policy
- HR-SUP-003 Capital Markets Addendum
- FORM-HR-124 Personal Trading Pre-Clearance Request and FORM-HR-125 Annual Personal Holdings Disclosure
- Compliance: contact through the Compliance page in MyHR. Ethics Office: ethics@bank.example. HR Connect: 1-800-555-0142.

## 13. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 4.0 | 2025-08-01 | Pre-clearance reply set at 1 business day and approval valid for the day given and the next business day; 30-day minimum holding period; Bank-approved brokerage for covered persons; annual holdings disclosure by 31 January. |
| 3.0 | 2023-08-01 | Previous version. Added the watch list and the duplicate-statement requirement. |
