# What a Record of Employment is and how to get it (Canada)

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-009 |
| Title | What a Record of Employment is and how to get it (Canada) |
| Document type | How-to article |
| Version | 1.0 |
| Status | Current |
| Effective date | 2025-10-01 |
| Last reviewed | 2026-08-25 |
| Next review | 2027-08-25 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada |
| Language | English |
| Related documents | HR-POL-015, HR-POL-009, FORM-HR-080, HOW-010 |

## 1. The short answer

A Record of Employment (ROE) is the electronic record of your earnings and hours that the government uses to assess an Employment Insurance claim, and Payroll Services issues it within 5 calendar days after the end of the pay period in which your employment ends.

## 2. Who this applies to

Employees in Canada, in every province and territory including Quebec, whose employment ends by resignation, retirement or termination. It does not apply to US employees, who receive a W-2 (see HOW-010) and, where relevant, a COBRA election notice. In Quebec, the Relevé 1 is a separate year-end tax slip.

## 3. Steps

1. Give written notice on FORM-HR-080 Resignation Notice (**MyHR > Employment > Resignation Notice**). HR Operations acknowledges it within 2 business days and confirms your last day of employment.
2. Keep your contact details current under **MyHR > Personal Information > Address**. Your MyHR access for pay statements and tax slips stays open for 24 months after your last day.
3. Work out the issue date: find the pay period that contains your last day (periods end on a Saturday); the ROE is due within 5 calendar days after that Saturday. For example, if your last day is Friday 2026-11-20, the pay period ends Saturday 2026-11-21 and the ROE is due by 2026-11-26.
4. Apply for Employment Insurance with the government as soon as your employment ends. The government sets its own deadlines and decides the claim.
5. If the ROE has not been issued by the due date, open **MyHR > HR Case Portal > New case**, category Pay, or call HR Connect.

## 4. What happens next

Payroll Services submits the ROE electronically; you do not need to collect a paper copy. Your final pay is issued on the next regular pay date or by the legal deadline for your province, whichever is earlier, and includes earned unused vacation (see HR-POL-015 Resignation and Offboarding Policy). Your T4 and, for Quebec, Relevé 1 follow by 28 February.

## 5. Common mistakes

- Waiting for the ROE before applying for Employment Insurance benefits.
- Confusing the ROE with final pay or with the T4; each is separate.
- Moving without updating your mailing address, which delays tax slips.
- Assuming a paper ROE will be mailed.

## 6. Who to call

HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, or live chat in MyHR. Former employees may also use HR Connect or the MyHR former-employee page. Maplewood Benefits claims line (benefits conversion questions): 1-800-555-0190.

## 7. Related documents

- HR-POL-015 Resignation and Offboarding Policy
- HR-POL-009 Compensation and Payroll Policy
- FORM-HR-080 Resignation Notice
- HOW-010 How to get your T4, Relevé 1 or W-2

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.0 | 2025-10-01 | First edition, aligned with HR-POL-015 version 3.0. |
