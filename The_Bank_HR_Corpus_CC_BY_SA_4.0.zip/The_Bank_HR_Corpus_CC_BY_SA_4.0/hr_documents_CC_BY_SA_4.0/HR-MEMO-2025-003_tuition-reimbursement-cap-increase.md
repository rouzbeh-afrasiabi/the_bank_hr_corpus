# Tuition Reimbursement Cap Rises to $5,000 CAD / $5,250 USD

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-MEMO-2025-003 |
| Title | Tuition Reimbursement Cap Rises to $5,000 CAD / $5,250 USD |
| Document type | Memo |
| Version | 1.0 |
| Status | Current |
| Effective date | 2025-10-06 |
| Last reviewed | Not applicable |
| Next review | Not applicable |
| Policy owner | SVP Talent and Learning |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-012, FORM-HR-060, HR-POL-011 |

**More support for your studies: the annual tuition cap goes up on 1 November 2025.**

**From:** SVP Talent and Learning

**To:** All employees in Canada and the US

**Date:** 6 October 2025

**Subject:** Higher tuition reimbursement limit from 1 November 2025

## 1. What is changing

HR-POL-012 Learning and Development Policy version 3.2 raises the tuition reimbursement cap per fiscal year. The old cap was $4,000. The new cap is $5,000 CAD in Canada and $5,250 USD in the US. The fiscal year runs from 1 November to 31 October.

## 2. Who is affected

Employees taking job-related or career-related degree or diploma courses who have 6 months of service and a last rating of Meets Expectations or higher.

## 3. Effective date

1 November 2025.

## 4. What to do

1. Get approval with FORM-HR-060 at least 15 business days before the course starts.
2. Claim within 60 days of completing the course, with your receipt and grade.
3. Reimbursement is 100% for a grade of 70% or higher (or a pass), 50% for 60 to 69%, and 0% below 60%.
4. If you resign within 12 months of your last reimbursement, you repay 100%.

The $2,000 annual professional development budget and the professional designation rules are unchanged.

## 5. Who to call

HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, or live chat in MyHR.

## 6. Related documents

- HR-POL-012 Learning and Development Policy
- FORM-HR-060 Learning Approval and Tuition Reimbursement Claim
- HR-POL-011 Performance Management Policy
