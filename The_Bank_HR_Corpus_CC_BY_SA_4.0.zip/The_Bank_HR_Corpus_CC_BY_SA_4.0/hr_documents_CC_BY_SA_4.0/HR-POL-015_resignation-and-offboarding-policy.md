# Resignation and Offboarding Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-015 |
| Title | Resignation and Offboarding Policy |
| Document type | Policy |
| Version | 3.0 |
| Status | Current |
| Effective date | 2025-10-01 |
| Last reviewed | 2026-08-25 |
| Next review | 2027-08-25 |
| Policy owner | VP HR Operations |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Applies to | All Canadian and US employees (see Scope) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-025, HR-POL-009, HR-POL-006, HR-GDE-001, HR-GDE-002, HR-REF-002, FORM-HR-080, FORM-HR-081, FORM-HR-082 |

## 1. Purpose

This policy sets out how an employee resigns from the Bank, how the Bank manages the period between notice and the last day of employment, and how employment is closed out in an orderly, lawful and respectful way. It covers notice, final pay, return of property, removal of access, benefits and retirement plan endings, tax slips, rehire eligibility and obligations that continue after employment.

Involuntary exits, including severance, are governed by HR-POL-025 Involuntary Termination and Severance Policy and are not repeated here.

## 2. Scope

This policy applies to all regular full-time, regular part-time, fixed-term, casual, student, co-op and intern employees in Canada (all provinces and territories) and in the US who leave the Bank by resignation or retirement. Contractors and agency workers are not employees; their engagements end under their contract terms and the access and equipment rules in section 8 apply to them. Where applicable law gives a greater right, the law applies.

## 3. Definitions

| Term | Meaning |
| --- | --- |
| Resignation | A voluntary decision by the employee to end employment, given in writing on FORM-HR-080 Resignation Notice. |
| Last day of employment | The final calendar day on which the employee is on the Bank's payroll, as confirmed in the HR acknowledgement. |
| Notice period | The time between the date notice is given and the last day of employment. |
| Garden leave | A period during the notice period in which the employee is paid but is relieved of duties and access. |
| Offboarding checklist | FORM-HR-081, completed by HR Operations with the manager. |
| Rehire eligibility code | A record in the HR system showing "Eligible" or "Not Eligible" for future employment. |
| ROE | Record of Employment, issued in Canada. |

## 4. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Employee | Gives written notice, returns equipment, completes handover and updates personal contact details for tax slips. |
| Manager | Receives notice, informs the HRBP the same day, plans handover, approves final time entry and does not conduct the exit interview. |
| HRBP | Advises on notice waiver, garden leave and counter-offers for Band 7 and above. |
| HR Operations | Acknowledges notice, opens the offboarding checklist, runs the exit interview and sets the rehire code. |
| Payroll Services | Calculates final pay, vacation payout and recoveries; issues ROE and tax slips. |
| Benefits Administration | Ends coverage and issues conversion and continuation information (see HR-GDE-001 Employee Benefits Guide). |
| Corporate Security and IT | Collect badges, remove access and recover equipment. |

## 5. Notice of resignation

### 5.1 Notice periods by band

Written notice must be submitted on FORM-HR-080 to the manager and to HR Operations. Notice periods are the same in Canada and the US.

| Job band (see HR-GDE-006 Job Architecture and Pay Bands Guide) | Notice period |
| --- | --- |
| Bands 1 to 4 | 2 weeks |
| Bands 5 and 6 | 4 weeks |
| Bands 7 and above | 8 weeks |

The notice period starts on the day after FORM-HR-080 is submitted. Employees on fixed-term contracts follow the notice in their contract where it is shorter.

### 5.2 Acknowledgement

HR Operations acknowledges every resignation in writing within 2 business days of receipt, confirming the last day of employment, final pay timing and next steps. If an employee has not received an acknowledgement within 2 business days, they should contact HR Connect and the case is treated as Priority 2 (see HR-GDE-004 HR Service and Support Guide).

### 5.3 Waiver, shortened notice and withdrawal

The Bank may waive all or part of the notice period and pay the employee through the notice period it has waived; the employee is then paid base salary for the waived days and benefits continue to the end of the month in which employment ends. An employee who cannot give full notice should speak to the manager and HRBP as early as possible; shortened notice requires written agreement. A resignation may be withdrawn only with the written agreement of the manager and HRBP before the last day of employment.

### 5.4 Retirement notice

An employee who intends to retire gives at least 3 months' notice on FORM-HR-080, marked "Retirement". Normal retirement age is 65; early retirement is available from age 55 with 5 years in the pension or savings plan. The longer retirement notice replaces the band notice period when it is longer. HR Operations arranges a retirement planning conversation, and Evergreen Retirement Services (1-800-555-0188) supports plan decisions (see HR-GDE-002 Retirement and Savings Plan Guide).

### 5.5 Garden leave

For Bands 7 and above, the Bank may place the employee on paid garden leave for all or part of the 8-week notice period. During garden leave the employee remains employed, receives full base salary and benefits, must not work for another employer, must remain available for reasonable questions, and may not access Bank systems or premises without approval. Garden leave is approved by the business unit head and the VP Employee Relations.

## 6. Final pay

### 6.1 General rule

Final pay is paid on the next regular pay date, but never later than the legal deadline in the table below. Final pay includes earned salary to the last day, earned unused vacation (paid out in all Canadian provinces and all US states; see HR-POL-006 Vacation and Paid Time Off Policy), and any other amounts owing under HR-POL-009 Compensation and Payroll Policy. Amounts owed to the Bank, such as an unearned vacation advance or an overpayment, are recovered from final pay where the law permits.

### 6.2 Legal deadlines by province and state

| Jurisdiction | Resignation | Termination by the Bank |
| --- | --- | --- |
| Ontario | Later of 7 days after employment ends or the next pay date | Same |
| Quebec | Next regular pay date | Next regular pay date |
| British Columbia | 6 days after resignation | 48 hours after termination |
| Alberta | 10 days after resignation | 3 days after termination |
| California | Within 72 hours of resignation without notice; on the last day if notice was given | Immediately on termination |
| New York | Next regular pay date | Next regular pay date |
| New Jersey | Next regular pay date | Next regular pay date |
| Florida | Next regular pay date | Next regular pay date |
| Other provinces, territories and states | Next regular pay date, or the earlier legal deadline confirmed by Payroll Services | Same |

Payroll Services applies the deadline of the employee's province or state of work. Where a deadline is earlier than the payroll cut-off, Payroll Services issues an off-cycle payment.

### 6.3 Annual Incentive Plan

AIP is paid only to employees who are on payroll on the payment date (the first pay date in February). Voluntary leavers who leave before the payment date forfeit the AIP for the year. Employees whose employment ended involuntarily are covered by HR-POL-025.

### 6.4 Tuition and other repayments

An employee who resigns within 12 months of their last tuition reimbursement repays 100% of the reimbursed amount (see HR-POL-012 Learning and Development Policy). Repayment is arranged with Payroll Services and, where the law requires written consent for a deduction, consent is obtained first.

## 7. Handover and exit interview

The manager agrees a handover plan with the employee within 3 business days of acknowledgement, covering open work, client files, system ownership and delegated approvals. The employee records handover items on FORM-HR-081.

HR Operations offers an exit interview in the employee's final week. It is voluntary, is held by HR Operations and never by the manager, and uses FORM-HR-082 Exit Interview Questionnaire. Responses are confidential, are aggregated quarterly and are reported without names. Declining an exit interview has no effect on final pay or rehire eligibility.

## 8. Equipment, property and access

| Item | Requirement |
| --- | --- |
| Laptop, phone, tokens, badge and other equipment | Returned within 5 business days of the last day of employment. Remote employees receive a prepaid shipping kit. |
| Documents and client data | Returned or deleted by the last day; no copies may be kept (see HR-POL-017 IT Acceptable Use and Information Security Policy). |
| System and building access | Ends at 17:00 on the last day of employment (immediately for involuntary exits and during garden leave). |
| Corporate card and signing authority | Cancelled on the last day; open balances are settled before the final pay is released. |
| Unreturned equipment | Payroll Services may deduct the replacement value where the law permits; unreturned items are referred to Corporate Security. |

The manager confirms in FORM-HR-081 that all items were returned. IT removes access in accordance with HR-POL-017 and revokes mobile device management enrolment on the last day.

## 9. Benefits and retirement plans

Benefits end at the end of the month in which employment ends. Benefits Administration sends the following notices:

| Item | Canada | US |
| --- | --- | --- |
| Health and dental coverage | Ends at month end | Ends at month end; COBRA election notice sent within 14 days, election window 60 days, coverage up to 18 months |
| Life insurance | Conversion option within 31 days | Conversion per the carrier's terms |
| Retiree health access | Age 55 with 10 years of service, 100% employee-paid | Same |
| Wellness spending account | Claims for expenses incurred to the last day, by 31 March of the following year | Same |
| Retirement plan | Bank Savings and Pension Plan: options communicated by Evergreen Retirement Services | Bank US 401(k) Savings Plan: unvested Bank contributions are forfeited; vested balance can be left, transferred or withdrawn |

The Wellspring Support Program remains available for 30 days after the last day. Full details are in HR-GDE-001 Employee Benefits Guide and HR-GDE-002 Retirement and Savings Plan Guide.

## 10. Record of Employment and tax slips

In Canada, Payroll Services issues the ROE electronically within 5 calendar days after the end of the pay period in which employment ends. The T4 and, for Quebec, the Relevé 1 are issued by 28 February. In the US, the W-2 is issued by 31 January. Former employees update their mailing address through HR Connect or the MyHR former-employee page; MyHR access for pay statements and tax slips remains for 24 months after the last day.

## 11. Rehire eligibility

HR Operations records a rehire eligibility code of "Eligible" or "Not Eligible" on the offboarding checklist. "Not Eligible" requires the approval of the VP Employee Relations and is limited to terminations for cause, resignation during an open investigation, or breach of the obligations in section 12. A rehire within 12 months restores prior service; a longer break restarts it (see HR-POL-014 Employment Status and Classification Policy).

## 12. Continuing obligations

Confidentiality, intellectual property and the non-solicitation obligations in the employee's agreement and the Code of Conduct (HR-POL-001 Code of Conduct and Ethics) continue after employment. A non-compete applies only to employees in Band 8 and above, and only where law permits and the agreement says so. Employees remain bound by duties relating to client and employee personal information (see HR-POL-016 Employee Data Privacy Policy). The Bank may remind former employees of these obligations in writing.

## 13. Offboarding checklist

HR Operations opens FORM-HR-081 on the day the notice is acknowledged. All items are required.

| Step | Owner | Due |
| --- | --- | --- |
| Acknowledge FORM-HR-080 and confirm last day | HR Operations | 2 business days after notice |
| Agree handover plan | Manager | 3 business days after acknowledgement |
| Notify Payroll Services, Benefits Administration and IT | HR Operations | 5 business days after notice |
| Approve final time entry and expenses | Manager | Last day |
| Offer exit interview (FORM-HR-082) | HR Operations | Final week |
| Remove access | IT / Corporate Security | 17:00 on last day |
| Return equipment | Employee | 5 business days after last day |
| Issue final pay | Payroll Services | Next pay date or legal deadline |
| Issue ROE (Canada) | Payroll Services | 5 calendar days after end of pay period |
| Set rehire code and close checklist | HR Operations | 10 business days after last day |

## 14. Exceptions, consequences and contacts

Exceptions to notice periods, garden leave or equipment timing require HR Operations and HRBP approval. Failure to give the required notice may affect rehire eligibility. Questions go to HR Connect (1-800-555-0142, hrconnect@bank.example) or, for managers, the Manager Hotline (1-800-555-0143). Evergreen Retirement Services: 1-800-555-0188. Maplewood Benefits claims line: 1-800-555-0190.

## 15. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 3.0 | 2025-10-01 | Added garden leave for Band 7 and above, the final pay deadlines table by province and state, and the offboarding checklist FORM-HR-081. |
| 2.0 | 2023-04-01 | Introduced notice periods by band and the HR acknowledgement timeline. |
| 1.0 | 2020-06-01 | Initial policy. |
