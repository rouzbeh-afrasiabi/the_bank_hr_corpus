# AML Investigator

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1035 |
| Title | AML Investigator |
| Document type | Job description |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-06-16 |
| Last reviewed | 2026-07-28 |
| Next review | 2027-07-28 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-POL-002, HR-POL-030, HR-POL-001 |

## 1. Role summary

The AML Investigator reviews alerts and cases that may point to money laundering, terrorist financing, sanctions evasion or other financial crime. The investigator analyses customer activity, documents findings in clear case narratives and recommends whether to close the case, escalate or file a suspicious activity report with the relevant authority through Financial Crimes leadership. A Band 3 investigator works independently on assigned cases and applies professional judgement within procedures.

## 2. Key responsibilities

- Review transaction-monitoring and screening alerts, and decide which require full investigation.
- Analyse account activity, customer profiles, source of funds and links between parties.
- Request information from branches, relationship managers and customers while preserving confidentiality and avoiding any tipping-off.
- Write accurate and complete case narratives that support the decision reached.
- Prepare suspicious activity reports for review by the Manager, Financial Crimes, and meet regulatory filing deadlines.
- Carry out enhanced due diligence reviews on higher-risk customers.
- Escalate sanctions matches, potential fraud and urgent threats immediately.
- Meet case-ageing and quality targets, and take part in quality-assurance reviews.
- Keep up with typologies and regulatory changes through the Learning Hub and team briefings.
- Report possible internal misconduct through the right channels, including the Speak-Up Line, as set out in HR-POL-001 Code of Conduct and Ethics.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in business, finance, criminology, law or a related field, or equivalent experience.
- Typically 2 to 5 years of experience in anti-money-laundering, fraud, compliance or financial investigations.
- Knowledge of anti-money-laundering and sanctions legislation in Canada and the US.
- Strong analytical, writing and critical-thinking skills.

### 3.2 Preferred

- A recognized anti-money-laundering certification.
- Experience with transaction-monitoring and case-management systems.
- Bilingual English and French.

### 3.3 Licences and certifications

No securities licence is required. The role is subject to the criteria in HR-POL-030 Fit and Proper and Conduct Standards Policy, including the annual fit-and-proper attestation and disclosure within 2 business days of a criminal charge or conviction, bankruptcy or regulatory sanction.

## 4. Competencies

Measured against HR-FWK-001 Competency and Leadership Model at the Practitioner level:

- Risk and Conduct Awareness
- Judgement and Decision Quality
- Drive for Results
- Collaboration
- Adaptability

## 5. Compensation and classification

| Item | Value |
| --- | --- |
| Band | 3 (Professional) |
| Canada range | $56,000 to $84,000 CAD |
| US range | $55,000 to $82,000 USD |
| Incentive target | 5% of base salary (Annual Incentive Plan) |
| Overtime eligibility, Canada | Yes (non-managerial Band 3) |
| FLSA classification, US | Exempt |
| Work arrangement | Hybrid (at least 3 days a week in the office) |

Band definitions are in HR-GDE-006 Job Architecture and Pay Bands Guide.

## 6. Working conditions and accessibility

This is an office role with a hybrid arrangement under HR-POL-002 Remote and Hybrid Work Policy: at least 3 days a week in the office, including the Tuesday and Thursday anchor days. The work involves sensitive and sometimes disturbing information, and strict confidentiality applies. The Wellspring Support Program is available at any time. The Bank provides accommodation to the point of undue hardship; see HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to: Manager, Financial Crimes. Direct reports: none.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-06-16 | Rewritten to add enhanced due diligence and conduct expectations |
| 1.0 | 2023-06-01 | First issue |
