# Involuntary Termination and Severance Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-025 |
| Title | Involuntary Termination and Severance Policy |
| Document type | Policy |
| Version | 2.4 |
| Status | Current |
| Effective date | 2025-02-01 |
| Last reviewed | 2026-07-21 |
| Next review | 2027-07-21 |
| Policy owner | VP Employee Relations |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Applies to | All Canadian and US employees (see Scope) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-015, HR-POL-021, HR-POL-013, HR-POL-009, HR-POL-014, HR-GDE-001, HR-GDE-005, HR-REF-002 |

## 1. Purpose

This policy sets out when and how the Bank ends employment involuntarily, what notice or pay in lieu of notice and enhanced severance an employee receives, and the process, approvals and protections that apply. It aims to be lawful, consistent and humane, and to make sure no employee is dismissed without a documented review.

Voluntary exits (resignation and retirement) are covered by HR-POL-015 Resignation and Offboarding Policy.

## 2. Scope

This policy applies to all regular full-time and regular part-time employees in Canada and in the US, and to fixed-term employees ended before the end of their term. Casual employees, students, co-op students and interns receive the minimum entitlements required by law. Contractors and agency workers are not covered. Where applicable law or a collective agreement gives a greater right, the law or agreement applies.

## 3. Definitions

| Term | Meaning |
| --- | --- |
| Termination without cause | Dismissal not based on employee misconduct or an unresolved performance failure, including restructuring, role elimination and position closure. |
| Termination for cause | Dismissal for serious misconduct or sustained failure to correct performance or conduct after progressive discipline (see HR-POL-021 Employee Relations and Progressive Discipline Policy). |
| Pay in lieu of notice | A payment of base salary instead of working through the notice period. |
| Enhanced severance | Bank-formula amount above the statutory minimum, conditional on a signed release. |
| Completed year of service | A full 12 months of continuous service, using the service date under HR-POL-014 Employment Status and Classification Policy. Partial years are not counted. |
| Release | A written agreement in which the employee accepts the package and gives up claims against the Bank. |
| Group termination | The termination of 50 or more employees in Canada, or a mass layoff or plant closing in the US. |

## 4. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Manager | Proposes the action with the HRBP, conducts the termination meeting and never decides alone. |
| HRBP | Prepares the case file, calculates the package with Payroll Services, attends the meeting. |
| Employee Relations (ER) consultant | Reviews cause cases and ensures that progressive discipline steps are complete. |
| VP Employee Relations | Approves every termination for cause with Legal; owns this policy. |
| Legal | Reviews releases, cause cases, group terminations and statutory compliance. |
| Payroll Services | Calculates and pays amounts due within the legal deadlines. |
| Benefits Administration | Ends or continues coverage and issues COBRA and conversion notices. |
| Corporate Security | On standby at the meeting where needed; removes access. |

## 5. Termination without cause

### 5.1 Severance formula

Notice or pay in lieu of notice is the greater of the statutory minimum for the employee's province or state and the Bank formula below. The Bank formula is based on completed years of service and the employee's current annual base salary divided by 52.

| Country | Bank formula per completed year | Minimum | Maximum |
| --- | --- | --- | --- |
| Canada | 2 weeks of base pay | 8 weeks | 52 weeks |
| US | 1 week of base pay | 4 weeks | 26 weeks |

Pay in lieu covers base salary only. Statutory payments owed regardless of a release (earned wages, vacation pay, and statutory notice or severance where the law requires) are always paid even if the employee declines to sign a release.

### 5.2 Worked examples

The examples assume the statutory minimum is lower than the Bank formula; where it is higher, the statutory amount is paid. Canada examples use annual base salary of $80,000 CAD (weekly base of $1,538.46). US examples use $100,000 USD (weekly base of $1,923.08).

| Years of service | Canada: formula | Canada: weeks and amount | US: formula | US: weeks and amount |
| --- | --- | --- | --- | --- |
| 3 | 3 x 2 = 6 weeks, raised to the 8-week minimum | 8 weeks, $12,307.69 CAD | 3 x 1 = 3 weeks, raised to the 4-week minimum | 4 weeks, $7,692.31 USD |
| 10 | 10 x 2 = 20 weeks | 20 weeks, $30,769.23 CAD | 10 x 1 = 10 weeks | 10 weeks, $19,230.77 USD |
| 25 | 25 x 2 = 50 weeks (below the 52-week cap) | 50 weeks, $76,923.08 CAD | 25 x 1 = 25 weeks (below the 26-week cap) | 25 weeks, $48,076.92 USD |

An employee with 26 or more completed years in Canada reaches the 52-week cap; in the US the 26-week cap is reached at 26 years.

### 5.3 Payment and benefits continuation

Enhanced severance is paid as a single lump sum within 10 business days after the release becomes effective, unless the law requires an earlier payment of the statutory part. In Canada, benefits and retirement plan participation continue through the notice period at the same employee cost. In the US, benefits end at the end of the month and, if the employee elects COBRA, the Bank pays 3 months of the Bank's premium share (see HR-GDE-001 Employee Benefits Guide). The employee remains eligible for Annual Incentive Plan payment only where HR-POL-009 Compensation and Payroll Policy requires it or the law does; pay in lieu does not extend the AIP payroll-date rule.

### 5.4 Release and timelines

Enhanced severance above the statutory minimum requires a release signed by the employee.

| Item | Canada | US |
| --- | --- | --- |
| Time to consider the release | 14 days | 21 days |
| Time to consider in a group termination | 14 days | 45 days |
| Revocation period | None unless the law requires | 7 days, for employees aged 40 or over |
| Legal advice | Encouraged; the Bank reimburses up to $1,000 CAD of independent legal advice | Encouraged; the Bank reimburses up to $750 USD |
| Release becomes effective | On signing | After the revocation period ends |

The offer lapses if the release is not signed by the end of the consideration period. Legal may agree to an extension in writing.

## 6. Termination for cause

Termination for cause results in no enhanced severance; only statutory entitlements are paid. Before the Bank can dismiss for cause:

1. the ER consultant confirms that progressive discipline steps are complete, or that the conduct is serious enough to skip steps (theft, fraud, violence, harassment, breach of confidentiality or falsifying records);
2. a fair, documented investigation has been completed and the employee has had a chance to respond within 5 business days;
3. the VP Employee Relations and Legal approve in writing.

Performance-based dismissals follow HR-POL-013 Performance Improvement Policy. A suspension with pay of up to 10 business days may be used while an investigation is open (see HR-POL-021). No manager may tell an employee that they are dismissed for cause without both approvals.

## 7. Group terminations

Any proposal affecting 5 or more employees is escalated to the VP Employee Relations and Legal before any communication. Group terminations of 50 or more employees in Canada, and mass layoffs in the US, follow the statutory notice rules, including 60 days' notice under the US WARN Act, and require notice to government authorities where the law says so. Employees affected are selected by objective, documented criteria reviewed for adverse impact. Legal prepares the group release and the disclosure information required for the 45-day period in the US. Union notices follow the collective agreement.

## 8. Termination meeting protocol

| Step | Requirement |
| --- | --- |
| Timing | A Tuesday to Thursday where possible; not on the employee's birthday, the day before a statutory holiday or during a protected leave unless Legal agrees. |
| Attendees | Manager and HRBP; Corporate Security on standby where needed. The employee is not accompanied by counsel but may bring a support person. |
| Length | 15 to 20 minutes, in a private room or by video for remote employees. |
| Script | State the decision plainly, summarize the package, explain next steps and give the HR Connect and Wellspring Support Program contact details (1-800-555-0166). |
| Immediately after | Access removed and equipment arrangements confirmed in line with HR-POL-015; HRBP follows up within 1 business day. |
| Records | HRBP records the meeting in the confidential file. |

Communication to the team is agreed with the HRBP and is brief, factual and respectful.

## 9. Final pay and records

Final pay is paid within the legal deadline of the province or state of work (see the table in HR-POL-015 Resignation and Offboarding Policy). It includes earned salary, earned unused vacation and any statutory amounts. In Canada the Record of Employment is issued electronically within 5 calendar days after the end of the pay period in which employment ends; T4 and Relevé 1 follow by 28 February. In the US, the W-2 follows by 31 January. Records are kept as set out in HR-REF-002 Employee Records Retention Schedule.

## 10. Outplacement support

Employees terminated without cause receive outplacement support from a vendor selected by HR Operations.

| Band | Outplacement duration |
| --- | --- |
| Bands 1 to 6 | 12 weeks |
| Band 7 and above | 26 weeks |

Outplacement is not offered to employees terminated for cause. The Wellspring Support Program stays available for 30 days after the last day.

## 11. Appeals and review

An employee who believes the termination or package was not applied correctly may request a review within 10 business days of the meeting, in writing to the VP Employee Relations (requests are logged in the HR Case Portal). A reviewer who did not take part in the decision, supported by Legal, completes the review within 15 business days and the written outcome is final under this policy. Filing a review does not stop the release period running unless Legal grants a written extension. The Ombuds Office (ombuds@bank.example) is available for informal, confidential advice. Employees may also use any external legal right at any time.

## 12. Protected circumstances

No termination may be based on a protected ground, a protected leave, an accommodation request (see HR-POL-018 Workplace Accommodation and Accessibility Policy), a good-faith report under HR-POL-022 Whistleblower and Speak-Up Policy, or a complaint of harassment. An employee on a protected leave or with a pending accommodation may only be terminated after Legal review. Retaliation is a breach of the Code of Conduct.

## 13. Related guidance

Managers follow HR-GDE-005 Manager's HR Procedures Guide for the step-by-step process and contact the HRBP before any action. Questions go to HR Connect (1-800-555-0142) or the Manager Hotline (1-800-555-0143).

## 14. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.4 | 2025-02-01 | Added worked examples, outplacement durations by band and the termination meeting protocol. |
| 2.0 | 2023-01-15 | Introduced the Bank formula for Canada and the US and the signed release requirement. |
| 1.0 | 2019-09-01 | Initial policy. |
