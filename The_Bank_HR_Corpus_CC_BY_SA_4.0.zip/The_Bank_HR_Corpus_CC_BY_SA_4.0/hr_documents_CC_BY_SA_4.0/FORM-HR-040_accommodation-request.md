# Accommodation Request

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-040 |
| Title | Accommodation Request |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | Head of Accessibility and Inclusion |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-018, HR-POL-016, FORM-HR-041 |

## 1. Purpose and when to use this form

Use this form to ask for a change that removes a barrier related to a protected ground such as disability, religion or creed, family status or pregnancy. **This form is optional.** You may instead tell your manager, call HR Connect (1-800-555-0142) or write to accommodations@bank.example. The word "accommodation" is not required. A manager who hears of a possible need passes it to the Accommodation Specialist the same business day.

## 2. Who completes it and who approves

You complete it, or your manager, HRBP or a representative does with your consent. The Accommodation Specialist, with your manager and HRBP, records the decision. Only the Head of Accessibility and Inclusion, with Legal, may decide a request causes undue hardship.

## 3. Where and when to submit

Submit in MyHR at any time. Timelines:

| Step | Timeline |
| --- | --- |
| Acknowledgement | Within 2 business days |
| Interim measures | Immediately where possible |
| Decision | Within 10 business days of complete information; 3 business days if urgent (safety, imminent return to work, hiring deadline) |
| Equipment or accessible formats | Normally within 10 business days of the decision |

## 4. Form fields

| Field | Required | Notes |
| --- | --- | --- |
| Name, role, manager | Yes | Pre-filled |
| What you need | Yes | In your own words |
| Barrier or task affected | Yes | For example schedule, workstation, document format |
| Protected ground | No | You need not share a diagnosis |
| Urgent | No | Tick if it affects safety or an imminent date |
| Preferred contact and format | No | Accessible formats are available |
| Solutions you have considered | No | |

## 5. Declarations and signatures

- I agree to take part in finding a solution and to say when my need changes.
- I understand I am never required to provide a diagnosis.

## 6. What happens next

If more information is needed, you may be asked for FORM-HR-041, which collects functional limitations only. The measures are put in place with a review date; long-term needs are reviewed at least once a year. Costs are met by the central Accommodation Fund, never your team budget. The Bank reimburses up to $150 CAD or $120 USD for completing medical forms. If you disagree with a decision, ask the Accommodation Review Panel within 10 business days of the decision; written reasons follow within 10 business days of your request. No one may disadvantage you for asking. Where applicable law gives a greater right, the law applies.

## 7. Related documents

- HR-POL-018 Workplace Accommodation and Accessibility Policy
- HR-POL-016 Employee Data Privacy Policy
- FORM-HR-041 Medical Information Supplement for Accommodation

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-09-01 | Added the 3-business-day urgent timeline and Accommodation Fund wording (HR-POL-018 version 3.2). |
