# Vacation Carryover Rises to 5 Days from 1 January 2026

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-MEMO-2025-006 |
| Title | Vacation Carryover Rises to 5 Days from 1 January 2026 |
| Document type | Memo |
| Version | 1.0 |
| Status | Current |
| Effective date | 2025-10-27 |
| Last reviewed | Not applicable |
| Next review | Not applicable |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-006, HR-MEMO-2024-001, HR-ARC-003, HR-POL-010 |

**You can now carry up to 5 unused vacation days into the new year.**

**From:** SVP Total Rewards

**To:** All employees in Canada and the US

**Date:** 27 October 2025

**Subject:** New vacation carryover limit, HR-POL-006 version 4.0

## 1. What is changing

| Item | Old (version 3.0, to 31 December 2025) | New (version 4.0, from 1 January 2026) |
| --- | --- | --- |
| Days carried into the next year | 3 | 5 |
| Deadline to use carried days | 31 March | 31 March |

Days above the limit are forfeited, except where you were on approved leave or the law requires payment. This memo supersedes HR-MEMO-2024-001.

## 2. Who is affected

All employees with vacation entitlement. Casual employees receive 6% vacation pay and have no vacation days.

## 3. Effective date

1 January 2026, so the first carryover under the new limit is from 2025 into 2026: up to 5 days, used by 31 March 2026.

## 4. What to do

1. Check your balance in MyHR before 31 December 2025.
2. Request days of 5 or more at least 4 weeks ahead; request fewer than 5 days at least 5 business days ahead. Your manager responds within 5 business days.
3. Book carried days so they are taken by 31 March 2026.

Statutory holidays during vacation are not charged to your balance (HR-POL-010).

## 5. Who to call

HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, or live chat in MyHR.

## 6. Related documents

- HR-POL-006 Vacation and Paid Time Off Policy
- HR-MEMO-2024-001 Reminder: Vacation Carryover into 2025 (superseded)
- HR-ARC-003 Vacation and Paid Time Off Policy (version 3.0), archived
