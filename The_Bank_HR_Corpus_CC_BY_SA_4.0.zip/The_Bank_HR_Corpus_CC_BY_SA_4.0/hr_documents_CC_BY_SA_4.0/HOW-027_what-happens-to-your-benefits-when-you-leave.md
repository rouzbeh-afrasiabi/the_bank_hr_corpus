# What happens to your benefits when you leave

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-027 |
| Title | What happens to your benefits when you leave |
| Document type | How-to article |
| Version | 1.1 |
| Status | Current |
| Effective date | 2025-10-01 |
| Last reviewed | 2026-10-20 |
| Next review | 2027-10-20 |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-001, HR-POL-015, HR-GDE-002, HOW-026 |

## 1. Short answer

Your health, dental and insurance coverage ends at the end of the month in which your employment ends, so a last day of 14 July means coverage ends on 31 July.

## 2. Who this applies to

Employees in Canada and the US who resign or retire and are enrolled in Bank benefits. Casual, student, co-op, intern and short fixed-term employees have only the Wellspring Support Program, which stays open for 30 days after the last day. Quebec employees: drug coverage follows the law, so ask Benefits Administration. Severance-related premium support is in HR-POL-025 Involuntary Termination and Severance Policy.

## 3. Steps

1. Submit FORM-HR-080 and confirm your last day with HR Operations (see HOW-026 How to resign and give notice).
2. Open MyHR > Benefits and review your elections, dependants and beneficiaries.
3. Submit any open claims to Maplewood Benefits within 12 months of the date of service.
4. **Canada:** apply to Maplewood Benefits to convert your life insurance within 31 days. **US:** watch for your COBRA election notice.
5. If you will be 55 or older with 10 years of service, contact Benefits Administration before your last day to arrange retiree health access.
6. Claim your wellness spending account ($500 CAD or $400 USD a year) for expenses incurred up to your last day.
7. Watch for Evergreen Retirement Services' letter about your pension or 401(k) options.
8. Check your mailing address in MyHR > Personal Information.

## 4. Deadlines

| Item | Canada | US |
| --- | --- | --- |
| Coverage ends | End of the month of your last day | End of the month of your last day |
| Life insurance conversion | Apply within 31 days | Per the carrier's terms |
| COBRA | Not applicable | Notice within 14 days; 60 days to elect; up to 18 months |
| Wellness account claims | By 31 March of the following year | By 31 March of the following year |

## 5. What happens next

Benefits Administration sends the notices above. Unvested Bank 401(k) contributions (under 2 years of service) are forfeited; your own contributions and a US health savings account are yours. Canadian pension assets are locked in until age 55. Retiree health costs you 100% of the premium, and COBRA can cost up to the full premium plus an administration fee. MyHR > Pay keeps your pay statements and tax slips for 24 months.

## 6. Common mistakes

- Assuming coverage runs to your last day rather than month end.
- Missing the 31-day life conversion or the 60-day COBRA election window.
- Forgetting the wellness account claim date of 31 March.

## 7. Who to call

HR Connect, 1-800-555-0142 (Monday to Friday 8:00 to 20:00 Eastern Time), hrconnect@bank.example. Claims: Maplewood Benefits, 1-800-555-0190. Retirement: Evergreen Retirement Services, 1-800-555-0188.

## 8. Related documents

- HR-GDE-001 Employee Benefits Guide
- HR-POL-015 Resignation and Offboarding Policy
- HR-GDE-002 Retirement and Savings Plan Guide

## 9. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.1 | 2025-10-01 | Aligned with HR-POL-015 version 3.0. |
| 1.0 | 2025-01-01 | First issue. |
