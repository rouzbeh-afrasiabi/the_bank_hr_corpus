# Customer Service Representative II

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1003 |
| Title | Customer Service Representative II |
| Document type | Job description |
| Version | 2.1 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-08-18 |
| Next review | 2027-08-18 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-POL-003, HR-POL-005, HR-POL-018 |

## 1. Role summary

The Customer Service Representative II (CSR II) handles the contact centre's more complex customer enquiries, complaints and escalations that the Customer Service Representative I team cannot resolve on first contact. The role applies sound judgement to dispute, fraud-related and multi-product situations, protects customer relationships when things have gone wrong, and helps coach newer colleagues. The CSR II works under general guidance from the Team Lead. This is a Band 2 (Associate) role in the Retail Banking family; see HR-GDE-006 Job Architecture and Pay Bands Guide.

## 2. Key responsibilities

- Handle escalated calls and chats, including disputes, billing and fee questions, and service failures.
- Investigate transaction disputes and card chargebacks, and explain outcomes and timelines clearly to customers.
- Own complaints through to resolution within the Bank's complaint-handling standards, and log them accurately.
- Support customers affected by fraud, identity theft or account takeover, working with the fraud and card teams.
- Coordinate with branches, payments operations and digital support teams to fix underlying causes.
- Review and approve routine goodwill gestures within the limits set by the Team Lead.
- Act as a point of contact for newer representatives, offering real-time guidance and call shadowing.
- Identify recurring issues and propose improvements to knowledge articles and scripts.
- Maintain quality, accuracy and customer satisfaction scores above team targets.
- Complete mandatory training and keep current on product and policy changes.

## 3. Qualifications

### 3.1 Required

- High school diploma or equivalent, plus one to three years of customer service experience, ideally in a financial services contact centre.
- Strong problem-solving, de-escalation and written communication skills.
- Working knowledge of retail banking products and processes.
- Ability to work a posted schedule including evenings and some weekends.

### 3.2 Preferred

- Post-secondary diploma in business or financial services.
- Experience handling complaints or disputes.
- Fluency in English and French.

### 3.3 Licences and certifications

None required.

## 4. Competencies

Competencies are defined in HR-FWK-001 Competency and Leadership Model; this role works at the Foundation level.

- **Customer Obsession**: restores trust when service has fallen short.
- **Judgement and Decision Quality**: weighs facts, policy and customer impact before deciding.
- **Risk and Conduct Awareness**: treats customers fairly and records complaints and fraud concerns completely.
- **Collaboration**: works across branches and specialist teams to resolve cases.
- **Developing Others**: coaches newer representatives through informal guidance.
- **Adaptability**: shifts between calm, urgent and emotionally charged contacts.

## 5. Compensation and classification

| Item | Detail |
| --- | --- |
| Band | 2 (Associate) |
| Canada salary range | $44,000 to $64,000 CAD per year |
| US salary range | $43,000 to $62,000 USD per year |
| Incentive target | Annual Incentive Plan (AIP): 5% of base salary |
| Overtime eligibility (Canada) | Yes (non-managerial Band 1 to 4 role) |
| FLSA classification (US) | Non-exempt |
| Work arrangement | On-site at the contact centre |

## 6. Working conditions and accessibility

This is an on-site role in the contact centre, working at a workstation with a headset to a posted schedule. Calls can be emotionally demanding, and employees can use the Wellspring Support Program at any time. Conduct towards colleagues and customers follows HR-POL-005 Workplace Harassment and Violence Prevention Policy, which also protects employees from abusive callers. Overtime follows HR-POL-003 Working Hours and Overtime Policy. The Bank provides accommodation to the point of undue hardship (Canada) or reasonable accommodation (US); see HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to the Team Lead, Contact Centre.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.1 | 2026-03-01 | Pay ranges updated to the 2026 pay bands |
| 2.0 | 2025-02-03 | Added complaint ownership and peer-guidance duties |
| 1.0 | 2024-04-01 | First issue |
