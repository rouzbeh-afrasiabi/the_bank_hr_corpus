# How to claim a professional designation

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-021 |
| Title | How to claim a professional designation |
| Document type | How-to article |
| Version | 1.1 |
| Status | Current |
| Effective date | 2025-11-01 |
| Last reviewed | 2026-09-22 |
| Next review | 2027-09-22 |
| Policy owner | SVP Talent and Learning |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-012, FORM-HR-061, HR-POL-029, HR-POL-006 |

## 1. The short answer

Submit FORM-HR-061 (Professional Designation Reimbursement Request) in MyHR > Career and Learning > Professional Designations before you register for the designation or exam.

## 2. Who this applies to

Regular full-time and regular part-time employees in Canada (including Quebec) and the US pursuing a recognized professional designation such as CFA, CPA, CFP, PMP or CISSP. A regulatory licence that your role needs (for example a mutual fund dealing representative licence or a Series registration) is a different process: use FORM-HR-123 under HR-POL-029 Licensing, Registration and Qualification Policy. Degree or diploma courses use tuition reimbursement (see HOW-020).

## 3. Steps

1. **Before registering,** open MyHR > Career and Learning > Professional Designations and complete FORM-HR-061.
2. Enter the designation and level or exam, the awarding body, the exam dates, and the registration, exam and membership fees (attach the fee schedule).
3. State whether your role requires the designation.
4. Request **5 study days** per designation exam in MyHR > Time and Absence as study leave. Your manager approves at least 10 business days before the first study day, or less where the exam date was set later.
5. Submit. Your manager approves; the HRBP reviews exceptions.
6. Register, take the exam, and keep your results.

## 4. Deadlines and what happens next

| What the Bank covers | Detail |
| --- | --- |
| Registration and exam fees | 100% on approval |
| Annual membership fees | For designations your role requires |
| Study leave | 5 paid study days per designation exam |

Payroll Services reimburses approved fees on a regular pay date after approval. Designation fees do not count against the tuition cap ($5,000 CAD / $5,250 USD per fiscal year) or the $2,000 professional development budget. Study days are not deducted from vacation, sick or personal days (see HR-POL-006 Vacation and Paid Time Off Policy), cannot be carried forward and cannot be paid out.

Fees are not repayable unless you have not completed the exam and resign within 12 months of reimbursement; the SVP Talent and Learning decides.

## 5. Common mistakes

- Registering or paying before the form is approved.
- Requesting study days less than 10 business days ahead when the exam date was already known.
- Using this form for a regulatory licence.
- Counting study days as vacation. They are separate.
- Forgetting to keep exam results.

## 6. Who to call

- Your manager first; your HRBP for exceptions.
- HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example.

## 7. Related documents

- HR-POL-012 Learning and Development Policy (the owning document)
- FORM-HR-061 Professional Designation Reimbursement Request
- HR-POL-029 Licensing, Registration and Qualification Policy

Where applicable law gives a greater right, the law applies.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.1 | 2025-11-01 | Aligned with HR-POL-012 version 3.2. |
| 1.0 | 2025-01-01 | First version. |
