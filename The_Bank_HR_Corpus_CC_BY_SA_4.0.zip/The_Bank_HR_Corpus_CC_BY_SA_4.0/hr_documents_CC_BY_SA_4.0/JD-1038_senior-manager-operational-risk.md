# Senior Manager, Operational Risk

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1038 |
| Title | Senior Manager, Operational Risk |
| Document type | Job description |
| Version | 1.1 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-08-19 |
| Next review | 2027-08-19 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-POL-002, HR-POL-018, HR-POL-030, HR-POL-022 |

## 1. Role summary

The Senior Manager, Operational Risk leads the team that identifies, measures and reduces operational risk across the Bank's business units: process failures, people and conduct risk, technology and third-party outages, fraud and business-continuity exposure. The role sets the operating plan for the function, challenges the first line and reports loss events and trends to the Director, Enterprise Risk. The role is Band 6 (Manager II / Senior Manager): it manages several teams or a significant function. See HR-GDE-006 Job Architecture and Pay Bands Guide.

## 2. Key responsibilities

- Lead and develop a team of operational risk analysts and officers, including goal setting and year-end ratings under HR-POL-011 Performance Management Policy.
- Own the risk and control self-assessment programme and the annual scenario analysis.
- Review operational loss events, near misses and root-cause analyses, and track remediation to closure.
- Challenge business-unit control design and test results; agree action plans with owners and due dates.
- Maintain key risk indicators and escalate threshold breaches to the Director, Enterprise Risk within 1 business day.
- Oversee third-party and outsourcing risk reviews with Procurement and the Chief Information Security Officer's team.
- Coordinate with Compliance on conduct risk themes and with Workplace Safety on business-continuity testing, which occurs twice a year.
- Prepare quarterly risk reporting for executive and board committees.
- Coach managers across the Bank on speaking up and escalating concerns, consistent with HR-POL-022 Whistleblower and Speak-Up Policy.
- Manage the function's budget and external audit and regulatory examination responses.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in business, finance, engineering or a related field.
- Nine or more years of experience in risk management, internal audit, compliance or operations, including at least 3 years leading people.
- Demonstrated skill in control testing, root-cause analysis and risk quantification.
- Ability to present complex risk matters to senior leaders.

### 3.2 Preferred

- Master's degree or a recognized risk or audit designation; the Bank reimburses approved designations (HR-POL-012 Learning and Development Policy).
- Experience in a regulated financial institution.

### 3.3 Licences, screening and conduct

No licence is required under HR-POL-029 Licensing, Registration and Qualification Policy. The role is Band 6 and is re-screened every 5 years (HR-POL-020 Pre-Employment Screening Policy). Annual fit-and-proper attestation applies (HR-POL-030 Fit and Proper and Conduct Standards Policy).

## 4. Competencies

Competency names follow HR-FWK-001 Competency and Leadership Model (Leader level, Bands 5 to 6).

- Risk and Conduct Awareness
- Judgement and Decision Quality
- Inclusive Leadership
- Developing Others
- Collaboration
- Drive for Results

## 5. Compensation and classification

| Item | Detail |
| --- | --- |
| Band | 6 (Manager II / Senior Manager) |
| Canada range | $112,000 to $168,000 CAD per year |
| US range | $110,000 to $166,000 USD per year |
| Incentive target | 15% of base salary (Annual Incentive Plan) |
| Overtime eligibility, Canada | No |
| FLSA classification, US | Exempt |
| Work arrangement | Hybrid |

## 6. Working conditions and accessibility

Office-based and hybrid by default, with at least 3 days a week in the office; Tuesday and Thursday are anchor days (HR-POL-002 Remote and Hybrid Work Policy). The arrangement is recorded on FORM-HR-030. Occasional travel to regional offices is possible. The Bank provides accommodation to the point of undue hardship (HR-POL-018 Workplace Accommodation and Accessibility Policy).

## 7. Reporting line

Reports to the Director, Enterprise Risk. Direct reports: operational risk managers and analysts.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.1 | 2026-03-01 | Pay ranges and incentive target aligned with the 2026 pay bands |
| 1.0 | 2025-01-01 | First issue |
