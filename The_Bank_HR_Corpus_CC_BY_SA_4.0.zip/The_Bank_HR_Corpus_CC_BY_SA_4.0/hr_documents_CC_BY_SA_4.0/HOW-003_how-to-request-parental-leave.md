# How to request parental leave

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-003 |
| Title | How to request parental leave |
| Document type | How-to article |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-11-01 |
| Last reviewed | 2026-08-10 |
| Next review | 2027-08-10 |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-008, HR-POL-007, FORM-HR-012, FORM-HR-013 |

## 1. The short answer

Submit FORM-HR-012 Parental Leave Notice and Top-Up Application in MyHR at least 4 weeks before your leave starts, and apply to the government benefit program at the same time if you are in Canada.

## 2. Who this applies to

Regular full-time and part-time employees, and fixed-term employees of 6 months or more, in Canada and the US. Quebec employees follow the same steps, with the Quebec Parental Insurance Plan in place of Employment Insurance.

| | Canada | US |
| --- | --- | --- |
| Bank-paid | Top-up to 100% of base salary: 17 weeks (birth parent), 8 weeks (non-birth, adoptive, surrogacy-intended) | 12 weeks at 100% of base salary for any new parent |
| Needs | 6 months of continuous service for the top-up | FMLA needs 12 months, 1,250 hours and 50 employees within 75 miles |
| Job protection | Up to 18 months for birth parents; leave must begin within 78 weeks of the birth or placement | 12 weeks under the Family and Medical Leave Act |

## 3. Steps

1. Tell your manager early.
2. Select **MyHR > Time and Absence > Parental Leave** and complete FORM-HR-012: type of leave, due or placement date, start and return dates, service start date.
3. Attach evidence: a medical certificate showing the due date, placement or adoption papers, or a surrogacy agreement (placement papers within 30 days of placement).
4. Canada: apply to Employment Insurance (or the Quebec Parental Insurance Plan) as early as possible, and send each benefit notice to the Leaves team within 5 business days of receiving it. The government pays that benefit and the Bank cannot guarantee it.
5. US birth parents: the Leaves team also arranges short-term disability for recovery (up to 6 weeks vaginal, 8 weeks caesarean; see HOW-004).

## 4. What happens next

The Leaves team confirms your leave dates, top-up amount and return conditions in writing within 5 business days of a complete application. Pregnancy leave may start up to 13 weeks before the due date and lasts up to 17 weeks. The Bank keeps paying its share of benefits, and vacation accrual and retirement contributions continue during Bank-paid pay. Give 4 weeks' notice of your return date. A phased return of up to 4 weeks at 80% of normal hours is available, and you return to the same or a comparable role at the same pay band.

## 5. Common mistakes

- Waiting for the government decision before telling the Bank.
- Forgetting to send benefit notices within 5 business days.
- Starting parental leave later than 78 weeks after the birth or placement.
- Using this form for caregiver leave; use FORM-HR-013 instead.

## 6. Who to call

HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, or live chat in MyHR.

## 7. Related documents

- HR-POL-008 Parental and Family Leave Policy
- HR-POL-007 Sick Leave and Personal Leave Policy
- FORM-HR-012 Parental Leave Notice and Top-Up Application

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-11-01 | Updated for 8-week non-birth top-up and 12-week US paid leave (HR-POL-008 version 5.1). |
| 1.0 | 2025-01-15 | First edition. |
