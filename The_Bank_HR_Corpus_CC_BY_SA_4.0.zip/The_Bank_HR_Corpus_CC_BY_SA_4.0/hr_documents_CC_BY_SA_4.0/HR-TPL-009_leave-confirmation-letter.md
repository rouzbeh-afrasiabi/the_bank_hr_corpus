# Leave Confirmation Letter

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-TPL-009 |
| Title | Leave Confirmation Letter |
| Document type | Template |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-06-30 |
| Next review | 2027-06-30 |
| Policy owner | VP HR Operations |
| Audience | HR only |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-008, HR-POL-007, FORM-HR-012, FORM-HR-010 |

## 1. Purpose and when to use this template

The Leaves team uses this template to confirm an approved leave in writing: parental leave (HR-POL-008 Parental and Family Leave Policy), personal unpaid leave and medical leaves (HR-POL-007 Sick Leave and Personal Leave Policy), and caregiver leave. The letter states the dates, the pay arrangement, benefits and the return conditions.

## 2. How to use this template

1. Send the letter within 5 business days of receiving a complete application (for example FORM-HR-012 Parental Leave Notice and Top-Up Application or FORM-HR-010 Leave of Absence Request).
2. Keep the leave type block that applies and delete the others.
3. Calculate pay with Payroll Services. Do not state government benefit amounts; the employee applies to the government and the Bank cannot guarantee it.
4. Copy the manager only with the dates and return conditions, never with medical or family details.

## 3. Letter text

**[Date]**   **Personal and confidential**

**[Employee full name]**, [Job title], Band [Band]

**Subject: Confirmation of your [Leave type]**

Dear [Employee first name],

We confirm your **[Leave type]** from **[Start date]** to **[Expected end date]**, based on the application you submitted on **[Application date]**.

**Pay.**

- **[Canada, birth parent, pregnancy leave:]** The Bank tops up your pay to 100% of base salary for **17 weeks**, coordinated with your government benefit.
- **[Canada, non-birth, adoptive or surrogacy-intended parent:]** The Bank tops up your pay to 100% of base salary for **8 weeks**, coordinated with your government benefit. The top-up requires 6 months of continuous service.
- **[US, any new parent:]** The Bank pays **12 weeks** at 100% of base salary, running together with FMLA and any state paid family leave program.
- **[Personal unpaid leave:]** The leave is unpaid. The maximum is 6 months. Your benefits continue only if you pay both the employee and Bank shares of the premiums, and vacation stops accruing after 30 days of leave.
- **[Caregiver leave:]** The leave is unpaid and job-protected for up to **[Weeks]** weeks.

**Government benefits.** You are responsible for applying to the government program and for sending the Leaves team your benefit notice within 5 business days of receiving it.

**Benefits and accruals.** The Bank continues its share of your benefits during Bank-paid leave **[and, in Canada, throughout the job-protected leave of up to 18 months]**. Vacation accrual continues during the top-up period. Retirement contributions continue on top-up pay.

**Returning to work.** Please give 4 weeks' notice of your return date. You will return to the same or a comparable role at the same pay band. A phased return of up to 4 weeks at 80% of normal hours, paid for hours worked, can be arranged with your manager and the Leaves team. **[Medical leave: A fitness-to-work form (FORM-HR-011) is required before return.]**

**Questions.** Contact the Leaves team through the HR Case Portal or HR Connect at 1-800-555-0142. The Wellspring Support Program, 1-800-555-0166, is available at any time.

Sincerely,
**[Leaves specialist name]**, Leaves team, HR Operations

## 4. Required clauses checklist

| Clause | Required content |
| --- | --- |
| Dates | Start date and expected end date |
| Pay | Top-up weeks (Canada 17 or 8; US 12) or unpaid status |
| Government benefit | Employee applies; the Bank cannot guarantee it |
| Benefits | Bank share continues during Bank-paid leave |
| Return | 4 weeks' notice; same or comparable role; phased return up to 4 weeks at 80% |

## 5. Drafting notes for HR

- Parental leave must begin within 78 weeks of the birth or placement in Canada; the total job-protected leave is up to 18 months combined for birth parents.
- US birth parents also receive short-term disability for medical recovery (up to 6 weeks, or 8 weeks after a caesarean), described in HR-POL-007.
- Confidential medical and family documents stay with the Leaves team, separate from the personnel file.
- Quebec employees receive the letter in French and the Quebec Parental Insurance Plan replaces Employment Insurance in the wording.
- If an employee is not eligible for FMLA, the US 12 weeks of Bank-paid leave still applies and the role is held for the same period.

## 6. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.0 | 2023-04-03 | First leave confirmation template |
| 2.0 | 2025-09-01 | Restructured by leave type and added the government-benefit, phased return and return-notice wording |
