# Recognition Award Nomination

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-126 |
| Title | Recognition Award Nomination |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-043, HR-POL-011, HR-POL-019, HR-FWK-001 |

## 1. Purpose and when to use this form

Use this form to nominate an employee or team for a Bank recognition award (HR-POL-043 Recognition and Awards Policy). Awards recognize behaviours that reflect the Bank values, described in HR-FWK-001 Competency and Leadership Model.

| Award | Amount | How to nominate |
| --- | --- | --- |
| Annual Excellence Award | Up to 60 recipients, $2,500 CAD / $2,000 USD each | This form, 1 September to 15 October; announced in December |
| Spot award | Manager up to $250 CAD / $200 USD; Director up to $500 / $400; maximum 3 per employee per fiscal year | This form, or directly by the awarding manager |
| Peer recognition points | 1 point = $1, redeemable in a catalogue, up to 500 points per recipient per fiscal year | MyHR, not this form |

Service awards at 5, 10, 15, 20, 25, 30, 35 and 40 years are handled by HR Operations and do not use this form. Referral bonuses are separate (HR-POL-019 Recruitment and Selection Policy).

## 2. Who completes it and who approves

Any employee may nominate a colleague. The nominee's manager endorses it, and a Director or above must support it. For spot awards, the manager or Director approves within their limit. Excellence Award recipients are selected by the Recognition Review Panel and recommended to the CHRO.

## 3. Where and when to submit (deadline, channel, processing time)

Submit in MyHR (Recognition > Nominate). Excellence Award nominations close on 15 October; late nominations are not accepted. Spot awards may be submitted at any time during the fiscal year (1 November to 31 October).

## 4. Form fields

| Field | Required | Notes |
| --- | --- | --- |
| Nominator name and employee ID | Yes | Pre-filled |
| Nominee name, employee ID and manager | Yes | Teams: list each member |
| Award type | Yes | Excellence Award or spot award |
| Amount requested (spot award) | For spot awards | Within manager or Director limits |
| Bank value shown | Yes | Integrity, Customer Focus, Accountability, Collaboration or Inclusion |
| Achievement and measurable impact | Yes | Describe what happened and the result for customers, colleagues or the Bank |
| Dates of the achievement | Yes | |
| Supporting evidence | No | Customer feedback, metrics |
| Is a conduct or risk matter open for the nominee? | Yes | Answer to the best of your knowledge |

## 5. Declarations and signatures

I confirm that the nomination is accurate and that I have no personal or financial interest in the outcome (see FORM-HR-100 Conflict of Interest Disclosure if you do). Nominator signature and date: ____________. Manager endorsement and date: ____________.

## 6. What happens next

The nominee's manager and HRBP check the nomination. Approved spot awards are paid through payroll. Cash awards are taxable. Excellence Award winners are announced in December. Unsuccessful nominations are not recorded on the nominee's file.

## 7. Related documents

- HR-POL-043 Recognition and Awards Policy
- HR-FWK-001 Competency and Leadership Model
- FORM-HR-100 Conflict of Interest Disclosure

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-01-01 | Added spot award and Excellence Award nomination windows. |
| 1.0 | 2023-09-01 | Initial form. |
