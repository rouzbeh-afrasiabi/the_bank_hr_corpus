# Annual Personal Holdings Disclosure

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-125 |
| Title | Annual Personal Holdings Disclosure |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | Chief Compliance Officer |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-032, HR-POL-001, FORM-HR-124, HR-SUP-003 |

## 1. Purpose and when to use this form

Covered persons use this form to disclose all brokerage accounts and personal holdings once a year (HR-POL-032 Personal Trading and Restricted Lists Policy). Covered persons are employees in Capital Markets, Wealth Management and Treasury, and others designated by Compliance. It helps Compliance monitor conflicts and insider-information risk, consistent with HR-POL-001 Code of Conduct and Ethics.

## 2. Who completes it and who approves

You complete it. Compliance reviews it and may ask for statements or clarification. Include accounts held by you and by anyone in your household.

## 3. Where and when to submit (deadline, channel, processing time)

Submit by 31 January each year in MyHR (Ethics > Annual Holdings). New covered persons disclose all brokerage accounts within 30 days of hire or designation. Breaches of the disclosure rules are conduct matters.

## 4. Form fields

| Field | Required | Notes |
| --- | --- | --- |
| Name, employee ID, business unit | Yes | Pre-filled |
| Brokerage name and account number | Yes | One line per account; covered persons use Bank-approved brokerages |
| Account holder and relationship | Yes | Yourself or a household member |
| Duplicate statements arranged with Compliance | Yes | Yes or No |
| Individual securities held | Yes | Name, ticker, quantity |
| Mutual funds, exchange-traded funds, government bonds, automatic investment plans | Yes | Disclosed, though they need no pre-clearance |
| Accounts opened or closed this year | Yes | |
| Trades made without pre-clearance | Yes | State "None" or describe |
| Account over which you do not have control | No | For example a managed account |

## 5. Declarations and signatures

I confirm that this list is complete and accurate, that I have pre-cleared every trade in individual securities using FORM-HR-124 Personal Trading Pre-Clearance Request, that I have respected the 30-day minimum holding period, and that I will tell Compliance of new accounts. Signature and date: ____________.

## 6. What happens next

Compliance reconciles your disclosure to the duplicate statements and trade records and may follow up. Any gaps are discussed with you first. Confirmed breaches are conduct matters (HR-POL-021 Employee Relations and Progressive Discipline Policy). Holdings information is confidential and used only for compliance monitoring. Capital Markets employees should also see HR-SUP-003 Capital Markets Addendum.

## 7. Related documents

- HR-POL-032 Personal Trading and Restricted Lists Policy
- FORM-HR-124 Personal Trading Pre-Clearance Request
- HR-POL-001 Code of Conduct and Ethics

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-09-01 | Set the 31 January deadline and added the household and exempt instrument lines. |
| 1.0 | 2021-08-01 | Initial form. |
