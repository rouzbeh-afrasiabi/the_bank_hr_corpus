# Proposed Compressed Four-Day Work Week Pilot

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

> **DRAFT: do not rely on this document.**

| Field | Value |
| --- | --- |
| Document ID | HR-DRAFT-001 |
| Title | Proposed Compressed Four-Day Work Week Pilot |
| Document type | Draft |
| Version | 0.3 |
| Status | Draft |
| Approval status | Not approved. Not in effect. Under review by the HR Policy Committee. |
| Effective date | 2026-08-10 |
| Last reviewed | Not applicable |
| Next review | Not applicable |
| Policy owner | VP HR Operations |
| Audience | HR leadership |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-002, HR-POL-003, HR-POL-006, HR-POL-010, HR-SUP-004 |

## 1. Status of this draft

This is a working draft dated 10 August 2026. It has not been approved by the HR Policy Committee and is not in effect. Nothing in it changes any current rule. Until a decision is taken, HR-POL-002 Remote and Hybrid Work Policy (at least 3 office days a week for hybrid employees, anchor days Tuesday and Thursday) and HR-POL-003 Working Hours and Overtime Policy (37.5-hour week in Canada, 40-hour week in the US) continue to apply. Employees must not be told that a four-day week is available.

## 2. Purpose and summary of the proposal

The proposal is a 6-month voluntary pilot of a compressed work week to test the effect on engagement, productivity, absence and service levels. Participants would work 4 days of 9.4 hours (37.6 hours a week) for the same pay as today.

| Item | Proposal |
| --- | --- |
| Pilot period | 6 months, 1 April 2027 to 30 September 2027 |
| Business units | 3: Technology and Operations (non-branch teams), Corporate Functions, Commercial Banking |
| Participants | About 2,400 employees, voluntary and team-based |
| Schedule | 4 days of 9.4 hours; the day off is Monday or Friday, chosen by the team |
| Pay and benefits | Unchanged; same base salary, incentive target and benefits |
| Excluded roles | Branch, contact-centre and trading-floor roles that follow posted schedules (HR-SUP-004 Branch Operations Scheduling Supplement) |
| Measures | Engagement pulse, service levels, absence, attrition, overtime hours, manager feedback |

## 3. Proposed rules during the pilot (for discussion)

- Anchor days (Tuesday and Thursday) and core hours of 10:00 to 15:00 would continue to apply to hybrid participants.
- Schedules would be posted at least 14 days ahead and changed only by consent, as in HR-POL-003.
- A vacation day taken on a compressed day would be charged as one day (see open question 6).
- Either the employee or the Bank could end participation with 30 calendar days' notice, and the employee would return to the standard schedule.

## 4. Open questions

| No. | Question | Owner | Needed by |
| --- | --- | --- | --- |
| 1 | Daily overtime: a 9.4-hour day exceeds 8 hours, which triggers daily overtime in British Columbia, Alberta and California. Should these employees be excluded, or should the Bank pay the premium? | SVP Total Rewards and Legal | 2026-10-30 |
| 2 | US hours: a 37.6-hour week is 2.4 hours below the 40-hour US standard week. Do US participants keep 40-hour pay for 37.6 hours, or work 4 days of 10 hours? | VP HR Operations | 2026-10-30 |
| 3 | Overtime-eligible and non-exempt employees: how are hours between 37.6 and 40 treated, and how does overtime approval work (HR-POL-003)? | SVP Total Rewards | 2026-11-13 |
| 4 | Coverage: how do teams cover the off day while keeping service levels, and who approves coverage plans? | Business unit heads | 2026-11-13 |
| 5 | Statutory holidays: is holiday pay for a 9.4-hour day paid at 9.4 hours or at the regular daily rate (HR-POL-010)? | SVP Total Rewards | 2026-11-13 |
| 6 | Vacation, sick and personal days are defined as 7.5 or 8 hours (HR-POL-006). Are they converted to hours for participants? | SVP Total Rewards | 2026-11-13 |
| 7 | Accommodation and caregiver needs: how do employees who cannot work 9.4-hour days take part? | Head of Accessibility and Inclusion | 2026-11-27 |
| 8 | Privacy and monitoring: which data may be used to measure the pilot (HR-POL-016)? | Chief Privacy Officer | 2026-11-27 |

## 5. Cost and impact analysis

These figures are planning estimates for discussion only. They are not budgeted or approved.

| Item | Basis | Estimate |
| --- | --- | --- |
| Daily overtime premium | 130 overtime-eligible participants in British Columbia, Alberta and California; 5.6 hours a week above 8 hours a day; $38 average hourly rate; premium of 0.5 x rate; 26 weeks | $359,632 |
| Coverage of the off day | 10% of 2,400 participants (240 employee-days a week) need cover; 26 weeks (6,240 days) at $330 a day | $2,059,200 |
| US capacity gap | 400 US participants x 2.4 hours a week x 26 weeks (24,960 hours) at $41.25 an hour | $1,029,600 |
| Pilot management and evaluation | HRBP time, analytics, surveys, independent evaluation | $450,000 |
| **Total estimated pilot cost** | Sum of the above (about $1,624 per participant) | **$3,898,432** |
| Possible offsetting benefit (not counted) | 0.5 fewer sick days per participant (1,200 days at $330) | $396,000 |

Impact notes: the Canadian week would be 0.1 hour longer than the 37.5-hour standard; engagement and attrition effects are unknown and are the reason for the pilot.

## 6. Risks

- Daily overtime and meal-period rules differ by jurisdiction; non-compliance risk is highest in California (see HR-SUP-002 California Supplement).
- Perceived unfairness for employees in excluded roles.
- Customer service gaps on the off day.

## 7. Next steps

1. Answer open questions 1 to 8 and obtain Legal review.
2. Return a costed version to the HR Policy Committee for a decision on whether to proceed.
3. If approved, publish a policy supplement and communicate 3 months before the start date.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 0.1 | 2026-06-15 | First outline of a four-day week pilot |
| 0.2 | 2026-07-13 | Added pilot business units, measures and open questions |
| 0.3 | 2026-08-10 | Added the cost and impact analysis and daily overtime questions |
