# More Paid Sick Days from 1 January 2026

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-MEMO-2025-005 |
| Title | More Paid Sick Days from 1 January 2026 |
| Document type | Memo |
| Version | 1.0 |
| Status | Current |
| Effective date | 2025-10-20 |
| Last reviewed | Not applicable |
| Next review | Not applicable |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-007, HR-POL-004, FORM-HR-011, HR-ARC-002 |

**Paid sick days go up in 2026: 10 in Canada and 8 in the US.**

**From:** SVP Total Rewards

**To:** All employees in Canada and the US

**Date:** 20 October 2025

**Subject:** Increase in paid sick days, HR-POL-007 version 3.0

## 1. What is changing

| Item | Old (to 31 December 2025) | New (from 1 January 2026) |
| --- | --- | --- |
| Paid sick days per calendar year, Canada | 8 | 10 |
| Paid sick days per calendar year, US | 6 | 8 |
| Personal days per calendar year | 3 | 3 (no change) |

Sick days are credited on 1 January, pro-rated for new hires, with no carryover and no payout. Up to 5 sick days may be used for family care. The minimum use is a half day.

## 2. Who is affected

All employees eligible for paid sick days. Where applicable law gives a greater right, the law applies.

## 3. Effective date

1 January 2026.

## 4. What to do

1. Report an absence to your manager before your scheduled start, or within 30 minutes after it.
2. Enter the absence in Time Tracker when you return.
3. From the 4th consecutive working day, submit FORM-HR-011 (Medical Certificate and Fitness-to-Work). In Quebec, evidence is requested only after 3 consecutive days.

## 5. Who to call

HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, or live chat in MyHR.

## 6. Related documents

- HR-POL-007 Sick Leave and Personal Leave Policy
- HR-POL-004 Attendance and Absenteeism Policy
- HR-ARC-002 Sick Leave and Personal Leave Policy (version 2.2), archived
