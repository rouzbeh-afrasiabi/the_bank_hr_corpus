# Work Arrangement Request (Hybrid or Remote)

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-030 |
| Title | Work Arrangement Request (Hybrid or Remote) |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-01-05 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-002, HR-POL-017, HR-POL-018, FORM-HR-031 |

## 1. Purpose and when to use this form

Use this form to record your hybrid schedule, to request a Remote arrangement, to change or end an arrangement, or to tell the Bank you are moving. On-site roles do not need it.

## 2. Who completes it and who approves

You complete it. Your manager responds within 5 business days; for Remote, the HRBP confirms eligibility. The business unit head must have designated the role remote-eligible.

## 3. Where and when to submit

Submit in MyHR. If you are moving to a different province or state, submit at least 30 days before the move. To end an arrangement, give 4 weeks' notice. If the Bank ends it for business reasons, you receive at least 30 calendar days' written notice.

## 4. Form fields

| Field | Required | Notes |
| --- | --- | --- |
| Requested arrangement | Yes | Hybrid or Remote |
| Office days | Hybrid | At least 3 days a week; Tuesday and Thursday are anchor days; the team chooses the third day |
| Home address and jurisdiction | Remote | Must be on the approved employment-jurisdiction list |
| Remote eligibility | Remote | Probation complete, last rating Meets Expectations or higher, no active performance improvement plan |
| Planned in-person events | Remote | Up to 4 per year |
| Equipment | No | Laptop, headset, one external monitor on request |
| Setup allowance | No | Once every 3 years: Hybrid $300 CAD / $225 USD; Remote $600 CAD / $450 USD |

## 5. Declarations and signatures

- I will follow the VPN, private-workspace and screen-lock rules in HR-POL-017 IT Acceptable Use and Information Security Policy.
- I am available online during core hours, 10:00 to 15:00 local time.
- I will claim the setup allowance with receipts within 60 days of purchase.
- Part-time hybrid employees attend 60% of scheduled days, rounded up.

## 6. What happens next

HR Operations records the arrangement in MyHR. A manager may approve up to 12 office-attendance exception days per calendar year; more needs the HRBP. A team may change its third day with 10 business days' notice. Accommodation needs follow HR-POL-018 and do not count against the 12 days. Where applicable law gives a greater right, the law applies.

## 7. Related documents

- HR-POL-002 Remote and Hybrid Work Policy
- HR-POL-017 IT Acceptable Use and Information Security Policy
- HR-POL-018 Workplace Accommodation and Accessibility Policy

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-01-05 | Updated for the 3-day hybrid minimum and Tuesday and Thursday anchor days from 5 January 2026. |
