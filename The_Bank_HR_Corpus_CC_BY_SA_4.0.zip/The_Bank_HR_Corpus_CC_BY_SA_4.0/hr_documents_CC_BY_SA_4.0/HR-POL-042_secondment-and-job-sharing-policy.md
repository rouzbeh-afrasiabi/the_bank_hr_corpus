# Secondment and Job Sharing Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-042 |
| Title | Secondment and Job Sharing Policy |
| Document type | Policy |
| Version | 1.3 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-08-12 |
| Next review | 2027-08-12 |
| Policy owner | VP HR Operations |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-014, HR-POL-011, HR-POL-006, HR-POL-002, HR-POL-039, FORM-HR-121, FORM-HR-128 |

## 1. Purpose

This policy describes two flexible ways of working at the Bank: a **secondment**, where an employee works for a time in another business unit, and **job sharing**, where two employees share one full-time role. Secondments build skills and networks across the Bank; job sharing lets employees reduce their hours while the role remains covered. The policy sets eligibility, approval, pay and benefits, performance and the steps and deadlines for both. Promotions and transfers are handled separately and are not governed by this policy.

## 2. Scope

The policy applies to regular full-time and regular part-time employees in Canada and the US. Casual, fixed-term, student, co-op and intern employees, and contractors and agency workers, are not eligible (see HR-POL-014 Employment Status and Classification Policy). Where applicable law gives a greater right, the law applies.

## 3. Definitions

- **Secondment:** a temporary assignment of an employee, with their agreement, to a role in a business unit other than their own.
- **Home manager and home unit:** the employee's manager and business unit before the secondment.
- **Host manager and host unit:** the manager and business unit the employee is seconded to.
- **Job share:** an arrangement in which two employees (the **partners**) share the duties and hours of one full-time role.
- **Split:** the division of hours between partners, either **50/50** or **60/40**.
- **Handover protocol:** the written agreement on how the partners hand over work, communicate and cover each other.
- **Trial period:** the first 6 months of a job share.

## 4. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Employee or partners | Apply, meet the eligibility conditions, keep to the agreed arrangement |
| Home and host managers | Agree the arrangement; the home manager plans backfill and keeps responsibility for performance and pay; the host manager sets goals, assigns work and gives performance input |
| HRBP | Confirms eligibility, approves with the managers, records the arrangement in MyHR |
| HR Operations | Updates MyHR and notifies Payroll Services and Benefits Administration |
| VP HR Operations | Owns this policy and decides exceptions |

## 5. Secondment

### 5.1 Rules

| Item | Rule |
| --- | --- |
| Length | 3 to 18 months |
| Extension | Once, up to 6 months, so the maximum total is 24 months |
| Eligibility | At least 12 months of service; last rating Meets Expectations or higher; no active performance improvement plan |
| Approval | Both managers and the HRBP |
| Band, pay and benefits | Unchanged |
| End of secondment | Return to the same or a comparable role in the home unit |
| Form | FORM-HR-121 Secondment Request |

### 5.2 Pay, benefits and entitlements

The employee remains an employee of the home unit. Band, base salary and benefits do not change because of the secondment, and the secondment is not a promotion. Vacation, sick and personal days, holidays and service continue as before (see HR-POL-006 Vacation and Paid Time Off Policy), and the host manager approves absences against the employee's usual balances. The two business units may agree to recharge the cost between themselves. A secondment into a higher band role does not move the employee into that band; any later move into it is handled separately.

### 5.3 Location and work arrangement

The employee follows the work arrangement of the host role, as recorded on FORM-HR-030 under HR-POL-002 Remote and Hybrid Work Policy, unless the managers agree otherwise in writing. A secondment does not by itself qualify for relocation benefits (see HR-POL-039 Relocation and Global Mobility Policy).

### 5.4 Performance, goals and the Annual Incentive Plan

The host manager sets goals with the employee within **30 days** of the start date and gives written performance input to the home manager before the mid-year check-in (1 May to 15 June) and before the year-end assessment due on 10 December. The home manager remains accountable for the performance rating and incorporates the host input (see HR-POL-011 Performance Management Policy). Annual Incentive Plan eligibility and any pro-ration are decided by the home unit using the rules in HR-POL-009 Compensation and Payroll Policy.

### 5.5 Procedure and deadlines

1. The employee discusses the opportunity with the home manager.
2. The employee submits FORM-HR-121 in MyHR **at least 30 days before** the proposed start date, giving the role, length, goals, backfill plan and development aim.
3. The HRBP confirms eligibility within **3 business days**.
4. The home manager, the host manager and the HRBP each respond within **10 business days** of the complete request. Approval needs all three.
5. HR Operations records the secondment in MyHR before the start date and the employee receives a confirmation letter showing the dates.
6. A request to extend is submitted on FORM-HR-121 at least **30 days before** the end date; the extension may be approved only once and for up to 6 months.
7. Either the employee or either manager may end a secondment early with **30 days'** written notice to the other parties and the HRBP. The employee returns to the home role or a comparable one.

## 6. Job sharing

### 6.1 Rules

| Item | Rule |
| --- | --- |
| Who | Two employees sharing one full-time role |
| Split | 50/50 or 60/40 of the hours of the role |
| Eligibility | At least 12 months of service each; last rating Meets Expectations or higher; no active performance improvement plan |
| Trial | 6 months |
| Handover | Written handover protocol before the start |
| Benefits | Pro-rated by hours; partners are treated as regular part-time employees under HR-POL-014 |
| Departure of a partner | Triggers a 60-day review |
| Form | FORM-HR-128 Job Sharing Request |

### 6.2 Classification, pay and entitlements

Each partner is recorded as a **regular part-time** employee for the duration of the job share, even if the scheduled hours are below the 20-hour line in HR-POL-014, so that benefits and pension continue from day 1 and are not reduced to casual terms. Pay is the pay for the role, pro-rated by scheduled hours. Vacation, sick days, personal days and the Annual Incentive Plan are pro-rated by hours; holiday pay is calculated under HR-POL-010 Statutory Holidays Policy for part-time employees. Each partner has their own goals, rating and development plan. Where the role is overtime-eligible, overtime is paid only for hours over the partner's scheduled hours that the manager has approved in advance under HR-POL-003 Working Hours and Overtime Policy.

### 6.3 Handover protocol

The partners and the manager prepare a one-page written handover protocol covering the days and hours each partner works, how handover notes are recorded, which partner is the contact for which customers or tasks, who attends which meetings, and how absences are covered. The protocol is attached to FORM-HR-128 and reviewed at the end of the trial.

### 6.4 Procedure and deadlines

1. The employee, with the partner, discusses the proposal with the manager. Where the partner is not yet identified, the manager and the HRBP help to find one. The proposal is not approved until both partners are named.
2. The partners submit FORM-HR-128 in MyHR **at least 30 days before** the proposed start.
3. The HRBP confirms eligibility within **3 business days** and decides, with the manager, within **10 business days** of the complete request.
4. HR Operations records the arrangement and notifies Payroll Services and Benefits Administration, so that pay, benefits and pro-rated entitlements change from the start of a pay period.
5. A review at **3 months** and a decision at the **end of the 6-month trial** confirm the job share, adjust it or end it. If the trial succeeds, the job share continues until one party asks to end it with 4 weeks' notice, or until it ends under 6.5.

### 6.5 When a partner leaves or the job share ends

When either partner resigns, goes on extended leave, is moved or is otherwise unable to continue, the manager and HRBP hold a **60-day review**. Options are to recruit a new partner (following HR-POL-019 Recruitment and Selection Policy), for the remaining partner to move back to the full-time role if the person wishes and the role needs it, or to end the job share. The remaining partner continues on their current hours during the review and is not required to cover the missing hours. At the end of the arrangement each partner returns to their previous full-time hours and role where that role still exists, or a comparable one, with 4 weeks' notice, in line with the status-change rule in HR-POL-014.

## 7. Worked examples

**Example 1: secondment length.** A Band 4 employee with 3 years of service and a Meets Expectations rating is seconded for 12 months from 1 March 2026. She extends by 6 months, taking the total to 18 months. The extension is allowed only once, so a second extension would be refused. An employee with 9 months of service is not yet eligible and may apply at 12 months.

**Example 2: 60/40 split in Canada.** Two employees share one full-time Canadian role of 37.5 hours a week. The 60/40 split gives 22.5 and 15 hours. Both are recorded as regular part-time, with benefits from day 1 and vacation pro-rated by hours: 60% and 40% of the full-time entitlement for their years of service.

**Example 3: partner resigns.** One partner resigns with 4 weeks' notice; the 60-day review starts on the day the notice is given. The remaining partner keeps her hours, and the manager opens a requisition for a new partner.

## 8. Exceptions

The VP HR Operations may approve an exception to the 12-month service requirement, the 18-month secondment length or the 6-month trial for a clear business reason, with the business unit heads' agreement. Exceptions may not change sections 5.2 and 6.2 or any legal entitlement.

## 9. Consequences

Starting a secondment or job share without approval is not allowed; it is reversed from the date discovered and pay is corrected under HR-POL-009. Misrepresenting hours may lead to action under HR-POL-021 Employee Relations and Progressive Discipline Policy. No one may be penalized for asking for a secondment or job share, or for a declined request.

## 10. Related documents and contacts

Related: HR-POL-014 Employment Status and Classification Policy; HR-POL-011 Performance Management Policy; HR-POL-006 Vacation and Paid Time Off Policy; HR-POL-002 Remote and Hybrid Work Policy; HR-POL-039 Relocation and Global Mobility Policy; FORM-HR-121; FORM-HR-128. Contact HR Connect at 1-800-555-0142 or hrconnect@bank.example.

## 11. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.0 | 2023-09-01 | First policy on secondments and job sharing |
| 1.2 | 2024-09-01 | Added the single extension of up to 6 months and the 60-day review when a partner leaves |
| 1.3 | 2025-09-01 | Aligned the eligibility conditions at 12 months of service and added FORM-HR-121 and FORM-HR-128 |
