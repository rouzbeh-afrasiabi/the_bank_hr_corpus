# US Jurisdiction Quick Reference

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-REF-004 |
| Title | US Jurisdiction Quick Reference |
| Document type | Reference |
| Version | 1.1 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-10-05 |
| Next review | 2027-10-05 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | US |
| Language | English |
| Related documents | HR-POL-003, HR-POL-010, HR-POL-015, HR-POL-007, HR-POL-008, HR-SUP-002 |

## 1. Purpose and how to use this reference

This quick reference puts the US rules that differ by state into one place for the states where the Bank has most of its US employees: California, New York, New Jersey, Florida, Illinois and Texas. It is a summary, not a policy. It restates key values and points to the owner: HR-POL-003 Working Hours and Overtime Policy, HR-POL-010 Statutory Holidays Policy, HR-POL-015 Resignation and Offboarding Policy, HR-POL-007 Sick Leave and Personal Leave Policy and HR-POL-008 Parental and Family Leave Policy. If this page differs from an owning policy, the owning policy applies. Where applicable law gives a greater right, the law applies. Where a value is shown as "confirm with HR Connect", call 1-800-555-0142 or write to hrconnect@bank.example.

Your state is the state where you work, as recorded in MyHR. For Canadian rules, see HR-REF-003 Canada Jurisdiction Quick Reference. California employees also follow HR-SUP-002 California Supplement.

## 2. US at a glance

| Topic | Rule for all US employees | Owner |
| --- | --- | --- |
| Standard work week | 40 hours (8 hours a day, 5 days), with a 60-minute unpaid meal period | HR-POL-003 |
| Overtime-eligible employees | Non-exempt under the Fair Labor Standards Act (generally Bands 1 to 3 and some Band 4) | HR-POL-003 |
| Compensatory time | Not available; overtime is paid in cash | HR-POL-003 |
| Paid sick days | 8 per calendar year | HR-POL-007 |
| Personal days | 3 per calendar year | HR-POL-007 |
| Paid holidays | 11 | HR-POL-010 |
| Pay dates | Biweekly, Fridays | HR-POL-009 |
| Tax form | W-2 by 31 January | HR-POL-009 |
| Employment eligibility | Form I-9 within 3 business days of the start date | HR-GDE-003 |

## 3. Overtime and breaks by state

| State | Overtime rule | Meal and rest |
| --- | --- | --- |
| California | 1.5x after 8 hours a day and after 40 hours a week; 2x after 12 hours a day | Meal period of 30 minutes before the end of the 5th hour; a paid 10-minute rest break per 4 hours worked |
| New York | 1.5x after 40 hours a week | 30-minute unpaid meal period after at most 5 consecutive hours; two paid 15-minute rest breaks per full shift |
| New Jersey | 1.5x after 40 hours a week | Same as New York |
| Florida | 1.5x after 40 hours a week | Same as New York |
| Illinois | 1.5x after 40 hours a week (the standard Bank rule for all other states) | Same as New York; confirm with HR Connect for any state-specific rest rule |
| Texas | 1.5x after 40 hours a week (the standard Bank rule for all other states) | Same as New York |

Overtime must be pre-approved by the manager in Time Tracker. More than 8 overtime hours in a week needs Director approval and HR notification. Time entry is due by Friday 17:00 local time, with manager approval by Monday 12:00 local time.

## 4. Final pay deadlines by state

Final pay includes earned, unused vacation in every state. Payroll Services applies the deadline of the state of work (see HR-POL-015).

| State | Resignation | Termination by the Bank |
| --- | --- | --- |
| California | Within 72 hours of resignation without notice; on the last day if notice was given | Immediately on termination |
| New York | Next regular pay date | Next regular pay date |
| New Jersey | Next regular pay date | Next regular pay date |
| Florida | Next regular pay date | Next regular pay date |
| Illinois | Confirm with HR Connect (Payroll Services applies the legal deadline) | Confirm with HR Connect |
| Texas | Confirm with HR Connect (Payroll Services applies the legal deadline) | Confirm with HR Connect |

Where a deadline is earlier than the payroll cut-off, Payroll Services issues an off-cycle payment.

## 5. Sick leave by state

The Bank gives 8 paid sick days per calendar year in every state (see HR-POL-007). Sick days are credited on 1 January, pro-rated for new hires, with a minimum use of a half day. Up to 5 of the days may be used for family care.

| State | Statutory sick-leave position |
| --- | --- |
| California, New York, New Jersey | The Bank entitlement satisfies the state law; where the law gives more, the more generous rule applies |
| Florida, Illinois, Texas | The Bank entitlement applies; where a state or local law gives more, the more generous rule applies; confirm with HR Connect |

A medical certificate is required from the 4th consecutive working day of absence. Short-term disability starts after 5 consecutive working days of absence and is administered by Maplewood Benefits (claims line 1-800-555-0190).

## 6. The 11 Bank holidays in 2026

| Holiday | Date | Observed |
| --- | --- | --- |
| New Year's Day | 2026-01-01 (Thursday) | 2026-01-01 |
| Martin Luther King Jr. Day | 2026-01-19 (Monday) | 2026-01-19 |
| Presidents' Day | 2026-02-16 (Monday) | 2026-02-16 |
| Memorial Day | 2026-05-25 (Monday) | 2026-05-25 |
| Juneteenth | 2026-06-19 (Friday) | 2026-06-19 |
| Independence Day | 2026-07-04 (Saturday) | Friday 2026-07-03 |
| Labor Day | 2026-09-07 (Monday) | 2026-09-07 |
| Veterans Day | 2026-11-11 (Wednesday) | 2026-11-11 |
| Thanksgiving | 2026-11-26 (Thursday) | 2026-11-26 |
| Day after Thanksgiving | 2026-11-27 (Friday) | 2026-11-27 |
| Christmas Day | 2026-12-25 (Friday) | 2026-12-25 |

The holiday list is the same in every state. A holiday on a Saturday is observed on the preceding Friday; a holiday on a Sunday is observed on the following Monday. An employee who works a holiday receives regular holiday pay plus 1.5x for the hours worked, paid in cash. Regular full-time and part-time employees are eligible from day one, and holiday pay is forfeited only if the employee has an unexcused absence on both the scheduled day before and the scheduled day after. Two floating Cultural and Religious Observance Days apply per calendar year (see HR-POL-010).

### 6.1 Pay dates near the holidays

The pay dates of Friday 2026-11-27 and Friday 2026-12-25 are paid early, on Wednesday 2026-11-25 and Thursday 2026-12-24, because of the holidays.

## 7. Family and medical leave pointers

| Item | Rule | Owner |
| --- | --- | --- |
| Paid parental leave | 12 weeks at 100% of base salary for any new parent (birth, adoption, foster) | HR-POL-008 |
| FMLA job protection | 12 weeks; eligibility needs 12 months of service, 1,250 hours worked and 50 employees within 75 miles | HR-POL-008 |
| FMLA caregiver leave | Up to 12 weeks; military caregiver up to 26 weeks | HR-POL-008 |
| Birth parent recovery | Short-term disability for up to 6 weeks (vaginal birth) or 8 weeks (caesarean) | HR-POL-007, HR-POL-008 |
| State paid family leave | Runs concurrently with the 12 weeks; where a state program pays a benefit, the Bank pays the balance so total pay equals 100% of base salary | HR-POL-008 |

The Bank's 12 weeks of paid leave are available even if an employee is not eligible for FMLA. For Illinois, Texas and any state program, confirm with HR Connect. The Leaves team confirms the leave sequence in writing within 5 business days of a complete application on FORM-HR-012. Notice is given 4 weeks ahead where possible.

## 8. Privacy and benefits pointers

California employees have rights under the California Consumer Privacy Act and the California Privacy Rights Act (see HR-SUP-002 and HR-POL-016 Employee Data Privacy Policy). Access requests (FORM-HR-090) are answered within 30 days, with an extension of up to a further 30 days. For other states, the privacy rights that apply are set out in HR-POL-016; confirm with the Privacy Office at privacy@bank.example.

For health coverage after employment, COBRA election notice is sent within 14 days, the election window is 60 days and coverage can last up to 18 months. Benefits end at the end of the month in which employment ends (see HR-GDE-001 Employee Benefits Guide).

## 9. What this reference does not say

State laws change. Where a value is not shown here, see the owning policy or confirm with HR Connect.

## 10. Contacts

HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time, closed on Bank holidays; hrconnect@bank.example; live chat in MyHR. Manager Hotline: 1-800-555-0143. Privacy Office: privacy@bank.example. Ombuds Office: ombuds@bank.example.

## 11. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.0 | 2025-01-01 | First edition of the US quick reference |
| 1.1 | 2026-01-01 | Updated for the 2026 calendar, 8 paid sick days, 12 weeks of paid parental leave and the 8-hour weekly overtime approval threshold |
