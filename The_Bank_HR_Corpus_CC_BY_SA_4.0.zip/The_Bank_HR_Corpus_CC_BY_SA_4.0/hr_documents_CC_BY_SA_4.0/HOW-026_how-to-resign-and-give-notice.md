# How to resign and give notice

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-026 |
| Title | How to resign and give notice |
| Document type | How-to article |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-10-01 |
| Last reviewed | 2026-08-25 |
| Next review | 2027-08-25 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-015, FORM-HR-080, FORM-HR-081, FORM-HR-082 |

## 1. The short answer

Submit FORM-HR-080 (Resignation Notice) in MyHR > Employment > Resignation Notice to your manager and HR Operations; you give 2 weeks' notice in Bands 1 to 4, 4 weeks in Bands 5 and 6, and 8 weeks in Band 7 and above.

## 2. Who this applies to

Employees in Canada (including Quebec) and the US who resign or retire. Notice periods are the same in both countries. Involuntary exits follow HR-POL-025 Involuntary Termination and Severance Policy. Fixed-term employees follow the notice in their contract where it is shorter.

## 3. Steps

1. Check your band (see HR-GDE-006 Job Architecture and Pay Bands Guide) to confirm your notice period.
2. Open MyHR > Employment > Resignation Notice and complete FORM-HR-080: resignation or retirement, your proposed last day, your province or state, and a personal mailing address and email for tax slips.
3. Submit it. The notice period starts the day after you submit. Retirement needs at least 3 months' notice.
4. Within 2 business days, HR Operations acknowledges in writing and confirms your last day, final pay timing and next steps.
5. Within 3 business days of that acknowledgement, agree a handover plan with your manager.
6. Return equipment within 5 business days after your last day (remote employees receive a prepaid shipping kit). Access ends at 17:00 on your last day.
7. Join the voluntary exit interview in your final week with HR Operations, not your manager (FORM-HR-082).

## 4. Deadlines and what happens next

Shortened notice needs written agreement. Withdrawal needs the written agreement of your manager and HRBP before your last day. Final pay comes on the next regular pay date, never later than the legal deadline where you work (for example Quebec: the next regular pay date; British Columbia: 6 days after resignation; Alberta: 10 days; California: within 72 hours of resignation without notice, or on the last day if you gave notice; other jurisdictions are in HR-POL-015). It includes earned unused vacation.

The Annual Incentive Plan is paid only to employees on payroll on the payment date (the first pay date in February), so leaving earlier forfeits it. Benefits end at the end of the month (see HOW-027). In Canada the Record of Employment follows within 5 calendar days after the end of the pay period in which employment ends, and the T4 or Relevé 1 by 28 February. In the US the W-2 follows by 31 January.

## 5. Common mistakes

- Telling your manager only verbally. Only FORM-HR-080 starts the notice.
- Giving less notice without written agreement.
- Forgetting repayments: 100% of tuition reimbursed in the last 12 months, and any unearned vacation advance.
- Not updating your mailing address for tax slips.
- Leaving equipment unreturned.

## 6. Who to call

- HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example. If you have no acknowledgement after 2 business days, call here; the case is treated as Priority 2.
- Evergreen Retirement Services: 1-800-555-0188, for your pension or 401(k) options.

## 7. Related documents

- HR-POL-015 Resignation and Offboarding Policy (the owning document)
- FORM-HR-080 Resignation Notice
- FORM-HR-081 Offboarding Checklist

Where applicable law gives a greater right, the law applies.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-10-01 | Added the final pay deadlines and offboarding steps (HR-POL-015 version 3.0). |
| 1.0 | 2025-01-01 | First version. |
