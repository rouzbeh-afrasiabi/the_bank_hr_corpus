# Talent Review and Succession Process

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-FWK-003 |
| Title | Talent Review and Succession Process |
| Document type | Framework |
| Version | 2.2 |
| Status | Current |
| Effective date | 2026-02-01 |
| Last reviewed | 2026-09-22 |
| Next review | 2027-09-22 |
| Policy owner | SVP Talent and Learning |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | Managers |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-011, HR-FWK-001, HR-FWK-002, HR-POL-016, HR-POL-024, HR-GDE-005 |

## 1. Purpose

This framework sets out how the Bank reviews its talent each year, identifies and prepares successors for key roles, and plans development. It gives business unit heads, managers and HR Business Partners (HRBPs) one consistent process so that talent decisions are fair, evidence-based and confidential.

## 2. Scope

The process covers all business units in Canada and the US. Talent review discusses employees in the business unit, with succession slates for roles in Band 6 and above and for roles the business unit head designates as critical. It is not a promotion process: promotions and transfers are handled separately, and placement in a talent review does not promise or decide a promotion, pay change or move. Where applicable law gives a greater right, the law applies.

## 3. Definitions

| Term | Meaning |
| --- | --- |
| Talent review | A structured meeting where leaders discuss the performance, potential and development of their people. |
| Potential | The likelihood and capacity of an employee to grow into broader or more senior roles over time, assessed against HR-FWK-001 Competency and Leadership Model. |
| 9-box | A grid that places employees by performance (three levels) and potential (three levels). |
| Succession slate | The list of named successors for a role, grouped by readiness. |
| Critical role | A role whose vacancy would significantly harm customers, risk control or business results. |
| Readiness | Ready now, ready in 1 to 2 years, or ready in 3 or more years. |
| Flight risk | The likelihood that a valued employee may leave in the near term. |

## 4. Annual cycle

The cycle follows the year-end ratings under HR-POL-011 Performance Management Policy, so decisions use calibrated ratings.

| Step | Timing | Owner |
| --- | --- | --- |
| Calibration closes and ratings communicated | Calibration ends 10 January; ratings by 15 January | Manager and HRBP |
| Managers prepare talent summaries and potential assessments | Before the business unit session | Manager |
| Talent review meetings | 15 January to 28 February | Business unit head, HRBP |
| Succession slates updated and approved | By 28 February | Business unit head |
| Development plans agreed with the employees | After the review, in the following months | Manager |
| Review of progress | At the mid-year check-in, 1 May to 15 June | Manager |

## 5. Preparing for the review

5.1 Managers prepare a short summary for each employee: the year-end rating, a view of potential with examples, strengths and development areas against HR-FWK-001, career interests the employee has shared (see HR-FWK-002 Career Paths and Job Families Guide) and any flight-risk observation.

5.2 HRBPs check summaries for bias, such as recency, similarity, part-time or remote status, or leave history, and make sure employees on approved leave are reviewed fairly. HR-POL-024 Diversity, Equity, Inclusion and Belonging Policy applies.

5.3 Assessments of potential rest on observed behaviour and evidence, not on tenure, age, personal characteristics or availability.

## 6. The 9-box

6.1 **Performance axis.** Performance comes from the year-end rating: ratings 1 and 2 are placed in the top performance row, rating 3 in the middle row, and ratings 4 and 5 in the bottom row.

6.2 **Potential axis.** Potential is assessed as low, medium or high by the manager, tested in the session.

| | Low potential | Medium potential | High potential |
| --- | --- | --- | --- |
| **High performance** | Trusted professional | High performer | Future leader |
| **Medium performance** | Effective contributor | Core contributor | Emerging talent |
| **Low performance** | Needs action | Develop or redirect | Enigma (explore causes) |

6.3 Placement is a conversation starter and is not a rating. It does not change the year-end rating, and it is not used to calculate pay or incentive.

6.4 Automated tools, if used to prepare summaries, may not make the final decision; a human decides. Any tool must complete the assessments required by HR-POL-016 Employee Data Privacy Policy before use.

## 7. Succession slates

7.1 Succession slates are required for roles in Band 6 and above and for critical roles.

7.2 For each role the slate names successors in three groups:

| Readiness | Meaning |
| --- | --- |
| Ready now | Could take the role within 6 months with minimal support |
| 1 to 2 years | Needs further experience, usually one or two stretch roles |
| 3 or more years | Strong potential but needs substantial development |

7.3 Slates should include more than one name, be reviewed for diversity of candidates, and show emergency cover for sudden vacancies. Business unit heads confirm each slate by 28 February.

7.4 Employees are not told that they are on a slate; they are told of the development actions that follow.

## 8. Flight-risk conversations

Managers and HRBPs identify employees whose loss would affect the business. They discuss the reasons for the risk, such as workload, growth, pay or leadership, and agree actions: a development opportunity, a career conversation, a pay review through the usual process or support from the HRBP. Retention actions follow the pay rules in HR-POL-009 Compensation and Payroll Policy and do not bypass them.

## 9. Development plans

For each employee in the review, the manager and employee agree a development plan with two or three actions: learning, a stretch assignment, mentoring, coaching or exposure. Leadership programs are offered from Band 5. Plans are recorded in MyHR and reviewed at the mid-year check-in. See HR-POL-012 Learning and Development Policy.

## 10. Confidentiality and records

10.1 Talent review outputs are confidential. They are available only to the business unit head, the HRBP, the SVP Talent and Learning, the CHRO and those the HRBP authorises.

10.2 **Managers do not share 9-box placement with employees.** Managers may share their feedback, strengths, development areas and development plan, but not the grid position, slate membership, readiness or flight-risk assessment.

10.3 Records are kept under HR-REF-002 Employee Records Retention Schedule. Requests for personal information are handled under HR-POL-016.

10.4 Sharing a talent review with someone outside the group in section 10.1 is a breach of confidentiality that may be addressed under HR-POL-021 Employee Relations and Progressive Discipline Policy.

## 11. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Business unit head | Leads the review, approves slates and owns bench strength |
| Manager | Prepares summaries and potential assessments; holds development conversations |
| HRBP | Facilitates, checks for bias, tracks actions |
| SVP Talent and Learning | Owns this framework and reports bench strength to the CHRO |
| CHRO | Reviews succession for the most senior roles with the Executive Committee |

## 12. Contacts

Managers can call the Manager Hotline on 1-800-555-0143 (managers only, Monday to Friday 8:00 to 20:00 Eastern Time; response within 4 business hours) or consult HR-GDE-005 Manager's HR Procedures Guide.

## 13. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.2 | 2026-02-01 | Talent review window set at 15 January to 28 February; added readiness groups and confidentiality rules for 9-box results. |
| 2.1 | 2025-02-01 | Added flight-risk conversations. |
