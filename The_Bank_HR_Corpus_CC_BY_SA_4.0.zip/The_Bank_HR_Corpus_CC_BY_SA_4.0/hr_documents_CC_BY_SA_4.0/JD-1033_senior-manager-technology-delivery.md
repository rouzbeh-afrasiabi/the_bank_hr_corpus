# Senior Manager, Technology Delivery

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1033 |
| Title | Senior Manager, Technology Delivery |
| Document type | Job description |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-03-02 |
| Last reviewed | 2026-09-29 |
| Next review | 2027-09-29 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-POL-002, HR-FWK-003, HR-POL-038 |

## 1. Role summary

The Senior Manager, Technology Delivery manages several delivery teams that build and run a significant set of Bank applications and platforms. The role sets operating plans, owns the delivery portfolio, budget and risk position for the area and leads Technology Team Leads, Business Analysts and senior specialists. The Senior Manager translates business priorities into deliverable roadmaps and is accountable for the quality, security and resilience of what is delivered.

## 2. Key responsibilities

- Own the delivery roadmap and operating plan for the area, aligned with business and technology strategy.
- Prioritize investment across teams and manage the area's budget, forecasts and vendor spend.
- Lead and develop Technology Team Leads and senior specialists, and plan succession (see HR-FWK-003 Talent Review and Succession Process).
- Make sure delivery follows the Bank's change, risk, security and privacy requirements.
- Manage portfolio risks, issues and dependencies; escalate material matters to the Director, Cloud Platforms and the Vice President, Technology.
- Partner with business executives on requirements, funding, benefits and acceptance of delivered change.
- Oversee incident management and post-incident improvement with Site Reliability Engineering.
- Set a clear performance and recognition culture: calibrate ratings and make pay recommendations under policy.
- Drive hiring plans and build diverse, skilled teams.
- Manage third-party suppliers and contractors through Procurement and Legal.
- Approve business travel and expenses within HR-POL-038 Business Travel and Expense Policy.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in computer science, engineering, business or a related field.
- Typically 9 to 13 years of technology experience, including at least 3 years managing managers or multiple teams.
- Track record of delivering complex change in a regulated environment.
- Strong financial, vendor and risk-management skills.

### 3.2 Preferred

- MBA or advanced technology degree.
- Certification in program management or service management.
- Experience with hybrid and distributed teams.

### 3.3 Licences and certifications

None required.

## 4. Competencies

Measured against HR-FWK-001 Competency and Leadership Model at the Leader level:

- Drive for Results
- Judgement and Decision Quality
- Developing Others
- Inclusive Leadership
- Collaboration
- Risk and Conduct Awareness
- Adaptability

## 5. Compensation and classification

| Item | Value |
| --- | --- |
| Band | 6 (Manager II / Senior Manager) |
| Canada range | $112,000 to $168,000 CAD |
| US range | $110,000 to $166,000 USD |
| Incentive target | 15% of base salary (Annual Incentive Plan) |
| Overtime eligibility, Canada | No |
| FLSA classification, US | Exempt |
| Work arrangement | Hybrid (at least 3 days a week in the office) |

Band definitions are in HR-GDE-006 Job Architecture and Pay Bands Guide.

## 6. Working conditions and accessibility

This is an office role with a hybrid arrangement under HR-POL-002 Remote and Hybrid Work Policy: at least 3 days a week in the office, including the Tuesday and Thursday anchor days. Occasional travel between Canadian and US sites is expected. Senior managers are needed for major incidents and releases, sometimes outside normal hours. The Bank provides accommodation to the point of undue hardship; see HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to: Director, Cloud Platforms. Direct reports: Technology Team Leads, Business Analysts and Senior Data Scientists.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-03-02 | Aligned band and range with 2026 pay bands |
| 1.0 | 2023-09-01 | First issue |
