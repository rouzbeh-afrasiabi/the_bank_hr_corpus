# Technology Team Lead

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1032 |
| Title | Technology Team Lead |
| Document type | Job description |
| Version | 1.4 |
| Status | Current |
| Effective date | 2025-09-15 |
| Last reviewed | 2026-08-18 |
| Next review | 2027-08-18 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-POL-002, HR-POL-011, HR-GDE-005 |

## 1. Role summary

The Technology Team Lead leads a delivery team of developers, engineers and analysts responsible for a set of the Bank's applications or platforms. The lead is accountable for the team's delivery, quality and day-to-day operations, for coaching team members and for creating an inclusive, high-trust working environment. The role is part people leader and part technical lead.

## 2. Key responsibilities

- Plan and prioritize the team's work with product owners and the Senior Manager, Technology Delivery.
- Make sure features are delivered on time, tested, secure and operable.
- Set expectations, give regular feedback and conduct performance conversations under HR-POL-011 Performance Management Policy.
- Coach and develop team members, supporting individual development plans and learning budgets.
- Approve time, leave and overtime in MyHR and Time Tracker, following HR-GDE-005 Manager's HR Procedures Guide.
- Manage the team's capacity, on-call rotation and workload fairly.
- Take part in hiring: structured interviews, selection decisions and onboarding of new team members.
- Manage production issues and coordinate with Site Reliability Engineering, Information Security and business stakeholders.
- Track and report delivery metrics, risks and dependencies each sprint.
- Champion engineering and control standards, including secure development and approved-tool usage.
- Create an inclusive team culture and address concerns promptly with the HR Business Partner when needed.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in computer science, engineering or a related field, or equivalent experience.
- Typically 7 to 10 years of technology experience, including at least 2 years leading projects or teams informally.
- Strong grounding in agile delivery, software engineering and operational support.
- Proven ability to coach others and handle conflict constructively.

### 3.2 Preferred

- Experience leading a team in a regulated environment.
- Agile or project-management certification (PMP is eligible for reimbursement).
- Completion of a Bank leadership program for Band 5 and above.

### 3.3 Licences and certifications

None required.

## 4. Competencies

Measured against HR-FWK-001 Competency and Leadership Model at the Leader level:

- Developing Others
- Inclusive Leadership
- Drive for Results
- Collaboration
- Judgement and Decision Quality
- Adaptability

## 5. Compensation and classification

| Item | Value |
| --- | --- |
| Band | 5 (Team Lead / Manager I) |
| Canada range | $90,000 to $134,000 CAD |
| US range | $88,000 to $132,000 USD |
| Incentive target | 10% of base salary (Annual Incentive Plan) |
| Overtime eligibility, Canada | No |
| FLSA classification, US | Exempt |
| Work arrangement | Hybrid (at least 3 days a week in the office) |

Band definitions are in HR-GDE-006 Job Architecture and Pay Bands Guide.

## 6. Working conditions and accessibility

This is an office role with a hybrid arrangement under HR-POL-002 Remote and Hybrid Work Policy: at least 3 days a week in the office, including the Tuesday and Thursday anchor days. Team leads are expected to be present on anchor days for their team and may occasionally be needed outside working hours for major incidents. The Bank provides accommodation to the point of undue hardship; see HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to: Senior Manager, Technology Delivery. Direct reports: Software Developers, Senior Software Developers, Site Reliability Engineers and Data Analysts on the team.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.4 | 2025-09-15 | Added people-leader responsibilities and manager procedures reference |
| 1.2 | 2024-06-01 | Hybrid wording updated |
| 1.0 | 2023-06-01 | First issue |
