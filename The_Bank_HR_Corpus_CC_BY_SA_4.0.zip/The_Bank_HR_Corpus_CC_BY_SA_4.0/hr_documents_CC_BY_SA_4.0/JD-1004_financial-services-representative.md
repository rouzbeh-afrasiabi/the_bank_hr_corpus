# Financial Services Representative

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1004 |
| Title | Financial Services Representative |
| Document type | Job description |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-09-14 |
| Next review | 2027-09-14 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-POL-028, HR-POL-029, HR-POL-018 |

## 1. Role summary

The Financial Services Representative (FSR) serves branch customers who need more than a teller transaction: opening and maintaining accounts, setting up everyday banking packages, arranging cards and basic credit products, and resolving service issues. The FSR is a bridge between the teller line and the branch's advisors, qualifying needs and handing off warm referrals for investment, mortgage and lending conversations. The role works under general guidance from the Branch Manager. This is a Band 2 (Associate) role in the Retail Banking family; see HR-GDE-006 Job Architecture and Pay Bands Guide.

## 2. Key responsibilities

- Open, maintain and close personal and student chequing and savings accounts, following know-your-customer and identity verification rules.
- Complete customer due diligence and escalate unusual activity under the Bank's anti-money-laundering and sanctions procedures.
- Process applications for debit cards, credit cards, overdraft protection and small unsecured credit products within delegated limits, and refer larger requests to an advisor.
- Explain fees, interest rates and account features in plain language so customers can make informed choices.
- Run short needs conversations and book appointments with Personal Banking Advisors, Mortgage Specialists and Wealth Advisors.
- Resolve account servicing requests such as address changes, stop payments, joint-account changes and safety deposit box rentals.
- Handle customer complaints at the branch and escalate unresolved matters to the Branch Manager.
- Support branch teller coverage during peak periods and in the absence of tellers.
- Treat customers fairly and record sales and service interactions accurately, without pressure selling.
- Complete mandatory training in the Learning Hub within the required windows.

## 3. Qualifications

### 3.1 Required

- High school diploma or equivalent, plus one to three years of retail banking, teller or customer service experience.
- Working knowledge of deposit, card and basic credit products.
- Accuracy with documentation and comfort using several banking systems.
- Clear communication and a service-minded approach.
- Satisfactory results in pre-employment screening.

### 3.2 Preferred

- Post-secondary diploma or certificate in business or financial services.
- Prior account-opening or branch administration experience.
- Fluency in English and French, or another community language.

### 3.3 Licences and certifications

No investment or mortgage licence is required for this role, and the FSR does not perform licensed activity. Employees who move into licensed roles follow HR-POL-029 Licensing, Registration and Qualification Policy. Staff banking rules on handling one's own or relatives' accounts are set in HR-POL-028 Staff Banking Privileges and Employee Loans Policy.

## 4. Competencies

Competencies are defined in HR-FWK-001 Competency and Leadership Model; this role works at the Foundation level.

- **Customer Obsession**: understands each customer's situation before recommending a product.
- **Risk and Conduct Awareness**: applies identity, due diligence and fair-selling standards every time.
- **Judgement and Decision Quality**: decides what can be approved within delegated limits and what must be referred.
- **Collaboration**: hands off customers smoothly to advisors and specialist colleagues.
- **Drive for Results**: meets service, quality and referral goals for the branch.

## 5. Compensation and classification

| Item | Detail |
| --- | --- |
| Band | 2 (Associate) |
| Canada salary range | $44,000 to $64,000 CAD per year |
| US salary range | $43,000 to $62,000 USD per year |
| Incentive target | Annual Incentive Plan (AIP): 5% of base salary |
| Overtime eligibility (Canada) | Yes (non-managerial Band 1 to 4 role) |
| FLSA classification (US) | Non-exempt |
| Work arrangement | On-site at the assigned branch |

## 6. Working conditions and accessibility

This is an on-site, customer-facing role in a branch, working a posted schedule that may include Saturdays and extended hours. Branch employees follow the Bank brand and uniform guidelines. The Bank provides accommodation to the point of undue hardship (Canada) or reasonable accommodation (US); see HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to the Branch Manager.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-03-01 | Pay ranges updated to the 2026 pay bands; clarified referral duties |
| 1.0 | 2024-06-03 | First issue |
