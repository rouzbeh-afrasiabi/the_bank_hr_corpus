# Bereavement, Jury Duty and Other Leaves Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-026 |
| Title | Bereavement, Jury Duty and Other Leaves Policy |
| Document type | Policy |
| Version | 2.1 |
| Status | Current |
| Effective date | 2025-12-01 |
| Last reviewed | 2026-09-15 |
| Next review | 2027-09-15 |
| Policy owner | SVP Total Rewards |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Applies to | All Canadian and US employees (see Scope) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-006, HR-POL-007, HR-POL-010, HR-POL-023, FORM-HR-010 |

## 1. Purpose

This policy sets out the paid and unpaid leaves the Bank grants for bereavement, civic duties and certain personal and community events. Where applicable law gives a greater right, the law applies.

## 2. Scope and definitions

### 2.1 Scope

The policy applies to regular full-time, regular part-time and fixed-term employees in Canada and the US from their first day of employment. Casual employees receive the leaves required by law. Sick leave and personal days are in HR-POL-007 Sick Leave and Personal Leave Policy; parental and caregiver leaves are in HR-POL-008 Parental and Family Leave Policy.

### 2.2 Definitions

- **Spouse or partner:** a legal spouse, common-law partner or domestic partner.
- **Family relationships** include step, foster, adoptive and in-law relationships.
- **Close friend:** a person with whom the employee has a close personal relationship; the employee's word is sufficient.
- **Days:** scheduled working days. For part-time employees paid bereavement days are paid at the regular scheduled hours of those days.

## 3. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Employee | Tell the manager as soon as possible, enter the leave in Time Tracker, and provide documents where listed. |
| Manager | Approve leave without delay, protect privacy, and arrange coverage. |
| Leaves team | Answers questions, handles exceptions and approves extended requests. |
| HR Business Partner (HRBP) | Considers unusual requests and ensures consistent decisions. |

## 4. Bereavement leave

### 4.1 Paid days

Bereavement leave is paid in both Canada and the US.

| Relationship of the deceased | Paid days |
| --- | --- |
| Spouse or partner, child, parent, sibling | 5 |
| Grandparent, grandchild, parent-in-law, sibling-in-law | 3 |
| Aunt, uncle, niece, nephew, close friend | 1 |

### 4.2 Travel days

An employee may take up to 3 further unpaid days for travel. If the travel exceeds 800 km one way, up to 5 further unpaid days may be taken.

### 4.3 Rules

- Days may be taken consecutively or split, and must be used within 30 days of the death or of the funeral, memorial or service, whichever is later. If a memorial is delayed, the Leaves team will agree a later period of up to 6 months.
- Days are not required to be used on consecutive calendar days. A statutory holiday inside the leave is paid as a holiday and not counted as a bereavement day (see HR-POL-010 Statutory Holidays Policy).
- If a death occurs during approved vacation, the vacation days affected are re-credited as bereavement days.
- Where a second death occurs, a new entitlement applies.
- No documentation is normally required. The Bank may ask for a funeral notice or similar confirmation only where there are reasonable concerns.
- If more time is needed, the employee may combine bereavement leave with vacation, personal days, or sick days where appropriate (see HR-POL-006 Vacation and Paid Time Off Policy).
- The Wellspring Support Program offers confidential counselling: 1-800-555-0166, 24 hours a day.

## 5. Jury duty and witness leave

### 5.1 Jury duty

An employee who is summoned as a juror receives full pay for up to 10 business days of jury duty. After that only the court allowance is paid. The employee must:

- give the manager a copy of the summons within 2 business days of receiving it;
- tell the manager each day of attendance and provide a court attendance letter;
- return to work for the rest of the day if released with at least 3 hours of the scheduled day remaining, where reasonable travel allows.

Employees may use vacation or personal days for days after the 10th if they wish to maintain pay. The Bank will not discourage employees from serving and will not retaliate. The Bank supports a request for deferral only where the court's own process allows and the employee agrees.

### 5.2 Witness

An employee who is subpoenaed as a witness is paid for the time required. An employee who is a witness in their own personal matter should use vacation or personal days.

## 6. Domestic and family violence leave

Employees who experience domestic or family violence, or who care for a family member who does, receive 10 paid days per year. This is separate from sick days.

- The leave is confidential. Employees may request it through HR Connect or the HRBP without giving the manager any reason; the leave is recorded without a reason.
- Days may be taken in hours or in full days, for medical care, counselling, legal matters, relocating or safety planning.
- Employees are referred to the Wellspring Support Program.
- Workplace safety planning is arranged with Corporate Security, 1-800-555-0119. In an emergency, call 911 first, then Corporate Security.
- No proof is required; the Bank may accept documentation voluntarily offered.

## 7. Other leaves

| Leave | Entitlement | Conditions |
| --- | --- | --- |
| Voting | 3 consecutive hours paid | Only if the polling hours do not already allow 3 consecutive hours outside working time; request at least 2 business days ahead |
| Citizenship ceremony | 1 paid day | Provide the ceremony notice |
| Volunteer day | 1 paid day per calendar year | Approved organization; requested at least 10 business days ahead; no carryover |
| Military or reservist leave | Unpaid and job-protected; up to 14 paid days per year for training (Bank top-up of the difference between military pay and base pay) | Give notice as early as possible, and at least 4 weeks ahead for planned training; provide orders |
| Blood donation | Up to 4 hours paid per donation | Canada and US |
| Living organ donor | Up to 5 paid days for recovery | Provide a physician's letter |
| Floating days (Cultural and Religious Observance Days) | 2 per calendar year, no carryover | See HR-POL-010 |

An approved volunteer organization is a registered charity or non-profit organization. Political campaigns and for-profit activities do not qualify. Longer unpaid time away not covered by this policy is requested on FORM-HR-010 Leave of Absence Request; see also the personal leave of absence in HR-POL-007.

## 8. Procedure

1. Notify the manager as soon as the need is known (same day for a death).
2. Enter the leave in Time Tracker under the leave type shown in MyHR.
3. Provide any document listed above to the Leaves team through the HR Case Portal.
4. The manager approves within 1 business day for bereavement and within 5 business days for other leaves.

## 9. Exceptions and consequences

Requests outside this policy go to the Leaves team and are decided by the SVP Total Rewards. Misrepresenting the reason for a leave is misconduct under HR-POL-001 Code of Conduct and Ethics. Statutory and Bank-approved leaves do not count in an attendance review (HR-POL-004 Attendance and Absenteeism Policy).

## 10. Contacts

HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time, hrconnect@bank.example, or live chat in MyHR. Managers: Manager Hotline 1-800-555-0143.

## 11. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.1 | 2025-12-01 | Added domestic and family violence leave guidance on confidentiality and safety planning; clarified travel days (5 days if travel exceeds 800 km one way). |
| 2.0 | 2024-12-01 | Introduced the 1-day paid volunteer leave and the living organ donor leave. |
