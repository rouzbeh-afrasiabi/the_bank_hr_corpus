# How to prepare for annual benefits enrolment

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-044 |
| Title | How to prepare for annual benefits enrolment |
| Document type | How-to article |
| Version | 1.0 |
| Status | Current |
| Effective date | 2026-09-14 |
| Last reviewed | 2026-10-20 |
| Next review | 2027-10-20 |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-001, HR-MEMO-2026-007, HR-PLN-004, HR-PLN-007 |

## 1. Short answer

Annual enrolment runs from 2 to 16 November 2026 for coverage from 1 January 2027: review your 2027 options in MyHR > Benefits, then make or confirm your elections before 17:00 Eastern Time on 16 November 2026.

## 2. Who this applies to

Regular full-time and regular part-time employees, and fixed-term employees of 6 months or more, in Canada and the US. Other employees have the Wellspring Support Program only (see HR-GDE-001 Employee Benefits Guide).

## 3. Steps

1. Before 2 November, list your dependants and check eligibility: in Canada, children to age 21 (26 if a full-time student); in the US, children to age 26.
2. Review what you used in 2026 and which plan fits (Essential, Standard or Enhanced in Canada; Choice PPO or Saver HDHP in the US).
3. On 2 November, the 2027 premiums are posted in MyHR. Open MyHR > Benefits > Annual Enrolment and compare the plans.
4. Check your beneficiaries for life insurance. Optional employee life above 4x salary or above $750,000 needs evidence of insurability.
5. In the US, re-elect your flexible spending accounts; they do not roll over.
6. Make or confirm your elections and add or remove dependants, then select Submit.
7. Save the confirmation. You can change your elections until 17:00 Eastern Time on 16 November 2026.
8. Claim your 2026 wellness spending account ($500 CAD / $400 USD) by 31 March 2027.

## 4. Deadlines

| Date | What happens |
| --- | --- |
| 2 November 2026 | Enrolment opens; 2027 premiums posted in MyHR |
| 16 November 2026, 17:00 Eastern Time | Last time to make or change elections |
| 1 January 2027 | New coverage starts |
| 31 March 2027 | Last day to claim 2026 wellness spending account |

HR Connect is closed on Remembrance Day and Veterans Day, Wednesday 11 November 2026, so do not leave questions to the last day.

## 5. What happens next

Elections are locked after the deadline for the whole 2027 plan year, unless you have a qualifying life event: you then have 31 days from the event to change them. If you make no election, your current elections roll over, except US flexible spending accounts. A new hire with no election is placed in Standard (Canada) or Choice PPO employee-only (US). The 2027 premiums apply from 1 January 2027.

## 6. Common mistakes

- Waiting for the last day and missing the 17:00 cut-off.
- Forgetting to re-elect US flexible spending accounts.
- Leaving an ineligible dependant on the plan, for example a child over the age limit. False dependant information breaches HR-POL-001 Code of Conduct and Ethics.
- Assuming a rollover keeps the same cost: premiums change on 1 January.
- Missing the 31-day window after a life event.

## 7. Who to call

HR Connect, 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time, hrconnect@bank.example, or live chat in MyHR. Maplewood Benefits claims line: 1-800-555-0190. Enrolment or premium errors: HR Case Portal in MyHR.

## 8. Related documents

- HR-GDE-001 Employee Benefits Guide
- HR-MEMO-2026-007 Annual Benefits Enrolment: 2 to 16 November 2026
- HR-PLN-004 Group Benefits Booklet (Canada)

## 9. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.0 | 2026-09-14 | First edition, published with HR-MEMO-2026-007. |
