# Fiscal 2026 Performance Cycle Timetable

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-MEMO-2025-007 |
| Title | Fiscal 2026 Performance Cycle Timetable |
| Document type | Memo |
| Version | 1.0 |
| Status | Current |
| Effective date | 2025-11-03 |
| Last reviewed | Not applicable |
| Next review | Not applicable |
| Policy owner | SVP Talent and Learning |
| Audience | Managers |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-011, HR-GDE-005, HR-POL-009 |

**Key dates for the fiscal 2026 performance year (1 November 2025 to 31 October 2026).**

**From:** SVP Talent and Learning

**To:** All people managers in Canada and the US

**Date:** 3 November 2025

**Subject:** Fiscal 2026 performance cycle timetable

## 1. What is changing

No process changes. This memo lists the dates in HR-POL-011 Performance Management Policy for the fiscal 2026 cycle.

| Step | Date |
| --- | --- |
| Goals set (3 to 5 goals; new hires within 30 days of start) | 15 December 2025 |
| Mid-year check-in window | 1 May to 15 June 2026 |
| Year-end self-assessment due | 15 November 2026 |
| Manager assessment due | 10 December 2026 |
| Calibration | 11 December 2026 to 10 January 2027 |
| Ratings communicated | By 15 January 2027 |
| Incentive paid | First pay date in February 2027 |
| Salary increases effective | 1 March 2027 |

## 2. Who is affected

Managers and their employees who started on or before 31 July 2026.

## 3. Effective date

Immediately; the cycle began on 1 November 2025.

## 4. What to do

1. Agree goals with each team member in MyHR by 15 December 2025.
2. Hold quarterly informal check-ins and the mid-year check-in.
3. Remind your team that a rating dispute goes in writing to the HRBP within 10 business days of being told the rating.

## 5. Who to call

Manager Hotline: 1-800-555-0143 (managers only, same hours as HR Connect, response within 4 business hours). HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays).

## 6. Related documents

- HR-POL-011 Performance Management Policy
- HR-GDE-005 Manager's HR Procedures Guide
- HR-POL-009 Compensation and Payroll Policy
