# Supplément pour le Québec

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

> **Document synthétique.** Contenu fictif produit pour des essais de recherche et de questions-réponses. Il ne constitue pas la politique d'une organisation réelle.

| Field | Value |
| --- | --- |
| Document ID | HR-SUP-001 |
| Title | Supplément pour le Québec |
| Document type | Supplement |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-09-10 |
| Next review | 2027-09-10 |
| Policy owner | VP HR Operations |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | Employees |
| Jurisdiction | Quebec |
| Language | French |
| Related documents | HR-POL-003, HR-POL-010, HR-POL-007, HR-POL-008, HR-POL-015, HR-POL-016, HR-POL-020, HR-GDE-001 |

## 1. Objet

Le présent supplément résume les règles de la Banque qui s'appliquent de façon particulière aux employés qui travaillent au Québec. Il complète les politiques de base de la Banque et n'en répète pas tous les détails. Pour chaque sujet, la politique propriétaire demeure la référence. Lorsque la loi applicable accorde un droit plus grand, la loi s'applique.

## 2. Portée

Le supplément vise tous les employés réguliers, à temps partiel, à durée déterminée et occasionnels dont le lieu de travail est le Québec. Il s'applique en plus de la politique visée et prévaut sur elle en cas de différence.

## 3. Langue de travail et communications en français

Les employés du Québec reçoivent les documents et les communications des Ressources humaines en français, par défaut ou sur demande. Une version anglaise est disponible pour toute personne qui la préfère. Cela comprend les avis de collecte de renseignements personnels, qui sont remis en français et en anglais à l'embauche, ainsi que les communications sur la vie privée, remises en français par défaut ou sur demande (voir HR-POL-016 Employee Data Privacy Policy).

Le Centre de contact RH Connect offre ses services en français et en anglais, avec interprète sur demande, du lundi au vendredi, de 8 h à 20 h (heure de l'Est). Le clavardage dans MyHR est offert aux mêmes heures.

## 4. Jours fériés payés en 2026

Les jours fériés payés de la Banque au Québec en 2026 sont au nombre de 11. Le calendrier complet et les règles de paie se trouvent dans HR-POL-010 Statutory Holidays Policy.

| Date | Jour | Jour férié |
| --- | --- | --- |
| 2026-01-01 | jeudi | Jour de l'An |
| 2026-04-03 | vendredi | Vendredi saint |
| 2026-05-18 | lundi | Journée nationale des patriotes |
| 2026-06-24 | mercredi | Fête nationale du Québec |
| 2026-07-01 | mercredi | Fête du Canada |
| 2026-09-07 | lundi | Fête du Travail |
| 2026-09-30 | mercredi | Journée nationale de la vérité et de la réconciliation |
| 2026-10-12 | lundi | Action de grâce |
| 2026-11-11 | mercredi | Jour du Souvenir |
| 2026-12-25 | vendredi | Noël |
| 2026-12-26 | samedi | Lendemain de Noël, observé le lundi 2026-12-28 |

- La Banque a choisi le Vendredi saint plutôt que le lundi de Pâques.
- La Journée nationale des patriotes est célébrée à la date où les autres provinces célèbrent la fête de la Reine (Victoria Day), soit le 18 mai 2026.
- La fête de la Famille et le congé civique du mois d'août ne sont pas observés au Québec.
- Les deux jours flottants d'observance culturelle et religieuse par année civile s'appliquent comme ailleurs à la Banque.
- Un jour férié qui tombe pendant les vacances n'est pas déduit du solde de vacances (voir HR-POL-006 Vacation and Paid Time Off Policy).

## 5. Heures de travail et heures supplémentaires

La semaine normale de travail est de 37,5 heures (7,5 heures par jour, 5 jours), avec une période de repas non payée de 60 minutes. Au Québec, les règles sont les suivantes (voir HR-POL-003 Working Hours and Overtime Policy).

| Élément | Règle au Québec |
| --- | --- |
| Heures supplémentaires | Rémunérées à 1,5 fois le taux normal après 40 heures par semaine |
| Règle quotidienne | Aucune |
| Heures entre 37,5 et 40 par semaine | Payées au taux normal, ou mises en banque 1 pour 1 |
| Temps compensatoire | 1,5 heure de congé par heure supplémentaire, à la demande de l'employé et avec l'approbation du gestionnaire (FORM-HR-020); banque maximale de 40 heures, à prendre dans les 3 mois; le solde non utilisé est payé au taux des heures supplémentaires à l'échéance |
| Approbation | Préalable, dans Time Tracker; plus de 8 heures supplémentaires dans une semaine exigent l'approbation d'un directeur et un avis aux RH |
| Repas et pauses | Période de repas non payée de 30 minutes après au plus 5 heures consécutives; deux pauses de 15 minutes payées par quart complet |

## 6. Congés de maladie et preuve médicale

Les employés du Québec ont droit aux jours de maladie payés prévus par la Banque pour le Canada, soit 10 jours par année civile, crédités le 1er janvier (voir HR-POL-007 Sick Leave and Personal Leave Policy). Les employés peuvent aussi prendre 3 jours personnels par année civile, sans certificat.

La Banque ne demande une preuve de l'absence qu'après 3 jours consécutifs d'absence. Dans les autres provinces, un certificat est exigé à partir du 4e jour de travail consécutif. Le certificat indique les limitations fonctionnelles et la durée prévue, jamais le diagnostic. Il est transmis à l'équipe des congés par MyHR, et non au gestionnaire. L'absence doit être signalée au gestionnaire avant le début du quart, ou au plus tard 30 minutes après.

## 7. Congés parentaux et Régime québécois d'assurance parentale

Au Québec, la prestation gouvernementale est versée par le Régime québécois d'assurance parentale (RQAP); ailleurs au Canada, elle l'est par l'assurance-emploi. La Banque coordonne sa prestation avec celle du RQAP afin que la rémunération totale soit égale à 100 % du salaire de base (voir HR-POL-008 Parental and Family Leave Policy).

| Parent | Complément de la Banque (100 % du salaire de base) |
| --- | --- |
| Parent biologique (congé de maternité) | 17 semaines |
| Parent non biologique, adoptif ou d'intention en cas de gestation pour autrui | 8 semaines |

- Il faut avoir 6 mois de service continu pour avoir droit au complément de la Banque.
- La prestation du RQAP est versée par le gouvernement; la Banque ne peut pas la garantir. L'employé remet l'avis de prestation à l'équipe des congés dans les 5 jours ouvrables suivant sa réception.
- Le préavis est de 4 semaines avant le début du congé, au moyen de FORM-HR-012, lorsque c'est possible.
- Le congé parental doit commencer dans les 78 semaines suivant la naissance ou le placement. Le congé protégé peut atteindre 18 mois au total pour un parent biologique.
- Un retour progressif d'au plus 4 semaines, à 80 % de l'horaire normal, est possible.

## 8. Assurance médicaments et avantages sociaux

Les employés du Québec adhèrent au régime public d'assurance médicaments ou au régime de la Banque, selon ce que la loi exige. Les garanties et les primes des options Essentiel, Standard et Amélioré sont décrites dans HR-GDE-001 Employee Benefits Guide. Maplewood Benefits administre les régimes d'assurance.

## 9. Fin d'emploi : paie finale et feuillets fiscaux

La paie finale est versée à la prochaine date de paie régulière, en cas de démission comme de congédiement par la Banque. Elle comprend les vacances acquises et non prises (voir HR-POL-015 Resignation and Offboarding Policy). Le relevé d'emploi est émis par voie électronique dans les 5 jours civils suivant la fin de la période de paie au cours de laquelle l'emploi prend fin. Le Relevé 1 est produit au plus tard le 28 février de l'année suivante.

## 10. Renseignements personnels et vérifications avant l'embauche

- **Casier judiciaire :** la Banque ne tient compte d'un casier judiciaire que s'il est lié à l'emploi (voir HR-POL-020 Pre-Employment Screening Policy). Le consentement est obtenu d'abord.
- **Transfert hors Québec :** une évaluation des facteurs relatifs à la vie privée (EFVP, ou PIA, FORM-HR-091) est requise avant tout transfert de renseignements hors du Québec. Le Bureau de la protection de la vie privée la réalise avec le responsable du système.
- **Accès aux renseignements :** une demande d'accès (FORM-HR-090) reçoit une réponse dans les 30 jours; ce délai peut être prolongé d'au plus 30 jours avec avis écrit.

## 11. Personnes-ressources

- RH Connect : 1-800-555-0142, hrconnect@bank.example (en français ou en anglais).
- Ligne des gestionnaires : 1-800-555-0143.
- Bureau de la protection de la vie privée : privacy@bank.example.
- Ligne Speak-Up : 1-800-555-0177, 24 heures sur 24, 7 jours sur 7, option anonyme.
- Programme de soutien Wellspring : 1-800-555-0166, 24 heures sur 24, 7 jours sur 7.

## 12. Historique des modifications

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.0 | 2023-01-01 | Première version du supplément pour le Québec |
| 2.0 | 2026-01-01 | Mise à jour des jours de maladie (10 jours), du calendrier des jours fériés de 2026, du complément du RQAP et des règles sur le transfert de renseignements hors du Québec |
