# Job Architecture and Pay Bands Guide

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-GDE-006 |
| Title | Job Architecture and Pay Bands Guide |
| Document type | Guide |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-09-28 |
| Next review | 2027-09-28 |
| Policy owner | SVP Total Rewards |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Applies to | All Canadian and US employees (see Scope) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-009, HR-POL-003, HR-POL-019, HR-POL-011, HR-POL-024, HR-GDE-004 |

## 1. Purpose

This guide explains how jobs at the Bank are organized into nine bands, what each band means, how pay ranges (pay bands) are set, how an individual salary is placed within a band, and how to read the pay range in a job posting. It is meant for employees, managers, HR Business Partners (HRBPs) and recruiters.

Payroll rules, the salary review and the Annual Incentive Plan (AIP) calculation are in HR-POL-009 Compensation and Payroll Policy. Overtime rules are in HR-POL-003 Working Hours and Overtime Policy. Promotions and transfers are handled separately and are not described in this guide. The `pay_bands.csv` file held with these documents is the source of truth for the pay ranges; the table in section 5 reproduces it. Where applicable law gives a greater right, the law applies.

## 2. Scope

This guide applies to all employees in Canada and the US. Executive Committee roles sit outside the bands and are governed by separate arrangements. Contractors and agency workers are not placed in bands.

## 3. Definitions

- **Band**: one of nine job levels from Band 1 to Band 9. Each job is assigned to exactly one band.
- **Pay band or salary range**: the minimum, midpoint and maximum annual base salary for a band, set separately for Canada (in CAD) and the US (in USD).
- **Midpoint**: the middle of the range, aligned with the market median (P50) of the Bank's defined peer group.
- **Compa-ratio**: your base salary divided by the midpoint of your band.
- **Range position** (also called range penetration): how far your salary sits between the minimum and the maximum, as a percentage.
- **Market pricing**: comparing Bank jobs with survey data for similar jobs at peer organizations.

## 4. The nine bands

Job levelling looks at four factors: scope of responsibility, complexity of work, accountability for results, and the level of independence expected. Experience figures are typical, not requirements; a job is levelled by the work, not by the person doing it.

| Band | Level title | Scope and level description | Typical experience | Example roles |
| --- | --- | --- | --- | --- |
| 1 | Associate Support | Performs defined, routine tasks under close guidance; follows set procedures | 0 to 1 year | Teller; Customer Service Representative I; Operations Clerk |
| 2 | Associate | Handles a broader range of tasks with some judgement; works under general guidance | 1 to 3 years | Financial Services Representative; Customer Service Representative II; Payments Processor |
| 3 | Professional | Applies professional knowledge to solve problems; works independently on assigned work | 2 to 5 years | Analyst; Advisor; HR Coordinator; Underwriter I |
| 4 | Senior Professional | Handles complex work, advises others and may guide junior colleagues; recognized for depth in a field | 5 to 8 years | Senior Analyst; Senior Advisor; HR Generalist; Business Analyst |
| 5 | Team Lead / Manager I | Leads a team or branch, or is a senior specialist; accountable for team results and day-to-day operations | 7 to 10 years | Branch Manager; Team Lead; Senior Specialist; HR Business Partner I |
| 6 | Manager II / Senior Manager | Manages several teams or a significant function, or is a principal specialist; sets operating plans | 9 to 13 years | Senior Manager; Regional Manager; Principal Specialist; HR Business Partner II |
| 7 | Director | Leads a function or large unit; shapes strategy and budget for the area | 12 to 16 years | Director; Head of a Function; Senior Principal |
| 8 | Senior Director / Vice President | Leads a major business or enterprise function; influences strategy across business units | 15 or more years | Vice President; Senior Director |
| 9 | Senior Vice President | Accountable for a business unit or enterprise-wide function; reports into the Executive Committee | 18 or more years | Senior Vice President; Managing Director |

## 5. Pay bands for 2026

Annual base salary; Canada in CAD, US in USD. These figures are copied from `pay_bands.csv`.

| Band | Level title | Canada min | Canada mid | Canada max | US min | US mid | US max | AIP target |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Associate Support | 38,000 | 46,000 | 54,000 | 36,000 | 44,000 | 52,000 | 5% |
| 2 | Associate | 44,000 | 54,000 | 64,000 | 43,000 | 52,000 | 62,000 | 5% |
| 3 | Professional | 56,000 | 70,000 | 84,000 | 55,000 | 68,000 | 82,000 | 5% |
| 4 | Senior Professional | 72,000 | 90,000 | 108,000 | 70,000 | 88,000 | 106,000 | 8% |
| 5 | Team Lead / Manager I | 90,000 | 112,000 | 134,000 | 88,000 | 110,000 | 132,000 | 10% |
| 6 | Manager II / Senior Manager | 112,000 | 140,000 | 168,000 | 110,000 | 138,000 | 166,000 | 15% |
| 7 | Director | 140,000 | 175,000 | 210,000 | 138,000 | 172,000 | 206,000 | 20% |
| 8 | Senior Director / Vice President | 180,000 | 225,000 | 270,000 | 175,000 | 220,000 | 265,000 | 30% |
| 9 | Senior Vice President | 240,000 | 300,000 | 360,000 | 235,000 | 295,000 | 355,000 | 45% |

Ranges are about 42% to 51% wide, measured as maximum minus minimum divided by minimum. Adjacent bands overlap, so a high performer in one band can earn more than a newer colleague in the next band.

## 6. Overtime eligibility by band

| Band | Canada | US |
| --- | --- | --- |
| 1 to 3 | Eligible if non-managerial | Eligible if classified non-exempt under the FLSA (generally yes) |
| 4 | Eligible if non-managerial | Generally exempt; some roles non-exempt |
| 5 to 9 | Not eligible | Not eligible |

Overtime thresholds, rates, time in lieu and approvals are set out in HR-POL-003 Working Hours and Overtime Policy. Your classification appears on your offer letter and in MyHR.

## 7. Annual Incentive Plan target by band

The AIP target is a percentage of base salary earned: Bands 1 to 3, 5%; Band 4, 8%; Band 5, 10%; Band 6, 15%; Band 7, 20%; Band 8, 30%; Band 9, 45%. The eligibility rules, formula, funding factor and individual multipliers are in HR-POL-009. For example, at a target of 8% the target payout for a Band 4 employee with a $90,000 salary is $7,200 when the funding factor is 1.0 and the rating is Meets Expectations.

## 8. How placement in the band works

### 8.1 New hires

New hires are placed inside the band, usually between the minimum and the midpoint. Where within that span depends on the candidate's skills and experience relative to the job, the pay of current employees doing similar work, and the market. Offers are approved within the band; an offer above the midpoint requires the approval of the HRBP and Total Rewards. No offer is made below the minimum or above the maximum of the band. Approval levels for requisitions are in HR-POL-019 Recruitment and Selection Policy.

### 8.2 Existing employees

Pay moves through the band through the annual salary review (effective 1 March) according to the year-end rating under HR-POL-011 Performance Management Policy. Over time, an employee who consistently performs at the expected level moves toward the midpoint, and an employee with sustained strong performance can move beyond it. Employees at or near the maximum may receive part of their increase as a lump sum rather than an addition to base salary, so that base pay does not go above the maximum.

### 8.3 Pay below the minimum or above the maximum

If an employee's pay falls below the minimum of the band (for example, because the range moved at a market update), Total Rewards reviews the case and normally brings the salary to the new minimum at the next salary review. If an employee's pay is above the maximum, there is no cut to pay; pay is held and future increases are paid as lump sums until the range catches up.

## 9. Compa-ratio and range position

### 9.1 Formulas

- Compa-ratio = base salary divided by midpoint.
- Range position = (base salary minus minimum) divided by (maximum minus minimum).

### 9.2 Worked examples

| Employee | Salary | Band range used | Midpoint | Compa-ratio | Range position |
| --- | --- | --- | --- | --- | --- |
| Senior Analyst, Canada, Band 4 | $81,000 CAD | 72,000 to 108,000 | 90,000 | 0.90 | 25% |
| Analyst, US, Band 3 | $68,000 USD | 55,000 to 82,000 | 68,000 | 1.00 | 48% |
| Branch Manager, Canada, Band 5 | $125,000 CAD | 90,000 to 134,000 | 112,000 | 1.12 | 80% |

Figures are rounded: for the Band 5 example, 125,000 divided by 112,000 is 1.116 and 35,000 divided by 44,000 is 79.5%; for the Band 3 example, 13,000 divided by 27,000 is 48.1%.

### 9.3 How to read your compa-ratio

| Compa-ratio | Typical meaning |
| --- | --- |
| Below 0.85 | Early in the role or below the market median; reviewed at each salary review |
| 0.85 to 1.15 | Normal competitive position |
| Above 1.15 | Experienced, high-performing or long-service; limited room for base increases |

These are guides, not entitlements. HRBPs use them, along with performance and equity data, in the annual pay-equity review (see HR-POL-009).

## 10. Market pricing

Total Rewards benchmarks the Bank's jobs each year against compensation surveys covering a defined peer group of Canadian and US financial institutions and employers of similar size. A Bank job is matched to survey jobs on content and level, and a match of at least 70% is needed to use the data. Midpoints are set to the market median (P50). After the survey results are analyzed, Total Rewards proposes any range changes to the HR Policy Committee; approved changes take effect on 1 March, together with the annual salary review. Pay ranges are separate for Canada and the US because the markets differ; there is one range per band for each country.

### 10.1 Requesting a job review

If you believe your job is in the wrong band, ask your manager to raise a case in the HR Case Portal. The HRBP checks the job description against the band descriptions in section 4 and sends the case to Total Rewards, which responds within 15 business days. A job review concerns the job, not the person, and does not create a promotion.

## 11. Pay transparency

The Bank discloses pay ranges in job postings. You can view the band and pay range for your own job in MyHR. You may discuss your own pay with anyone; the Bank does not retaliate against employees who do. HR staff and managers must keep other employees' pay confidential, in line with HR-POL-016 Employee Data Privacy Policy. The annual pay-equity and representation report is described in HR-POL-024 Diversity, Equity, Inclusion and Belonging Policy.

## 12. How to read a job posting range

A job posting shows the full range for the band, in the currency of the posting country, together with the AIP target. For example:

> Pay range: $72,000 to $108,000 CAD per year. AIP target: 8% of base salary.

This is Band 4 in Canada. How to interpret it:

1. The range is the minimum and the maximum of the band. It is the range the Bank may legitimately pay for the job.
2. Most new hires are offered a salary between the minimum and the midpoint ($90,000 in this example). The midpoint is the market median.
3. The AIP target is not guaranteed; the payout depends on the funding factor and your rating (see HR-POL-009).
4. Benefits and retirement contributions are in addition to the pay range; see HR-GDE-001 Employee Benefits Guide and HR-GDE-002 Retirement and Savings Plan Guide.
5. If the posting shows a US range, the figures are in USD and use the US column of the band table.

Postings stay open for at least 5 business days (see HR-POL-019).

## 13. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| SVP Total Rewards | Owns this guide and the band structure |
| Total Rewards | Levels jobs, runs market pricing, maintains `pay_bands.csv` |
| HRBP | Advises on band placement and offers; reviews equity |
| Manager | Writes accurate job descriptions; explains pay to employees |
| Employee | Reviews your band and range in MyHR; raises questions with your manager or HR Connect |

## 14. Contacts

HR Connect, 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time, hrconnect@bank.example. For service levels see HR-GDE-004 HR Service and Support Guide.

## 15. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-03-01 | 2026 pay bands applied; added compa-ratio, range position and posting-range explanation |
| 1.0 | 2023-03-01 | First issue of the job architecture and pay band guide |
