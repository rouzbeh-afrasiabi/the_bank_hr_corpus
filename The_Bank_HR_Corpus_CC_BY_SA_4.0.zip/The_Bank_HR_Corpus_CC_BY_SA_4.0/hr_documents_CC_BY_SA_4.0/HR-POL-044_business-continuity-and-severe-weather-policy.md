# Business Continuity and Severe Weather Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-044 |
| Title | Business Continuity and Severe Weather Policy |
| Document type | Policy |
| Version | 2.3 |
| Status | Current |
| Effective date | 2025-11-01 |
| Last reviewed | 2026-09-02 |
| Next review | 2027-09-02 |
| Policy owner | Head of Workplace Safety |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-004, HR-POL-002, HR-POL-023, HR-POL-003, HR-POL-017, HR-POL-010 |

## 1. Purpose

This policy sets out what employees and managers do when the Bank's normal operations are disrupted by severe weather, an emergency, a pandemic, a building or technology failure or any other incident. It explains how closures are decided and announced, how employees are paid, who must keep working, how employees check in, which alert channels the Bank uses, and how the Bank tests its plans. Its goals are the safety of people first, then continuity of critical services to customers.

## 2. Scope

The policy applies to all employees in Canada and the US, at every Bank site and working from any location. It complements HR-POL-004 Attendance and Absenteeism Policy, which owns the closure announcement rule, and HR-POL-023 Workplace Health, Safety and Wellness Policy, which owns emergency procedures on site. Contractors and agency workers follow the instructions of their engagement contact and the site. Where applicable law gives a greater right, the law applies.

## 3. Definitions

- **Incident:** an event that disrupts, or may disrupt, the Bank's people, premises, technology or services, such as a storm, fire, flood, power cut, public-health emergency, security event or technology outage.
- **Declared incident:** an incident that the Corporate Security duty officer or the Head of Workplace Safety has declared and announced through Bank Alert.
- **Closure:** the closing of a branch, office or operations centre for a day or part of a day.
- **Essential role:** a role that must continue during a disruption under a business-continuity plan: branch cash operations, payments, the Security Operations Centre and the contact centre.
- **Business-continuity plan (BCP):** the written plan for a business unit or site, listing essential roles, alternates, recovery steps and contacts.
- **Bank Alert:** the Bank's mass notification service.
- **Check-in:** a confirmation to the manager of the employee's safety and availability.

## 4. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Employee | Keeps contact details current in MyHR; reads alerts; checks in; follows instructions; never takes unsafe risks to reach work |
| Manager | Knows the team's availability; maintains the team call tree; confirms check-ins; agrees work for each employee; records absences correctly |
| Business unit head | Owns the BCP for the unit and names the essential roles and alternates |
| Head of Workplace Safety | Owns this policy; runs tests; leads post-incident reviews |
| Corporate Security | Monitors weather and incidents 24 hours a day and declares closures with the Head of Workplace Safety; 1-800-555-0119 |
| Security Operations Centre (SOC) | Leads response to technology and cyber incidents; 1-800-555-0155 |
| HR Operations | Sends alerts and updates the intranet banner; adjusts payroll codes |
| HRBP | Advises on pay, leave and fairness questions |
| Payroll Services | Makes sure pay for closure days is correct |

## 5. Closure decisions and announcements

### 5.1 Timing

Corporate Security and the Head of Workplace Safety decide on closures. A decision to close for a morning is announced by **6:30 local time**, through three channels together: a **MyHR alert**, a **text message** and the **intranet banner**. A closure that becomes necessary later in the day is announced as soon as the decision is made, through the same channels, and affected employees are sent home with pay for the day. Bank Alert may also be used (section 7).

### 5.2 If there is no announcement

If no closure is announced, the workplace is open. An employee who cannot get to an open workplace safely tells the manager before the start of the shift, and the rules in HR-POL-004 apply: the employee may use vacation, a personal day or other approved time off, with the manager's agreement. No employee is required to take an unsafe journey, and no one is disciplined for a good-faith safety decision.

### 5.3 Pay and time recording

| Situation | Treatment |
| --- | --- |
| Employee's branch or office is closed | Paid for the day at the regular scheduled hours; not charged to vacation, sick days or personal days |
| Hybrid or remote employee | Works from home on the closure day (HR-POL-002 Remote and Hybrid Work Policy); a closed office does not reduce the day's pay |
| Essential role required to work during a closure | Hours worked are paid under HR-POL-003 Working Hours and Overtime Policy, including any overtime that applies; holidays as in HR-POL-010 Statutory Holidays Policy |
| Part-day closure | Paid for the scheduled shift |

Non-exempt employees record the closure day in Time Tracker with the closure code the manager provides. Employees do not make up the hours later.

## 6. Hybrid and remote employees

On a declared closure, hybrid and remote employees work from home and are available during core hours of 10:00 to 15:00 local time, following HR-POL-017 IT Acceptable Use and Information Security Policy. If the employee has no power, internet or other safe means of working, the employee tells the manager as soon as possible and the manager agrees reasonable adjustments: a changed schedule, work that does not need connectivity, or time off under section 5.2.

## 7. Bank Alert and check-in

1. The employee's mobile number and email are held in MyHR, and the employee confirms they are correct whenever they change and at least once a year.
2. When an incident is declared, Corporate Security sends a Bank Alert by text, email, MyHR and the intranet banner.
3. Every affected employee **checks in with the manager within 2 hours** of a declared incident, using the method in the alert (reply to the text, call, or message the manager).
4. The manager confirms all team members' safety to the business unit head within the next hour and reports anyone not reached to Corporate Security.
5. If an employee cannot reach the manager, they call Corporate Security (1-800-555-0119, 24/7). In an emergency, call 911 first.
6. Employees must not post unverified details of an incident publicly (HR-POL-027 Social Media and External Communications Policy).

## 8. Essential roles

Essential roles are named in the BCP of the business unit, and each has at least one trained alternate. Essential employees:

- are told in writing by the manager that they hold an essential role;
- know the call tree, the alternate site or system, and the order in which to restore services;
- take part in every BCP test for their role;
- are never required to work in a place that Corporate Security has assessed as unsafe; where branch cash operations cannot be performed safely, the plan moves the work to another branch or channel.

Expenses for work at a different site are reimbursed under HR-POL-038 Business Travel and Expense Policy. Employees with an accommodation need are supported under HR-POL-018 Workplace Accommodation and Accessibility Policy, and the plan includes assisted evacuation arrangements.

## 9. Procedures by type of incident

| Incident | What employees do | Lead |
| --- | --- | --- |
| Evacuation (fire, gas, threat) | Leave by the nearest safe exit, do not use elevators, go to the assembly point, wait for the floor warden's release (HR-POL-023) | Corporate Security |
| Shelter in place and lockdown | Stay where you are, secure the door, follow alerts; do not leave until told | Corporate Security |
| Severe weather | Follow section 5; do not travel in conditions the authorities advise against | Corporate Security |
| Pandemic or public-health emergency | Follow public-health direction, work from home where the role allows, stay home when ill (HR-POL-007 Sick Leave and Personal Leave Policy); essential roles follow the BCP | Head of Workplace Safety |
| Technology outage | Switch to manual or downtime procedures, report to the SOC, never use unapproved tools or personal devices for Confidential or Restricted data (HR-POL-017) | SOC |
| Loss of building, power or utilities | Move to the alternate site or work from home as the manager directs | Business unit head |

## 10. Testing and review

BCPs are tested **twice a year** for each business unit, including one live exercise and one tabletop or technology recovery test. The Head of Workplace Safety publishes the schedule at the start of the year. Participation is mandatory for essential roles. Corrective actions from a test are assigned an owner and completed within 30 days or escalated to the VP HR Operations. After any declared incident, the Head of Workplace Safety holds a review within 10 business days.

## 11. Exceptions

Only the Head of Workplace Safety may vary a closure decision or a BCP test requirement, and the reason is recorded. A business unit head may not override a closure for operational convenience if Corporate Security has judged the site unsafe.

## 12. Consequences

An employee who ignores an evacuation or shelter instruction, falsely reports a check-in, or skips a required BCP test may face action under HR-POL-021 Employee Relations and Progressive Discipline Policy. Managers who pressure employees to travel unsafely breach this policy. Retaliation for a good-faith decision not to travel is prohibited.

## 13. Worked examples

**Example 1: snowstorm.** At 5:50 a storm closes a Canadian regional office. The MyHR alert, text message and intranet banner go out at 6:15. An employee in the office is paid for the day and is not charged vacation. Her hybrid colleague works from home during core hours.

**Example 2: no announcement.** A storm warning is in the area but there is no closure. An employee cannot get to the branch safely and tells his manager before the shift starts. They agree he uses a personal day. He is not disciplined, and the absence does not count towards an attendance trigger.

**Example 3: technology outage.** A branch payment system fails at 10:00. The manager calls the SOC and the team moves to the manual procedures in the BCP. All employees check in with the manager within 2 hours of the declared incident.

**Example 4: essential role.** A payments employee is assigned as essential during a flood closure. She works on site under the BCP, is paid for hours worked under HR-POL-003 and has no deduction from her vacation balance.

## 14. Related documents and contacts

Related: HR-POL-004 Attendance and Absenteeism Policy; HR-POL-002 Remote and Hybrid Work Policy; HR-POL-023 Workplace Health, Safety and Wellness Policy; HR-POL-003 Working Hours and Overtime Policy; HR-POL-017 IT Acceptable Use and Information Security Policy; HR-POL-010 Statutory Holidays Policy. Corporate Security: 1-800-555-0119 (24/7). Security Operations Centre: 1-800-555-0155, soc@bank.example (24/7). HR Connect: 1-800-555-0142 (Monday to Friday 8:00 to 20:00 Eastern Time), hrconnect@bank.example. Managers: Manager Hotline 1-800-555-0143. In an emergency call 911 first.

## 15. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2023-11-01 | Combined the severe weather and business continuity rules into one policy |
| 2.2 | 2024-11-01 | Added Bank Alert and the 2-hour check-in |
| 2.3 | 2025-11-01 | Added the BCP testing schedule of twice a year, the essential-roles list and the pandemic and technology outage procedures |
