# How to complete mandatory training

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-022 |
| Title | How to complete mandatory training |
| Document type | How-to article |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-11-01 |
| Last reviewed | 2026-10-19 |
| Next review | 2027-10-19 |
| Policy owner | SVP Talent and Learning |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-012, HR-MEMO-2026-006, HR-MEMO-2026-009, HR-POL-011, HR-GDE-003 |

## 1. The short answer

Complete every assigned course in the Learning Hub (MyHR > Career and Learning > Learning Hub) in the annual window, 1 August to 31 October; new hires have 30 days from their start date.

## 2. Who this applies to

All employees in Canada (including Quebec) and the US, and contractors and agency workers engaged by the Bank. Quebec employees may ask for course materials in French through HR Connect.

| Course | Frequency |
| --- | --- |
| Code of Conduct and Ethics | Annually |
| Anti-Money Laundering and Sanctions | Annually |
| Privacy and Information Security Awareness | Annually |
| Workplace Harassment and Violence Prevention | Annually |
| Workplace Health and Safety | Annually |
| Fraud Awareness | Annually |
| Accessibility and Human Rights | Every 2 years |

## 3. Steps

1. Sign in to MyHR and open Career and Learning > Learning Hub.
2. Select **Mandatory training** to see your assigned courses and due dates.
3. Open each course, finish all modules and pass any knowledge check.
4. Confirm that each course shows **Complete**. Your manager can see your status in MyHR.
5. Also complete your annual Code of Conduct and fit-and-proper attestation in MyHR by 31 October (see HR-MEMO-2026-009 Reminder: Code Attestation and Mandatory Training Due 31 October 2026 and HR-POL-001 Code of Conduct and Ethics).

## 4. Deadlines and what happens next

Existing employees: **31 October**. New hires: **30 days from the start date**. Employees on approved leave have their due dates extended by the length of the leave. Training records are kept for 7 years. Mandatory training does not count toward the 24 hours of learning a year that employees are encouraged to complete.

| Days after the due date | What happens |
| --- | --- |
| 7 | Automatic reminder to you |
| 14 | Your manager is notified |
| 30 | Annual Incentive Plan eligibility and the "how" part of your year-end rating are affected (see HR-POL-011 Performance Management Policy) |

Persistent non-completion may also be handled under HR-POL-021 Employee Relations and Progressive Discipline Policy.

## 5. Common mistakes

- Leaving the courses to the last week of October.
- Assuming a course completed last year still counts. Most are annual.
- Forgetting the 2-year Accessibility and Human Rights course in its due year.
- Closing a course early so that it shows **In progress**.
- Ignoring the reminders. Day 30 can affect your incentive and rating.

## 6. Who to call

- Learning Hub or MyHR access problems: HR Connect, 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, or live chat in MyHR.
- Questions about extensions: your manager, then your HRBP.
- Lost access to your accounts or a suspected incident: Security Operations Centre, 1-800-555-0155.

## 7. Related documents

- HR-POL-012 Learning and Development Policy (section 8, the owning document)
- HR-MEMO-2026-006 Annual Mandatory Training Window: 1 August to 31 October 2026
- HR-MEMO-2026-009 Reminder: Code Attestation and Mandatory Training Due 31 October 2026
- HR-GDE-003 New Employee Onboarding Guide

Where applicable law gives a greater right, the law applies.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-11-01 | Aligned with HR-POL-012 version 3.2 and the 1 August to 31 October annual window. |
| 1.0 | 2025-01-01 | First version. |
