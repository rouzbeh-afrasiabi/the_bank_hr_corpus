# HR Generalist

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1045 |
| Title | HR Generalist |
| Document type | Job description |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-09-02 |
| Next review | 2027-09-02 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-004, HR-GDE-005, HR-GDE-006, HR-FWK-001, HR-POL-011, HR-POL-021 |

## 1. Role summary

The HR Generalist is the day-to-day HR contact for managers and employees in an assigned business unit. The Generalist resolves questions on policies, performance, leaves and employee relations, supports the HR Business Partner and guides the HR Coordinator. The role is Band 4 (Senior Professional): it handles complex work, advises others and guides junior colleagues. See HR-GDE-006 Job Architecture and Pay Bands Guide.

## 2. Key responsibilities

- Advise managers on the procedures in HR-GDE-005 Manager's HR Procedures Guide, including probation, attendance and performance conversations.
- Own assigned cases in the HR Case Portal and meet the service levels in HR-GDE-004 HR Service and Support Guide: 2 business days for first response on P3 cases and a resolution target of 5 business days.
- Support the performance cycle by reminding managers of deadlines (goals by 15 December, mid-year check-in 1 May to 15 June, assessments due 10 December) and reviewing rating-dispute paperwork under HR-POL-011 Performance Management Policy.
- Coach managers through early-stage attendance and conduct concerns and refer matters to Employee Relations when they move toward written warnings (HR-POL-021 Employee Relations and Progressive Discipline Policy).
- Coordinate leave and accommodation requests with the Leaves team and the Accommodation Specialist, keeping medical information limited to functional limitations.
- Monitor and report on business-unit HR data: turnover, absence, engagement results and mandatory-training completion.
- Support restructuring and role changes by preparing documentation and communications; promotions and transfers are handled separately.
- Run exit-interview follow-up and share aggregated themes with the HR Business Partner.
- Deliver HR information sessions for new managers and guide the HR Coordinator on process quality.
- Maintain accurate records in MyHR and handle personal information as required by HR-POL-016 Employee Data Privacy Policy.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in human resources, industrial relations, business or a related field.
- Five to eight years of progressive HR experience, with a mix of employee relations, policy interpretation and HR operations.
- Knowledge of Canadian employment standards and US federal and state employment law.
- Strong coaching, listening and written communication skills.

### 3.2 Preferred

- A recognized HR designation; the Bank reimburses designation fees (HR-POL-012 Learning and Development Policy).
- Experience in a large, regulated organization with a unionized or multi-jurisdiction workforce.
- Bilingual English and French.

## 4. Competencies

Competency names follow HR-FWK-001 Competency and Leadership Model (Practitioner level, Bands 3 to 4).

- Collaboration
- Judgement and Decision Quality
- Developing Others
- Inclusive Leadership
- Risk and Conduct Awareness
- Customer Obsession

## 5. Compensation and classification

| Item | Detail |
| --- | --- |
| Band | 4 (Senior Professional) |
| Canada range | $72,000 to $108,000 CAD per year |
| US range | $70,000 to $106,000 USD per year |
| Incentive target | 8% of base salary (Annual Incentive Plan) |
| Overtime eligibility, Canada | Yes (non-managerial) |
| FLSA classification, US | Exempt |
| Work arrangement | Hybrid |

## 6. Working conditions and accessibility

Office-based and hybrid by default, with at least 3 days a week in the office; Tuesday and Thursday are anchor days (HR-POL-002 Remote and Hybrid Work Policy; FORM-HR-030). Some regional site visits are expected. The Bank provides accommodation to the point of undue hardship (HR-POL-018 Workplace Accommodation and Accessibility Policy).

## 7. Reporting line

Reports to the HR Business Partner. The role has no direct reports but guides the HR Coordinator.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-03-01 | Pay band aligned with the 2026 pay bands; performance-cycle dates updated |
| 1.0 | 2025-01-01 | First issue |
