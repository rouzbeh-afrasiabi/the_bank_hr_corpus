# Annual Mandatory Training Window: 1 August to 31 October 2026

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-MEMO-2026-006 |
| Title | Annual Mandatory Training Window: 1 August to 31 October 2026 |
| Document type | Memo |
| Version | 1.0 |
| Status | Current |
| Effective date | 2026-07-27 |
| Last reviewed | Not applicable |
| Next review | Not applicable |
| Policy owner | SVP Talent and Learning |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-012, HR-POL-011, HR-POL-009 |

**Your mandatory training opens on 1 August and must be finished by 31 October 2026.**

**From:** SVP Talent and Learning

**To:** All employees in Canada and the US

**Date:** 27 July 2026

**Subject:** Annual mandatory training window and late-completion escalation

## 1. What is changing

The annual window opens on 1 August 2026 and closes on 31 October 2026. Courses in the Learning Hub under HR-POL-012 Learning and Development Policy:

- Code of Conduct and Ethics
- Anti-Money Laundering and Sanctions
- Privacy and Information Security Awareness
- Workplace Harassment and Violence Prevention
- Workplace Health and Safety
- Fraud Awareness

Accessibility and Human Rights is completed every 2 years.

## 2. Who is affected

All employees. New hires complete the courses within 30 days of starting.

## 3. Effective date

1 August 2026.

## 4. What to do

1. Open the Learning Hub from MyHR and complete every assigned course by 31 October 2026.
2. If a course is overdue, you receive a reminder at 7 days, your manager is notified at 14 days, and at 30 days late your AIP eligibility and the "how" component of your rating (HR-POL-011) are affected (HR-POL-009).
3. Managers: follow up with team members who are late.

## 5. Who to call

HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, or live chat in MyHR. Managers: Manager Hotline 1-800-555-0143.

## 6. Related documents

- HR-POL-012 Learning and Development Policy
- HR-POL-011 Performance Management Policy
- HR-POL-009 Compensation and Payroll Policy
