# Learning Approval and Tuition Reimbursement Claim

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-060 |
| Title | Learning Approval and Tuition Reimbursement Claim |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-11-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | SVP Talent and Learning |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-012, HR-POL-011, HR-POL-009, FORM-HR-061 |

## 1. Purpose and when to use this form

Use this form to get approval for a job-related or career-related degree or diploma course (Part A) and to claim reimbursement afterwards (Part B). It is not for the $2,000 professional development budget or for professional designations (use FORM-HR-061).

## 2. Who completes it and who approves

You complete both parts. Your manager approves that the course is job-related or career-related, and the HRBP confirms eligibility: at least 6 months of service, regular full-time or part-time status, and a last rating of Meets Expectations or higher.

## 3. Where and when to submit

- **Part A:** in MyHR at least 15 business days before the course starts.
- **Part B:** within 60 days of the course completion date, with the receipt and proof of grade. Late claims are not reimbursed unless the SVP Talent and Learning approves an exception.

## 4. Form fields

| Field | Required | Notes |
| --- | --- | --- |
| Institution, course and dates | Part A | |
| Business or career link | Part A | Short explanation |
| Estimated cost | Part A | Tuition, mandatory course fees, required books |
| Work time needed | Part A | Study is normally outside working hours |
| Actual cost and receipt | Part B | Application fees, travel, parking and equipment are not covered |
| Grade or pass result | Part B | Transcript or confirmation |

## 5. Declarations and signatures

- The costs and grade are genuine; false claims or altered receipts are misconduct under HR-POL-001 Code of Conduct and Ethics.
- I understand that if I resign within 12 months of my last tuition reimbursement I must repay 100% of reimbursements paid in that period.

## 6. What happens next

Reimbursement depends on the result:

| Grade | Reimbursement |
| --- | --- |
| 70% or higher, or a pass | 100% of eligible costs |
| 60% to 69% | 50% |
| Below 60% | 0% |

The annual cap is $5,000 CAD (Canada) or $5,250 USD (US) per fiscal year (1 November to 31 October). Costs count toward the fiscal year in which the course ends. Payroll Services pays on a regular pay date after approval; any taxable amount is included in pay. No repayment is required if employment ends by involuntary termination without cause, restructuring, or during a Bank-approved leave. Where applicable law gives a greater right, the law applies.

## 7. Related documents

- HR-POL-012 Learning and Development Policy
- HR-POL-011 Performance Management Policy
- HR-POL-009 Compensation and Payroll Policy

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-11-01 | Cap raised to $5,000 CAD / $5,250 USD from $4,000 (HR-POL-012 version 3.2, 1 November 2025). |
