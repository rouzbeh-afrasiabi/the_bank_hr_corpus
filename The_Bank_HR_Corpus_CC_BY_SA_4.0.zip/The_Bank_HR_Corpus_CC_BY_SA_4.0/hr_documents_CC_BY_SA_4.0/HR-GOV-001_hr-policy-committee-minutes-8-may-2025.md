# HR Policy Committee Minutes, 8 May 2025

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-GOV-001 |
| Title | HR Policy Committee Minutes, 8 May 2025 |
| Document type | Minutes |
| Version | 1.0 |
| Status | Current |
| Effective date | 2025-05-08 |
| Last reviewed | Not applicable |
| Next review | Not applicable |
| Policy owner | Office of the CHRO |
| Audience | HR leadership |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-003, HR-POL-004, HR-POL-012, HR-GDE-005, HR-MEMO-2025-001 |

Chair: Chief Human Resources Officer

Meeting: Thursday 8 May 2025, 10:00 to 11:30 Eastern Time, by video conference.

## 1. Attendance and quorum

**Voting members present (8 of 9):** Chief Human Resources Officer (Chair), SVP Total Rewards, SVP Talent and Learning, VP Employee Relations, VP HR Operations, Chief Compliance Officer, Head of Ethics Office, Head of Workplace Safety.

**Apologies:** Chief Privacy Officer.

**Also present (non-voting):** Head of Accessibility and Inclusion; Committee Secretary (Office of the CHRO).

Quorum is 5 voting members including the Chair. Quorum was confirmed.

## 2. Agenda

1. Opening, quorum and minutes of the previous meeting
2. Overtime approval threshold: HR-POL-003 Working Hours and Overtime Policy
3. Revisions to HR-POL-004 Attendance and Absenteeism Policy
4. Tuition reimbursement review: progress report
5. Any other business and close

## 3. Discussion

### 3.1 Opening and previous minutes

The Chair opened the meeting, confirmed quorum and noted the minutes of the previous meeting, which were approved without change.

### 3.2 Overtime approval threshold

The SVP Total Rewards proposed lowering the weekly overtime that a manager may approve without Director approval from 10 hours (version 4.1, in force since 1 July 2024) to 8 hours. Managers' reports showed that approvals were clustering just under the 10-hour limit, and the Head of Workplace Safety raised fatigue and wellbeing concerns for branch and operations teams. The VP HR Operations confirmed that Time Tracker can enforce the lower threshold without a system change beyond a configuration update. The other rules in the policy are unchanged: HR is notified when the threshold is exceeded, and no employee is scheduled beyond 12 hours a day or 48 hours a week without VP approval and written consent. Members asked that managers be briefed before the effective date.

### 3.3 Revisions to HR-POL-004

The VP Employee Relations presented version 3.1 of the policy, which clarifies the list of protected absences, adds the no-call/no-show contact steps (at least 3 documented contact attempts and a letter by courier or registered mail before job abandonment is presumed) and adds a return-to-work conversation within 2 business days after an absence of 5 or more days. The Chair had issued the revisions on an interim basis effective 1 April 2025 under delegated authority, and the Committee was asked to confirm them. The attendance review triggers were not changed.

### 3.4 Tuition reimbursement review

The SVP Talent and Learning reported that the review of the tuition reimbursement cap under HR-POL-012 Learning and Development Policy is in progress. The current cap is $4,000 CAD per fiscal year. External benchmarking is under way and no change is proposed at this meeting. The Committee noted the report and asked for an options paper.

## 4. Decisions

| No. | Decision | Effective | Vote |
| --- | --- | --- | --- |
| D1 | Approved the reduction of the weekly overtime threshold requiring Director approval from 10 hours to 8 hours (HR-POL-003, version 4.2). | 2025-07-01 | For 8, Against 0, Abstain 0. Carried. |
| D2 | Approved the revisions to HR-POL-004 (version 3.1), confirming the interim issue by the Chair. | 2025-04-01 | For 7, Against 0, Abstain 1 (VP Employee Relations, as policy owner). Carried. |

## 5. Items noted

- The tuition reimbursement review is in progress. No decision was taken.

## 6. Action items

| No. | Action | Owner | Due |
| --- | --- | --- | --- |
| A1 | Issue the employee memo on the new overtime threshold (HR-MEMO-2025-001). | SVP Total Rewards | 2025-05-20 |
| A2 | Brief managers on the 8-hour threshold through the Manager Hotline team and update HR-GDE-005 Manager's HR Procedures Guide. | VP HR Operations | 2025-06-13 |
| A3 | Configure the 8-hour approval threshold in Time Tracker and test it before go-live. | VP HR Operations | 2025-06-20 |
| A4 | Publish version 3.1 of HR-POL-004 in MyHR and update manager guidance on no-call/no-show steps. | VP Employee Relations | 2025-06-06 |
| A5 | Circulate an options paper on the tuition reimbursement cap for the next meeting. | SVP Talent and Learning | 2025-08-29 |

## 7. Close

There being no other business, the Chair closed the meeting at 11:30. The next regular meeting was scheduled for September 2025.
