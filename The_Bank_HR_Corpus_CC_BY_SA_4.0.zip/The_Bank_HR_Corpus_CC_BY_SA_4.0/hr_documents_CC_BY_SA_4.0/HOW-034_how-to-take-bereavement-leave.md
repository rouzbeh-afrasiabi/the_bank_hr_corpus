# How to take bereavement leave

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-034 |
| Title | How to take bereavement leave |
| Document type | How-to article |
| Version | 1.1 |
| Status | Current |
| Effective date | 2025-12-01 |
| Last reviewed | 2026-09-15 |
| Next review | 2027-09-15 |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-026, HR-POL-010, HR-POL-006, HOW-036 |

## 1. Short answer

Tell your manager as soon as you can (the same day for a death), enter the leave in Time Tracker, and take 1, 3 or 5 paid days depending on your relationship to the person who died, plus unpaid travel days if you need them.

## 2. Who this applies to

Regular full-time, regular part-time and fixed-term employees in Canada and the US, from the first day of employment. The paid days are the same in both countries. Casual employees receive the bereavement leave the law requires. Where applicable law gives a greater right, the law applies. Part-time employees are paid their regular scheduled hours for those days.

## 3. Steps

1. **Tell your manager** as soon as the need is known.
2. **Check your paid days:**

| Relationship of the deceased | Paid days |
| --- | --- |
| Spouse or partner, child, parent, sibling | 5 |
| Grandparent, grandchild, parent-in-law, sibling-in-law | 3 |
| Aunt, uncle, niece, nephew, close friend | 1 |

Family relationships include step, foster, adoptive and in-law. For a close friend, your word is sufficient.

3. **Add travel if needed:** up to 3 further unpaid days, or up to 5 if you travel more than 800 km one way.
4. **Enter the leave** in MyHR > Time and Absence (Time Tracker) under the leave type shown there. Days may be consecutive or split.
5. **Wait for approval.** Your manager approves within 1 business day.

## 4. Deadlines

Use the days within 30 days of the death or of the funeral, memorial or service, whichever is later. If a memorial is delayed, the Leaves team will agree a later period of up to 6 months. Requests for more time go to the Leaves team through MyHR > HR Case Portal.

## 5. What happens next

Payroll Services pays the days at your regular pay. No documentation is normally required. A statutory holiday inside the leave is paid as a holiday and not counted as a bereavement day. If a death occurs during approved vacation, the affected vacation days are re-credited as bereavement days. A second death starts a new entitlement. You may add vacation, personal days or sick days if you need more time. Bereavement leave never counts in an attendance review.

## 6. Common mistakes

- Waiting for the funeral date before telling your manager.
- Counting a statutory holiday as a bereavement day.
- Missing the 30-day window without asking the Leaves team about a delayed memorial.
- Forgetting that travel days are unpaid.

## 7. Who to call

Your manager first. HR Connect, 1-800-555-0142, hrconnect@bank.example. Wellspring Support Program, 1-800-555-0166, 24 hours a day: free, confidential counselling.

## 8. Related documents

- HR-POL-026 Bereavement, Jury Duty and Other Leaves Policy
- HR-POL-010 Statutory Holidays Policy
- HR-POL-006 Vacation and Paid Time Off Policy

## 9. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.1 | 2025-12-01 | Clarified travel days (5 days if travel exceeds 800 km one way) per HR-POL-026 version 2.1. |
| 1.0 | 2025-01-01 | First issue. |
