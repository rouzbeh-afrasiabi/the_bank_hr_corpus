# Social Media and External Communications Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-027 |
| Title | Social Media and External Communications Policy |
| Document type | Policy |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-07-01 |
| Last reviewed | 2026-06-18 |
| Next review | 2027-06-18 |
| Policy owner | Head of Ethics Office |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Applies to | All Canadian and US employees (see Scope) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-001, HR-POL-005, HR-POL-016, HR-POL-017, HR-POL-021 |

## 1. Purpose

Social media and other public channels let employees share ideas and connect with customers and colleagues. They also carry risks to the Bank's reputation, to customers' privacy and to the security of Bank information. This policy explains how to use social media and other external channels responsibly, who may speak for the Bank, and how to handle media and public inquiries.

## 2. Scope

This policy applies to all employees in Canada and in the US, and to contractors and agency workers who use Bank systems. It covers any public or semi-public online channel, including social networks, professional networking sites, video and photo sharing, blogs and podcasts, public forums and comment sections, messaging groups with many members, review sites, and public generative AI tools. It applies at work and outside work when the content relates to the Bank, its customers or employees, or may affect the working relationship. Where applicable law gives a greater right, the law applies.

## 3. Definitions

- **Official channel:** a social media account, website or publication created and approved by the Bank to speak on its behalf.
- **Authorized spokesperson:** an employee who has been designated in writing to speak to the media or the public on behalf of the Bank.
- **Confidential information:** information classified as Confidential or Restricted under HR-POL-017 IT Acceptable Use and Information Security Policy, and any non-public information about customers, employees, suppliers, the Bank's finances or strategy.
- **Personal use:** use of an account that you hold in your own name and for your own purposes.

## 4. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Employees | Follow this policy, protect confidential information, make clear when views are personal, report problems promptly. |
| Managers | Guide their teams, refer media and external inquiries, and report suspected breaches to the HRBP. |
| Corporate Communications | Manages official channels, designates spokespersons, answers media inquiries and handles crisis communications. |
| Head of Ethics Office | Owns this policy, advises on grey areas and approves exceptions. |
| Chief Information Security Officer | Sets the rules for AI and public tools and monitors for data loss (HR-POL-017). |
| Employee Relations | Reviews breaches and applies corrective action under HR-POL-021. |

## 5. Personal use of social media

You are free to use social media in your personal life. When you do, remember that online content is public, lasting and easily shared, and that your Bank role may be known even if you do not mention it.

### 5.1 Rules for personal use

1. **Use your own time and your own devices.** Personal use at work must be brief and not interfere with your duties, in line with the incidental use rules in HR-POL-017.
2. **Make it clear that the views are your own.** If you identify yourself as a Bank employee, or your profile shows it, and you post about banking, finance or the Bank, make it clear that your views are personal and not those of the Bank.
3. **Do not use Bank logos, trademarks, templates or marketing images** to suggest that your account is official.
4. **Do not post confidential information**, including non-public financial results, customer details, internal documents, screenshots of internal systems, security details, or information about unannounced products or projects.
5. **Do not give financial, investment or legal advice** as though it comes from the Bank, and do not discuss specific securities in a way that breaches the inside information and personal trading rules in HR-POL-001 Code of Conduct and Ethics.
6. **Respect others.** Do not post content that is harassing, discriminatory, threatening, defamatory or otherwise breaches HR-POL-005 Workplace Harassment and Violence Prevention Policy.
7. **Do not post photos or video** of colleagues, customers or Bank premises (especially vaults, security areas and back-office floors) without permission.
8. **Follow the law and platform rules**, including copyright, and the rules on endorsements, such as clearly disclosing any relationship with a company you promote.

Nothing in this policy prevents employees from discussing their wages, hours and working conditions, taking part in lawful concerted activity, or reporting concerns to a regulator, where the law protects those rights.

### 5.2 Professional networking

A professional profile may state your Bank role, employer and responsibilities, which must be accurate. Recommendations, endorsements and comments about the Bank's products on professional networking sites must be accurate and not misleading. Do not use professional networks to solicit Bank customers or recruit colleagues for another employer in breach of any agreement you have with the Bank.

## 6. Professional use and official channels

Only employees authorized by Corporate Communications may create or run a Bank-branded account, page or group, or post on an official channel. A business unit that wants a social media presence must submit a request to Corporate Communications, which reviews the plan and brand, and assigns at least two trained administrators. All posts are reviewed to ensure that they are accurate and meet regulatory requirements for marketing and customer communications. When a customer posts a complaint on an official channel, the team moves the conversation to a private channel and must not request account numbers or other personal information publicly.

## 7. Who may speak for the Bank

Only **authorized spokespersons** may speak, post or comment on behalf of the Bank, or comment publicly on the Bank's financial performance, strategy, legal matters, regulatory matters or an incident. The CEO, the Chief Financial Officer and the heads of Corporate Communications and Investor Relations act as spokespersons for the Bank. Other spokespersons are designated in writing, for a stated topic and period. If you are asked to speak at a conference, join a panel, publish an article or take part in a podcast in your Bank capacity, obtain the approval of your manager, your business unit head (Band 8 or above) and Corporate Communications **at least 10 business days in advance**. Content that mentions customers or non-public information needs review by Compliance.

## 8. Media inquiries

If a journalist, analyst, researcher, regulator, lawyer or other outside party contacts you about the Bank:

1. **Do not respond**, comment off the record or confirm or deny any information.
2. Politely say that you will pass the inquiry to the right team, and take the person's name, organization, contact details and question.
3. **Send the inquiry to Corporate Communications on the same business day**, and tell your manager. Managers may call the Manager Hotline (1-800-555-0143) for advice.
4. Inquiries from a regulator, a law enforcement authority or a lawyer should also be copied to the Chief Compliance Officer's office. Inquiries about a specific employee's employment, or a request for a reference, are directed to HR Connect and are not answered by individual managers.

## 9. Confidentiality and customer information

You must never post, share or discuss customer information on social media, including names, accounts, transactions, complaints, images of documents or any detail that would identify a customer, even in a private message or a closed group. This applies even if the customer has already posted it. If a customer contacts you on your personal account, ask them to use official channels and do not discuss their business. Employee personal information, such as a colleague's health, leave or performance, is also confidential (see HR-POL-016 Employee Data Privacy Policy). A suspected disclosure of customer or employee information must be reported to the Privacy Office (privacy@bank.example) immediately, and in any case within 24 hours of discovery.

## 10. Disclaimers

If you post about the Bank or banking topics and your connection to the Bank is clear, include a short, visible disclaimer such as: "The views expressed are my own and do not represent those of my employer." A disclaimer is helpful but does not excuse a breach of this policy, such as sharing confidential information or harassing others.

## 11. Online harassment

Harassment and bullying through digital channels, including messaging apps, social media, group chats and comments, are covered by HR-POL-005 Workplace Harassment and Violence Prevention Policy, even if they occur outside working hours or on personal accounts, when they involve colleagues, customers or others connected with the Bank. If you are the target of online harassment because of your Bank role, save evidence (screenshots, links, dates), do not respond, report it to your manager, HRBP or the Speak-Up Line (1-800-555-0177), and contact Corporate Security (1-800-555-0119) if there is a threat. The Bank will help you report content to the platform and may refer threats to the police. Impersonation accounts, fake Bank profiles or scams that use the Bank's name must be reported to the Security Operations Centre (soc@bank.example) immediately.

## 12. Artificial intelligence and public tools

Using public generative AI tools, chatbots, online translators, summarizers, transcription services and similar public tools carries a high risk of leaking information. You must:

- use **only Bank-approved AI tools** for work, as set out in HR-POL-017 IT Acceptable Use and Information Security Policy;
- never enter customer data, employee personal data, inside information or other Confidential or Restricted information into a public tool;
- never use AI tools to create content that impersonates a colleague, customer or executive, or to produce deepfakes, and never post AI-generated content about the Bank without review by Corporate Communications;
- check the accuracy of AI output before you rely on it or share it, and take responsibility for what you post.

This restriction also applies to AI features built into personal social media apps. Report a suspected leak to the Security Operations Centre immediately and no later than 1 hour after discovery.

## 13. Monitoring

The Bank monitors the use of its systems, networks and official channels for security, compliance and regulatory purposes, and this monitoring is disclosed and not covert (see HR-POL-017). The Bank does not ask for personal social media passwords and does not monitor private accounts as a routine matter. It may, however, act on public content that is reported to it or that comes to its attention, and may require an employee to remove content that breaches this policy. Information collected is handled according to HR-POL-016 Employee Data Privacy Policy.

## 14. Exceptions

Exceptions require the written approval of the Head of Ethics Office, in consultation with Corporate Communications, and must be recorded. No exception may allow disclosure of customer information or breach of law.

## 15. Consequences

A breach of this policy may lead to corrective action under HR-POL-021 Employee Relations and Progressive Discipline Policy, up to and including termination for cause. A serious breach, such as sharing customer or inside information, harassment or speaking falsely on behalf of the Bank, may be treated as serious misconduct and may result in immediate termination and referral to authorities. Employees must remove content on request, and when they leave they must hand over any Bank-related accounts and update their profile to show the end of their employment.

## 16. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-07-01 | Current version. Added the AI and public tools section, clarified spokesperson authorization and media inquiry handling, and extended the policy to online harassment. |
