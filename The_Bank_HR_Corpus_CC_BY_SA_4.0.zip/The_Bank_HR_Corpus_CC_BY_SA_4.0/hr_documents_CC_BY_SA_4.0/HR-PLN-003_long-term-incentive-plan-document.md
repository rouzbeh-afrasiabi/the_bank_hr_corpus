# Long-Term Incentive Plan Document

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-PLN-003 |
| Title | Long-Term Incentive Plan Document |
| Document type | Plan document |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-09-30 |
| Next review | 2027-09-30 |
| Policy owner | SVP Total Rewards |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-PLN-001, HR-POL-031, HR-GDE-006, HR-POL-025, HR-POL-015 |

## 1. Purpose

1.1 This document sets out the terms of the Bank's Long-Term Incentive Plan (the "Plan"). The Plan aligns the long-term interests of senior leaders with those of shareholders by granting share-based awards that vest over three years.

1.2 It also contains the termination rules that apply to deferred Annual Incentive Plan amounts, as required by HR-POL-031 Incentive Deferral and Clawback Policy. Where applicable law gives a greater right, the law applies.

## 2. Definitions

| Term | Meaning |
| --- | --- |
| Grant date | The date in December on which the Board HR Committee approves the annual grant. |
| Grant value | Base salary on the grant date multiplied by the percentage for the band (section 4). |
| RSU | A restricted share unit: a right to receive one Bank share (or its cash value) when it vests. |
| PSU | A performance share unit: a right to receive Bank shares, from 0% to 200% of the units granted, depending on performance over the performance period. |
| Performance period | The three years beginning on the grant date. |
| Retirement | Leaving the Bank at or after age 55 with at least 10 years of service. |
| Board HR Committee | The committee of the Board of Directors responsible for human resources and compensation. |

## 3. Eligibility

3.1 Employees in Band 7 and above (see HR-GDE-006 Job Architecture and Pay Bands Guide) are eligible for an annual grant. Executive Committee roles are governed by separate arrangements and also receive awards under this Plan.

3.2 To receive a grant the employee must be on payroll on the grant date, must not have given or received notice of termination, and must not have a last rating of Unsatisfactory.

3.3 Eligibility for one year's grant does not guarantee a grant in any later year.

## 4. Award

4.1 Each year the grant value is set as a percentage of base salary.

| Band | Level title | Grant value (% of base salary) |
| --- | --- | --- |
| 7 | Director | 25% |
| 8 | Senior Director / Vice President | 50% |
| 9 | Senior Vice President | 100% |

4.2 The grant value is split equally: 50% in RSUs and 50% in PSUs.

4.3 The number of units is the portion of the grant value divided by the closing price of the Bank's shares on the grant date, rounded down to the nearest whole unit.

4.4 **Worked example.** A Band 7 employee has a base salary of $180,000 on the grant date. The grant value is 25% = $45,000. RSUs are 50% = $22,500 and PSUs are 50% = $22,500. At an illustrative closing share price of $37.50 the grant is 600 RSUs and 600 target PSUs.

4.5 The Plan is not matched by retirement plan contributions and the grant is not part of base salary for any other plan.

## 5. Vesting and settlement

5.1 **RSUs.** RSUs vest one third each year on the first, second and third anniversaries of the grant date. In the example in section 4.4, 200 RSUs vest on each anniversary.

5.2 **PSUs.** PSUs vest in full at the end of the three-year performance period (a 3-year cliff). The number of units that vest depends on two measures, weighted equally: relative total shareholder return compared with a peer group of financial institutions approved by the Board HR Committee, and return on equity. The result ranges from 0% to 200% of the target units. In the example, between 0 and 1,200 shares may be delivered.

5.3 **Dividend equivalents.** Where the Bank pays dividends, dividend equivalents are credited as additional units and vest on the same schedule as the units to which they relate.

5.4 **Settlement.** Vested units are settled in Bank shares, or in cash of equal value where local law or the Board HR Committee requires, within 60 days after the vesting date. Statutory tax is withheld on settlement.

5.5 **Deferred Annual Incentive Plan amounts.** Deferred amounts under HR-POL-031 are delivered in share units that vest equally over 3 years from the payment date of the incentive. They follow the termination rules in section 6, except as HR-POL-031 provides otherwise: unvested deferred amounts are forfeited on resignation and are kept on retirement or death.

## 6. Termination of employment

| Reason | RSUs | PSUs |
| --- | --- | --- |
| Resignation | Unvested RSUs are forfeited. | Unvested PSUs are forfeited. |
| Termination for cause | Unvested RSUs are forfeited. | Unvested PSUs are forfeited. |
| Retirement | Continue to vest on the original schedule, pro rata: the number that vests is multiplied by the whole months from the grant date to the retirement date, divided by 36. | Continue to the end of the performance period; the result is pro-rated in the same way and based on actual performance. |
| Involuntary termination without cause | Pro-rata vesting on the same basis as retirement, at the next vesting date. | Pro-rata vesting on the same basis, at the end of the performance period, based on actual performance. |
| Death | Vest in full on the date of death. | Vest in full at target on the date of death. |

6.1 **Leave of absence.** Vesting continues during approved leave unless the Board HR Committee decides otherwise.

6.2 **Notice periods.** Unless the law requires otherwise, a notice period or severance (see HR-POL-025 Involuntary Termination and Severance Policy) does not extend the vesting period. Resignation notice and garden leave are described in HR-POL-015 Resignation and Offboarding Policy.

## 7. Change of control

7.1 If the Bank undergoes a change of control, the Board HR Committee may decide that unvested awards are assumed or replaced by awards of equal value on the same vesting terms.

7.2 If awards are assumed or replaced and the employee is terminated without cause within 24 months after the change of control, the awards vest in full on termination; PSUs vest at the greater of target and performance to date.

7.3 If awards are not assumed or replaced, they vest in full on the change of control on the same PSU basis.

## 8. Clawback and malus

8.1 Awards, whether vested or not, are subject to HR-POL-031: unvested amounts may be reduced (malus) at any time, and amounts paid may be recovered for up to 3 years after delivery (5 years for Material Risk Takers) for misconduct, a material misstatement or a material risk-management failure.

8.2 Decisions are made by the Board HR Committee on the recommendation of the CHRO. The employee receives written notice and has 15 business days to respond.

## 9. Restrictions

9.1 Units are not transferable, other than by will or under law. The employee must not hedge or pledge unvested units.

9.2 The employee must comply with HR-POL-032 and the personal trading and restricted-list rules when selling delivered shares.

## 10. Administration

10.1 The Board HR Committee administers the Plan, approves each grant and the peer group, certifies performance results and may interpret the Plan. Its decisions are final.

10.2 The SVP Total Rewards runs the administration, maintains grant records and gives each participant a statement showing units, vesting dates and settlement values in MyHR.

10.3 The Bank may adjust the number or terms of units for share splits, mergers or similar events so that the value of the awards is not unfairly increased or reduced.

## 11. Amendment and termination of the Plan

11.1 The Board HR Committee may amend, suspend or end the Plan at any time, but an amendment may not reduce the rights under a grant already made without the participant's consent, except as needed to comply with law or under section 8.

11.2 The Plan is discretionary, is not part of an employment contract and does not guarantee future grants.

## 12. Related documents and contacts

HR-PLN-001 Annual Incentive Plan Document; HR-POL-031 Incentive Deferral and Clawback Policy; HR-GDE-006 Job Architecture and Pay Bands Guide; HR-POL-032 Personal Trading and Restricted Lists Policy. Questions: HR Connect, 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time, hrconnect@bank.example.

## 13. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-01-01 | Grant values set at 25%, 50% and 100% of base salary by band; added dividend equivalents, change of control and the termination table. |
| 1.0 | 2025-01-01 | First issue of the Plan document. |
