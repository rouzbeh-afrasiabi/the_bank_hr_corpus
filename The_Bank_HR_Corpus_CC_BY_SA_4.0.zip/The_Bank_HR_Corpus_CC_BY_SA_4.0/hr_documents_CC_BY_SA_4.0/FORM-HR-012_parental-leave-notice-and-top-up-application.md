# Parental Leave Notice and Top-Up Application

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-012 |
| Title | Parental Leave Notice and Top-Up Application |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-11-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-008, HR-POL-007, HR-POL-009, FORM-HR-013 |

## 1. Purpose and when to use this form

Use this form to give notice of a pregnancy, parental, adoption, foster or surrogacy leave and to apply for the Bank top-up (Canada) or paid parental leave (US).

## 2. Who completes it and who approves

You complete it. The Leaves team confirms eligibility and calculates your pay. Your manager plans coverage.

## 3. Where and when to submit

Submit in MyHR at least 4 weeks before the leave starts where possible, or as soon as practicable if it starts unexpectedly. The Leaves team confirms dates, top-up amount and return conditions in writing within 5 business days of a complete application.

## 4. Form fields

| Field | Required | Notes |
| --- | --- | --- |
| Type of leave | Yes | Birth parent, non-birth parent, adoptive, foster (US), surrogacy-intended |
| Due date or placement date | Yes | Pregnancy leave may start up to 13 weeks before the due date |
| Requested start and return dates | Yes | Give 4 weeks' notice of return |
| Evidence | Yes | Medical certificate with due date, placement or adoption papers, or surrogacy agreement; placement papers within 30 days of placement |
| Service start date | Yes | Canada top-up needs 6 months of continuous service |
| Government benefit application | Canada | Employment Insurance, or Quebec Parental Insurance Plan in Quebec |
| Phased return request | No | Up to 4 weeks at 80% of normal hours |

## 5. Declarations and signatures

- The information is accurate.
- I will apply to the government programs as early as possible and give the Leaves team each benefit notice within 5 business days of receiving it.
- I understand the government benefit is paid by the government and the Bank cannot guarantee it.

## 6. What happens next

| | Canada | US |
| --- | --- | --- |
| Bank-paid leave | Top-up to 100% of base salary: 17 weeks (birth parent), 8 weeks (non-birth, adoptive, surrogacy-intended) | 12 weeks at 100% of base salary for any new parent |
| Job protection | Up to 18 months combined for birth parents; leave must begin within 78 weeks of the birth or placement | 12 weeks under the Family and Medical Leave Act, run concurrently |

Benefits and retirement contributions continue as described in HR-POL-008. Birth parents in the US also receive short-term disability for medical recovery (HR-POL-007). You return to the same or a comparable role at the same pay band. Where applicable law gives a greater right, the law applies.

## 7. Related documents

- HR-POL-008 Parental and Family Leave Policy
- HR-POL-009 Compensation and Payroll Policy
- HR-POL-007 Sick Leave and Personal Leave Policy

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-11-01 | Updated for HR-POL-008 version 5.1 (8-week non-birth top-up and 12-week US paid leave). |
