# How to request access to your personal information

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-031 |
| Title | How to request access to your personal information |
| Document type | How-to article |
| Version | 1.1 |
| Status | Current |
| Effective date | 2026-02-01 |
| Last reviewed | 2026-09-01 |
| Next review | 2027-09-01 |
| Policy owner | Chief Privacy Officer |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-016, FORM-HR-090, HR-REF-002, HR-PRC-008 |

## 1. Short answer

Submit FORM-HR-090 Personal Information Access Request, or email privacy@bank.example, and the Privacy Office will respond within 30 days of a complete request, at no fee.

## 2. Who this applies to

Current employees, former employees and job applicants in Canada and the US. Quebec employees may ask for the response in French. Where applicable law gives a greater right, the law applies. Former employees and applicants email the Privacy Office directly. Records are kept under HR-REF-002 Employee Records Retention Schedule.

## 3. Steps

1. **Check MyHR first.** Most of your information is visible in MyHR > Personal Information, and you can correct many details there yourself.
2. **Open the form.** Go to MyHR > Privacy > Access Request (FORM-HR-090), or email privacy@bank.example.
3. **Say what you want.** Give your full name and employee ID (or applicant reference), your province or state, your contact details, and whether you want access, a correction or both. Be specific, for example payroll history, performance records or your recruitment file, and add a date range if you can.
4. **Prove who you are.** Upload an identity document. It is deleted after verification.
5. **Add evidence for a correction** and state the record and the correct information.
6. **Choose your format:** electronic or paper, English or French.

## 4. Deadlines

| Step | Timeline |
| --- | --- |
| Identity check | Before any information is released |
| Response | Within 30 days of a complete request |
| Extension | Up to a further 30 days, with written notice and reasons |
| Fee | None for a standard request |

## 5. What happens next

The Privacy Office acknowledges your request, verifies your identity, gathers the records and sends them securely. It explains anything withheld, which can include information about other people, privileged legal advice, investigation information protected by law, or information whose release could harm someone. An accepted correction is made; if the Bank does not agree the information is inaccurate, a note of your disagreement is added. You can complain to the Privacy Office or a privacy regulator at any time.

## 6. Common mistakes

- Asking for "everything" instead of naming the records; a specific request is faster.
- Leaving out the identity document, which delays a complete request.
- Putting medical or sensitive details in a case description instead of an attachment.

## 7. Who to call

Privacy Office, privacy@bank.example. HR Connect, 1-800-555-0142 (Monday to Friday 8:00 to 20:00 Eastern Time), hrconnect@bank.example, for help finding the form. Report a suspected privacy breach immediately and within 24 hours. The Ombuds Office, ombuds@bank.example, gives informal advice.

## 8. Related documents

- HR-POL-016 Employee Data Privacy Policy
- FORM-HR-090 Personal Information Access Request
- HR-REF-002 Employee Records Retention Schedule

## 9. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.1 | 2026-02-01 | Aligned with HR-POL-016 version 4.0. |
| 1.0 | 2025-01-01 | First issue. |
