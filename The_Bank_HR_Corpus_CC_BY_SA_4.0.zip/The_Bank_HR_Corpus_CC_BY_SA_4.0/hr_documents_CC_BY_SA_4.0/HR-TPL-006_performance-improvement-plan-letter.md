# Performance Improvement Plan Letter

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-TPL-006 |
| Title | Performance Improvement Plan Letter |
| Document type | Template |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-06-30 |
| Next review | 2027-06-30 |
| Policy owner | VP Employee Relations |
| Audience | HR only |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-013, HR-POL-011, HR-POL-018, FORM-HR-070 |

## 1. Purpose and when to use this template

This template is the cover letter given to an employee at the start of a performance improvement plan (PIP). The plan itself is recorded in FORM-HR-070 Performance Improvement Plan, and the rules are in HR-POL-013 Performance Improvement Policy. It is used only after the HRBP has approved the plan.

## 2. How to use this template

1. Confirm the trigger: a rating of Needs Improvement or Unsatisfactory (HR-POL-011 Performance Management Policy), or documented sustained underperformance after at least one documented coaching conversation.
2. Get the HRBP's approval before the meeting, and check for any accommodation need first (HR-POL-018 Workplace Accommodation and Accessibility Policy).
3. Send the draft plan and evidence to the HRBP at least 3 business days before the meeting.
4. Hold the kickoff meeting within 10 business days of the trigger, give the employee the letter and FORM-HR-070, and record any refusal to sign.

## 3. Letter text

**[Date]**   **Personal and confidential**

**[Employee full name]**, [Job title], Band [Band]

**Subject: Performance improvement plan**

Dear [Employee first name],

This letter confirms our conversation on **[Meeting date]**. As discussed, **[Brief, factual description of the performance gaps and the trigger]**. The attached plan (FORM-HR-070) sets out what needs to improve and how we will support you.

**Length.** The plan starts on **[Start date]** and ends on **[End date]**. The standard length is 60 days; this plan is **[30 / 60 / 90] days**. **[If 90 days: The longer period was approved by the HRBP and Employee Relations because [reason].]**

**What is expected.** The plan lists each gap with examples, the measurable standard expected, and a date for each target. Check-ins are held **every week on [Day and time]** for 30 minutes, and there is a mid-point review at **[Mid-point date]**.

**Support.** The Bank will provide **[Training, coaching, tools, workload adjustments, mentor]**. You may use the Learning Hub, the Wellspring Support Program (1-800-555-0166, 24 hours a day, confidential) and the Ombuds Office (ombuds@bank.example) at any time.

**Your rights in the process.** You may bring a support person to meetings; the person may not be legal counsel. You may add written comments to the plan within 5 business days. Your signature shows that you received the plan; it does not mean that you agree with it. If you need an accommodation, tell your manager, HR Connect or accommodations@bank.example at any time; a PIP does not stop you from asking.

**During the plan.** You continue to receive your pay, benefits, vacation and statutory leaves. During an active plan you are not eligible for a merit increase or an internal transfer, and a remote arrangement requires that you have no active plan.

**Outcome.** A written outcome will be issued within 5 business days of the end date. If you meet the targets, the plan closes and the restrictions above end. If progress is clear but not complete, the HRBP may approve one extension of up to 30 days. If the plan is not successful, the matter moves to progressive discipline, which may lead to termination after Employee Relations approval.

Sincerely,
**[Manager name]**, [Manager title]
**[HRBP name]**, HR Business Partner

Acknowledgement of receipt: ____________  Date: ____________

## 4. Required clauses checklist

| Clause | Required content |
| --- | --- |
| Length | 60 days standard (range 30 to 90); 90 days needs HRBP and Employee Relations approval |
| Form | FORM-HR-070 attached |
| Check-ins | Weekly, 30 minutes |
| Support person | Allowed, not legal counsel |
| Comments | Within 5 business days |
| Restrictions | No merit increase or internal transfer during the plan |
| Outcomes | Success, one extension up to 30 days, or progressive discipline |

## 5. Drafting notes for HR

- A PIP is about performance, not conduct. Conduct issues go to HR-POL-021 Employee Relations and Progressive Discipline Policy.
- A PIP must not be used to retaliate against someone who raised a complaint, requested an accommodation, took protected leave or contacted the Speak-Up Line.
- A plan may be paused during a protected absence of more than 5 consecutive business days; the end date moves by the length of the absence and this is not the extension.
- PIP records are removed from the active file 12 months after successful completion.
- Describe gaps with specific examples, not labels such as "poor attitude".

## 6. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.0 | 2023-04-03 | First PIP letter template (90-day standard length) |
| 2.0 | 2025-09-01 | Updated for the 60-day standard length in HR-POL-013 version 2.1 and added the accommodation check |
