# Electronic Monitoring Acknowledgement

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-129 |
| Title | Electronic Monitoring Acknowledgement |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-11-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | Chief Information Security Officer |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-033, HR-POL-016, HR-POL-017, HR-POL-003 |

## 1. Purpose and when to use this form

Use this form to acknowledge that you have received and read the Electronic Monitoring and Right to Disconnect Policy (HR-POL-033 Electronic Monitoring and Right to Disconnect Policy). The Bank's monitoring is disclosed, never covert, and is used for security, compliance, fraud prevention and safety. The Bank monitors: email and messaging scanning; web filtering; endpoint security; data-loss prevention; badge and building access; recorded telephone lines in branches, the contact centre and trading; VPN and application logs; and vehicle telematics for fleet vehicles only. The Bank does not use keystroke or screen capture for productivity scoring, and does not monitor you by webcam at home.

## 2. Who completes it and who approves

You complete it. No approval is needed. HR Operations records it.

## 3. Where and when to submit (deadline, channel, processing time)

HR Operations gives new hires the policy within 30 days of the start date, and gives all employees the updated policy within 30 days of a change. Acknowledge within 30 days of receiving it. Submit in MyHR (My Profile > Policies and Acknowledgements).

## 4. Form fields

| Field | Required | Notes |
| --- | --- | --- |
| Name, employee ID, business unit | Yes | Pre-filled |
| Reason for acknowledgement | Yes | New hire or policy change |
| Policy version acknowledged | Yes | Pre-filled |
| I have read the list of monitored systems | Yes | Tick |
| I understand the purposes of monitoring | Yes | Tick |
| I understand how long logs are kept | Yes | 13 months; call recordings in Capital Markets and Wealth are kept 7 years |
| I understand who may access monitoring data | Yes | Security and Compliance, with a documented reason; HR requests need Privacy Office approval |
| I have read the right to disconnect section | Yes | Tick |
| Questions or concerns | No | Sent to the Privacy Office |

## 5. Declarations and signatures

I acknowledge that I have read and understood the policy and that the Bank monitors the systems listed in it. I understand that the policy sets out my right to disconnect: I am not expected to answer messages outside working hours except when on call; meetings are scheduled between 8:00 and 18:00 local time unless urgent; and there is no penalty for not responding outside hours. This acknowledgement is not consent to any monitoring the policy prohibits. Signature and date: ____________.

## 6. What happens next

HR Operations records your acknowledgement. If you have questions about how monitoring data is handled, contact the Privacy Office at privacy@bank.example. Where monitoring of employees is introduced or changed, it requires a documented purpose and an assessment under HR-POL-016 Employee Data Privacy Policy. On-call duties follow HR-POL-003 Working Hours and Overtime Policy. Report a suspected misuse of monitoring data to the Privacy Office or the Speak-Up Line (1-800-555-0177).

## 7. Related documents

- HR-POL-033 Electronic Monitoring and Right to Disconnect Policy
- HR-POL-016 Employee Data Privacy Policy
- HR-POL-017 IT Acceptable Use and Information Security Policy

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-11-01 | Added right to disconnect acknowledgement and the 30-day change rule. |
| 1.0 | 2024-02-01 | Initial form. |
