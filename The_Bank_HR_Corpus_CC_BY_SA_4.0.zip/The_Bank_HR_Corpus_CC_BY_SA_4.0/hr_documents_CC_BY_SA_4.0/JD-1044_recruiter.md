# Recruiter

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1044 |
| Title | Recruiter |
| Document type | Job description |
| Version | 1.1 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-06-18 |
| Next review | 2027-06-18 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-019, HR-POL-020, HR-GDE-006, HR-FWK-001, HR-POL-037, HR-POL-024 |

## 1. Role summary

The Recruiter manages the full hiring cycle for assigned business units, from intake with the hiring manager to a signed offer. The Recruiter sources and assesses candidates, runs a fair and structured process and keeps the time-to-fill target of 45 days in view. The role is Band 3 (Professional): it applies professional knowledge and works independently on assigned requisitions. See HR-GDE-006 Job Architecture and Pay Bands Guide.

## 2. Key responsibilities

- Hold an intake meeting for each requisition and confirm the approved band, job description and pay range, which must appear in the posting (HR-POL-037 Pay Transparency Policy).
- Confirm requisition approval at the right level: Directors for Bands 1 to 4, Vice Presidents for Bands 5 and 6, and SVP and CHRO for Band 7 and above (HR-POL-019 Recruitment and Selection Policy).
- Post roles for at least 5 business days and source candidates through the Bank careers site, networks and employee referrals.
- Screen applications against the job requirements; an automated screening tool is never the sole basis for rejecting a candidate.
- Set up structured interviews with a panel of at least 3 and at least 2 interview stages, and brief panellists on fair assessment.
- Build diverse interview slates for Band 5 and above in line with HR-POL-024 Diversity, Equity, Inclusion and Belonging Policy.
- Complete 2 reference checks and start pre-employment screening after a conditional offer (HR-POL-020 Pre-Employment Screening Policy, FORM-HR-111).
- Prepare offers within band, with an offer above the midpoint approved by the HRBP and Total Rewards; offers remain valid for 5 business days.
- Administer the employee referral programme and confirm the referral bonus after the referred hire completes 6 months.
- Keep candidate data in the applicant tracking system and delete or archive it after 12 months.
- Report time-to-fill and candidate experience metrics monthly to the Manager, Talent Acquisition.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree or diploma in human resources, business or a related field.
- Two to five years of full-cycle recruiting in an agency or corporate environment.
- Strong interviewing and assessment skills; ability to manage 20 or more open requisitions.
- Knowledge of employment equity and human rights principles in hiring.

### 3.2 Preferred

- Experience hiring for financial services, technology or licensed roles (HR-POL-029 Licensing, Registration and Qualification Policy).
- Bilingual English and French.

## 4. Competencies

Competency names follow HR-FWK-001 Competency and Leadership Model (Practitioner level, Bands 3 to 4).

- Customer Obsession
- Collaboration
- Inclusive Leadership
- Drive for Results
- Judgement and Decision Quality
- Adaptability

## 5. Compensation and classification

| Item | Detail |
| --- | --- |
| Band | 3 (Professional) |
| Canada range | $56,000 to $84,000 CAD per year |
| US range | $55,000 to $82,000 USD per year |
| Incentive target | 5% of base salary (Annual Incentive Plan) |
| Overtime eligibility, Canada | Yes (non-managerial) |
| FLSA classification, US | Exempt |
| Work arrangement | Hybrid |

## 6. Working conditions and accessibility

Office-based and hybrid by default, with at least 3 days a week in the office; Tuesday and Thursday are anchor days (HR-POL-002 Remote and Hybrid Work Policy; FORM-HR-030). Some evening interviews and campus events may be required. The Bank provides accommodation to the point of undue hardship, including in the hiring process (HR-POL-018 Workplace Accommodation and Accessibility Policy).

## 7. Reporting line

Reports to the Manager, Talent Acquisition. The role has no direct reports.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.1 | 2025-09-01 | Added pay transparency, referral and screening duties |
| 1.0 | 2025-01-01 | First issue |
