# Relationship Manager, Small Business

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1013 |
| Title | Relationship Manager, Small Business |
| Document type | Job description |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-08-25 |
| Next review | 2027-08-25 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-POL-002, HR-POL-038, HR-POL-018 |

## 1. Role summary

The Relationship Manager, Small Business is the main banking contact for owner-managed businesses with modest borrowing and cash-management needs. The role builds a portfolio of small business clients, recommends financing, deposit, payments and card solutions, and manages credit within delegated authority. The Relationship Manager is a trusted adviser to business owners and a connector to the Bank's specialists in payments, wealth and commercial lending. This is a Band 4 (Senior Professional) role in the Commercial Banking family; see HR-GDE-006 Job Architecture and Pay Bands Guide.

## 2. Key responsibilities

- Manage and grow a portfolio of small business clients through proactive outreach and regular reviews.
- Assess business financial performance, cash flow and collateral, and structure credit solutions within delegated authority.
- Recommend operating accounts, term loans, lines of credit, equipment finance, merchant services and corporate cards that fit each client's needs.
- Prepare and submit credit applications above delegated limits for independent credit approval.
- Monitor portfolio performance, covenant compliance and early-warning signals, and take timely action.
- Complete know-your-business and beneficial ownership checks, and escalate unusual activity under anti-money-laundering procedures.
- Refer owners to Wealth Advisors, Personal Banking Advisors and Commercial colleagues for personal and growth needs.
- Develop prospects through networking, local business associations and branch referrals.
- Travel to client locations and branches within the territory, with expenses managed under HR-POL-038 Business Travel and Expense Policy.
- Maintain accurate client records and meet risk and conduct standards.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in business, finance or a related field, or equivalent experience.
- Five to eight years of experience in commercial or small business banking, credit or business development.
- Strong credit analysis and financial statement skills.
- Proven ability to build relationships with business owners.
- Satisfactory results in pre-employment screening, including credit check for roles with financial authority.

### 3.2 Preferred

- Prior small business lending experience with a delegated authority record.
- CFA or a credit-related designation, or progress towards one.
- Fluency in English and French.

### 3.3 Licences and certifications

No securities or mortgage licence is required for this role. Clients' personal investment needs are referred to licensed colleagues under HR-POL-029 Licensing, Registration and Qualification Policy.

## 4. Competencies

Competencies are defined in HR-FWK-001 Competency and Leadership Model; this role works at the Practitioner level.

- **Customer Obsession**: acts as a trusted adviser to business owners.
- **Judgement and Decision Quality**: makes balanced credit decisions that support client growth.
- **Risk and Conduct Awareness**: manages credit, fraud and conduct risk responsibly.
- **Drive for Results**: grows and deepens the portfolio.
- **Collaboration**: brings the right specialists to client conversations.
- **Adaptability**: responds to the changing needs of small businesses.

## 5. Compensation and classification

| Item | Detail |
| --- | --- |
| Band | 4 (Senior Professional) |
| Canada salary range | $72,000 to $108,000 CAD per year |
| US salary range | $70,000 to $106,000 USD per year |
| Incentive target | Annual Incentive Plan (AIP): 8% of base salary |
| Overtime eligibility (Canada) | Yes (non-managerial Band 1 to 4 role) |
| FLSA classification (US) | Exempt |
| Work arrangement | Hybrid: at least 3 days a week in the office, with client visits scheduled around them |

## 6. Working conditions and accessibility

This is a hybrid role with regular client visits within the territory; some travel by personal vehicle may be needed. Hybrid arrangements follow HR-POL-002 Remote and Hybrid Work Policy, with at least 3 days a week in the office and anchor days on Tuesday and Thursday. The Bank provides accommodation to the point of undue hardship (Canada) or reasonable accommodation (US); see HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to the Regional Manager, Commercial.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-03-01 | Pay ranges updated to the 2026 pay bands; hybrid requirement aligned to HR-POL-002 v3.0 |
| 1.0 | 2024-05-06 | First issue |
