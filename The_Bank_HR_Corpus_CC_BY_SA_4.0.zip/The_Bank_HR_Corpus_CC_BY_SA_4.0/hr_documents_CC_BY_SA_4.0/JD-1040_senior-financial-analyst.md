# Senior Financial Analyst

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1040 |
| Title | Senior Financial Analyst |
| Document type | Job description |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-09-22 |
| Next review | 2027-09-22 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-POL-002, HR-POL-018, HR-POL-031 |

## 1. Role summary

The Senior Financial Analyst is the finance partner for a major business unit or enterprise cost area. The role owns the planning cycle for that area, leads complex analyses such as profitability, capital allocation and incentive funding, and guides junior analysts. The role is Band 4 (Senior Professional): it handles complex work, advises others and is recognized for depth in the field. See HR-GDE-006 Job Architecture and Pay Bands Guide.

## 2. Key responsibilities

- Lead the annual budget and quarterly reforecast for an assigned business unit, challenging assumptions with business leaders.
- Build and maintain profitability and unit-cost models, and present findings to the Senior Manager, Finance and business-unit executives.
- Model the funding of incentive pools, including the business funding factor range (0 to 1.5) and the deferral rules in HR-POL-031 Incentive Deferral and Clawback Policy, in cooperation with Total Rewards.
- Review the quality of month-end close entries and accruals prepared by junior analysts.
- Prepare board and executive committee financial packages with clear narratives.
- Evaluate investment cases and business cases, including sensitivity and downside analysis.
- Coach Band 3 analysts and review their work; contribute to their year-end feedback.
- Improve reporting processes and lead small automation projects.
- Support regulatory financial reporting and external audit fieldwork.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in finance, accounting, economics or business.
- Five to eight years of experience in financial planning, corporate finance or accounting, ideally in financial services.
- Advanced financial modelling and data-analysis skills.
- Proven ability to explain numbers to non-finance leaders.

### 3.2 Preferred

- CPA or CFA designation, or equivalent; fees are reimbursed under HR-POL-012 Learning and Development Policy (FORM-HR-061).
- Experience with enterprise planning and business-intelligence tools.

### 3.3 Licences, screening and conduct

No licence is required. Access to restricted financial results before release makes the role subject to the personal trading and restricted-list rules; confirm your status with Compliance (HR-POL-032 Personal Trading and Restricted Lists Policy).

## 4. Competencies

Competency names follow HR-FWK-001 Competency and Leadership Model (Practitioner level, Bands 3 to 4).

- Judgement and Decision Quality
- Drive for Results
- Collaboration
- Developing Others
- Adaptability
- Risk and Conduct Awareness

## 5. Compensation and classification

| Item | Detail |
| --- | --- |
| Band | 4 (Senior Professional) |
| Canada range | $72,000 to $108,000 CAD per year |
| US range | $70,000 to $106,000 USD per year |
| Incentive target | 8% of base salary (Annual Incentive Plan) |
| Overtime eligibility, Canada | Yes (non-managerial) |
| FLSA classification, US | Exempt |
| Work arrangement | Hybrid |

## 6. Working conditions and accessibility

Office-based and hybrid by default, with at least 3 days a week in the office and Tuesday and Thursday as anchor days (HR-POL-002 Remote and Hybrid Work Policy; FORM-HR-030). Workload peaks around quarter-end and year-end (31 October). The Bank provides accommodation to the point of undue hardship (HR-POL-018 Workplace Accommodation and Accessibility Policy).

## 7. Reporting line

Reports to the Senior Manager, Finance. The role has no direct reports but guides Band 3 analysts.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-03-01 | Pay band and incentive target aligned with the 2026 pay bands |
| 1.0 | 2025-01-01 | First issue |
