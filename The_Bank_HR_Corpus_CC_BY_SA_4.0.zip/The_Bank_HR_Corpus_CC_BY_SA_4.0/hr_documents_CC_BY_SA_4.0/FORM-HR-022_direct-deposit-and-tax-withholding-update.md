# Direct Deposit and Tax Withholding Update

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-022 |
| Title | Direct Deposit and Tax Withholding Update |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-009, HR-GDE-003, FORM-HR-021 |

## 1. Purpose and when to use this form

Use this form to set up or change your bank account for direct deposit (mandatory; pay is by direct deposit only), your tax withholding, or your name and address. New hires also use it for onboarding.

## 2. Who completes it and who approves

You complete it. Payroll Services verifies and processes it. No manager approval is needed.

## 3. Where and when to submit

Submit in MyHR. Changes to bank details and tax forms must be entered by the payroll cut-off, 17:00 Eastern Time five business days before the pay date. A change received later is processed on the next pay date. For example, for the Canada pay date of 2026-03-05 the cut-off is 2026-02-26.

## 4. Form fields

| Field | Required | Notes |
| --- | --- | --- |
| Update type | Yes | Direct deposit, tax withholding, name, address |
| Bank institution and account details | For direct deposit | Canada: institution, transit and account numbers. US: routing and account numbers |
| Account type and split | For direct deposit | Chequing or savings; one account unless you ask for a split |
| Canada: federal and provincial personal tax credit return forms | For tax update | Upload the completed forms |
| US: Form W-4 and state withholding form | For tax update | Upload the completed forms |
| New legal name or address | If changing | Supporting document for a name change |
| Effective pay date | Yes | Shown after the cut-off check |

## 5. Declarations and signatures

- The account is in my name and the details are accurate.
- I understand Payroll Services may confirm changes with me through MyHR before processing.
- I understand I am responsible for the accuracy of my tax forms.

## 6. What happens next

Payroll Services processes the update for the next eligible pay date. Pay statements appear in MyHR 2 business days before the pay date. Keep your address current: tax slips (T4 and Relevé 1 by 28 February; W-2 by 31 January) are issued from it. Garnishments are applied as required by court order and law, and you are notified. If a payment goes to the wrong account, raise a P1 case through FORM-HR-021. Where applicable law gives a greater right, the law applies.

## 7. Related documents

- HR-POL-009 Compensation and Payroll Policy
- HR-GDE-003 New Employee Onboarding Guide
- HR-POL-017 IT Acceptable Use and Information Security Policy

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-03-01 | Combined direct deposit, tax withholding and personal information updates into one MyHR form. |
