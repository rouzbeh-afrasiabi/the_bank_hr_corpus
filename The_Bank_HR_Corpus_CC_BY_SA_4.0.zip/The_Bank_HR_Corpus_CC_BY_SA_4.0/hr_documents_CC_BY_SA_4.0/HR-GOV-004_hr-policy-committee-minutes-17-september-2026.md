# HR Policy Committee Minutes, 17 September 2026

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-GOV-004 |
| Title | HR Policy Committee Minutes, 17 September 2026 |
| Document type | Minutes |
| Version | 1.0 |
| Status | Current |
| Effective date | 2026-09-17 |
| Last reviewed | Not applicable |
| Next review | Not applicable |
| Policy owner | Office of the CHRO |
| Audience | HR leadership |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-DRAFT-001, HR-DRAFT-002, HR-POL-001, HR-POL-034, HR-GDE-001 |

Chair: Chief Human Resources Officer

Meeting: Thursday 17 September 2026, 13:00 to 15:00 Eastern Time, in person and by video conference.

## 1. Attendance and quorum

**Voting members present (9 of 9):** Chief Human Resources Officer (Chair), SVP Total Rewards, SVP Talent and Learning, VP Employee Relations, VP HR Operations, Chief Compliance Officer, Chief Privacy Officer, Head of Ethics Office, Head of Workplace Safety.

**Also present (non-voting):** Head of Inclusion and Belonging (item 5); Head of Accessibility and Inclusion; Committee Secretary (Office of the CHRO).

Quorum is 5 voting members including the Chair. Quorum was confirmed.

## 2. Agenda

1. Opening, quorum and minutes of the meeting of 5 February 2026 (HR-GOV-003)
2. Annual policy attestations and mandatory training
3. Draft proposals: four-day work week pilot and vacation carryover change
4. 2027 annual benefits enrolment dates
5. Pay-equity review results
6. Any other business and close

## 3. Discussion

### 3.1 Annual policy attestations

The Head of Ethics Office and the Chief Compliance Officer reviewed progress on the annual attestations: the Code of Conduct and Ethics attestation (HR-POL-001, due 31 October 2026), the fit-and-proper attestation that accompanies it, and the annual licence review held each 1 September. The mandatory training window runs from 1 August to 31 October 2026. Members agreed that managers will receive a reminder with the 7-day, 14-day and 30-day escalation steps. No policy change was proposed.

### 3.2 Draft proposals not approved

The VP HR Operations presented HR-DRAFT-001, a proposed six-month compressed four-day work week pilot from 1 April 2027 for three business units. The SVP Total Rewards presented HR-DRAFT-002, a proposed change to vacation carryover with a cash-out option. Members raised open questions on overtime treatment, coverage in branches and operations, payroll cost and the interaction with the mandatory 10-day block leave control. Neither proposal was approved. Both drafts are not in effect and were sent back for costing. The current rules remain: a minimum of 3 hybrid office days a week, and carryover of up to 5 vacation days used by 31 March.

### 3.3 2027 benefits enrolment

Benefits Administration proposed annual enrolment from 2 to 16 November 2026 for coverage from 1 January 2027. The Committee noted that the dates had already been shown on a planning basis in HR-MEMO-2026-007 of 14 September 2026 and confirmed them. If an employee makes no election, the default is the Standard plan in Canada and Choice PPO employee-only in the US.

### 3.4 Pay-equity review

The Head of Inclusion and Belonging presented the annual pay-equity review by gender and designated group under HR-POL-034 Employment Equity and Pay Equity Policy. The Committee reviewed the results and asked that the findings be considered in the 2027 salary planning. Any adjustments are funded centrally.

## 4. Decisions

| No. | Decision | Effective | Vote |
| --- | --- | --- | --- |
| D1 | Confirmed that the four-day work week pilot proposal (HR-DRAFT-001) and the vacation carryover change proposal (HR-DRAFT-002) are not approved, and sent both back for costing. | Not applicable | For 9, Against 0, Abstain 0. Carried. |
| D2 | Approved the 2027 annual benefits enrolment dates of 2 to 16 November 2026, for coverage from 1 January 2027. | 2026-11-02 | For 9, Against 0, Abstain 0. Carried. |

## 5. Items noted

- The annual policy attestations were reviewed. No decision was required.
- The pay-equity results were reviewed. No decision was required.

## 6. Action items

| No. | Action | Owner | Due |
| --- | --- | --- | --- |
| A1 | Return a costed version of HR-DRAFT-001, including overtime and coverage options. | VP HR Operations | 2026-12-04 |
| A2 | Return a costed version of HR-DRAFT-002, including the cost of the cash-out option. | SVP Total Rewards | 2026-12-04 |
| A3 | Send managers the reminder on attestation and mandatory training due 31 October 2026 (HR-MEMO-2026-009). | Head of Ethics Office | 2026-10-19 |
| A4 | Open annual enrolment in MyHR and post the 2027 premiums. | SVP Total Rewards | 2026-11-02 |
| A5 | Carry the pay-equity findings into the 2027 salary planning inputs. | SVP Total Rewards | 2026-11-30 |

## 7. Close

The Chair closed the meeting at 15:00.
