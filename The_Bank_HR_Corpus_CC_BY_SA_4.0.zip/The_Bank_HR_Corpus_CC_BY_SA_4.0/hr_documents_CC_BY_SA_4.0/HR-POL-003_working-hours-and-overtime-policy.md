# Working Hours and Overtime Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-003 |
| Title | Working Hours and Overtime Policy |
| Document type | Policy |
| Version | 4.2 |
| Status | Current |
| Effective date | 2025-07-01 |
| Last reviewed | 2026-06-15 |
| Next review | 2027-06-15 |
| Policy owner | SVP Total Rewards |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Applies to | All Canadian and US employees (see Scope) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-009, HR-POL-010, HR-POL-014, HR-POL-002, HR-GDE-006, FORM-HR-020 |

## 1. Purpose

This policy sets the Bank's standard hours of work, the rules for overtime and time in lieu, meal and rest breaks, scheduling, premiums, on-call duty and time entry. Where the Bank rule is more generous than the law, the Bank rule applies. Where applicable law gives a greater right, the law applies.

## 2. Scope

The policy covers all employees in Canada and the US. Time entry, overtime pay and time in lieu apply only to employees who are overtime-eligible (Canada) or non-exempt (US). Contractors are outside this policy (see HR-POL-014 Employment Status and Classification Policy).

## 3. Definitions

- **Standard work week:** 37.5 hours in Canada (7.5 hours a day, 5 days) and 40 hours in the US (8 hours a day, 5 days), each with a 60-minute unpaid meal period.
- **Core hours:** 10:00 to 15:00 local time for office-based staff. Retail branch and operations staff follow posted schedules.
- **Extra hours (Canada):** hours worked between 37.5 and 40 in a week.
- **Overtime:** hours that attract a premium rate under the tables in section 5.
- **Overtime-eligible / non-exempt:** see section 11.

## 4. Standard hours

| Item | Canada | US |
| --- | --- | --- |
| Weekly hours | 37.5 | 40 |
| Daily hours | 7.5 | 8 |
| Working days | 5 | 5 |
| Unpaid meal period | 60 minutes | 60 minutes |

Extra hours in Canada are paid at straight time, or banked 1:1 as time off at the employee's request. They are not overtime.

## 5. Overtime rules by region

### 5.1 Canada

Overtime in Canada is paid at 1.5x. The Bank pays earlier than the law in several provinces.

| Jurisdiction | Daily rule | Weekly rule | Notes |
| --- | --- | --- | --- |
| Ontario | None | 1.5x after 40 hours | The provincial threshold is 44; the Bank pays from 40 |
| Quebec | None | 1.5x after 40 hours | |
| British Columbia | 1.5x after 8 hours; 2x after 12 hours | 1.5x after 40 hours | Hours already paid as daily overtime are not counted again |
| Alberta | 1.5x after 8 hours | 1.5x after 40 hours | The greater of the daily or weekly overtime hours is paid, not both |
| Manitoba, Saskatchewan, Nova Scotia, New Brunswick, Newfoundland and Labrador, Prince Edward Island | None | 1.5x after 40 hours | |
| Yukon, Northwest Territories, Nunavut | None | 1.5x after 40 hours | |

### 5.2 United States

| Jurisdiction | Daily rule | Weekly rule |
| --- | --- | --- |
| California | 1.5x after 8 hours; 2x after 12 hours | 1.5x after 40 hours |
| New York, New Jersey, Florida | None | 1.5x after 40 hours |
| All other states | None | 1.5x after 40 hours |

Non-exempt US employees are paid overtime in cash. Compensatory time is not available in the US.

## 6. Worked examples

Each example uses an hourly rate of $30 and counts hours actually worked, excluding unpaid meal periods.

**Ontario.** An employee works 9 hours on each of 5 days (45 hours). The first 37.5 hours are regular, the next 2.5 are extra hours at straight time, and 5 hours exceed 40 and are paid at 1.5x. Pay: 40 x $30 = $1,200, plus 5 x $45 = $225, for $1,425.

**British Columbia.** Hours are Monday 9, Tuesday 8, Wednesday 13, Thursday 8, Friday 7.5 (45.5 hours). Daily overtime at 1.5x is 1 hour on Monday plus 4 hours on Wednesday (5 hours); 1 hour on Wednesday beyond 12 is paid at 2x. The remaining 39.5 hours do not exceed 40, so there is no weekly overtime. Pay: 39.5 x $30 = $1,185, plus 5 x $45 = $225, plus 1 x $60 = $60, for $1,470.

**Alberta.** Hours are Monday 11, Tuesday 4, Wednesday to Friday 8 each (39 hours). Daily overtime is 3 hours; weekly overtime is 0. The greater, 3 hours, is paid at 1.5x. Pay: 36 x $30 = $1,080, plus 3 x $45 = $135, for $1,215. If the same employee worked 7.5 hours on 6 days (45 hours), weekly overtime of 5 hours would be greater than daily overtime of 0 and would apply.

**California.** Hours are Monday 10, Tuesday 8, Wednesday 13, Thursday 8, Friday 8 (47 hours). Daily overtime at 1.5x is 2 hours on Monday and 4 on Wednesday (6 hours); 1 hour on Wednesday beyond 12 is at 2x. The remaining 40 hours are straight time. Pay: 40 x $30 = $1,200, plus 6 x $45 = $270, plus 1 x $60 = $60, for $1,530.

## 7. Time in lieu (Canada only)

At the employee's request and with manager approval on FORM-HR-020, overtime may be banked as paid time off at **1.5 hours per overtime hour**. Four overtime hours therefore bank 6 hours. The bank is capped at **40 hours**, and banked time (including extra hours banked 1:1) must be taken within **3 months**. Any unused balance is paid out at the overtime rate at expiry. Time in lieu for holiday work is covered by HR-POL-010 Statutory Holidays Policy.

## 8. Meal and rest breaks

| Item | Canada (all provinces) | US except California | California |
| --- | --- | --- | --- |
| Meal period | 30 minutes unpaid, after at most 5 consecutive hours | Same as Canada | 30 minutes, taken before the end of the 5th hour |
| Rest breaks | Two paid 15-minute breaks per full shift | Two paid 15-minute breaks per full shift | A paid 10-minute break per 4 hours worked |

The standard 60-minute meal period may be shortened to 30 minutes with the manager's agreement. Managers do not discourage or interrupt breaks.

## 9. Scheduling and rest

- Schedules are posted at least **14 days** ahead.
- A schedule change with less than **96 hours'** notice needs the employee's consent.
- An employee may decline a shift added with less than **24 hours'** notice.
- No employee is scheduled beyond **12 hours a day or 48 hours a week** without VP approval and the employee's written consent.
- Employees have at least **8 hours of rest between shifts** and **24 consecutive hours off per week**.
- There is no expectation to respond to messages outside working hours, except when on call (right to disconnect).

## 10. Overtime approval

Overtime must be pre-approved by the manager in Time Tracker. Planned or recurring overtime needs FORM-HR-020. More than **8 overtime hours in a week** needs Director approval and HR notification. Emergency overtime is approved by the manager by the next business day. Unapproved overtime is still paid, but repeated unapproved overtime may be addressed under HR-POL-021 Employee Relations and Progressive Discipline Policy. The weekly limit was 10 hours before 1 July 2025.

## 11. Exempt and non-exempt employees

- **Canada:** Bands 1 to 4 non-managerial roles are overtime-eligible. Bands 5 and above are not.
- **US:** employees classified non-exempt under the Fair Labor Standards Act (generally Bands 1 to 3 and some Band 4) are overtime-eligible. Exempt employees are not.

Classification depends on job duties and pay, not on title, and is determined by HR Operations with Legal. Bands are defined in HR-GDE-006 Job Architecture and Pay Bands Guide. An employee who thinks a role is misclassified follows HR-POL-014.

## 12. Time entry

Overtime-eligible and non-exempt employees record start, end and meal times in Time Tracker. Exempt employees record absences only. The weekly entry deadline is **Friday 17:00** local time and manager approval is due by **Monday 12:00** local time. Corrections after payroll cut-off follow HR-POL-009 Compensation and Payroll Policy. Falsifying time records is serious misconduct.

## 13. Shift premium and on-call

| Item | Canada | US |
| --- | --- | --- |
| Shift premium (Technology and Operations; branches with extended hours), hours between 18:00 and 06:00 | $2.00 CAD per hour | $2.00 USD per hour |
| On-call allowance | $200 CAD per week | $150 USD per week |
| Call-out minimum | 3 hours' pay at the applicable rate | 3 hours' pay at the applicable rate |

## 14. Roles and responsibilities

Employees record time accurately and obtain approval first. Managers approve, monitor hours and protect rest periods. Directors approve more than 8 weekly overtime hours. Payroll Services pays overtime and time in lieu balances. The SVP Total Rewards owns this policy.

## 15. Contacts

HR Connect: 1-800-555-0142, hrconnect@bank.example. Manager Hotline: 1-800-555-0143.

## 16. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 4.0 | 2023-07-01 | Added region-by-region overtime tables and time in lieu bank cap of 40 hours |
| 4.1 | 2024-07-01 | Set maximum weekly overtime without Director approval at 10 hours |
| 4.2 | 2025-07-01 | Lowered maximum weekly overtime without Director approval from 10 hours to 8 hours |
