# Sample Total Rewards Statement

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-PLN-008 |
| Title | Sample Total Rewards Statement |
| Document type | Plan document |
| Version | 2026.1 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-09-28 |
| Next review | 2027-09-28 |
| Policy owner | SVP Total Rewards |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | Employees |
| Jurisdiction | Canada |
| Language | English |
| Related documents | HR-POL-009, HR-GDE-006, HR-GDE-001, HR-GDE-002, HR-PLN-001, HR-POL-006, HR-POL-007, HR-POL-010 |

## 1. Purpose

1.1 This document shows what a Total Rewards Statement looks like and how to read it. It uses one fictional employee, so that you can compare the layout and the arithmetic with your own statement in MyHR (menu path: Pay and Rewards, then Total Rewards).

1.2 The figures are illustrations for a fictional Band 4 employee in Ontario with 6 years of service. They are not an offer, a guarantee or a promise of any amount. Your own statement is based on your records; the plan documents and policies named below govern if there is a difference. Where applicable law gives a greater right, the law applies.

## 2. How to read a statement

A statement has three parts: **direct annual value** (cash and Bank-paid contributions that can be added in dollars), **paid time off** (days, not dollars) and **development and wellbeing** (amounts you may use, which are not added to your total because they depend on whether you use them).

## 3. The fictional employee

| Item | Value |
| --- | --- |
| Employee | Sample Employee (fictional) |
| Role | Business Analyst |
| Band | 4 (Senior Professional) |
| Province | Ontario |
| Years of service | 6 |
| Base salary | $90,000 CAD (equal to the Band 4 midpoint in `pay_bands.csv`) |
| Status | Regular full-time |
| Statement basis | Salary effective 2026-03-01; plan year 2026 |

## 4. Direct annual value

| Component | Basis | Annual amount |
| --- | --- | --- |
| Base salary | Annual rate | $90,000 |
| Annual Incentive Plan, at target | 8% of base salary at target (funding factor 1.0, rating Meets Expectations) | $7,200 |
| Retirement: Bank pension contribution | 2% base contribution + 4% match = 6% of $90,000 | $5,400 |
| Employer-paid benefits | Bank-paid share of group benefits, including basic life and short-term and long-term disability coverage | $4,800 |
| **Direct annual value** | 90,000 + 7,200 + 5,400 + 4,800 | **$107,400** |

### 4.1 Notes

- The Annual Incentive Plan payout is not guaranteed. It is the target; the actual payout equals base salary earned x 8% x the business funding factor x the individual multiplier (see HR-PLN-001 Annual Incentive Plan Document). At the highest possible factor (1.5) and rating (Outstanding, 1.5) the payout would be $16,200; if the rating were Unsatisfactory it would be $0.
- The pension figure assumes the employee contributes at least 4% of base salary (the first 4% is matched). The employee's own contributions are not included. Bank contributions vest immediately; incentive pay is not matched (HR-GDE-002 Retirement and Savings Plan Guide).
- The employer-paid benefits amount is the Bank's cost of the employer-paid coverages. Employee premiums for optional plan choices are not subtracted or added. See HR-GDE-001 Employee Benefits Guide.
- **Life insurance protection.** Basic life insurance of 2x annual base salary, employer-paid, is $180,000 of coverage. This is protection, not a cash value, and is not included in the total above.

## 5. Paid time off

| Item | Days per year | Rule |
| --- | --- | --- |
| Vacation | 20 | Completed service of 3 to under 10 years (HR-POL-006 Vacation and Paid Time Off Policy) |
| Sick days | 10 | Canada, calendar year; no carryover (HR-POL-007 Sick Leave and Personal Leave Policy) |
| Personal days | 3 | Any reason, calendar year |
| Floating days | 2 | Cultural and Religious Observance Days (HR-POL-010 Statutory Holidays Policy) |
| Paid statutory holidays | 12 | Ontario list below |

### 5.1 Ontario paid holidays in 2026

| Holiday | Date |
| --- | --- |
| New Year's Day | 2026-01-01 |
| Family Day | 2026-02-16 |
| Good Friday | 2026-04-03 |
| Victoria Day | 2026-05-18 |
| Canada Day | 2026-07-01 |
| Civic Holiday | 2026-08-03 |
| Labour Day | 2026-09-07 |
| National Day for Truth and Reconciliation | 2026-09-30 |
| Thanksgiving | 2026-10-12 |
| Remembrance Day | 2026-11-11 |
| Christmas Day | 2026-12-25 |
| Boxing Day (observed) | 2026-12-28 |

Time off is shown in days and is not given a dollar value in the statement.

## 6. Development and wellbeing

| Item | Amount | Rule |
| --- | --- | --- |
| Wellness spending account | $500 CAD per calendar year | Claim by 31 March of the following year |
| Professional development budget | $2,000 CAD per fiscal year | Courses, conferences and books (HR-POL-012 Learning and Development Policy) |
| Tuition reimbursement | Up to $5,000 CAD per fiscal year | After 6 months of service, last rating Meets Expectations or higher, with pre-approval |
| Wellspring Support Program | Up to 8 counselling sessions per issue per calendar year | Free, confidential, available 24 hours a day |

These amounts are available to you but are not added to the direct annual value because their value depends on use.

## 7. Key assumptions

1. The fictional employee earns the full base salary for the whole year and takes no unpaid leave.
2. Benefit values are annual and rounded.
3. The statement uses the Band 4 range for Canada in `pay_bands.csv`; the source of truth for pay ranges is that file, summarised in HR-GDE-006 Job Architecture and Pay Bands Guide.
4. Payroll rules, pay dates and deductions are in HR-POL-009 Compensation and Payroll Policy. Income tax and other deductions are not shown.

## 8. Where to find your own statement

Sign in to MyHR and open Total Rewards; the statement is refreshed after the annual salary review on 1 March. If a figure looks wrong, raise a case in the HR Case Portal. HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time, hrconnect@bank.example.

## 9. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2026.1 | 2026-03-01 | Updated for the 2026 salary review, 2026 benefit values and the 2026 Ontario holiday list. |
| 2025.1 | 2025-03-01 | Prior-year sample statement. |
