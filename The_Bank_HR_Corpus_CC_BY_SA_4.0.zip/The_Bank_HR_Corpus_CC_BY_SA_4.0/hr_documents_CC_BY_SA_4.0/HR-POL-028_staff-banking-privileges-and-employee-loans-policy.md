# Staff Banking Privileges and Employee Loans Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-028 |
| Title | Staff Banking Privileges and Employee Loans Policy |
| Document type | Policy |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-08-18 |
| Next review | 2027-08-18 |
| Policy owner | Chief Compliance Officer |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-001, HR-POL-030, HR-POL-009, HR-POL-020, HR-POL-021, FORM-HR-120 |

## 1. Purpose

Employees are customers of the Bank as well as colleagues. This policy sets out the banking privileges the Bank offers to eligible employees, the controls that keep employee accounts and credit free from conflicts of interest and abuse of access, and the employee hardship loan that helps employees through genuine emergencies. It supports the standards in HR-POL-001 Code of Conduct and Ethics and the conduct and honesty standards in HR-POL-030 Fit and Proper and Conduct Standards Policy.

## 2. Scope

The policy applies to regular employees and to fixed-term employees whose contract is 6 months or more, in Canada and the US, once they have completed the 3-month probation described in HR-POL-014 Employment Status and Classification Policy. Casual employees, students, co-op placements, interns, contractors and agency workers are not eligible for staff banking privileges. The hardship loan has its own eligibility rule in section 8. Where applicable law gives a greater right, the law applies.

## 3. Definitions

| Term | Meaning |
| --- | --- |
| Staff privileges | The products and pricing in section 5 that are offered to eligible employees. |
| Relative | As defined in HR-POL-001: a spouse or partner, child, parent, sibling, grandparent, grandchild, in-law, or anyone living in your household. |
| Household member | A person who lives at the same address as the employee. |
| Independent credit officer | A credit decision-maker who is outside the employee's reporting line and has no personal or financial relationship with the applicant. |
| Posted rate | The Bank's published rate for a product on the day of approval, before any staff discount. |
| Hardship loan | A short-term, interest-free loan to an employee under section 8 and FORM-HR-120 Hardship Loan Application. |

## 4. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Employee | Uses privileges honestly, keeps accounts in good standing, declares relationships, and never handles their own accounts or credit. |
| Manager | Reassigns any transaction that involves an account of the employee, a relative or a household member, and never approves credit or waivers for a team member. |
| Independent credit officer | Decides every employee credit application on the same criteria as customers. |
| Chief Compliance Officer | Owns the policy, receives the quarterly senior-employee credit report and approves exceptions. |
| HR Business Partner (HRBP) | Co-approves hardship loans and checks eligibility. |
| Payroll Services | Co-approves hardship loans, pays funds, sets up and runs the payroll deduction and recovers balances. |
| Ethics Office | Advises on conflicts and handles reports of misuse. |

## 5. Staff privileges

### 5.1 What is offered

| Privilege | Terms |
| --- | --- |
| Chequing and savings accounts | No monthly fees. |
| Credit card | One personal credit card with no annual fee. |
| Mortgage | Discount of 0.75 percentage points from the posted rate, for a maximum of 2 properties. The principal residence is financed first. |
| Personal line of credit | Discount of 1.00 percentage point from the posted rate, on a limit of up to $50,000 CAD (Canada) or $40,000 USD (US). |
| Safety deposit box | No fee. |

Other terms (qualification, security, insurance, term and prepayment) are the same as for customers.

### 5.2 When privileges end

The mortgage and line of credit discounts end 90 days after employment ends. For a mortgage, the discount continues to the end of the current term, and the posted rate applies when the mortgage is renewed. Fee waivers on accounts, the card and the safety deposit box return to standard customer pricing 90 days after employment ends. A privilege may also be withdrawn if this policy is breached.

### 5.3 Tax

The value of an interest-rate discount is a taxable benefit where tax law requires. Payroll Services reports it on the annual tax slip (see HR-POL-009 Compensation and Payroll Policy) and the employee is responsible for any tax owing.

## 6. Controls on employee accounts and credit

1. **No handling of your own business.** You may not open, approve, process, review, release holds on or change your own accounts, or the accounts or credit of a relative or household member. This applies even where the system would let you do it.
2. **Independent handling.** Such a transaction is handled by a colleague outside your reporting line. Tell your manager so that it can be reassigned.
3. **No self-waivers.** You may not waive or reverse a fee, overdraft charge, interest, or credit limit for yourself or a relative, and may not authorize an overdraft or limit increase on your own account.
4. **Independent credit decisions.** Every credit application from an employee is decided by an independent credit officer on the same criteria and documents that apply to customers. The staff discount is applied only after approval.
5. **Senior employee reporting.** Credit held with the Bank by employees in Band 7 and above is reported to the Chief Compliance Officer every quarter.
6. **Access to records.** Looking at your own or a relative's account without a business need is a breach of HR-POL-001 Code of Conduct and Ethics, section 13. All access is logged and audited.

## 7. Procedures and deadlines

| Step | Who | Deadline |
| --- | --- | --- |
| Request a staff product through the normal customer channel, identifying yourself as an employee | Employee | Any time after probation |
| Declare a relative or household member who is a customer and is being served by your team | Employee | Before the next transaction; the manager reassigns it the same business day |
| Credit decision | Independent credit officer | As for customers |
| Report a suspected misuse of privileges or access | Anyone | Immediately, to the Ethics Office (ethics@bank.example) or the Speak-Up Line (1-800-555-0177) |
| Tell the Chief Compliance Officer's office if you become Band 7 or above and hold Bank credit | Employee | Within 10 business days of the change |

## 8. Employee hardship loan

### 8.1 Terms

| Item | Rule |
| --- | --- |
| Eligibility | 6 months of service. Employees in the categories listed in section 2 only. |
| Amount | Up to $5,000 CAD (Canada) or $4,000 USD (US) |
| Interest | 0% |
| Repayment | By payroll deduction over 3 to 12 months. The deduction may not exceed 15% of net pay per pay period. |
| Number | One loan at a time |
| Reasons | Emergency: medical, housing, family emergency or disaster |
| Application | FORM-HR-120 Hardship Loan Application, through MyHR |
| Approval | HRBP and Payroll Services, within 5 business days of a complete application |
| Funds | Paid by direct deposit within 3 business days of approval |

### 8.2 Repayment and leaving the Bank

- Deductions follow the limits in HR-POL-009 Compensation and Payroll Policy. Where law requires written consent before a deduction is made (for example in California), consent is obtained first.
- If employment ends, the balance is due in the final pay. The deduction is made only as far as the law allows, and any remainder must be repaid within 60 days.
- A borrower who is struggling to repay should contact Payroll Services at once. The repayment period may be extended within the 12-month maximum. The Wellspring Support Program (1-800-555-0166) offers free, confidential support.

### 8.3 What is not covered

The hardship loan is not for investing, buying property, paying tax debts that are not an emergency, or paying another loan. It does not replace a staff line of credit and is not a salary advance.

## 9. Worked examples

1. **Mortgage discount.** The posted 5-year fixed rate on the day of approval is 5.49%. An eligible employee receives 5.49% minus 0.75 = 4.74%. If the employee buys a third property, no staff discount applies to it.
2. **Line of credit.** A Canadian employee applies for a $60,000 CAD line. The staff discount of 1.00 percentage point applies to the first $50,000 CAD only. Standard pricing applies above that.
3. **Own account.** A teller notices that the account in front of them belongs to their sibling. They do not process it. A colleague outside the teller's reporting line does.
4. **Hardship loan.** An employee in Canada with 14 months of service needs $4,000 CAD after a flood and has net pay of $2,000 per pay period. The 15% cap is $300 per pay period, so the repayment must run at least 14 pay periods (about 7 months), which is within the 3 to 12 month range.
5. **Leaving.** The same employee resigns with $1,200 CAD outstanding. The balance is due in the final pay, subject to the law. If the final pay cannot cover it, the remainder is repaid within 60 days.

## 10. Exceptions

Exceptions to this policy are rare. They require the written approval of the Chief Compliance Officer and, for a hardship loan, the additional approval of the VP HR Operations. An exception may never allow an employee to approve their own credit or waive their own fees.

## 11. Consequences of breach

Using privileges dishonestly, handling your own or a relative's accounts or credit, or giving a false reason on a hardship loan application is a breach of HR-POL-001 Code of Conduct and Ethics. It is handled under HR-POL-021 Employee Relations and Progressive Discipline Policy and may lead to withdrawal of privileges and to termination for cause. Serious misuse may be reported to regulators or law enforcement. A pattern of unpaid debts or of dishonest dealings with the Bank may also be reviewed under HR-POL-030 Fit and Proper and Conduct Standards Policy.

## 12. Related documents and contacts

- HR-POL-001 Code of Conduct and Ethics
- HR-POL-030 Fit and Proper and Conduct Standards Policy
- HR-POL-009 Compensation and Payroll Policy
- HR-POL-014 Employment Status and Classification Policy
- HR-POL-021 Employee Relations and Progressive Discipline Policy
- FORM-HR-120 Hardship Loan Application
- HR Connect: 1-800-555-0142, hrconnect@bank.example. Ethics Office: ethics@bank.example.

## 13. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-09-01 | Added the independent credit officer rule, quarterly reporting for Band 7 and above, and the employee hardship loan (FORM-HR-120). Clarified that discounts end 90 days after employment ends. |
| 1.0 | 2022-09-01 | First version. Staff accounts and discounts only. |
