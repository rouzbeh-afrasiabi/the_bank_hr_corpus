# Hardship Loan Application

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-120 |
| Title | Hardship Loan Application |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | Chief Compliance Officer |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-028, HR-POL-009, HR-POL-015, FORM-HR-022, HR-PRC-003 |

## 1. Purpose and when to use this form

Use this form to apply for an interest-free employee hardship loan after an emergency such as a medical, housing or family emergency, or a disaster (HR-POL-028 Staff Banking Privileges and Employee Loans Policy).

| Item | Rule |
| --- | --- |
| Eligibility | At least 6 months of service |
| Maximum | $5,000 CAD / $4,000 USD |
| Interest | 0% |
| Repayment | Payroll deduction over 3 to 12 months, at most 15% of net pay per period |
| Number of loans | One at a time |

## 2. Who completes it and who approves

You complete it. The HRBP and Payroll Services approve. The loan is separate from your regular staff banking credit, which is decided by an independent credit officer.

## 3. Where and when to submit (deadline, channel, processing time)

Submit in MyHR (Pay > Hardship Loan). The HRBP and Payroll Services decide within 5 business days. Funds are paid by direct deposit within 3 business days of approval. Keep your bank details current (FORM-HR-022 Direct Deposit and Tax Withholding Update). Payroll changes follow the payroll cut-off in HR-POL-009 Compensation and Payroll Policy.

## 4. Form fields

| Field | Required | Notes |
| --- | --- | --- |
| Name, employee ID, band, start date | Yes | Pre-filled; start date confirms 6 months of service |
| Country of work | Yes | Sets CAD or USD |
| Reason for the loan | Yes | Medical, housing, family emergency or disaster |
| Brief description of the situation | Yes | Share only what is needed; confidential |
| Amount requested | Yes | Not more than the maximum |
| Repayment term in months | Yes | 3 to 12 |
| Existing hardship loan balance | Yes | Must be nil |
| Supporting documents | No | Invoices or notices, if available |
| Direct deposit account on file | Yes | Confirm |

## 5. Declarations and signatures

I confirm that the information is accurate and that I authorize payroll deduction to repay the loan, up to 15% of my net pay per period. Where the law requires written consent for a deduction, I give it here. I understand that if my employment ends, the balance is due in my final pay, deducted only as far as the law allows, and that I must repay any remainder within 60 days. Signature and date: ____________.

## 6. What happens next

You receive the decision in MyHR. If approved, Payroll Services sets up the deduction schedule and pays the funds. You can ask Payroll Services to review the repayment term if your circumstances change. The Wellspring Support Program (1-800-555-0166, 24 hours) offers free confidential support. Information on this form is kept confidential and used only for the loan.

## 7. Related documents

- HR-POL-028 Staff Banking Privileges and Employee Loans Policy
- HR-POL-009 Compensation and Payroll Policy
- HR-POL-015 Resignation and Offboarding Policy

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-09-01 | Aligned maximum, repayment terms and approval timing with HR-POL-028 version 2.0. |
| 1.0 | 2022-09-01 | Initial form. |
