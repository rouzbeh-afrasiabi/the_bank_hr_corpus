# Temporary Work-from-Elsewhere Request

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-031 |
| Title | Temporary Work-from-Elsewhere Request |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-01-05 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-002, HR-POL-017, FORM-HR-030 |

## 1. Purpose and when to use this form

Use this form to work temporarily from a location other than your normal workplace. It does not change your arrangement; use FORM-HR-030 for that.

## 2. Who completes it and who approves

You complete it. The approvers depend on where you will work:

| Location | Limit per calendar year | Submit at least | Approval |
| --- | --- | --- | --- |
| Elsewhere in your home country | 20 working days | 5 business days ahead | Manager |
| Across the Canada-US border | 10 working days | 10 business days ahead | Manager, with Payroll Services and Legal review |
| Any other country | Not permitted by default | 30 days ahead | Global Mobility and Legal |

The domestic and cross-border limits are separate.

## 3. Where and when to submit

Submit in MyHR within the lead time above. The Bank may refuse a request for tax, immigration, regulatory or security reasons.

## 4. Form fields

| Field | Required | Notes |
| --- | --- | --- |
| Destination (city, province, state or country) | Yes | |
| First and last working day | Yes | Counts toward the annual limit |
| Reason | Yes | |
| Working days used so far this year | Yes | Pre-filled from MyHR |
| Right to work at destination | Cross-border or other | You are responsible for it |
| Bank device travel to a restricted country | If applicable | Notify Corporate Security 10 business days ahead |
| Private workspace and secure connection | Yes | |

## 5. Declarations and signatures

- I will keep the VPN on, avoid public Wi-Fi without the VPN, lock my screen, and keep a private workspace (HR-POL-017 IT Acceptable Use and Information Security Policy).
- I understand time away does not extend my vacation or create any right to different pay or tax treatment.
- I will report a lost device or suspected incident to the Security Operations Centre, 1-800-555-0155, immediately and no later than 1 hour.

## 6. What happens next

You are told the decision in MyHR before your travel dates. Approved days are added to your annual count. Keep working your core hours, 10:00 to 15:00 local time. Where applicable law gives a greater right, the law applies. Questions: HR Connect, 1-800-555-0142.

## 7. Related documents

- HR-POL-002 Remote and Hybrid Work Policy
- HR-POL-017 IT Acceptable Use and Information Security Policy

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-01-05 | Added domestic and cross-border limits and lead times from HR-POL-002 version 3.0. |
