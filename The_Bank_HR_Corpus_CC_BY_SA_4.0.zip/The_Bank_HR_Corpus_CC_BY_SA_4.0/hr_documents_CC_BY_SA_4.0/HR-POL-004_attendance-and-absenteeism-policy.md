# Attendance and Absenteeism Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-004 |
| Title | Attendance and Absenteeism Policy |
| Document type | Policy |
| Version | 3.1 |
| Status | Current |
| Effective date | 2025-04-01 |
| Last reviewed | 2026-05-12 |
| Next review | 2027-05-12 |
| Policy owner | VP Employee Relations |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Applies to | All Canadian and US employees (see Scope) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-007, HR-POL-021, HR-POL-018, HR-POL-002, HR-POL-015, FORM-HR-011, FORM-HR-071 |

## 1. Purpose

This policy sets out what the Bank expects of employees about reliable attendance, how absences are reported and recorded, when attendance is reviewed, and how the Bank supports employees whose attendance is affected by health, family or other protected circumstances. It aims to be fair, consistent and supportive before it is corrective.

## 2. Scope

The policy applies to all regular full-time, regular part-time and fixed-term employees in Canada and the US, and to casual employees on their scheduled shifts. It does not replace the entitlements set out in HR-POL-007 Sick Leave and Personal Leave Policy or any statutory leave. Where applicable law gives a greater right, the law applies.

## 3. Definitions

- **Late arrival:** arriving more than 10 minutes after the scheduled start without prior notice.
- **Absence occurrence:** one continuous absence from scheduled work for the same reason, whether it lasts one day or several consecutive days.
- **Absence day:** a scheduled working day (or part of one) missed.
- **Protected absence:** an absence that never counts towards any attendance trigger: statutory and Bank-approved leaves, accommodated absences, jury duty, bereavement, vacation, approved personal days, and work-related injury.
- **No-call/no-show:** failure to attend a scheduled shift without contacting the manager.

## 4. Reporting an absence

1. The employee contacts their manager **before the scheduled start of the shift**. If that is impossible, contact must be made **within 30 minutes after the scheduled start**.
2. Contact is by phone or message. An email alone is not enough on the day of the absence.
3. Branch employees also notify the branch manager.
4. The employee gives the expected duration and, if possible, a return date, without having to disclose a diagnosis.
5. On return, the employee enters the absence in Time Tracker.

A late call is not by itself misconduct, but it is recorded.

## 5. Medical certificates

A medical certificate (FORM-HR-011) is required from the **4th consecutive working day** of illness, and in the other circumstances set out in HR-POL-007. Certificates state fitness to work and any limitations, not the diagnosis. Quebec follows its own rule in HR-POL-007.

## 6. Attendance review triggers

An attendance pattern review begins when either of the following is reached, excluding protected absences:

| Trigger | Threshold |
| --- | --- |
| Late arrivals | 3 in 30 days |
| Absence occurrences | 4 separate occurrences in a rolling 12 months |
| Absence days | 8 days in a rolling 12 months |

A trigger starts a conversation, not discipline. Paid sick days and unprotected absences count towards the triggers unless the law protects the absence, in which case it is excluded. The manager and HRBP consider the context first, including any health condition, family circumstance, domestic or family violence, or possible accommodation need (see HR-POL-018 Workplace Accommodation and Accessibility Policy).

## 7. Stages

| Stage | Action | Documentation |
| --- | --- | --- |
| Stage 1 | Informal conversation between manager and employee, held within 5 business days of the trigger | Documented in a note; not discipline |
| Stage 2 | Written attendance plan with targets, support and a 90-day review period | FORM-HR-071 |
| Stage 3 | Final written warning if attendance does not improve during the plan | Per HR-POL-021 |
| Termination | Considered only after HR and Employee Relations review | Per HR-POL-021 |

The stages follow HR-POL-021 Employee Relations and Progressive Discipline Policy. The employee may respond in writing within 5 business days of any written step and may bring a support person to meetings. A sustained pattern attributable to a disability is referred to the Accommodation Specialist instead of being treated as a conduct matter.

## 8. No-call/no-show and presumed job abandonment

- One missed shift without contact is followed up the same day by the manager.
- When an employee has not reported for **3 consecutive scheduled days** and has not contacted the Bank, the manager notifies the HRBP.
- Before any conclusion, HR makes **at least 3 documented contact attempts**: by phone, by email and through the employee's emergency contact.
- HR then sends a letter by courier or registered mail, asking the employee to make contact within 5 business days.
- If the employee does not respond, job abandonment is presumed and the matter is processed as a resignation under HR-POL-015 Resignation and Offboarding Policy, after review by Employee Relations.
- Where there is a concern for safety, HR may ask Corporate Security (1-800-555-0119) to arrange a welfare check.

If the employee makes contact and gives a reasonable explanation, such as an emergency or medical event, the absence is reviewed under sections 6 and 7 rather than as abandonment.

## 9. Severe weather and emergency closures

Closure decisions are announced by **6:30 local time** through a MyHR alert, a text message and the intranet banner. Employees whose branch or office is closed are paid for the day. Hybrid and remote employees work from home (see HR-POL-002 Remote and Hybrid Work Policy). An employee who cannot reach an open workplace safely tells the manager before the start of the shift and may use vacation, a personal day or other approved time off, with manager agreement.

## 10. Return-to-work conversation

After **5 or more absence days**, the manager holds a return-to-work conversation within **2 business days** of the employee's return. The conversation confirms fitness to work, any workplace adjustments and the support available, including the Wellspring Support Program (1-800-555-0166). The manager keeps only the notes needed and does not record medical details in the general personnel file.

## 11. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Employee | Reports absences on time, enters them in Time Tracker, supplies certificates when required |
| Manager | Monitors attendance fairly, holds Stage 1 conversations and return-to-work conversations |
| HRBP | Advises on triggers, protected absences and Stage 2 and 3 steps |
| Employee Relations (ER) consultant | Reviews stages, abandonment and any termination recommendation |
| Accommodation Specialist | Assesses accommodation needs |
| VP Employee Relations | Owns this policy |

## 12. Confidentiality and fairness

Attendance records are held in Time Tracker and the HR Case Portal and shared only with those who need them. Managers apply the policy consistently and must not ask for a diagnosis. Retaliation against an employee for taking a protected absence is prohibited. Employees may raise concerns with the HRBP, the Ombuds Office (ombuds@bank.example) or the Speak-Up Line (1-800-555-0177).

## 13. Related documents and contacts

Related: HR-POL-007, HR-POL-018, HR-POL-021, HR-POL-002, HR-POL-015. HR Connect: 1-800-555-0142, hrconnect@bank.example.

## 14. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 3.0 | 2023-04-01 | Introduced late-arrival and absence-occurrence triggers and staged approach |
| 3.1 | 2025-04-01 | Clarified protected absences, added no-call/no-show contact steps and the return-to-work conversation after 5 or more absence days |
