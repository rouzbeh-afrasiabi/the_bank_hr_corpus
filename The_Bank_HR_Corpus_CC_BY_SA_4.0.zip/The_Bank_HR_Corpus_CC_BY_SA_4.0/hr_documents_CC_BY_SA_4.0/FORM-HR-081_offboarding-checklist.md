# Offboarding Checklist

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-081 |
| Title | Offboarding Checklist |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-10-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-015, HR-POL-017, FORM-HR-080, FORM-HR-082, HR-GDE-001 |

## 1. Purpose and when to use this form

This checklist records every step needed to close out an employee's employment in an orderly way. HR Operations opens it on the day a resignation is acknowledged, and all items are required (HR-POL-015 Resignation and Offboarding Policy).

## 2. Who completes it and who approves

HR Operations owns the checklist and closes it. The manager, the leaving employee, Payroll Services, Benefits Administration, IT and Corporate Security each complete their own items. The manager confirms that equipment was returned. Closure is approved by HR Operations.

## 3. Where and when to submit (deadline, channel, processing time)

The checklist lives in the HR Case Portal in MyHR and is not submitted separately. Items are due as shown in section 4. HR Operations closes it 10 business days after the last day of employment.

## 4. Form fields

| Step | Owner | Due | Required |
| --- | --- | --- | --- |
| Acknowledge FORM-HR-080 and confirm last day | HR Operations | 2 business days after notice | Yes |
| Agree handover plan (open work, client files, system ownership, delegated approvals) | Manager and employee | 3 business days after acknowledgement | Yes |
| Notify Payroll Services, Benefits Administration and IT | HR Operations | 5 business days after notice | Yes |
| Approve final time entry and expenses | Manager | Last day | Yes |
| Offer exit interview (FORM-HR-082) | HR Operations | Final week | Yes |
| Remove system and building access | IT and Corporate Security | 17:00 on last day | Yes |
| Cancel corporate card and signing authority | Manager and Payroll Services | Last day | Yes |
| Return equipment, badge and tokens | Employee | 5 business days after last day | Yes |
| Return or delete documents and client data | Employee | Last day | Yes |
| Issue final pay | Payroll Services | Next pay date or legal deadline | Yes |
| Issue Record of Employment (Canada) | Payroll Services | 5 calendar days after end of pay period | Yes |
| Send benefits and retirement plan notices | Benefits Administration | Before month end | Yes |
| Set rehire code (Eligible or Not Eligible) and close | HR Operations | 10 business days after last day | Yes |

## 5. Declarations and signatures

Employee: I have completed my handover items and will return all Bank property. Signature and date: ____________.

Manager: I confirm that handover is complete and equipment was returned. Signature and date: ____________.

HR Operations: I confirm all items are complete. Signature and date: ____________.

## 6. What happens next

Remote employees receive a prepaid shipping kit. Unreturned items are referred to Corporate Security. A "Not Eligible" rehire code needs the approval of the VP Employee Relations. Benefits end at the end of the month in which employment ends (see HR-GDE-001 Employee Benefits Guide).

## 7. Related documents

- HR-POL-015 Resignation and Offboarding Policy
- HR-POL-017 IT Acceptable Use and Information Security Policy
- FORM-HR-080 Resignation Notice

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-10-01 | Aligned steps and due dates with HR-POL-015 version 3.0. |
| 1.0 | 2023-04-01 | Initial form. |
