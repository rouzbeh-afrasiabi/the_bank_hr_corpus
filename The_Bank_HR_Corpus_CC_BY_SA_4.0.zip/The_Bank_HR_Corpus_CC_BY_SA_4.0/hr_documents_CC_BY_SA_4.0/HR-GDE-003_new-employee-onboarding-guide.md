# New Employee Onboarding Guide

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-GDE-003 |
| Title | New Employee Onboarding Guide |
| Document type | Guide |
| Version | 4.0 |
| Status | Current |
| Effective date | 2026-02-02 |
| Last reviewed | 2026-08-04 |
| Next review | 2027-08-04 |
| Policy owner | VP HR Operations |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Applies to | All Canadian and US employees (see Scope) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-020, HR-POL-012, HR-POL-011, HR-POL-014, HR-GDE-001, HR-GDE-002, HR-GDE-004, FORM-HR-022 |

## 1. Purpose

This guide explains what happens from the moment a candidate accepts an offer until the end of the first 90 days. It tells new employees, managers and HR what to do, and by when, so that a new hire is welcomed, paid correctly, enrolled in benefits and productive quickly.

## 2. Scope

The guide applies to all new employees in Canada and the US, including those hired into remote roles. Benefit and pension eligibility depends on the employment category (see HR-POL-014 Employment Status and Classification Policy). The guide does not cover internal moves: promotions and transfers are handled separately. Where applicable law gives a greater right, the law applies.

## 3. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| New employee | Completes forms and training by the deadlines, enrols in benefits, asks questions early. |
| Hiring manager | Plans the first day and first week, meets the new hire, sets goals, holds the 30, 60 and 90-day check-ins, and decides on probation outcome with the HRBP. |
| Onboarding buddy | A peer who answers day-to-day questions during the first 90 days. The buddy is not the manager and does not assess performance. |
| HR Operations | Runs the onboarding process, checks documents and activates systems. |
| Payroll Services | Sets up pay, tax withholding and direct deposit. |
| Benefits Administration | Supports enrolment through MyHR and Maplewood Benefits. |
| Technology and Operations | Orders, configures and delivers equipment. |

## 4. Before day 1

| Item | Responsible | Deadline |
| --- | --- | --- |
| Offer accepted in writing | Recruiter and candidate | Within 5 business days of the offer (see HR-POL-019 Recruitment and Selection Policy) |
| Screening complete | HR Operations | Before the start date (see HR-POL-020 Pre-Employment Screening Policy) |
| Equipment ordered | Hiring manager and Technology and Operations | At least 10 business days before the start date |
| Laptop delivered to remote employees | Technology and Operations | 3 business days before the start date |
| MyHR and Learning Hub accounts activated | HR Operations | The day before the start date |
| Welcome message from the manager with the first-day agenda | Hiring manager | At least 3 business days before the start date |
| Onboarding buddy assigned | Hiring manager | Before the start date |

New hires receive a welcome email with the start time, location or video link, what to bring, and a link to the pre-boarding page. New hires should not start work, access systems or perform duties before the start date and before screening is complete.

## 5. Day 1

Day 1 starts at 9:00 local time. The agenda is the same in both countries and may be delivered virtually or at the office.

| Time (local) | Activity | Lead |
| --- | --- | --- |
| 9:00 | Welcome and orientation (virtual or at the office): who we are, values, how the Bank is organized | HR Operations |
| 10:00 | Badge issue (office) and workstation set-up; equipment check | Technology and Operations |
| 10:30 | Security set-up, including multi-factor authentication, passphrase and the Bank password manager | Technology and Operations |
| 11:30 | Meet the manager and the onboarding buddy; review the first-week plan | Hiring manager |
| 12:30 | Lunch with the team (or the buddy by video) | Buddy |
| 13:30 | Complete MyHR profile, emergency contacts, direct deposit and tax forms | New employee with HR Operations support |
| 15:00 | First learning assignments in the Learning Hub | New employee |
| 16:30 | End-of-day check-in with the manager | Hiring manager |

## 6. Documents to provide

All new hires must bring government photo identification on day 1. Emergency contacts are entered in MyHR on day 1.

### 6.1 Canada

| Document | Deadline |
| --- | --- |
| Social Insurance Number | Within 3 business days of the start date |
| Federal and provincial personal tax credit return forms | By day 1, entered through MyHR (late forms: payroll cut-off, see section 12) |
| Direct deposit (FORM-HR-022) | By day 1 (mandatory) |
| Proof of right to work | By day 1 |
| Government photo ID | Day 1 |

### 6.2 US

| Document | Deadline |
| --- | --- |
| Form I-9 (employment eligibility) | Within 3 business days of the start date |
| Form W-4 and state withholding form | By day 1, entered through MyHR |
| Direct deposit (FORM-HR-022) | By day 1 (mandatory) |
| Government photo ID | Day 1 |

Documents are checked by HR Operations. Payroll Services keeps tax form changes confidential and available only as needed. Employees can update their name, address and tax form details in MyHR with FORM-HR-022. If documents are missing, the new hire may be paid late; see section 12 for the payroll cut-off.

## 7. Week 1

The manager and the new hire work through the checklist below by the end of the first week.

1. Equipment and system access working; the SOC contact (1-800-555-0155) shared for any lost device or suspected incident.
2. Read HR-POL-001 Code of Conduct and Ethics and the IT acceptable use rules; the annual attestation is due within 30 days of the start date. Within 30 days of receiving HR-POL-033 Electronic Monitoring and Right to Disconnect Policy, acknowledge it on FORM-HR-129.
3. Learning Hub: start the mandatory courses (see section 10).
4. Work arrangement confirmed with the manager (see HR-POL-002 Remote and Hybrid Work Policy): hybrid employees attend at least 3 days a week, including the Tuesday and Thursday anchor days.
5. Meet the team and key partners; introduction to the HRBP.
6. Review of working hours, time entry in Time Tracker, and how to report an absence (see HR-POL-004 Attendance and Absenteeism Policy).
7. Draft goals discussed (see section 8).
8. Home office allowance requested where eligible (see section 13).
9. Benefits and pension information reviewed (see section 11).
10. Friday check-in with the manager: what went well, what is unclear.

## 8. The 30/60/90-day plan

### 8.1 First 30 days: learn

The new hire completes mandatory training within 30 days, meets the main stakeholders, learns the core processes and tools, and agrees 3 to 5 goals with the manager within 30 days of the start date (see HR-POL-011 Performance Management Policy). Benefits enrolment is due within 31 days. A 30-day check-in with the manager is held and recorded in MyHR.

### 8.2 Days 31 to 60: contribute

The new hire begins to work independently on assigned tasks, takes part in team meetings and builds relationships. The 60-day check-in covers progress against the goals, feedback in both directions and any support needed.

### 8.3 Days 61 to 90: own

The new hire takes ownership of agreed work, shows the Bank values in daily work and prepares for the probation decision. The 90-day check-in covers the overall assessment and development plan.

| Check-in | Timing | Focus |
| --- | --- | --- |
| 30 days | Day 30 | Settling in, training status, goals confirmed |
| 60 days | Day 60 | Progress, feedback, support |
| 90 days | Day 90 | Probation review, next steps |

Example: for a start date of 2 March 2026, the 30-day check-in is on 1 April 2026, the 60-day check-in on 1 May 2026 and the 90-day check-in on 31 May 2026.

## 9. Probation

New hires are on probation for 3 months. Probation may be extended once, to 6 months, with written notice from the manager before the end of month 3; the HRBP must agree before the notice is given. The manager and HRBP confirm the outcome in writing. During probation, employees receive the same benefits, vacation accrual and holidays as other employees in their category. Sick days are available from the start date and personal days are pro-rated (see HR-POL-006 Vacation and Paid Time Off Policy for vacation rules; vacation accrues monthly from the start date and may be requested from day 1 but taken after the first 3 months of service). Probation outcomes are recorded in MyHR.

## 10. Mandatory training

New hires complete all mandatory courses in the Learning Hub within 30 days of the start date. The owner of the training rules is HR-POL-012 Learning and Development Policy.

| Course | New hire deadline |
| --- | --- |
| Code of Conduct and Ethics | 30 days from start |
| Anti-Money Laundering and Sanctions | 30 days from start |
| Privacy and Information Security Awareness | 30 days from start |
| Workplace Harassment and Violence Prevention | 30 days from start |
| Workplace Health and Safety | 30 days from start |
| Fraud Awareness | 30 days from start |
| Accessibility and Human Rights | 30 days from start |

If a course is overdue by 7 days a reminder is sent; at 14 days the manager is notified; at 30 days the matter affects AIP eligibility and the "how" component of the rating.

## 11. Benefits and pension deadlines

The key deadlines for a new hire are in the table. Details of the plans are in HR-GDE-001 Employee Benefits Guide and HR-GDE-002 Retirement and Savings Plan Guide.

| Item | Deadline | Notes |
| --- | --- | --- |
| Benefits enrolment in MyHR | Within 31 days of hire | If no election is made, the default is Standard (Canada) or Choice PPO employee-only (US). Later changes need a qualifying life event or annual enrolment. |
| Benefits coverage start | Day 1 for regular full-time, regular part-time and fixed-term employees of 6 months or more | Others are covered per HR-POL-014. |
| Pension auto-enrolment, Canada | First pay date after 30 days | Auto-enrolled at 4% of base salary; opt out within 90 days for a refund of contributions. |
| 401(k) auto-enrolment, US | After 30 days | Auto-enrolled at 5%, increasing 1% each year to 8%; opt out at any time. |
| Beneficiaries and dependants | With benefits enrolment | Complete in MyHR. |
| Wellspring Support Program | Available from day 1 | 1-800-555-0166, 24/7, confidential. |

For example, for a start date of 2 March 2026, the benefits election is due by 2 April 2026. The Bank's pension contributions are explained by Evergreen Retirement Services (1-800-555-0188). Maplewood Benefits claims line: 1-800-555-0190.

## 12. First pay

Employees are paid biweekly in arrears: Canada on Thursdays, US on Fridays. Pay statements are available in MyHR 2 business days before the pay date. New hires whose paperwork is complete by the payroll cut-off are paid on the next pay date. The cut-off is 17:00 Eastern Time five business days before the pay date (see HR-POL-009 Compensation and Payroll Policy).

Example: a new hire starts on Monday 2 March 2026. The first pay period runs 1 March to 14 March 2026. For Canada the pay date is Thursday 19 March 2026 and the cut-off is Thursday 12 March 2026 at 17:00 Eastern Time. For the US the pay date is Friday 20 March 2026 and the cut-off is Friday 13 March 2026 at 17:00 Eastern Time. If the paperwork is received after the cut-off, pay moves to the following pay date and is corrected under the payroll correction process (FORM-HR-021) if needed.

Direct deposit is mandatory. First-pay problems are urgent (priority P1); report them to HR Connect (see HR-GDE-004 HR Service and Support Guide).

## 13. Remote and hybrid onboarding

Employees hired into role-designated remote positions, and employees who join a hybrid role from a location away from an office, are onboarded virtually.

- Laptop and equipment are delivered 3 business days before the start date. Do not open the box until the manager's welcome message arrives; follow the set-up card.
- MyHR and Learning Hub accounts are activated the day before the start date.
- Day 1 orientation is held by video at 9:00 local time. The new hire should join from a private workspace with the camera on where possible.
- The VPN must be on whenever the new hire works remotely, and public Wi-Fi is not used without VPN.
- The home office set-up allowance is available once every 3 years:

| Arrangement | Canada | US |
| --- | --- | --- |
| Remote | $600 CAD | $450 USD |
| Hybrid | $300 CAD | $225 USD |

- The manager schedules a 15-minute video call every day in week 1 and arranges virtual coffee with the buddy and 3 team members.
- Remote employees attend in person up to 4 planned team or client events per year (see HR-POL-002).

## 14. Common issues

| Issue | What to do |
| --- | --- |
| Equipment does not arrive | Call HR Connect and tell the manager; a replacement is arranged. |
| Cannot sign in to MyHR | Contact HR Connect; accounts are active from the day before the start date. |
| Missing tax or deposit forms | Complete FORM-HR-022 in MyHR before the payroll cut-off. |
| Lost or stolen device | Report to the SOC immediately and no later than 1 hour. |
| Need accommodation | Tell the manager, HR Connect or accommodations@bank.example (see HR-POL-018 Workplace Accommodation and Accessibility Policy). |

## 15. Who to call

| Need | Contact |
| --- | --- |
| Any HR question | HR Connect, 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time, hrconnect@bank.example, or live chat in MyHR |
| Manager questions | Manager Hotline, 1-800-555-0143 (managers only) |
| Security incident or lost device | Security Operations Centre, 1-800-555-0155 |
| Emergency | 911, then Corporate Security, 1-800-555-0119 |
| Counselling and support | Wellspring Support Program, 1-800-555-0166 |
| Confidential, informal advice | Ombuds Office, ombuds@bank.example |
| Retirement and savings | Evergreen Retirement Services, 1-800-555-0188 |
| Benefit claims | Maplewood Benefits, 1-800-555-0190 |

## 16. Exceptions and consequences

Exceptions to the deadlines in this guide need the approval of HR Operations. Employees who do not provide required documents may not be paid on time or may have access restricted. A manager who allows work to start before screening is complete is in breach of HR-POL-020 Pre-Employment Screening Policy.

## 17. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 4.0 | 2026-02-02 | Added the remote onboarding section, the day 1 agenda table, the worked first-pay example and the pension auto-enrolment timing. |
| 3.1 | 2024-02-05 | Introduced the onboarding buddy and the 30, 60 and 90-day check-ins. |
