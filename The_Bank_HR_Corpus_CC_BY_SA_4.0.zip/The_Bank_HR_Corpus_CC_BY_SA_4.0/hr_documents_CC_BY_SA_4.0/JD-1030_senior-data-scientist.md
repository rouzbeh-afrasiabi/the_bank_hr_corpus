# Senior Data Scientist

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1030 |
| Title | Senior Data Scientist |
| Document type | Job description |
| Version | 1.0 |
| Status | Current |
| Effective date | 2025-10-01 |
| Last reviewed | 2026-09-22 |
| Next review | 2027-09-22 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-POL-002, HR-POL-016, HR-POL-017 |

## 1. Role summary

The Senior Data Scientist is a senior specialist who designs, builds and deploys statistical and machine-learning solutions that improve credit decisions, fraud detection, customer insight and operations. The role owns solutions from problem framing to production monitoring, is accountable for model quality, fairness and explainability and sets technical direction for the Data Analysts and Data Scientists around them.

## 2. Key responsibilities

- Frame business problems as modelling problems, agree success measures with sponsors and plan the work.
- Build, validate and deploy predictive and classification models, and document methods, data and limitations.
- Test models for bias, stability and explainability, and take part in independent model validation and governance reviews.
- Work with engineers to put models into production with versioning, monitoring and retraining plans.
- Monitor model performance and drift, and recommend retirement or redevelopment when needed.
- Make sure any use of personal data meets privacy law and Bank policy, and complete the required assessments before launch (see HR-POL-016 Employee Data Privacy Policy for the PIA and DPIA rules that apply to employee data).
- Evaluate new techniques, including approved generative AI tools, and recommend their use only where risks are understood and controlled.
- Present findings and trade-offs to senior business leaders in plain language.
- Mentor junior data practitioners and review their work.
- Collaborate with Information Security on protecting training data and models.

## 3. Qualifications

### 3.1 Required

- Master's degree or doctorate in statistics, mathematics, computer science, data science or a related quantitative field.
- Typically 7 to 10 years of experience in data science, including deploying models in production.
- Expert-level skill in a data-analysis programming language and in machine-learning methods.
- Experience communicating model results and limits to senior non-technical audiences.

### 3.2 Preferred

- Experience in credit risk, fraud or marketing analytics at a financial institution.
- Experience with large-scale data platforms and model-operations practice.
- Publications or recognized contributions in applied machine learning.

### 3.3 Licences and certifications

None required.

## 4. Competencies

Measured against HR-FWK-001 Competency and Leadership Model at the Leader level:

- Judgement and Decision Quality
- Drive for Results
- Collaboration
- Risk and Conduct Awareness
- Developing Others
- Adaptability

## 5. Compensation and classification

| Item | Value |
| --- | --- |
| Band | 5 (Team Lead / Manager I) |
| Canada range | $90,000 to $134,000 CAD |
| US range | $88,000 to $132,000 USD |
| Incentive target | 10% of base salary (Annual Incentive Plan) |
| Overtime eligibility, Canada | No |
| FLSA classification, US | Exempt |
| Work arrangement | Hybrid (at least 3 days a week in the office) |

Band definitions are in HR-GDE-006 Job Architecture and Pay Bands Guide.

## 6. Working conditions and accessibility

This is an office role with a hybrid arrangement under HR-POL-002 Remote and Hybrid Work Policy: at least 3 days a week in the office, including the Tuesday and Thursday anchor days. Work with sensitive data follows the Bank's data-classification rules and is carried out only on Bank-issued devices. The Bank provides accommodation to the point of undue hardship; see HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to: Senior Manager, Technology Delivery. Direct reports: none (technical lead for data analysts and junior data scientists).

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.0 | 2025-10-01 | First issue |
