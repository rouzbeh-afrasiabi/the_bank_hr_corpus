# Accommodation Case Management Procedure

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-PRC-007 |
| Title | Accommodation Case Management Procedure |
| Document type | Procedure |
| Version | 2.1 |
| Status | Current |
| Effective date | 2025-08-01 |
| Last reviewed | 2026-06-30 |
| Next review | 2027-06-30 |
| Policy owner | Head of Accessibility and Inclusion |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | HR only |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-018, HR-POL-016, HR-POL-007, HR-POL-019, HR-PRC-001, HR-PRC-006, FORM-HR-040, FORM-HR-041 |

## 1. Purpose

This procedure tells the Accommodation Specialist, HR Connect agents and HRBPs how to open, work, decide, fund, review and close an accommodation case. It implements HR-POL-018 Workplace Accommodation and Accessibility Policy and uses the same timelines. It adds system steps, case-file rules and checklists; if it ever appears to differ from the policy, the policy applies.

## 2. Scope

The procedure applies to requests from employees (regular, part-time, casual, fixed-term, student, co-op and intern) and applicants in Canada and the US, on any protected ground: disability, religion or creed, family status, pregnancy, sex, age and others recognized by law. In Canada the Bank accommodates to the point of undue hardship; in the US it provides reasonable accommodation unless undue hardship exists. The standard that gives the greater protection applies. Where applicable law gives a greater right, the law applies.

## 3. Roles

| Role | Responsibility |
| --- | --- |
| Accommodation Specialist | Single point of contact; owns the case; gathers information, proposes options and monitors timelines. |
| HR Connect agent | Logs the request at once and routes it to the Accommodation Specialist; never asks for a diagnosis. |
| Manager | Passes on a possible need the same business day; puts agreed measures in place; keeps information confidential. |
| HRBP | Supports the manager, resolves conflicts with job requirements and team impacts. |
| Head of Accessibility and Inclusion | Owns the policy; chairs the Accommodation Review Panel; with Legal, the only decision-maker on undue hardship. |
| Legal | Advises on undue hardship and legal duties; sits on the panel. |
| Employee Relations (ER) consultant | Sits on the panel; has no part in the original decision. |

## 4. Timeline at a glance

| Step | Timeline |
| --- | --- |
| Manager passes a possible need to the Accommodation Specialist | Same business day |
| Acknowledge the request | Within 2 business days |
| Interim measures | Immediately where possible |
| Decision | Within 10 business days of complete information |
| Urgent decision (safety, imminent return to work, hiring deadline) | Within 3 business days |
| Implementation of equipment and accessible formats | Normally within 10 business days of the decision |
| Review of long-term needs | At least once a year |
| Request for panel review | Within 10 business days of the decision |
| Panel decision with written reasons | Within 10 business days of the request for review |
| Accessible format of a document, form or training | Within 10 business days of request |

## 5. Step-by-step procedure

### 5.1 Receive the request

1. A request may arrive through the manager, HR Connect (1-800-555-0142), accommodations@bank.example or an HRBP. The word "accommodation" is not required: any statement that a person needs a change because of a protected ground starts the process. FORM-HR-040 Accommodation Request is optional; never make a request wait for a form.
2. Open a case in the HR Case Portal using case type Accommodation. Record the date and time the Bank first learned of the need. Every timeline runs from the first knowledge, even if it was by a manager.
3. A request may also come from a manager, HRBP or representative with the person's consent, and from an applicant at any stage of recruitment (HR-POL-019 Recruitment and Selection Policy). Do not share an applicant's request with the hiring panel beyond what is needed to arrange the adjustment.

### 5.2 Acknowledge (within 2 business days)

The Accommodation Specialist sends a written acknowledgement that names the process and timelines, the contact person, the right to a support person, the confidentiality rules and the review route. Offer a conversation in the person's preferred format and language.

### 5.3 Decision point: urgent or standard?

| If the need affects | Treat as |
| --- | --- |
| Safety, an imminent return to work or a hiring deadline | Urgent: decision within 3 business days |
| Anything else | Standard: decision within 10 business days of complete information |

### 5.4 Gather information

1. Start with a conversation about what the person can and cannot do, not about a diagnosis. The employee is not required to share a diagnosis.
2. Where information from a health care provider is needed, send FORM-HR-041 Medical Information Supplement for Accommodation. It asks only for functional limitations, restrictions and expected duration. The employee gives it as soon as reasonably possible; extra time is available on request. The clock for the decision starts when the information is complete.
3. The Bank reimburses up to $150 CAD or $120 USD for the cost of completing medical forms. Process the reimbursement through the HR Case Portal with the receipt.
4. If the information is unclear, ask the employee first and, with consent, the provider. Do not ask for more than needed.

### 5.5 Interim measures

Put temporary adjustments in place at once where possible (a modified schedule, remote work, a seating change, a temporary tool). Record each interim measure and the date it ends. Interim measures are not a decision.

### 5.6 Options and decision (within 10 business days, or 3 if urgent)

1. List at least two options where possible, preferring those that respect dignity and independence. Test each against the job duties and the team.
2. Consult the manager and HRBP on the effect on the team and the job. A manager's or colleagues' preference, a morale concern, a customer preference or an inconvenience is not undue hardship.
3. Record the decision in writing: the accommodation, who does what, the start date, the review date and what happens if the need changes.
4. If a request cannot be met as asked, offer the best alternative and give written reasons.
5. Undue hardship may be decided only by the Head of Accessibility and Inclusion with Legal, after all reasonable options, including partial or alternative solutions, are considered and documented. The factors are cost (after funding from the Accommodation Fund and any external funding), health and safety risk, and unmanageable impact on operations or legal obligations.

### 5.7 Fund and implement

1. Costs are met by the central Accommodation Fund and never by the team budget. A manager's budget is not a reason to refuse or delay a request.
2. The Accommodation Specialist approves routine purchases. A purchase above $5,000 CAD or $4,000 USD is approved by the Head of Accessibility and Inclusion. Record the amount, the item and the approver in the Portal.
3. Coordinate with Technology, Corporate Security, Workplace Safety and the Leaves team (HR-PRC-006 Leaves Administration Procedure) as needed. Equipment remains Bank property unless otherwise agreed.
4. Provide accessible formats (large print, screen-reader compatible documents, captioning, sign language interpretation, plain language) within 10 business days of request, faster if a deadline requires it.
5. Confirm in writing to the employee and to the manager that the measure is in place.

### 5.8 Review

Review long-term accommodations at least once a year and whenever the need changes. A graduated return to work of up to 12 weeks is coordinated with the Leaves team (HR-POL-007 Sick Leave and Personal Leave Policy). Modified duties after a work-related injury may last up to 12 weeks. Close the case when the need ends or the person confirms the accommodation works and the next review is set.

## 6. Case file separation and confidentiality

- Keep the accommodation case in a restricted file separate from the general personnel file. Do not copy medical content into ER, payroll or performance files (HR-POL-016 Employee Data Privacy Policy).
- Managers receive only the functional limitations and the expected duration, never the diagnosis, treatment, test results or medical history.
- Access to the file is limited to the Accommodation Specialist and those with a need to know. All access is logged. The Privacy Office reviews the logs quarterly.
- Accommodation records are kept for 7 years after employment ends (HR-REF-002 Employee Records Retention Schedule).
- Send a privacy incident report at once if any information is sent to the wrong person (HR-PRC-008 Privacy Request and Incident Handling Procedure).

## 7. Review by the Accommodation Review Panel

An employee who disagrees with a decision, a delay or a refusal may ask for panel review within 10 business days of the decision.

1. The Accommodation Specialist logs the request and sends the file to the panel within 2 business days.
2. The panel is chaired by the Head of Accessibility and Inclusion with an ER consultant and a representative of Legal. None may have taken part in the original decision; if the Head was involved, the CHRO office appoints an alternate chair.
3. The panel reviews the file, meets the employee, who may bring a support person, and gives written reasons within 10 business days of the request.
4. The decision is final under the policy. The employee may use the Ombuds Office (ombuds@bank.example), the Speak-Up Line and any external right of complaint at any time.

## 8. Coordination with other cases

If an accommodation request arrives during a performance improvement plan, a disciplinary process or a termination review, the HRBP involves the Accommodation Specialist first and applies HR-POL-018 before taking another step. The request does not stop the employee's right to be assessed fairly, and no one may be penalized for asking (HR-PRC-001 Employee Relations Case Handling Playbook).

## 9. Checklist

- [ ] Case opened; date of first knowledge recorded.
- [ ] Acknowledged within 2 business days.
- [ ] Interim measures recorded.
- [ ] FORM-HR-041 used only if needed; no diagnosis collected.
- [ ] Decision in writing within 10 business days of complete information (3 if urgent).
- [ ] Funding recorded against the Accommodation Fund.
- [ ] Manager told functional limits only.
- [ ] Review date set; panel rights explained.

## 10. Escalation and contacts

Missed timeline: escalate to the Head of Accessibility and Inclusion. Accessibility feedback goes to accessibility@bank.example, acknowledged in 2 business days. Accommodation requests: accommodations@bank.example.

## 11. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.1 | 2025-08-01 | Added the 3-business-day urgent decision, the 10-business-day accessible format rule and Accommodation Fund approval steps to match HR-POL-018 version 3.2. |
| 2.0 | 2023-06-01 | Introduced the Accommodation Review Panel steps. |
