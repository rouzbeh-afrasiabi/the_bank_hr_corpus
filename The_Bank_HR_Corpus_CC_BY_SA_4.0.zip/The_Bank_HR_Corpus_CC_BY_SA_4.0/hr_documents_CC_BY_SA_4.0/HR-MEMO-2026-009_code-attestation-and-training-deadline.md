# Reminder: Code Attestation and Mandatory Training Due 31 October 2026

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-MEMO-2026-009 |
| Title | Reminder: Code Attestation and Mandatory Training Due 31 October 2026 |
| Document type | Memo |
| Version | 1.0 |
| Status | Current |
| Effective date | 2026-10-19 |
| Last reviewed | Not applicable |
| Next review | Not applicable |
| Policy owner | Head of Ethics Office |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-001, HR-POL-012, HR-POL-030 |

**Twelve days left: finish your attestation and mandatory training by 31 October.**

**From:** Head of Ethics Office

**To:** All employees in Canada and the US

**Date:** 19 October 2026

**Subject:** Annual Code of Conduct attestation and mandatory training deadline

## 1. What is changing

Nothing is changing. Both items are due by 31 October 2026: your annual attestation to HR-POL-001 Code of Conduct and Ethics (which includes the fit-and-proper attestation under HR-POL-030), and your mandatory training in the Learning Hub (HR-POL-012).

## 2. Who is affected

All employees. New hires attest within 30 days of starting.

## 3. Effective date

The deadline is 31 October 2026.

## 4. What to do

1. Complete the attestation in MyHR.
2. Complete every assigned course in the Learning Hub, including Code of Conduct and Ethics.
3. Make sure your conflict of interest disclosures are current (FORM-HR-100; disclose within 10 business days of becoming aware).
4. Late training triggers a reminder at 7 days, your manager is notified at 14 days, and at 30 days late AIP eligibility and the "how" rating component are affected.

## 5. Who to call

Ethics Office: ethics@bank.example. Speak-Up Line (24/7, anonymous option, run by Clearline): 1-800-555-0177. HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example.

## 6. Related documents

- HR-POL-001 Code of Conduct and Ethics
- HR-POL-012 Learning and Development Policy
- HR-POL-030 Fit and Proper and Conduct Standards Policy
