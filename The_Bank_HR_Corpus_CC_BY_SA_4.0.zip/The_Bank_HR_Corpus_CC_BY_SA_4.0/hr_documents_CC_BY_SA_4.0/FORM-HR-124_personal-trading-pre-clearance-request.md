# Personal Trading Pre-Clearance Request

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-124 |
| Title | Personal Trading Pre-Clearance Request |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | Chief Compliance Officer |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-032, HR-POL-001, HR-SUP-003, FORM-HR-125 |

## 1. Purpose and when to use this form

Covered persons use this form to obtain pre-clearance before every personal trade in an individual security (HR-POL-032 Personal Trading and Restricted Lists Policy). Covered persons are employees in Capital Markets, Wealth Management and Treasury, and others designated by Compliance (see HR-POL-001 Code of Conduct and Ethics). All employees must follow the restricted list and insider-information rules.

## 2. Who completes it and who approves

You complete it. Compliance approves or declines.

## 3. Where and when to submit (deadline, channel, processing time)

Submit before placing the trade, in MyHR (Ethics > Personal Trading). Compliance answers within 1 business day. Approval is valid for the day given and the next business day; request again if you have not traded in that time. Do not trade before you have the approval.

## 4. Form fields

| Field | Required | Notes |
| --- | --- | --- |
| Name, employee ID, business unit | Yes | Pre-filled |
| Brokerage and account number | Yes | Must be a disclosed, Bank-approved brokerage account |
| Security name and ticker | Yes | |
| Buy or sell, and quantity | Yes | |
| Date you last bought or sold this security | Yes | Checks the 30-day minimum holding period |
| Does it appear on the restricted or watch list? | Yes | If Yes, you cannot trade |
| Do you hold material non-public information about the issuer? | Yes | If Yes, you cannot trade |
| Is this a short-term trade? | Yes | Short-term trading is not allowed |

No pre-clearance is needed for mutual funds, exchange-traded funds, government bonds or automatic investment plans, but they must be disclosed on FORM-HR-125 Annual Personal Holdings Disclosure.

## 5. Declarations and signatures

I confirm that I hold no material non-public information about this issuer, that the security is not on the restricted or watch list, that I will hold it for at least 30 days, and that I will trade only through a disclosed account. Signature and date: ____________.

## 6. What happens next

You receive the decision in MyHR. If approved, trade within the validity period. If declined, do not trade. Disclose all brokerage accounts within 30 days of hire or designation, and arrange for duplicate statements to Compliance. Breaches are conduct matters under HR-POL-021 Employee Relations and Progressive Discipline Policy. Capital Markets employees should also see HR-SUP-003 Capital Markets Addendum.

## 7. Related documents

- HR-POL-032 Personal Trading and Restricted Lists Policy
- FORM-HR-125 Annual Personal Holdings Disclosure
- HR-SUP-003 Capital Markets Addendum

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-09-01 | Added validity period, holding period check and exempt instruments. |
| 1.0 | 2021-08-01 | Initial form. |
