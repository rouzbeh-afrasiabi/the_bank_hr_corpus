# Licensing, Registration and Qualification Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-029 |
| Title | Licensing, Registration and Qualification Policy |
| Document type | Policy |
| Version | 3.0 |
| Status | Current |
| Effective date | 2025-06-01 |
| Last reviewed | 2026-07-06 |
| Next review | 2027-07-06 |
| Policy owner | Chief Compliance Officer |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-012, HR-POL-020, HR-POL-021, HR-POL-030, HR-SUP-003, FORM-HR-123 |

## 1. Purpose

Some roles at the Bank may be performed only by people who hold a regulatory licence, registration or qualification. This policy sets out which roles are licensed, who pays for what, how the Bank supports employees through exams, what happens if a licence lapses, and what employees must report to Compliance and by when.

## 2. Scope

The policy applies to every employee in Canada or the US who holds, is applying for, or is required to hold a licence or registration for their role, and to their managers and HRBPs. Capital Markets employees should also read HR-SUP-003 Capital Markets Addendum. Professional designations that are not a legal condition of the role (for example CFA or CPA) are covered by HR-POL-012 Learning and Development Policy. Where applicable law or a regulator's rule is stricter or gives a greater right, the law or rule applies.

## 3. Definitions

| Term | Meaning |
| --- | --- |
| Licence or registration | Permission from a regulator or self-regulatory body to carry out a regulated activity, including a registration of the individual in a regulator's system. |
| Licensed duties | Activities for which the licence is required, such as advising on or selling investment products, or arranging mortgages. |
| Active | A licence that is current, in good standing and recorded as active with the regulator. |
| Lapse | Loss or suspension of an active licence, for example through missed renewal or missed continuing education. |
| Continuing education | Training required by the regulator to keep a licence active. |
| Compliance | The Bank's compliance function, led by the Chief Compliance Officer. |

## 4. Licensed roles

### 4.1 Canada

| Role | Licence or registration |
| --- | --- |
| Personal Banking Advisors, Senior Personal Banking Advisors, Wealth Advisors | Mutual fund dealing representative |
| Mortgage Specialists | Provincial mortgage brokerage licence |
| Capital Markets employees, Portfolio Managers | Securities registrations, as the role needs |

### 4.2 US

| Role | Licence or registration |
| --- | --- |
| Wealth Advisors, Portfolio Managers, Capital Markets employees | Series 6, 7, 63, 65 or 66 as the role needs |
| Mortgage Specialists | NMLS registration |

Compliance publishes the exact licence list for each job in MyHR. A role's licence requirement is also stated in its job description.

**No licensed duties may be performed until the licence is active.** A manager may not assign licensed work, and an employee may not accept it, before Compliance confirms in writing that the licence is active.

## 5. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Employee | Applies on time, studies, sits exams, completes continuing education before the deadline, and reports changes to Compliance. |
| Manager | Allows study time, assigns licensed work only to active licence holders, and tells Compliance and the HRBP of any lapse. |
| Compliance | Sponsors applications, tracks every licence, files with regulators, pays fees, confirms active status and reviews disclosures. |
| HRBP | Takes part in lapse and redeployment reviews and supports the employee. |
| Chief Compliance Officer | Owns the policy and approves exceptions. |
| Learning team | Provides exam preparation courses in the Learning Hub (see HR-POL-012 Learning and Development Policy). |

## 6. What the Bank pays for

| Item | Rule |
| --- | --- |
| Exam fees | 100% paid by the Bank for two attempts per exam |
| Licence and registration fees | 100% paid by the Bank |
| Required continuing education | 100% paid by the Bank |
| Study time | 5 paid study days per exam, on the same basis as designation exams under HR-POL-012 Learning and Development Policy |
| Third attempt | At the employee's cost, unless Compliance approves the Bank paying |

Study days are requested in MyHR as study leave and are not taken from vacation, sick or personal days. The employee keeps receipts for any expense that is not paid directly by the Bank.

## 7. Procedures and deadlines

### 7.1 Getting licensed

1. Before or at hire, HR Operations confirms any licences the candidate already holds as part of screening (HR-POL-020 Pre-Employment Screening Policy).
2. Within 5 business days of start (or of moving to a licensed role), the employee and manager submit FORM-HR-123 Licence and Registration Application in MyHR.
3. Compliance sponsors the application and books exams with the employee.
4. The employee sits each exam. A failed exam may be retaken; the Bank pays for two attempts, as set out in section 6.
5. If the employee has not passed after 3 attempts, or 9 months after hire have passed without an active licence, whichever comes first, the HRBP and Compliance hold a redeployment review. The review considers vacant roles that need no licence and the employee's skills. It is not a disciplinary step.
6. When the licence is active, Compliance confirms it in writing and licensed duties may begin.

### 7.2 Keeping the licence active

- Compliance reviews every licence once a year on **1 September**. It checks status, continuing education, fees and outstanding regulatory items.
- The employee completes continuing education before the regulator's deadline. Compliance sends reminders, but the responsibility stays with the employee.

### 7.3 Changes you must report

Tell Compliance **within 2 business days** of any of the following:

- any change in your registration status;
- a regulatory inquiry about you or your work;
- a complaint about you, from a customer or anyone else;
- a regulatory or professional sanction;
- a bankruptcy;
- a criminal charge or conviction.

You must also tell your manager. Disclosures of charges, convictions, bankruptcy and sanctions are assessed under HR-POL-030 Fit and Proper and Conduct Standards Policy. Reporting something promptly will never itself be a reason for discipline.

## 8. Licence lapse

1. **Immediate removal.** If a licence lapses, the employee is removed from licensed duties immediately. The manager reassigns the work the same business day.
2. **Pay and status.** Pay, benefits and employment continue. The employee is given non-licensed work or restoration activities.
3. **60 days to restore.** The employee has up to 60 days to restore the licence. Compliance supports the filing.
4. **Review.** If the licence is not restored within 60 days, the HRBP and Compliance review the case. Outcomes include an extension, redeployment to a role that needs no licence, or other action under HR-POL-021 Employee Relations and Progressive Discipline Policy where the lapse was avoidable.
5. **Conduct.** A lapse caused by missed continuing education is a conduct matter, because the requirement and the deadline were known. A lapse the employee could not control (for example a regulator's administrative error) is not.
6. **Leaves.** An employee on an approved leave is not penalised for a lapse that results from the leave, and the periods in this section are extended by the length of the leave.

## 9. Worked examples

1. **New advisor.** A Personal Banking Advisor in Ontario starts on 4 January. FORM-HR-123 is due within 5 business days. The advisor fails the first exam, passes the second and the Bank pays both. The advisor serves customers on investment products only after Compliance confirms the licence is active.
2. **Third attempt.** A Wealth Advisor in the US fails the same exam twice. The Bank paid for both attempts. The third attempt is at the advisor's cost unless Compliance approves. If the advisor fails a third time, a redeployment review follows.
3. **Missed continuing education.** A Mortgage Specialist misses the continuing education deadline and the licence lapses on a Monday. The specialist is removed from licensed duties that day. Day 60 passes without restoration, so the HRBP and Compliance review. Because the deadline was known and reminders were sent, the lapse is also treated as a conduct matter.
4. **Charge.** A Portfolio Manager is charged with an offence on a Tuesday and tells Compliance on the Wednesday. That meets the 2-business-day deadline. Compliance and the employee's HRBP then follow HR-POL-030.

## 10. Exceptions

Exceptions to timelines or payment rules need the written approval of the Chief Compliance Officer. An exception can never allow licensed duties to be performed before the licence is active.

## 11. Consequences

Performing licensed duties without an active licence, failing to disclose a change within 2 business days, or giving false information to a regulator or to Compliance is serious misconduct under HR-POL-001 Code of Conduct and Ethics and HR-POL-021 Employee Relations and Progressive Discipline Policy. The Bank may report it to the regulator.

## 12. Related documents and contacts

- HR-POL-012 Learning and Development Policy
- HR-POL-020 Pre-Employment Screening Policy
- HR-POL-021 Employee Relations and Progressive Discipline Policy
- HR-POL-030 Fit and Proper and Conduct Standards Policy
- HR-SUP-003 Capital Markets Addendum
- FORM-HR-123 Licence and Registration Application
- Compliance: contact through the Compliance page in MyHR. HR Connect: 1-800-555-0142, hrconnect@bank.example.

## 13. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 3.0 | 2025-06-01 | Set the Bank-paid limit at two exam attempts, the 60-day period to restore a lapsed licence, the 2-business-day reporting rule and the annual review on 1 September. Added the redeployment review after 3 failed attempts or 9 months. |
| 2.0 | 2023-06-01 | Previous version. Added the US registrations and the licence list by role. |
