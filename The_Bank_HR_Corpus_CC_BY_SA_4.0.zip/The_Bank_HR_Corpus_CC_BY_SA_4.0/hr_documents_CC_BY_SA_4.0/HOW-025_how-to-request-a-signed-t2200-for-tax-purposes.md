# How to request a signed T2200 for tax purposes

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-025 |
| Title | How to request a signed T2200 for tax purposes |
| Document type | How-to article |
| Version | 1.1 |
| Status | Current |
| Effective date | 2026-01-05 |
| Last reviewed | 2026-08-20 |
| Next review | 2027-08-20 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada |
| Language | English |
| Related documents | HR-POL-002, FORM-HR-030, HR-FAQ-001 |

## 1. The short answer

Open a case in MyHR > HR Case Portal asking HR Operations for a signed form T2200 (declaration of conditions of employment); it is usually signed within 10 business days where your conditions of employment support it.

## 2. Who this applies to

Employees in Canada, including Quebec, who work from home under a hybrid or remote arrangement and want the form for their income tax filing. It does not apply to US employees, who should ask HR Connect what applies to them. The Bank gives no tax advice. Whether any deduction is available is for you and a tax adviser to decide. Quebec employees can ask HR Connect for the request in French, and should ask a tax adviser what provincial paperwork also applies.

## 3. Steps

1. Check that your arrangement is recorded in MyHR > Personal Information > Work Arrangement (FORM-HR-030; see HOW-016). The form relies on your conditions of employment as recorded.
2. Open MyHR > HR Case Portal and select **New case**.
3. Choose the category **Pay** (or the closest match) and ask for a signed form T2200 for the tax year. State the year and any date by which you need it.
4. Include only what is asked. Do not add banking or medical details.
5. Submit. You receive a case number by email and a confirmation in MyHR.
6. Collect the signed form from the case when HR Operations marks it **Resolved**.

## 4. Deadlines and what happens next

HR Operations signs the form where your conditions of employment support it, usually within 10 business days of the request. Request it early in the year so that you have it well before you file: T4 slips are issued by 28 February (Relevé 1 for Quebec). If you need more than the standard timeline allows, say so in the case and choose a higher priority if your deadline is close (see HR-GDE-004 HR Service and Support Guide). If HR Operations cannot sign, the case explains why and you can reply in the case.

## 5. Common mistakes

- Assuming that a signed form guarantees a deduction. It does not.
- Asking your manager to sign. Only HR Operations signs.
- Not keeping your arrangement up to date in MyHR. HR Operations signs only where your conditions of employment support it.
- Mixing it up with the setup allowance (see HOW-018). The allowance is claimed in MyHR > Pay; the T2200 is a separate request.
- Asking HR for tax advice. Speak to a qualified tax adviser.
- Waiting until the filing deadline.

## 6. Who to call

- HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, or live chat in MyHR, in English or French.

## 7. Related documents

- HR-POL-002 Remote and Hybrid Work Policy (section 9.1, the owning document)
- FORM-HR-030 Work Arrangement Request (Hybrid or Remote)
- HR-FAQ-001 Employee HR FAQ

Where applicable law gives a greater right, the law applies.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.1 | 2026-01-05 | Aligned with HR-POL-002 version 3.0. |
| 1.0 | 2025-01-01 | First version. |
