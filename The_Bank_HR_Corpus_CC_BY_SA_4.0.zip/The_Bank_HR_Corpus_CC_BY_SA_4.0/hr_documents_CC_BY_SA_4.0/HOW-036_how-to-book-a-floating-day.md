# How to book a floating day

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-036 |
| Title | How to book a floating day |
| Document type | How-to article |
| Version | 1.1 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-10-05 |
| Next review | 2027-10-05 |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-010, HR-POL-026, HR-POL-006, HR-POL-014 |

## 1. Short answer

Book a floating Cultural and Religious Observance Day in Time Tracker with at least 24 hours' notice; no reason is required, and you have 2 per calendar year.

## 2. Who this applies to

Every eligible employee in Canada and the US receives 2 floating days a year, for a cultural or religious observance of their choice. Regular full-time and regular part-time employees are eligible from day one, and part-time employees receive the same 2 days. Fixed-term employees are eligible as set out in HR-POL-014 Employment Status and Classification Policy. Casual employees receive holiday entitlements as the law requires. Where applicable law gives a greater right, the law applies.

## 3. Steps

1. **Pick the date** of your observance and check your balance in MyHR > Time and Absence.
2. **Submit the request** in Time Tracker, choosing the floating day leave type, at least 24 hours before the day. You do not have to explain or name the observance.
3. **Tell your team** so work can be covered. Your manager plans coverage fairly.
4. **Take the day.** Repeat for the second day if you need it.

## 4. Deadlines

| Item | Rule |
| --- | --- |
| Notice | At least 24 hours |
| Entitlement | 2 per calendar year |
| Use by | 31 December; no carryover and no cash value |
| New hires | Credited pro rata, rounded up to the nearest half day |

## 5. What happens next

Your manager records the day, and it is paid as a normal day. It does not reduce your vacation, personal day or sick day balance. If you are a new hire, your balance in MyHR is already pro-rated. Because floating days expire on 31 December, check your balance now and book remaining days before year-end.

## 6. Common mistakes

- Waiting until the last week of December; unused days are lost.
- Thinking you must give a reason or prove your observance.
- Assuming part-time employees get fewer days; they receive the same 2.
- Using a floating day when a Bank holiday already covers the date; Bank holidays are listed in HR-POL-010 Statutory Holidays Policy, and a floating day is for a different date.
- Mixing it up with the 1 paid volunteer day, which is a separate leave (see HOW-035 How to book your volunteer day).

## 7. Who to call

Your manager first. HR Connect, 1-800-555-0142 (Monday to Friday 8:00 to 20:00 Eastern Time, closed on Bank holidays), hrconnect@bank.example, or live chat in MyHR. Managers: Manager Hotline, 1-800-555-0143.

## 8. Related documents

- HR-POL-010 Statutory Holidays Policy
- HR-POL-026 Bereavement, Jury Duty and Other Leaves Policy
- HR-POL-006 Vacation and Paid Time Off Policy

## 9. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.1 | 2026-01-01 | Set 2 floating days a year per HR-POL-010 version 3.0. |
| 1.0 | 2025-01-01 | First issue. |
