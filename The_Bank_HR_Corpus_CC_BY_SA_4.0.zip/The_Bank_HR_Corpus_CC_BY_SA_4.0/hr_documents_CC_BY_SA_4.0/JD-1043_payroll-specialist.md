# Payroll Specialist

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1043 |
| Title | Payroll Specialist |
| Document type | Job description |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-09-28 |
| Next review | 2027-09-28 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-009, HR-PRC-003, HR-GDE-006, HR-FWK-001, HR-POL-003, HR-POL-016 |

## 1. Role summary

The Payroll Specialist is a Tier 2 specialist in Payroll Services. The role processes the biweekly payroll for Canadian and US employees, resolves pay questions escalated through the HR Case Portal and keeps statutory deductions and year-end slips accurate. The role is Band 3 (Professional): it applies professional knowledge and works independently on an assigned pay group. See HR-GDE-006 Job Architecture and Pay Bands Guide.

## 2. Key responsibilities

- Run the biweekly payroll in arrears for an assigned population (Canada paid on Thursdays, US on Fridays) following HR-PRC-003 Payroll Processing Calendar and Runbook.
- Apply the payroll cut-off: changes received by 17:00 Eastern five business days before the pay date are processed in that cycle.
- Audit the preliminary payroll register, investigate variances and confirm pay statements are in MyHR 2 business days before the pay date.
- Calculate overtime, shift premiums and on-call allowances using the regional rules in HR-POL-003 Working Hours and Overtime Policy, including the California daily overtime rules.
- Process underpayments of $250 or more (net) off-cycle within 3 business days of confirmation; schedule smaller corrections for the next regular pay date (FORM-HR-021).
- Manage overpayment recoveries within the limits in HR-POL-009 Compensation and Payroll Policy, including the plan options agreed with the employee.
- Process direct deposit and tax withholding updates (FORM-HR-022), garnishments and benefit deductions.
- Support Annual Incentive Plan payments on the first pay date in February.
- Prepare year-end tax slips: T4 and Relevé 1 by 28 February; W-2 by 31 January.
- Respond to P1 missed-pay cases within 4 business hours and keep the employee informed in the HR Case Portal.
- Reconcile payroll to the general ledger with the Finance team.

## 3. Qualifications

### 3.1 Required

- Post-secondary diploma or degree in accounting, business or a related field, or equivalent experience.
- Two to five years of payroll processing experience in a multi-jurisdiction environment.
- Strong knowledge of statutory deductions and payroll compliance in Canada and the US.
- High attention to detail and the discipline to meet fixed deadlines.

### 3.2 Preferred

- A recognized payroll compliance certificate.
- Experience with an enterprise payroll platform and Quebec-specific payroll requirements.
- Experience reconciling payroll to the general ledger.

## 4. Competencies

Competency names follow HR-FWK-001 Competency and Leadership Model (Practitioner level, Bands 3 to 4).

- Drive for Results
- Judgement and Decision Quality
- Customer Obsession
- Risk and Conduct Awareness
- Collaboration

## 5. Compensation and classification

| Item | Detail |
| --- | --- |
| Band | 3 (Professional) |
| Canada range | $56,000 to $84,000 CAD per year |
| US range | $55,000 to $82,000 USD per year |
| Incentive target | 5% of base salary (Annual Incentive Plan) |
| Overtime eligibility, Canada | Yes (non-managerial) |
| FLSA classification, US | Non-exempt |
| Work arrangement | Hybrid |

## 6. Working conditions and accessibility

Office-based and hybrid by default, with at least 3 days a week in the office; Tuesday and Thursday are anchor days (HR-POL-002 Remote and Hybrid Work Policy; FORM-HR-030). Pay-week deadlines can require extended hours, which must be pre-approved in Time Tracker. Work with payroll data follows the data classification rules in HR-POL-016 Employee Data Privacy Policy. The Bank provides accommodation to the point of undue hardship (HR-POL-018 Workplace Accommodation and Accessibility Policy).

## 7. Reporting line

Reports to the Manager, Payroll Services. The role has no direct reports.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-03-01 | Correction threshold updated to $250; pay band ranges aligned with the 2026 pay bands |
| 1.0 | 2025-01-01 | First issue |
