# Privacy Assessments Required Before Using AI in HR Processes

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-MEMO-2026-004 |
| Title | Privacy Assessments Required Before Using AI in HR Processes |
| Document type | Memo |
| Version | 1.0 |
| Status | Current |
| Effective date | 2026-04-13 |
| Last reviewed | Not applicable |
| Next review | Not applicable |
| Policy owner | Chief Privacy Officer |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-016, FORM-HR-091, FORM-HR-092, HR-POL-017, HR-POL-019 |

**No AI tool in an HR process without a completed privacy assessment.**

**From:** Chief Privacy Officer

**To:** All HR staff, HR system owners and people managers

**Date:** 13 April 2026

**Subject:** PIA and DPIA before any AI tool is used in an HR process

## 1. What is changing

Before any AI tool is used in an HR process, the system owner must complete a Privacy Impact Assessment (FORM-HR-091). If the use is high-risk, including AI-assisted decisions about employees, a Data Protection Impact Assessment (FORM-HR-092) is also required. This applies the rules in HR-POL-016 Employee Data Privacy Policy.

## 2. Who is affected

System owners, HR teams and managers who propose, buy or switch on AI features for hiring, performance, pay, monitoring or other employee decisions.

## 3. Effective date

13 April 2026.

## 4. What to do

1. Complete FORM-HR-091 first. The Privacy Office reviews it within 15 business days; reassess every 3 years or on material change.
2. For high-risk use, also complete FORM-HR-092. The CISO and Legal review it, and the Privacy Governance Committee decides within 30 days; reassess annually.
3. Do not start use until the assessment is approved.
4. A human must make the final decision on any employment outcome. AI screening is never the sole basis for rejecting a candidate (HR-POL-019).
5. Confirm the tool is also Bank-approved under HR-POL-017.

## 5. Who to call

Privacy Office: privacy@bank.example. General questions: HR Connect, 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example.

## 6. Related documents

- HR-POL-016 Employee Data Privacy Policy
- HR-POL-017 IT Acceptable Use and Information Security Policy
- HR-POL-019 Recruitment and Selection Policy
