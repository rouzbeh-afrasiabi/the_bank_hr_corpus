# US 401(k) Savings Plan Summary Plan Description

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-PLN-006 |
| Title | US 401(k) Savings Plan Summary Plan Description |
| Document type | Plan document |
| Version | 2026.1 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-09-17 |
| Next review | 2027-09-17 |
| Policy owner | SVP Total Rewards |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | Employees |
| Jurisdiction | US |
| Language | English |
| Related documents | HR-GDE-002, HR-PLN-005, HR-PLN-007, HR-POL-014, HR-POL-009, HR-POL-015 |

## 1. Introduction and status

This Summary Plan Description (SPD) describes the main features of the Bank US 401(k) Savings Plan (the "Plan"), the retirement savings plan sponsored by the Bank for its employees in the US. It explains who may participate, how contributions are made, how the Bank's contributions vest, when loans and withdrawals are available, how benefits are paid, and how to make a claim.

HR-GDE-002 Retirement and Savings Plan Guide describes the Plan in plain language with worked examples. The formal plan document and the trust agreement govern if they differ from this SPD. Annual federal contribution limits are set by the tax authorities each year and are not stated here; Evergreen Retirement Services publishes the current limits. Where applicable law gives a greater right, the law applies. The Canadian plan is described in HR-PLN-005 Bank Savings and Pension Plan Text Summary (Canada).

## 2. Definitions

- **Account** means the record of a participant's contributions, the Bank's contributions and the earnings on them.
- **Base salary** means the participant's annual rate of pay before deductions, excluding incentive pay under the Annual Incentive Plan, overtime, premiums and allowances.
- **Base contribution** means the Bank contribution made on behalf of a participant whether or not the participant contributes, as a percentage of base salary.
- **Match** means the Bank contribution that matches a participant's own deferrals.
- **Participant** means an eligible employee who has an Account.
- **Plan administrator** means the Bank, acting through the SVP Total Rewards.
- **Recordkeeper** means Evergreen Retirement Services.
- **Roth** means after-tax contributions that may be withdrawn tax-free under the conditions set by tax law.
- **Service date** means the first day of continuous employment in a regular role, as determined under HR-POL-014 Employment Status and Classification Policy.
- **Vesting** means the participant's ownership of the Bank's contributions.

## 3. Eligibility and participation

### 3.1 Who may participate

| Employment category | Eligibility |
| --- | --- |
| Regular full-time and regular part-time employees | From day 1 |
| Fixed-term employees, 6 months or more | From day 1 |
| Fixed-term employees under 6 months | Not eligible |
| Casual employees | After 1,000 hours worked |
| Students, co-op students and interns | Not eligible |

Contractors and agency workers are not employees and do not participate.

### 3.2 Automatic enrolment

An eligible employee is automatically enrolled at 5% of base salary after 30 days of employment. The rate then increases by 1% each year until it reaches 8%, so that the path is 5%, 6%, 7% and 8%. A participant may opt out at any time, and may change the rate or the yearly increase at any time.

### 3.3 Cross-border moves

An employee who moves between the US and Canada should contact HR Connect before the move, because participation in the Plan or in the plan described in HR-PLN-005 changes with the work location.

## 4. Participant contributions

### 4.1 Types of contributions

A participant may contribute on a pre-tax basis, on a Roth basis, or on a combination of the two. Pre-tax contributions reduce current taxable pay and are taxed when withdrawn. Roth contributions are made from after-tax pay and qualified withdrawals are not taxed.

### 4.2 Changing contributions

A participant changes the rate, the pre-tax and Roth split, or the yearly increase in MyHR. A change takes effect at the next payroll cut-off, which is 17:00 Eastern Time five business days before the pay date (see HR-POL-009 Compensation and Payroll Policy). A change made after the cut-off applies from the following pay date.

### 4.3 Limits

Federal tax law limits the amount a participant may contribute in a year and the total that may be allocated to an Account. If a limit would be exceeded, Evergreen Retirement Services and Payroll Services may reduce or stop contributions, or return excess amounts, as the plan document and tax law require.

## 5. Bank contributions

### 5.1 Amounts

| Bank contribution | Amount |
| --- | --- |
| Base contribution | 2% of base salary |
| Match | 100% on the first 4% of base salary the participant contributes |
| Maximum Bank total | 6% of base salary |

Incentive pay is not matched. A participant who contributes at least 4% of base salary receives the full 6% Bank contribution. For example, on a base salary of $90,000, a participant who contributes 5% in the first year contributes $4,500; the Bank contributes a base of $1,800 and a match of $3,600, a Bank total of $5,400; and $9,900 enters the Account.

### 5.2 Leaves of absence

During an unpaid leave no contributions are made, because there is no base salary on which to base them. During a Bank-paid leave, contributions continue on the pay received, including paid parental leave pay (see HR-POL-008 Parental and Family Leave Policy).

## 6. Vesting

A participant's own contributions, and the earnings on them, are always 100% vested. The Bank base contribution and the match vest after 2 years of service under a cliff schedule:

| Service | Vested share of Bank contributions |
| --- | --- |
| Before the second anniversary of the service date | 0% |
| From the second anniversary of the service date | 100% |

A participant who leaves before the second anniversary forfeits the unvested Bank contributions and their earnings. If the participant is rehired within the period allowed under the plan document, forfeited amounts may be restored. Forfeitures are used to pay plan expenses or to reduce future Bank contributions, as the plan document states.

### 6.1 Example

A participant contributes 5% in the first year and 6% in the second year, and leaves 6 months into the second year, with 18 months of service. The participant keeps $4,500 + $2,700 = $7,200 of the participant's own contributions plus earnings. Bank contributions of $5,400 + $2,700 = $8,100 are forfeited because the 2-year cliff was not reached.

## 7. Investments

Contributions are invested in the default target-date fund chosen by the participant's age, assuming retirement at 65, unless the participant chooses other funds from the Plan's investment menu. A participant may change investments and move balances between funds without charge, except where a fund's rules say otherwise. The Plan is intended to comply with the rules that let participants direct their own investments, so the Bank and the fiduciaries are not responsible for investment losses that result from the participant's choices. Quarterly statements are available in MyHR and from Evergreen Retirement Services. Each participant may book a free one-to-one financial advice session each year.

## 8. Loans

A participant may borrow from the vested Account balance on these terms:

| Feature | Rule |
| --- | --- |
| Number of loans | One loan at a time |
| Amount | Up to 50% of the vested balance, to a maximum of $50,000 |
| Repayment | By payroll deduction |
| Unpaid balance at termination | May be treated as a taxable distribution unless repaid within the period the plan document allows |

Loan interest is credited to the participant's own Account. A loan taken and not repaid on time may also be subject to additional tax. Loans are not available in the Canadian pension plan.

## 9. Hardship withdrawals

A participant who has an immediate and heavy financial need may request a hardship withdrawal of an amount that the plan document and tax law allow, if no other reasonably available resources exist. Qualifying needs are those listed in the plan document, such as medical expenses, preventing eviction or foreclosure, tuition and funeral costs. The participant must provide documentation. Hardship withdrawals are taxable and may be subject to an early-withdrawal penalty. Evergreen Retirement Services applies the plan document and tax law, and the participant may appeal under section 12.

## 10. Distributions and rollovers

### 10.1 When benefits may be paid

Vested benefits may be distributed after employment ends, on death or disability, or on reaching the age at which the plan document and tax law permit in-service withdrawals. Evergreen Retirement Services sends the participant an options package within 30 days after employment ends.

### 10.2 Retirement

| Item | Rule |
| --- | --- |
| Normal retirement age | 65 |
| Early retirement | From age 55 with at least 5 years in the Plan |
| Retirement notice | 3 months before the intended last day |

A participant who plans to retire submits FORM-HR-080 Resignation Notice and tells HR Operations that the resignation is a retirement. Notice periods by band are in HR-POL-015 Resignation and Offboarding Policy.

### 10.3 Forms of payment and rollovers

A participant may leave the vested Account in the Plan, roll it over to an individual retirement account or another employer plan, or take a distribution, subject to tax and any early-withdrawal penalty. A direct rollover avoids current tax withholding. Money that is paid to the participant before the age at which penalty-free withdrawals begin may be taxed and penalized unless an exception applies.

### 10.4 Death and beneficiaries

On a participant's death the vested Account is paid to the beneficiary named in MyHR or through Evergreen Retirement Services. A surviving spouse may have a legal right to the Account in some circumstances, so a participant should review beneficiaries after marriage, divorce, the birth or adoption of a child, or the death of a beneficiary. If no valid beneficiary is on file, the plan document and applicable law decide who receives the Account.

### 10.5 Divorce

A court may divide an Account through a qualified domestic relations order, which the plan administrator reviews against the plan document and tax law before acting.

## 11. Your rights as a participant

Participants have certain rights and protections under federal retirement law. In summary, a participant may examine the plan document, the annual report and other plan documents without charge in MyHR or at the offices of the plan administrator, obtain copies on written request (a reasonable fee may be charged), receive a summary of the Plan's annual financial report, and obtain a statement of the Account balance and vested benefits at least once a year on request. The people who operate the Plan, who are called fiduciaries, must act prudently and in the interest of participants.

No one, including the Bank, may fire a participant or discriminate against a participant to prevent the participant from obtaining a benefit or exercising these rights. A participant whose claim is denied in whole or in part has the right to know why, to obtain the documents that relate to the decision, and to appeal. A participant may also contact the appropriate federal retirement-plan authority with questions, or file suit in court if a claim is denied after the review in section 12 is complete.

## 12. Claims and appeals

### 12.1 Filing a claim

A participant or beneficiary who believes a benefit has been denied or incorrectly calculated may file a written claim with Evergreen Retirement Services, through MyHR or by calling 1-800-555-0188. The claim must be submitted within 12 months of the date of the event that the claim concerns. Evergreen Retirement Services decides the claim within 30 days after receiving it. If more information is needed, the participant is told in writing what is missing.

### 12.2 Denial notice

A written denial explains the specific reasons, refers to the plan provisions on which it is based, describes any additional information needed, and explains the review process and how to start it.

### 12.3 Appeal and review

A participant may appeal within 180 days of receiving a denial. The appeal is decided within 30 days. A participant who is not satisfied may ask for a second-level review by the Benefits Appeals Committee, which decides within 30 days. The detailed steps, documentation and common denial reasons are in HR-PLN-007 Benefits Claims and Appeals Guide.

## 13. Plan administration

The plan name is Bank US 401(k) Savings Plan, sponsored by the Bank, with a plan year of 1 January to 31 December. The plan administrator is the Bank, acting through the SVP Total Rewards; the recordkeeper is Evergreen Retirement Services; legal process is accepted by the Bank's Legal department.

The Bank may amend or terminate the Plan, subject to the plan document and the law, and notifies affected participants of a material amendment. Personal information is handled under HR-POL-016 Employee Data Privacy Policy.

## 14. Contacts

| Need | Contact |
| --- | --- |
| Account balances, investments, loans, withdrawals, advice sessions | Evergreen Retirement Services, 1-800-555-0188 |
| Eligibility, payroll deductions, policy | HR Connect, 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time, hrconnect@bank.example |

## 15. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2026.1 | 2026-01-01 | Summary Plan Description issued in plan-document form, aligned with HR-GDE-002 version 3.0 |
