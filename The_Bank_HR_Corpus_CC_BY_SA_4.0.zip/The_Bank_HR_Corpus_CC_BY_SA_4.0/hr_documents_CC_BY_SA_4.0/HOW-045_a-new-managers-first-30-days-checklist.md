# A new manager's first 30 days checklist

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-045 |
| Title | A new manager's first 30 days checklist |
| Document type | How-to article |
| Version | 1.1 |
| Status | Current |
| Effective date | 2026-02-02 |
| Last reviewed | 2026-10-06 |
| Next review | 2027-10-06 |
| Policy owner | SVP Talent and Learning |
| Audience | Managers |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-005, HR-GDE-004, HR-POL-011, HR-POL-006 |

## 1. Short answer

In your first 30 days, learn what you may approve, set up your team in MyHR, hold a first conversation with every team member, and know the deadlines and the escalation paths; call the Manager Hotline at 1-800-555-0143 whenever you are unsure.

## 2. Who this applies to

Every new people manager in Canada or the US, including an acting manager. An acting manager needs written delegation recorded in MyHR.

## 3. Steps

### Week 1: know your authority

1. Read HR-GDE-005 Manager's HR Procedures Guide, especially the approvals matrix. You approve vacation, personal days, time in lieu and hybrid exception days; you do not approve exceptions to policy or promise pay, leave or accommodation outcomes.
2. In MyHR, confirm your team list and delegations. Save the Manager Hotline (1-800-555-0143, Monday to Friday 8:00 to 20:00 Eastern Time, response within 4 business hours) and the name of your HR Business Partner.
3. Complete your manager training in the Learning Hub and check the team's mandatory training status.

### Week 2: meet and set direction

4. Hold a one-to-one with each team member. Check that goals exist: new hires set goals within 30 days of starting; the whole team sets goals by 15 December.
5. Book a quarterly informal check-in with each person. Mid-year check-ins fall between 1 May and 15 June.
6. For new hires, schedule check-ins at 30, 60 and 90 days; probation is 3 months.

### Week 3: routines and approvals

7. Approve time in MyHR > Time and Absence by Monday 12:00 local time (see HOW-046).
8. Respond to vacation requests within 5 business days and make sure everyone plans 10 consecutive business days of block leave.
9. Learn the attendance triggers: 3 late arrivals in 30 days, or 4 absence occurrences or 8 absence days in a rolling 12 months, excluding protected absences.

### Week 4: protect people and data

10. Know the same-day duties: refer harassment or violence to Employee Relations through the HR Case Portal the same business day; send accommodation requests to accommodations@bank.example the same business day.
11. Never ask for a diagnosis. Report a lost device or phishing to the Security Operations Centre immediately and within 1 hour.
12. Review your team's system access, then meet your HR Business Partner to review this checklist.

## 4. Deadlines

Self-assessments are due 15 November, your written assessments 10 December, calibration runs 11 December to 10 January and ratings are communicated by 15 January.

## 5. What happens next

Keep a one-line note after each agreement with a team member. Use the Manager Hotline for guidance; decisions on discipline and termination remain with you, the HR Business Partner and Employee Relations.

## 6. Common mistakes

- Approving something outside your authority, or promising an outcome.
- Approving by email only; approvals are recorded in MyHR or Time Tracker.
- Handling a complaint yourself instead of referring it the same business day.
- Letting a new hire's 30-day goal deadline pass.

## 7. Who to call

Manager Hotline: 1-800-555-0143. HR Connect for team members: 1-800-555-0142. Speak-Up Line (ethics concerns): 1-800-555-0177. Emergency: 911, then Corporate Security, 1-800-555-0119.

## 8. Related documents

- HR-GDE-005 Manager's HR Procedures Guide
- HR-POL-011 Performance Management Policy
- HR-POL-006 Vacation and Paid Time Off Policy

## 9. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.1 | 2026-02-02 | Aligned with HR-GDE-005 version 3.2. |
| 1.0 | 2025-02-03 | First edition. |
