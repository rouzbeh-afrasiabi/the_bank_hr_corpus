# How to contact HR Connect and track your case

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-040 |
| Title | How to contact HR Connect and track your case |
| Document type | How-to article |
| Version | 1.0 |
| Status | Current |
| Effective date | 2026-03-16 |
| Last reviewed | 2026-09-29 |
| Next review | 2027-09-29 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-004, HR-FAQ-001, HR-REF-001 |

## 1. Short answer

Call HR Connect at 1-800-555-0142 or use live chat in MyHR (Monday to Friday 8:00 to 20:00 Eastern Time), and open a case in MyHR > HR Case Portal for anything that needs tracking, attachments or a decision. Every case has a number you can follow until it is resolved.

## 2. Who this applies to

All employees in Canada and the US, including part-time, casual and fixed-term employees. Managers can also use the Manager Hotline, 1-800-555-0143. Contractors and agency workers use their engagement contact.

## 3. Steps

1. Choose a channel: phone, live chat in MyHR, or hrconnect@bank.example. HR Connect works in English and French, with an interpreter on request, and is closed on Bank holidays.
2. To open a tracked case, sign in to MyHR and select HR Case Portal > New case.
3. Choose the category (for example Pay, Benefits, Leave, Employee Relations, Privacy or Accessibility). Describe the issue and the date by which you need an answer. Do not type medical diagnoses or banking details; attach them only if asked.
4. Accept or adjust the suggested priority. The portal sets P1 automatically for missed pay, safety and harassment.
5. Attach any form or proof (for example FORM-HR-021 for a pay correction) and select Submit. You receive a case number by email and a confirmation in MyHR.
6. To track it, open MyHR > HR Case Portal and select the case. The status is New, In progress, Waiting for you, Resolved or Closed. Add comments to the case rather than sending a new email.

## 4. Deadlines

| Priority | First response |
| --- | --- |
| P1 urgent | 4 business hours |
| P2 high | 1 business day |
| P3 standard | 2 business days |
| P4 low or information | 3 business days |

- P3 cases handled by a specialist team (Tier 2) have a resolution target of 5 business days; complex cases (Tier 3) 10 business days.
- If a case is Waiting for you and you do not reply within 5 business days, it is resolved with a reminder. You can reopen it within 30 days.

## 5. What happens next

HR Connect resolves simple questions at first contact. Otherwise the case goes to a specialist team (Payroll Services, Benefits Administration, Leaves, Total Rewards or HR Operations) or, for sensitive matters, to your HR Business Partner, Employee Relations, Legal or the Privacy Office. If a deadline is missed, select Escalate in the case or ask HR Connect: the HR Operations manager acts after the first missed deadline, then the VP HR Operations, then the Office of the CHRO.

## 6. Common mistakes

- Emailing again instead of adding a comment, which splits the history.
- Leaving out the date you need an answer.
- Calling after hours about a pay emergency: log it in the HR Case Portal; the 4-business-hour clock starts when HR Connect next opens.

## 7. Who to call

HR Connect: 1-800-555-0142, hrconnect@bank.example. Conduct concerns, anonymous option: Speak-Up Line, 1-800-555-0177 (24/7). Personal safety: 911 first, then Corporate Security, 1-800-555-0119. Lost device or cyber incident: Security Operations Centre, 1-800-555-0155. Informal advice: Ombuds Office, ombuds@bank.example.

## 8. Related documents

- HR-GDE-004 HR Service and Support Guide
- HR-FAQ-001 Employee HR FAQ
- HR-REF-001 HR Glossary

## 9. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.0 | 2026-03-16 | First edition, aligned with HR-GDE-004 version 2.5. |
