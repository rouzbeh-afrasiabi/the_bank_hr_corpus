# How to request a workplace accommodation

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-019 |
| Title | How to request a workplace accommodation |
| Document type | How-to article |
| Version | 1.3 |
| Status | Current |
| Effective date | 2025-08-01 |
| Last reviewed | 2026-06-30 |
| Next review | 2027-06-30 |
| Policy owner | Head of Accessibility and Inclusion |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-018, FORM-HR-040, FORM-HR-041, HR-POL-016 |

## 1. The short answer

Tell your manager, HR Connect (1-800-555-0142) or accommodations@bank.example what you need, or submit FORM-HR-040 in MyHR > HR Case Portal; the form is optional and you never need to give a diagnosis.

## 2. Who this applies to

All employees (regular, part-time, casual, fixed-term, student, co-op and intern) and applicants, in Canada (including Quebec) and the US. A need linked to a protected ground, such as disability, religion or creed, family status or pregnancy, qualifies. In Canada the Bank accommodates to the point of undue hardship; in the US it provides reasonable accommodation unless it causes undue hardship. Whichever standard protects you more applies.

## 3. Steps

1. **Ask in any way.** Speak to your manager, call HR Connect, write to accommodations@bank.example, or open MyHR > HR Case Portal > New case > Accessibility and complete FORM-HR-040. The word "accommodation" is not required. A manager must pass a possible need to the Accommodation Specialist the same business day.
2. **Describe what you need,** in your own words, and tick **Urgent** if it affects safety, an imminent return to work or a hiring deadline.
3. **Supply functional information if asked.** The Accommodation Specialist may ask for FORM-HR-041, completed by your health care provider. It covers only what you can and cannot do and for how long, never a diagnosis, treatment or test results.
4. **Agree the solution.** The Accommodation Specialist, with your manager and HRBP, proposes options and records the decision in writing.

## 4. Deadlines and what happens next

| Step | Timeline |
| --- | --- |
| Acknowledgement | Within 2 business days |
| Interim measures | Immediately where possible |
| Decision | Within 10 business days of complete information; 3 business days if urgent |
| Equipment or accessible formats | Normally within 10 business days of the decision |
| Review | At least once a year for long-term needs |

If you disagree with a decision, ask the Accommodation Review Panel within 10 business days of the decision; written reasons follow within 10 business days of your request. The central Accommodation Fund pays the costs, never your team budget. The Bank reimburses up to $150 CAD or $120 USD for completing medical forms. Your manager learns only your functional limitations and their expected duration. Your records are kept separately from your personnel file.

## 5. Common mistakes

- Waiting for a form or a diagnosis. Neither is required to start.
- Telling only a colleague. Tell your manager, HR Connect or the Accommodation Specialist so the clock starts.
- Putting medical detail in a case description. Attach it only when asked.
- Missing the 10-business-day window to ask for a panel review.
- Fearing a penalty. Retaliation for asking breaches the Code of Conduct.

## 6. Who to call

- Accommodations: accommodations@bank.example.
- HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, in English or French.
- Accessible formats of any HR document, within 10 business days: accessibility@bank.example.
- Wellspring Support Program: 1-800-555-0166, 24 hours a day.

## 7. Related documents

- HR-POL-018 Workplace Accommodation and Accessibility Policy (the owning document)
- FORM-HR-040 Accommodation Request
- FORM-HR-041 Medical Information Supplement for Accommodation

Where applicable law gives a greater right, the law applies.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.3 | 2025-08-01 | Added the 3-business-day urgent timeline and Accommodation Fund wording (HR-POL-018 version 3.2). |
| 1.0 | 2025-01-01 | First version. |
