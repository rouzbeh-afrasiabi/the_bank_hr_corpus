# How to use the Speak-Up Line

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-029 |
| Title | How to use the Speak-Up Line |
| Document type | How-to article |
| Version | 1.1 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-08-11 |
| Next review | 2027-08-11 |
| Policy owner | Head of Ethics Office |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-022, HR-POL-001, HR-POL-005, HOW-028 |

## 1. Short answer

Call 1-800-555-0177 at any time, or use the Speak-Up page in MyHR, to report suspected wrongdoing in confidence or anonymously; the line is run independently by Clearline.

## 2. Who this applies to

Employees in Canada and the US, and also contractors, agency workers, suppliers and other third parties. Report anything you reasonably believe is wrong, such as fraud, bribery, money laundering, accounting irregularities, insider trading, serious privacy or safety breaches, or retaliation. You need a good-faith belief, not proof. Harassment and violence may also be reported here (see HOW-028 How to report harassment or violence). Personal grievances about pay, ratings or workload usually go to your manager, HRBP or the Ombuds Office.

## 3. Steps

1. **Choose a channel:** the Speak-Up Line (24 hours, 7 days, interpreter available); the Speak-Up page in MyHR; ethics@bank.example; or your manager or HRBP.
2. **Describe what you know:** who, what, when, where, and how you learned it. Do not investigate or confront anyone.
3. **Choose whether to give your name.** Anonymous reports are taken as seriously as named ones.
4. **Save your report number and password** if you report anonymously. Clearline uses them for updates and follow-up questions.
5. **Check back** and answer follow-up questions.

A concern about the Ethics Office, a senior executive or a director can go directly to the Chair of the Audit Committee through Clearline.

## 4. Deadlines and timeline

| Step | Timeline |
| --- | --- |
| Manager or HRBP forwards your concern to the Ethics Office | Within 1 business day |
| Acknowledgement | Within 3 business days |
| Triage by the Ethics Office | Within 5 business days |
| Status updates | At least every 30 days |
| Target closure | 90 days |

## 5. What happens next

The Ethics Office routes the report to Employee Relations, Corporate Security or Compliance, the Privacy Office, the Security Operations Centre or the Audit Committee Chair. A trained, impartial investigator reviews it, and anyone named in the report is never involved. You are told whether the concern was addressed, though discipline details stay confidential. Retaliation is prohibited, and the Ethics Office checks on you during the investigation and 6 months after closure. Case files are kept for 7 years after closing. You may contact a regulator at any time without telling the Bank.

## 6. Common mistakes

- Waiting until you have proof.
- Losing your anonymous report number and password.
- Trying to identify an anonymous reporter, which is not allowed.
- Making a knowingly false report, which is misconduct.

## 7. Who to call

Speak-Up Line, 1-800-555-0177 (24 hours, 7 days). Ethics Office, ethics@bank.example. For a danger to safety, call 911 first, then Corporate Security, 1-800-555-0119.

## 8. Related documents

- HR-POL-022 Whistleblower and Speak-Up Policy
- HR-POL-001 Code of Conduct and Ethics
- HR-POL-005 Workplace Harassment and Violence Prevention Policy

## 9. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.1 | 2025-09-01 | Aligned with HR-POL-022 version 3.1. |
| 1.0 | 2025-01-01 | First issue. |
