# How to report an absence or a sick day

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-002 |
| Title | How to report an absence or a sick day |
| Document type | How-to article |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-09-15 |
| Next review | 2027-09-15 |
| Policy owner | VP Employee Relations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-004, HR-POL-007, FORM-HR-011, HOW-004 |

## 1. The short answer

Phone or message your manager before your scheduled start (or within 30 minutes after it if you cannot), then record the absence in Time Tracker when you return.

## 2. Who this applies to

All employees in Canada and the US on scheduled shifts. Paid sick days are 10 a year in Canada and 8 in the US, with a half day as the minimum. In Quebec the Bank asks for evidence only after 3 consecutive days; elsewhere from the 4th consecutive working day.

## 3. Steps

1. Contact your manager by phone or message before your shift starts. If that is impossible, do it within 30 minutes after the start. Email alone is not enough on the day.
2. Branch employees also notify the branch manager.
3. Give the expected duration and a return date if you can. You do not have to give a diagnosis.
4. On your return, select **MyHR > Time and Absence > Enter Absence** (Time Tracker) and choose **Sick day**, **Personal day** or another type.
5. If you are away for 4 or more consecutive working days, complete FORM-HR-011 Medical Certificate and Fitness-to-Work, or provide an equivalent provider note. Upload it in **MyHR > HR Case Portal** (case type Leave) within 5 business days of the request. It goes to the Leaves team, not your manager, and shows functional limitations, never a diagnosis.

## 4. Deadlines to remember

| Item | Rule |
| --- | --- |
| Reporting | Before the start, or within 30 minutes after |
| Certificate | From the 4th consecutive working day (Quebec: after 3 days) |
| Family care | Up to 5 of the sick days a year |
| Personal days | 3 a year, 24 hours' notice where possible, no certificate |
| Disability | After 5 consecutive working days, apply within 5 business days of going off work (see HOW-004) |

## 5. What happens next

After 5 or more absence days your manager holds a return-to-work conversation within 2 business days of your return. A pattern review starts at 3 late arrivals in 30 days, or 4 occurrences or 8 absence days in a rolling 12 months; it is a conversation, not discipline, and protected absences never count.

## 6. Common mistakes

- Sending only an email on the morning of the absence.
- Not also telling the branch manager (branch employees).
- Missing 3 consecutive scheduled days without contact, which can lead to presumed job abandonment.
- Sending a certificate to your manager instead of the Leaves team.

## 7. Who to call

HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, or live chat in MyHR. Wellspring Support Program: 1-800-555-0166, 24 hours.

## 8. Related documents

- HR-POL-004 Attendance and Absenteeism Policy
- HR-POL-007 Sick Leave and Personal Leave Policy
- FORM-HR-011 Medical Certificate and Fitness-to-Work
- HOW-004 How to apply for short-term disability

## 9. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-01-01 | Sick days updated to 10 (Canada) and 8 (US). |
| 1.0 | 2025-04-01 | First edition. |
