# Vice President, Commercial Banking

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1018 |
| Title | Vice President, Commercial Banking |
| Document type | Job description |
| Version | 1.1 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-10-06 |
| Next review | 2027-10-06 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-POL-031, HR-PLN-003, HR-POL-002, HR-POL-018 |

## 1. Role summary

The Vice President, Commercial Banking leads a major segment of the Bank's commercial franchise, such as mid-market, real estate or specialty industries, across Canada and the US. The role sets the segment strategy, owns its financial and risk results, and leads the Directors and Regional Managers who manage client relationships. The Vice President represents the Bank to key clients, regulators and industry bodies, and shapes enterprise decisions affecting commercial clients. This is a Band 8 (Senior Director / Vice President) role in the Commercial Banking family; see HR-GDE-006 Job Architecture and Pay Bands Guide.

## 2. Key responsibilities

- Set and execute the segment strategy, targets and annual plan with the Senior Vice President, Commercial Banking.
- Own segment revenue, expense, credit quality and capital outcomes and report them to senior leadership and the Board as required.
- Lead and develop a leadership team of Directors, Regional Managers and senior specialists, and manage succession.
- Approve large or complex credit transactions within delegated authority and champion disciplined credit policy.
- Oversee portfolio quality, concentration limits, watch-list accounts and remediation plans.
- Build and sustain senior relationships with strategic clients and prospects.
- Partner with Risk, Compliance, Finance, Technology and Capital Markets to deliver integrated client solutions.
- Ensure the segment meets regulatory, conduct, anti-money-laundering and sanctions obligations.
- Manage the segment's budget, investment priorities and talent plan.
- Foster an inclusive, ethical and high-performance culture and act on engagement results.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in business, finance or a related field; an MBA is valued.
- At least fifteen years of progressive commercial banking, credit or corporate finance experience, including senior leadership of a client-facing business.
- Strong track record of delivering growth with disciplined credit and risk management.
- Executive presence, strategic thinking and financial acumen.
- Satisfactory results in pre-employment screening and periodic re-screening for senior roles.

### 3.2 Preferred

- Experience in both the Canadian and US commercial markets.
- A recognized credit or leadership qualification.
- Fluency in English and French.

### 3.3 Licences and certifications

No licence is required. Where licensed colleagues report within the segment, the Vice President is accountable for supervision consistent with HR-POL-029 Licensing, Registration and Qualification Policy.

## 4. Competencies

Competencies are defined in HR-FWK-001 Competency and Leadership Model; this role works at the Enterprise Leader level.

- **Drive for Results**: delivers segment performance across cycles.
- **Judgement and Decision Quality**: makes consequential credit and strategic decisions.
- **Risk and Conduct Awareness**: sets the tone for credit discipline and conduct.
- **Inclusive Leadership**: builds diverse leadership teams and inclusive client engagement.
- **Developing Others**: grows senior leaders and a deep succession bench.
- **Collaboration**: works across the enterprise to serve clients.
- **Adaptability**: leads the segment through economic and regulatory change.

## 5. Compensation and classification

| Item | Detail |
| --- | --- |
| Band | 8 (Senior Director / Vice President) |
| Canada salary range | $180,000 to $270,000 CAD per year |
| US salary range | $175,000 to $265,000 USD per year |
| Incentive target | Annual Incentive Plan (AIP): 30% of base salary; deferral and clawback apply under HR-POL-031; eligible for the Long-Term Incentive Plan (HR-PLN-003) |
| Overtime eligibility (Canada) | No |
| FLSA classification (US) | Exempt |
| Work arrangement | Hybrid: at least 3 days a week in the office, with client and travel commitments scheduled around them |

## 6. Working conditions and accessibility

This is a hybrid office role with regular client and internal travel across Canada and the US, including cross-border travel. Hybrid arrangements follow HR-POL-002 Remote and Hybrid Work Policy, with at least 3 days a week in the office and anchor days on Tuesday and Thursday. The Bank provides accommodation to the point of undue hardship (Canada) or reasonable accommodation (US); see HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to the Senior Vice President, Commercial Banking.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.1 | 2026-03-01 | Pay ranges updated to the 2026 pay bands; added deferral and long-term incentive references |
| 1.0 | 2025-02-03 | First issue |
