# Information Security Analyst

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1031 |
| Title | Information Security Analyst |
| Document type | Job description |
| Version | 2.2 |
| Status | Current |
| Effective date | 2025-11-03 |
| Last reviewed | 2026-10-06 |
| Next review | 2027-10-06 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-POL-002, HR-POL-017, HR-POL-033 |

## 1. Role summary

The Information Security Analyst protects the Bank, its customers and its employees from cyber threats. The analyst monitors security alerts, investigates suspected incidents with the Security Operations Centre (SOC), assesses vulnerabilities and helps teams apply the controls in HR-POL-017 IT Acceptable Use and Information Security Policy. A Band 3 analyst works independently on assigned investigations and escalates complex or high-impact events.

## 2. Key responsibilities

- Monitor and triage alerts from security tools, and decide whether an event is a false alarm or an incident.
- Investigate suspected compromise, phishing reports and lost-device reports; the SOC expects reports within 1 hour of discovery.
- Contain threats by isolating devices, disabling accounts or blocking indicators, following the incident playbooks.
- Document investigations, evidence and timelines accurately for later review and, where needed, legal use.
- Run vulnerability scans, rate findings by risk and track remediation with technology teams.
- Review access requests and quarterly access reviews against the least-privilege principle.
- Support phishing simulations and security-awareness campaigns, including remedial training follow-up.
- Tune detection rules and contribute to threat-hunting exercises.
- Handle monitoring data lawfully and only for the purposes set out in HR-POL-033 Electronic Monitoring and Right to Disconnect Policy.
- Escalate privacy-impacting incidents to the Privacy Office immediately and no later than 24 hours after discovery.
- Participate in the on-call rotation for security incidents.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in computer science, information security or a related field, or equivalent experience.
- Typically 2 to 5 years of experience in security operations, incident response or vulnerability management.
- Understanding of networking, operating systems, authentication and common attack techniques.
- Clear written communication for incident reports.

### 3.2 Preferred

- CISSP or a comparable security certification (reimbursed under HR-POL-012 Learning and Development Policy).
- Experience with security information and event management platforms and endpoint detection tools.
- Experience in financial services.

### 3.3 Licences and certifications

None required. Security certifications are encouraged.

## 4. Competencies

Measured against HR-FWK-001 Competency and Leadership Model at the Practitioner level:

- Judgement and Decision Quality
- Risk and Conduct Awareness
- Adaptability
- Collaboration
- Drive for Results

## 5. Compensation and classification

| Item | Value |
| --- | --- |
| Band | 3 (Professional) |
| Canada range | $56,000 to $84,000 CAD |
| US range | $55,000 to $82,000 USD |
| Incentive target | 5% of base salary (Annual Incentive Plan) |
| Overtime eligibility, Canada | Yes (non-managerial Band 3) |
| FLSA classification, US | Exempt |
| Work arrangement | Hybrid (at least 3 days a week in the office) |

The on-call allowance, call-out minimum and shift premium are set out in HR-POL-003 Working Hours and Overtime Policy. Band definitions are in HR-GDE-006 Job Architecture and Pay Bands Guide.

## 6. Working conditions and accessibility

This is an office role with a hybrid arrangement under HR-POL-002 Remote and Hybrid Work Policy: at least 3 days a week in the office, including the Tuesday and Thursday anchor days. The role includes on-call duty for incidents and, at times, outside-hours investigation. Analysts have privileged access to security data and must use it only with a documented reason. The Bank provides accommodation to the point of undue hardship; see HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to: Manager, Security Operations. Direct reports: none.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.2 | 2025-11-03 | Added monitoring-policy and privacy escalation wording |
| 2.0 | 2024-05-01 | Added vulnerability management duties |
| 1.0 | 2023-05-01 | First issue |
