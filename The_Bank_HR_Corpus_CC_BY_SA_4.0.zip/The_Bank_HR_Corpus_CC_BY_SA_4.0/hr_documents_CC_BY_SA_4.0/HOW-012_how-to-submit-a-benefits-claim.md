# How to submit a benefits claim

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-012 |
| Title | How to submit a benefits claim |
| Document type | How-to article |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-10-20 |
| Next review | 2027-10-20 |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-PLN-007, HR-PLN-004, HR-GDE-001, HR-POL-007 |

## 1. The short answer

Show your Maplewood Benefits card for direct billing where you can; otherwise pay and submit an itemized receipt through the Maplewood Benefits member portal (linked from MyHR) within 12 months of the expense.

## 2. Who this applies to

Employees enrolled in Maplewood Benefits health, dental or vision coverage in Canada and the US. Quebec employees use the public drug plan or the Bank plan as the law requires. Disability claims follow HOW-004. The wellness spending account has its own deadline (see HOW-014).

## 3. Steps in Canada

1. Present your card at a pharmacy or dental office that offers direct billing; you pay only your share.
2. Otherwise pay the provider, then select **MyHR > Benefits > Submit a Claim**, which opens the member portal.
3. Upload an itemized receipt showing the provider, the service or drug and the amount, plus any statement from another plan.
4. For major dental work estimated above $500, ask your dentist to send a treatment plan for predetermination before treatment.

Claim payments go to the account in your Maplewood Benefits profile.

## 4. Steps in the US

1. Show your card at the time of service and use in-network providers for the best coinsurance.
2. For out-of-network care, select **MyHR > Benefits > Submit a Claim** and file in the member portal.
3. For health savings account and flexible spending account claims, use the account administrator linked from MyHR.

## 5. Deadlines to remember

| Step | Time |
| --- | --- |
| Submit a claim | Within 12 months of the expense date |
| Decision (Canada) | 30 days after the complete claim |
| Decision (US) | Urgent 72 hours; pre-service 15 days; post-service 30 days |
| Appeal | Within 180 days of the decision notice |

## 6. What happens next

Maplewood Benefits decides the claim and sends a written notice. If it is denied, appeal in **MyHR > Benefits > Appeal a claim decision**: the first-level decision is made within 30 days, and a second-level review by the Benefits Appeals Committee within a further 30 days (see HR-PLN-007 Benefits Claims and Appeals Guide). The Ombuds Office (ombuds@bank.example) can help informally.

## 7. Common mistakes

- Submitting after 12 months.
- Uploading a card slip or credit statement instead of an itemized receipt.
- Not claiming from another plan first.
- Skipping predetermination for major dental work.
- Expecting HR to decide claims; Maplewood Benefits decides.

## 8. Who to call

Maplewood Benefits claims line: 1-800-555-0190. HR Connect for eligibility, enrolment and how to appeal: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, or live chat in MyHR.

## 9. Related documents

- HR-PLN-007 Benefits Claims and Appeals Guide
- HR-PLN-004 Group Benefits Booklet (Canada)
- HR-GDE-001 Employee Benefits Guide

## 10. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-01-01 | Time limits aligned across Canada and the US (HR-PLN-007 version 2.1). |
| 1.0 | 2025-01-06 | First edition. |
