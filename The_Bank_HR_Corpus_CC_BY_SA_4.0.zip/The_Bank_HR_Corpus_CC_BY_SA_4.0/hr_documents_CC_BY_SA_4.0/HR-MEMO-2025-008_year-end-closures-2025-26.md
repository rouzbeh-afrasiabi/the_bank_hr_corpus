# Year-End Closures 2025-26

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-MEMO-2025-008 |
| Title | Year-End Closures 2025-26 |
| Document type | Memo |
| Version | 1.0 |
| Status | Current |
| Effective date | 2025-12-08 |
| Last reviewed | Not applicable |
| Next review | Not applicable |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-010, HR-GDE-004, HR-POL-044 |

**Bank holidays and HR Connect closures over the year-end period.**

**From:** VP HR Operations

**To:** All employees in Canada and the US

**Date:** 8 December 2025

**Subject:** Year-end closures 2025-26

## 1. What is changing

HR Connect and Bank holiday closures:

| Date | Holiday | Where observed |
| --- | --- | --- |
| Thursday 25 December 2025 | Christmas Day | Canada and US |
| Friday 26 December 2025 | Boxing Day (observed that day) | Canada only |
| Thursday 1 January 2026 | New Year's Day | Canada and US |

HR Connect is closed on all three days, including live chat.

## 2. Who is affected

All employees. US employees work Friday 26 December as a normal day but cannot reach HR Connect.

## 3. Effective date

The closures apply on the dates above. HR Connect reopens on its next business day.

## 4. What to do

1. Submit non-urgent requests in the HR Case Portal in MyHR; they are handled when HR Connect reopens.
2. Employees who must work a holiday receive regular holiday pay plus 1.5x for hours worked, or in Canada 1.5x time in lieu taken within 60 days (HR-POL-010).
3. Do not book vacation on a holiday: statutory holidays during vacation are not charged to your balance.

## 5. Who to call

During closures: Corporate Security 1-800-555-0119 (24/7; call 911 first in an emergency), Wellspring Support Program 1-800-555-0166 (24/7), Speak-Up Line 1-800-555-0177 (24/7). Otherwise HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time, hrconnect@bank.example.

## 6. Related documents

- HR-POL-010 Statutory Holidays Policy
- HR-GDE-004 HR Service and Support Guide
- HR-POL-044 Business Continuity and Severe Weather Policy
