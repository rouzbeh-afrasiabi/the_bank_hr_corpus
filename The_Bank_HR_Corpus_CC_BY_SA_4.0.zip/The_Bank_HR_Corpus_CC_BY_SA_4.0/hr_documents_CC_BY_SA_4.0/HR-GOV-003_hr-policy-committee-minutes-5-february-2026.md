# HR Policy Committee Minutes, 5 February 2026

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-GOV-003 |
| Title | HR Policy Committee Minutes, 5 February 2026 |
| Document type | Minutes |
| Version | 1.0 |
| Status | Current |
| Effective date | 2026-02-05 |
| Last reviewed | Not applicable |
| Next review | Not applicable |
| Policy owner | Office of the CHRO |
| Audience | HR leadership |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-009, HR-POL-017, HR-POL-016, HR-PRC-005, HR-MEMO-2026-002 |

Chair: Chief Human Resources Officer

Meeting: Thursday 5 February 2026, 10:00 to 11:30 Eastern Time, by video conference.

## 1. Attendance and quorum

**Voting members present (8 of 9):** Chief Human Resources Officer (Chair), SVP Total Rewards, SVP Talent and Learning, VP Employee Relations, VP HR Operations, Chief Privacy Officer, Head of Ethics Office, Head of Workplace Safety.

**Apologies:** Chief Compliance Officer.

**Also present (non-voting):** Chief Information Security Officer (item 4 only); Head of Accessibility and Inclusion; Committee Secretary (Office of the CHRO).

Quorum is 5 voting members including the Chair. Quorum was confirmed.

## 2. Agenda

1. Opening, quorum and minutes of the meeting of 18 September 2025 (HR-GOV-002)
2. Payroll correction threshold: HR-POL-009 Compensation and Payroll Policy
3. 2026 merit budget
4. Approved AI tools clause: HR-POL-017 IT Acceptable Use and Information Security Policy
5. Any other business and close

## 3. Discussion

### 3.1 Payroll correction threshold

The SVP Total Rewards proposed raising the net underpayment amount that is paid off-cycle (within 3 business days of confirmation) from $200 to $250, with smaller amounts corrected on the next regular pay date. Payroll Services reported that the higher threshold reduces the number of off-cycle runs without delaying any material correction. The Committee asked that the change be communicated clearly so that employees know the amount that applies to their case and where to report an error (FORM-HR-021 in the HR Case Portal).

### 3.2 2026 merit budget

The SVP Total Rewards recommended a merit budget of 3.5% of base payroll for the 2026 salary review, which takes effect on 1 March 2026 and is based on the year-end ratings. Members discussed how the budget supports the Bank's target of paying at the market median and the annual pay-equity review. Merit guidance by rating is set in HR-PRC-005 Calibration and Salary Planning Guidelines.

### 3.3 Approved AI tools clause

The Chief Information Security Officer presented a clause for version 8.1 of the IT policy: only Bank-approved AI tools may be used, and no client or employee personal data may be entered in public AI tools. The Chief Privacy Officer confirmed that the clause is consistent with the Privacy Impact Assessment and Data Protection Impact Assessment requirements in HR-POL-016 Employee Data Privacy Policy. The Chief Information Security Officer will take the full policy to the Information Security Governance Committee, which approves it together with the CHRO.

## 4. Decisions

| No. | Decision | Effective | Vote |
| --- | --- | --- | --- |
| D1 | Approved a payroll correction threshold of $250 (HR-POL-009, version 7.2). | 2026-03-01 | For 8, Against 0, Abstain 0. Carried. |
| D2 | Approved the AI tools clause for HR-POL-017, version 8.1. | 2026-04-01 | For 7, Against 0, Abstain 1 (Head of Ethics Office). Carried. |
| D3 | Approved the 2026 merit budget of 3.5% of base payroll, as recommended by the SVP Total Rewards (HR-PRC-005). | 2026-03-01 | For 8, Against 0, Abstain 0. Carried. |

## 5. Action items

| No. | Action | Owner | Due |
| --- | --- | --- | --- |
| A1 | Issue the employee memo on the new payroll correction threshold (HR-MEMO-2026-002). | SVP Total Rewards | 2026-02-10 |
| A2 | Configure the $250 threshold in the payroll correction workflow before the March pay cycle. | VP HR Operations | 2026-02-27 |
| A3 | Issue the employee memo on the approved AI tools clause (HR-MEMO-2026-003). | Chief Information Security Officer | 2026-03-30 |
| A4 | Issue guidance that a PIA and, for high-risk processing, a DPIA are required before any AI tool is used in an HR process (HR-MEMO-2026-004). | Chief Privacy Officer | 2026-04-13 |
| A5 | Confirm the 3.5% merit budget to Payroll Services and the business unit HRBPs for the 1 March salary review. | SVP Total Rewards | 2026-02-13 |

## 6. Close

The Chair closed the meeting at 11:30.
