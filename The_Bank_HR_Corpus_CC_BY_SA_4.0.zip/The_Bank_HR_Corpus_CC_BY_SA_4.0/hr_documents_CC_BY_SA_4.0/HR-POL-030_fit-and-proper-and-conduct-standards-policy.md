# Fit and Proper and Conduct Standards Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-030 |
| Title | Fit and Proper and Conduct Standards Policy |
| Document type | Policy |
| Version | 2.1 |
| Status | Current |
| Effective date | 2025-10-01 |
| Last reviewed | 2026-09-14 |
| Next review | 2027-09-14 |
| Policy owner | Chief Compliance Officer |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-001, HR-POL-020, HR-POL-021, HR-POL-029, HR-POL-022, HR-POL-028 |

## 1. Purpose

A bank relies on the trust of customers and regulators. People who handle money, advise customers or make decisions for the Bank must be honest, competent and financially sound. This policy explains how the Bank checks that on a continuing basis (not only at hire), what employees must disclose, how the Bank decides what to do with a disclosure, and the conduct standards every employee follows.

## 2. Scope

The policy applies to all employees of the Bank in Canada and the US, including employees on leave. The re-screening rule in section 5.4 applies to roles with financial authority and to the sensitive roles named in HR-POL-020 Pre-Employment Screening Policy. Licensed roles must also follow HR-POL-029 Licensing, Registration and Qualification Policy. Where applicable law gives a greater right, the law applies. In Quebec, a criminal record is considered only where it is related to the job.

## 3. Definitions

| Term | Meaning |
| --- | --- |
| Fit and proper | Meeting the standard of honesty and integrity, competence, and financial soundness needed for the role. |
| Fit-and-proper attestation | The yearly written statement, made with the Code attestation, that the employee has disclosed everything this policy requires. |
| Reportable event | An event in section 5.2 that the employee must disclose. |
| Individualized assessment | A documented, job-related review of the facts, which considers the nature of the event, the time that has passed, its relevance to the duties and any mitigating facts. |
| Redeployment | Moving the employee to a role where the event is not relevant. |
| Role with financial authority | A role that can approve, release or commit Bank or customer funds, or approve credit. |

## 4. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Employee | Discloses reportable events on time, attests each year, tells the truth and cooperates with the assessment. |
| Manager | Refers any concern, supports the employee and never investigates privately. |
| Compliance | Receives disclosures, gathers facts, performs the individualized assessment and advises on regulatory consequences. |
| HRBP | Supports the employee and the manager and takes part in the assessment. |
| VP Employee Relations | Decides the outcome together with the Chief Compliance Officer. |
| Chief Compliance Officer | Owns the policy and decides jointly with the VP Employee Relations. |
| Review officer | A senior leader named by the CHRO who was not involved in the first decision. |

## 5. Standards and disclosures

### 5.1 The fit-and-proper criteria

1. **Honesty and integrity:** truthfulness in dealings with customers, colleagues, regulators and the Bank; no fraud, dishonesty or breach of trust.
2. **Competence:** the knowledge, skills, licences and diligence needed for the role.
3. **Financial soundness:** the ability to manage personal finances prudently, particularly for roles with financial authority, so that personal pressure does not create a risk to customers or the Bank.

### 5.2 What you must disclose

Tell Compliance **within 2 business days** of any of the following:

- a criminal charge or conviction;
- bankruptcy, or a formal insolvency or debt-settlement proceeding;
- a regulatory or professional sanction;
- a civil judgement related to honesty or to financial matters.

Disclose events that happen outside work as well. An event is reportable even if you believe it is not relevant. Compliance decides that. Also tell Compliance if you are asked to give information to a regulator about your own conduct. Your manager should be told, in general terms, to the extent needed to protect the work and the team. If HR-POL-020 or HR-POL-029 also requires a notice, one disclosure to Compliance within 2 business days can serve all of them.

### 5.3 Annual attestation

Every employee completes the fit-and-proper attestation together with the Code attestation under HR-POL-001 Code of Conduct and Ethics, **by 31 October** each year. New hires attest within 30 days of their start date. Attestation is completed in MyHR. Late attestations are handled under the training escalation in HR-POL-012 Learning and Development Policy.

### 5.4 Re-screening

Employees in roles with financial authority, and in the other sensitive roles named in HR-POL-020 Pre-Employment Screening Policy, are re-screened every 5 years under that policy. Re-screening is done with the employee's consent and covers the checks listed in that policy.

## 6. Conduct standards

All employees must:

- **Treat customers fairly:** explain products honestly and clearly, offer what suits the customer's needs, and handle complaints promptly.
- **Avoid mis-selling:** never sell, recommend or open a product the customer does not need or understand, and never create accounts or sales to meet a target. Pay is never linked to a single product (see HR-PLN-002 Advisor and Sales Incentive Plan Document).
- **Keep accurate records:** record what was done, said and agreed; never alter, backdate, or falsify any record.
- **Escalate concerns:** raise a risk, an error or a suspected breach as soon as you know about it, with your manager, Compliance, the Ethics Office or the Speak-Up Line (see HR-POL-022 Whistleblower and Speak-Up Policy).
- **Deal with your own banking properly:** follow HR-POL-028 Staff Banking Privileges and Employee Loans Policy.

## 7. Procedure after a disclosure

| Step | Action | Timing |
| --- | --- | --- |
| 1 | The employee discloses to Compliance. Compliance acknowledges. | Disclosure within 2 business days of the event; acknowledgement within 1 business day |
| 2 | Compliance and the HRBP gather the facts and meet the employee. | Starts within 3 business days of the disclosure |
| 3 | Interim measures, if needed (see 7.1). | Same business day as the decision to impose them |
| 4 | Individualized assessment against the three criteria. | Decision within 10 business days of complete information |
| 5 | Written decision to the employee, with the reasons. | On the day of the decision |
| 6 | The employee may ask for a review. | Request within 10 business days of the written decision |
| 7 | The review officer decides and gives written reasons. | Within 10 business days of the request |

### 7.1 Interim measures

While a disclosure is being assessed, Compliance and the HRBP may temporarily remove access to funds or systems, change duties or reassign licensed work. Interim measures are not discipline, are kept as short as possible, and do not reduce pay. Suspension with pay is limited by HR-POL-021 Employee Relations and Progressive Discipline Policy.

### 7.2 Outcomes

The decision is made by the VP Employee Relations together with the Chief Compliance Officer. The outcome is one of:

| Outcome | Meaning |
| --- | --- |
| No action | The event is not relevant to the role. |
| Conditions | The employee continues, with conditions such as extra supervision, limits on authority or financial counselling. |
| Redeployment | The employee moves to a suitable role at the same band. |
| Termination | The employee cannot meet the standard in any available role. Termination for cause also needs the approvals set in HR-POL-021. |

A disclosure does not by itself lead to an adverse outcome. Compliance applies the same individualized assessment to every case and considers accommodation and human-rights obligations first. A charge is not proof of guilt and the assessment looks at its relevance to the job. A person who discloses honestly and promptly is treated more favourably than one who hides an event.

## 8. Worked examples

1. **Bankruptcy of a teller.** A Teller files for personal bankruptcy and discloses it the next business day. Tellers handle cash, so Compliance and the HRBP assess financial soundness. They set conditions: dual control on large cash items and a referral to the Wellspring Support Program (1-800-555-0166). The employee stays in the role.
2. **Late disclosure.** A Senior Trader is charged with an offence on a Monday and tells Compliance on the following Monday, 5 business days later. The outcome of the charge is assessed separately, but the late disclosure is itself a breach and is handled under HR-POL-021.
3. **Driving offence.** A Financial Analyst is convicted of a minor traffic offence with no link to honesty or finances. Compliance decides no action is needed.
4. **Review.** An employee in a role with financial authority is redeployed after a civil judgement for fraud. The employee asks for a review 6 business days after the decision. The review officer has 10 business days to decide.

## 9. Exceptions

Exceptions to the deadlines in this policy require the written approval of the Chief Compliance Officer, and are granted only where the law or the employee's health or safety makes on-time disclosure impossible. There are no exceptions to the honesty standard.

## 10. Consequences

Failing to disclose a reportable event, giving false or incomplete information, or breaching the conduct standards may lead to action under HR-POL-021 Employee Relations and Progressive Discipline Policy, up to and including termination for cause, and may be reported to a regulator. Retaliation against anyone who raises a concern is prohibited under HR-POL-001 Code of Conduct and Ethics.

## 11. Related documents and contacts

- HR-POL-001 Code of Conduct and Ethics
- HR-POL-020 Pre-Employment Screening Policy
- HR-POL-021 Employee Relations and Progressive Discipline Policy
- HR-POL-022 Whistleblower and Speak-Up Policy
- HR-POL-029 Licensing, Registration and Qualification Policy
- HR-POL-028 Staff Banking Privileges and Employee Loans Policy
- Compliance: contact through the Compliance page in MyHR. Ethics Office: ethics@bank.example. Speak-Up Line: 1-800-555-0177. HR Connect: 1-800-555-0142.

## 12. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.1 | 2025-10-01 | Clarified that the fit-and-proper attestation is made with the Code attestation by 31 October, added the written decision and review timelines and a list of outcomes. |
| 2.0 | 2023-10-01 | Previous version. Introduced the 2-business-day disclosure rule and the conduct standards. |
