# Commercial Banking Analyst

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1012 |
| Title | Commercial Banking Analyst |
| Document type | Job description |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-08-25 |
| Next review | 2027-08-25 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-POL-002, HR-POL-017, HR-POL-018 |

## 1. Role summary

The Commercial Banking Analyst supports Relationship Managers in serving mid-sized and larger commercial clients. The Analyst spreads financial statements, analyzes borrower performance, prepares credit submissions and manages the documentation and administration of credit facilities. The role is a proving ground for commercial banking talent, offering exposure to client conversations, structuring and credit risk. This is a Band 3 (Professional) role in the Commercial Banking family; see HR-GDE-006 Job Architecture and Pay Bands Guide.

## 2. Key responsibilities

- Spread and analyze client financial statements, tax filings, projections and borrowing base certificates.
- Prepare credit memoranda and annual reviews, with clear risk ratings and supporting analysis, for the Relationship Manager's review.
- Monitor covenant compliance and early-warning indicators and alert the Senior Relationship Manager to concerns.
- Coordinate loan documentation, security registration and conditions precedent with Legal and credit administration.
- Prepare client meeting materials, pipeline reports and portfolio summaries.
- Research industries, competitors and market trends relevant to assigned clients.
- Respond to client requests for statements, confirmations and simple facility changes within delegated authority.
- Maintain accurate client files and records in line with Bank retention and privacy requirements.
- Apply anti-money-laundering, know-your-client and sanctions procedures for commercial clients.
- Contribute to team processes and tools that improve turnaround time and data quality.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in finance, accounting, economics or business, or equivalent experience.
- Two to five years of experience in commercial banking, credit analysis, corporate finance or accounting.
- Strong skills in financial statement analysis and spreadsheet modelling.
- Clear written communication and attention to detail.
- Satisfactory results in pre-employment screening, including credit check for roles with financial authority.

### 3.2 Preferred

- Progress towards or completion of the CFA program or a credit analysis designation.
- Experience with commercial lending systems and risk rating methodologies.
- Fluency in English and French.

### 3.3 Licences and certifications

No licence is required. Professional designations such as the CFA are supported under the Bank's learning policy (HR-POL-012 Learning and Development Policy).

## 4. Competencies

Competencies are defined in HR-FWK-001 Competency and Leadership Model; this role works at the Practitioner level.

- **Judgement and Decision Quality**: reaches sound credit conclusions from incomplete information.
- **Customer Obsession**: understands client businesses and anticipates their needs.
- **Risk and Conduct Awareness**: applies credit, know-your-client and confidentiality standards.
- **Drive for Results**: delivers accurate analysis and documentation on deadline.
- **Collaboration**: works well with relationship managers, credit and legal partners.
- **Adaptability**: handles shifting priorities across several clients.

## 5. Compensation and classification

| Item | Detail |
| --- | --- |
| Band | 3 (Professional) |
| Canada salary range | $56,000 to $84,000 CAD per year |
| US salary range | $55,000 to $82,000 USD per year |
| Incentive target | Annual Incentive Plan (AIP): 5% of base salary |
| Overtime eligibility (Canada) | Yes (non-managerial Band 1 to 4 role) |
| FLSA classification (US) | Exempt |
| Work arrangement | Hybrid: at least 3 days a week in the office |

## 6. Working conditions and accessibility

This is a hybrid office role with occasional client visits. Hybrid arrangements follow HR-POL-002 Remote and Hybrid Work Policy, with at least 3 days a week in the office and anchor days on Tuesday and Thursday. Client and credit data must be handled according to HR-POL-017 IT Acceptable Use and Information Security Policy. The Bank provides accommodation to the point of undue hardship (Canada) or reasonable accommodation (US); see HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to the Senior Relationship Manager.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-03-01 | Pay ranges updated to the 2026 pay bands; hybrid requirement aligned to HR-POL-002 v3.0 |
| 1.0 | 2024-05-06 | First issue |
