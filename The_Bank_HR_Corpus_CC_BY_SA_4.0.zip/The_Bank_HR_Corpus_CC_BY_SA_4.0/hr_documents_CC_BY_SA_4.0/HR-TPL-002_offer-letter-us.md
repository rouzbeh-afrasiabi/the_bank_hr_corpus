# Offer Letter (US)

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-TPL-002 |
| Title | Offer Letter (US) |
| Document type | Template |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-06-30 |
| Next review | 2027-06-30 |
| Policy owner | VP HR Operations |
| Audience | HR only |
| Jurisdiction | US |
| Language | English |
| Related documents | HR-POL-019, HR-POL-020, HR-POL-003, HR-TPL-001 |

## 1. Purpose and when to use this template

This template is the standard offer of employment for a regular full-time, regular part-time or fixed-term employee hired in the US. It is issued by HR Operations after the offer has been approved under HR-POL-019 Recruitment and Selection Policy. For Canadian hires use HR-TPL-001 Offer Letter (Canada).

## 2. How to use this template

1. Confirm the requisition approval and that the salary is inside the US pay range for the band in `pay_bands.csv`.
2. Confirm the classification under the Fair Labor Standards Act (non-exempt or exempt) with HR Operations; see HR-POL-003 Working Hours and Overtime Policy.
3. Replace every `[placeholder]` and delete the options that do not apply.
4. Send the letter from MyHR. The offer is valid for 5 business days from the date sent.
5. If the work state is California, attach the California Supplement notices (HR-SUP-002 California Supplement).

## 3. Letter text

**[Date]**

**[Candidate full name]**
[Candidate address]

**Subject: Offer of employment, [Job title], Band [Band]**

Dear [Candidate first name],

We are pleased to offer you employment with the Bank as **[Job title]** in **[Business unit]**, reporting to **[Manager name]**. Your work location is **[Work location, state]** and your work arrangement is **[On-site / Hybrid / Remote]**. Your start date is **[Start date]**.

**Compensation.** Your annual base salary is **[Base salary] USD**, paid biweekly in arrears by direct deposit on Fridays. Your position is classified as **[Exempt / Non-exempt]** under the Fair Labor Standards Act. If non-exempt, you will record your hours in Time Tracker and receive overtime as set out in HR-POL-003. You are eligible for the Annual Incentive Plan with a target of **[AIP target %]** of base salary for Band **[Band]**, subject to the plan terms, including being hired on or before 31 July of the fiscal year and being on payroll on 31 October and on the payment date.

**Probation.** Your first 3 months of employment are a probation period, which may be extended once to 6 months by written notice before the end of month 3.

**Benefits and savings.** You are eligible for health, dental, vision and life coverage from your first day. Enrol within 31 days of your start date; if you make no election you are placed in Choice PPO, employee-only coverage. You are eligible for the Bank US 401(k) Savings Plan; you are automatically enrolled at 5% after 30 days unless you opt out.

**Time off.** You are entitled to **[Vacation days]** vacation days in your first calendar year, pro-rated from your start date and rounded up to the nearest half day (15 days a year in the first 3 years of service). You also receive 8 paid sick days and 3 personal days per calendar year, pro-rated in your first year, and 11 paid Bank holidays. Your standard work week is 40 hours.

**Conditions of this offer.** This offer is conditional on satisfactory pre-employment screening under HR-POL-020 Pre-Employment Screening Policy, which starts only after this conditional offer and for which you will receive FORM-HR-111 Consent to Pre-Employment Screening. On or before your third business day you must complete Form I-9 and provide the documents it requires, and complete Form W-4 and your state withholding form.

**At-will employment.** Your employment is at will. You or the Bank may end the employment at any time, with or without cause or notice, and nothing in this letter creates a contract for a fixed term. If you resign, the Bank asks you to give the notice for your band set out in HR-POL-015 Resignation and Offboarding Policy. Any severance is governed by HR-POL-025 Involuntary Termination and Severance Policy as in force at the time.

**Confidentiality and policies.** You will keep Bank and client information confidential during and after your employment, and you agree to follow Bank policies, including the Code of Conduct and Ethics, and to complete mandatory training and the Code attestation within 30 days of your start date.

This offer is open for acceptance for **5 business days** from the date above. To accept, sign and return this letter through MyHR.

Sincerely,
**[Hiring manager name]**, [Hiring manager title]
**[Recruiter name]**, Talent Acquisition

I accept this offer. Signature: ____________  Date: ____________

## 4. Required clauses checklist

| Clause | Required content |
| --- | --- |
| Compensation | Base salary, FLSA classification, pay frequency, AIP target by band |
| Probation | 3 months, one extension to 6 months |
| Benefits | From day 1, enrol within 31 days, default Choice PPO employee-only |
| Vacation | Entitlement for the first year, pro-rated |
| Conditions | Screening after the conditional offer, Form I-9 within 3 business days |
| At-will | Statement of at-will employment |
| Validity | 5 business days |

## 5. Drafting notes for HR

- AIP target by band: B1 5%, B2 5%, B3 5%, B4 8%, B5 10%, B6 15%, B7 20%, B8 30%, B9 45%. Sales incentive roles use the target in HR-PLN-002 Advisor and Sales Incentive Plan Document (8%, 10%, 12% or 20%).
- Fair-chance rules apply: do not ask about criminal history before the conditional offer.
- Do not state a notice period or severance amount in the letter; at-will wording must not be weakened.
- Add state or local notices (for example pay transparency) required for the work location; confirm with Legal.
- Pay ranges are shown in postings and on request before the first interview (HR-POL-037 Pay Transparency Policy).

## 6. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.0 | 2023-04-03 | First standard US offer letter |
| 2.0 | 2025-09-01 | Added FLSA classification, fair-chance screening wording and the 5-business-day validity period |
