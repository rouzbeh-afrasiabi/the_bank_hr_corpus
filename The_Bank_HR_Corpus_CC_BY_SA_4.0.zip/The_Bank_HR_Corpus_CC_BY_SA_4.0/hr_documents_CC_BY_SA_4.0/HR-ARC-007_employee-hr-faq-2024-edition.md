# Employee HR FAQ (2024 edition)

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

> **Archived version.** Kept for reference only. Do not rely on it. See HR-FAQ-001 Employee HR FAQ.

| Field | Value |
| --- | --- |
| Document ID | HR-ARC-007 |
| Title | Employee HR FAQ (2024 edition) |
| Document type | Archived version |
| Version | 2024.2 |
| Status | Superseded |
| Superseded by | HR-FAQ-001 Employee HR FAQ, version 2026.3 (effective 2026-10-26) |
| Effective date | 2024-09-02 |
| Last reviewed | Not applicable |
| Next review | Not applicable |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-FAQ-001, HR-POL-002, HR-POL-003, HR-POL-006, HR-POL-007, HR-POL-008, HR-POL-013 |

## 1. Status of this version

This is the 2024 edition (version 2024.2) of the Employee HR FAQ. It was in force from 2 September 2024 until it was replaced by later editions, the latest being HR-FAQ-001 Employee HR FAQ (version 2026.3). It quotes the values that applied in 2024. Several of those values have since changed, so do not rely on the answers below. Each answer names the policy that owned the rule at the time.

## 2. Purpose and scope

This FAQ gave plain-language answers to common employee questions in Canada and the US. If the FAQ and the owning policy differed, the owning policy applied. Where applicable law gave a greater right, the law applied. Questions not covered went to HR Connect at 1-800-555-0142 or hrconnect@bank.example.

## 3. Working arrangements and hours

### How many days a week must I be in the office?

Hybrid employees attended the office at least 2 days a week. There were no anchor days; you and your manager agreed which days and recorded them on FORM-HR-030. See HR-POL-002 Remote and Hybrid Work Policy (then version 2.1).

### Can I work from home full time?

Only if your role was designated remote-eligible and you were approved on FORM-HR-030. You needed to have passed probation, hold a Meets Expectations rating or higher, have no active performance improvement plan, and live in an approved jurisdiction. See HR-POL-002.

### How many days could I skip the office?

Your manager could approve up to 12 office-attendance exception days per calendar year. More than 12 needed your HRBP. See HR-POL-002.

### Can I work from somewhere else for a short time?

Up to 20 working days per calendar year within your home country, requested on FORM-HR-031 at least 5 business days ahead, and up to 10 working days across the Canada-US border, requested at least 10 business days ahead. See HR-POL-002.

### How long is my standard work week?

Canada 37.5 hours (7.5 per day) and the US 40 hours (8 per day), each with a 60-minute unpaid meal period. Core hours for office staff were 10:00 to 15:00 local time. See HR-POL-003 Working Hours and Overtime Policy.

### When does overtime need approval?

Overtime had to be pre-approved by your manager in Time Tracker. Working more than 10 overtime hours in a week also needed Director approval and HR notification. See HR-POL-003 (then version 4.1).

### Can I take time off instead of overtime pay?

In Canada, with manager approval on FORM-HR-020, at 1.5 hours off per overtime hour. The bank cap was 40 hours and the time had to be taken within 3 months, or it was paid out. US non-exempt employees were paid cash only. See HR-POL-003.

## 4. Time off and leaves

### How much vacation do I get?

15 days (under 3 years of completed service), 20 days (3 to under 10 years), 25 days (10 to under 20 years) or 30 days (20 years or more), in both countries. See HR-POL-006 Vacation and Paid Time Off Policy.

### Can I carry vacation into next year?

Up to 3 days could be carried over and had to be used by 31 March. The rest was forfeited unless you were on approved leave or the law required payment. See HR-POL-006 (then version 3.0).

### How many sick days do I get?

Canada 8 paid sick days per calendar year and the US 6, pro-rated for new hires. Up to 5 could be used for family care. See HR-POL-007 Sick Leave and Personal Leave Policy (then version 2.2).

### Do I need a doctor's note?

A medical certificate was needed from the 4th consecutive working day of absence, or after 3 consecutive days in Quebec. See HR-POL-007.

### What are personal days?

Three per calendar year for any reason, with 24 hours' notice where possible, no certificate and no carryover. See HR-POL-007.

### How long is parental leave in Canada?

Pregnancy leave of up to 17 weeks with a Bank top-up to 100% of base salary for those 17 weeks after 6 months of service. Non-birth, adoptive and surrogacy-intended parents received a top-up to 100% for 6 weeks. See HR-POL-008 Parental and Family Leave Policy.

### How long is paid parental leave in the US?

8 weeks at 100% of base salary for any new parent (birth, adoption or foster), running together with FMLA and any state paid family leave program. See HR-POL-008.

## 5. Pay, performance and learning

### When do I get paid?

Biweekly in arrears: Thursdays in Canada and Fridays in the US. Your pay statement was in MyHR 2 business days before the pay date. See HR-POL-009.

### Who do I call if my pay is short?

HR Connect at 1-800-555-0142, or file FORM-HR-021 in the HR Case Portal. A net shortfall of $200 or more was paid off-cycle within 3 business days of confirmation; smaller amounts were corrected on the next regular pay date. See HR-POL-009 Compensation and Payroll Policy.

### What is a PIP and how long does it last?

A performance improvement plan: 90 days as standard (range 30 to 120 days), with weekly check-ins, a written plan on FORM-HR-070, and a support person who is not legal counsel if you wish. See HR-POL-013 Performance Improvement Policy (then version 2.0).

### How much does the Bank pay for tuition?

Tuition reimbursement of up to $4,000 CAD per fiscal year for Canadian employees, after 6 months of service with a Meets Expectations rating or higher. Pre-approve on FORM-HR-060 at least 15 business days ahead. See HR-POL-012 Learning and Development Policy.

## 6. Conduct and getting help

### Can I accept a gift from a client?

Gifts of up to $150 per occasion were allowed, with no cumulative annual cap. Above $150 you needed pre-approval on FORM-HR-101. Never cash or gift cards. See HR-POL-001 Code of Conduct and Ethics.

### How do I reach HR?

HR Connect: 1-800-555-0142, hrconnect@bank.example, Monday to Friday 8:00 to 20:00 Eastern Time. Managers could call the Manager Hotline at 1-800-555-0143. See HR-GDE-004 HR Service and Support Guide.

## 7. Related documents

HR-FAQ-001 Employee HR FAQ (current). The policies named in each answer have current versions that may differ from the values above.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2024.1 | 2024-01-02 | Annual refresh of the 2024 edition |
| 2024.2 | 2024-09-02 | Updated answers on overtime approval and tuition reimbursement |
| 2026.1 | 2026-01-05 | Superseded by the 2026 editions (see HR-FAQ-001) |
