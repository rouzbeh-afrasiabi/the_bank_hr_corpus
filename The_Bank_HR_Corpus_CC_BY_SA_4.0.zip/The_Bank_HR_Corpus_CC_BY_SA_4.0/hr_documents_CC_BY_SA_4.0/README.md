# Synthetic bank HR documents

A set of 262 fictional HR documents and 13 data tables for a bank with employees in Canada and the US.
They are written for retrieval and question-answering experiments, such as the agent-native retrieval. Nothing here is the policy of a real organization, and no
real organization, person or phone number is named. Every document says so at the top. The employee roster
identifies fictional employees by number only.

The corpus holds about 290,000 words (about 1.7 million characters, roughly 430,000 tokens), which is too large to
fit in a model's context window, so a question needs retrieval.

## What is here

| Type | ID prefix | Count | What it holds |
| --- | --- | ---: | --- |
| Policy | `HR-POL-###` | 44 | Conduct, work arrangements, hours and overtime, leaves, pay, performance, privacy, security, accommodation, discipline, termination, staff banking, licensing, personal trading, clawback, monitoring, equity, travel, relocation, and more |
| Plan document | `HR-PLN-###` | 8 | Incentive plans, benefits booklet, pension and 401(k) plan texts, claims and appeals, sample total rewards statement |
| Guide | `HR-GDE-###` | 6 | Benefits, retirement, onboarding, HR service, manager procedures, job architecture and pay bands |
| Framework | `HR-FWK-###` | 4 | Competency model, career paths, talent review and succession, engagement survey |
| Procedure (HR only) | `HR-PRC-###` | 8 | Case handling, investigations, payroll runbook, terminations, calibration, leaves, accommodation, privacy requests |
| Supplement | `HR-SUP-###` | 4 | Quebec (in French), California, Capital Markets, branch scheduling |
| Governance minutes | `HR-GOV-###` | 4 | HR Policy Committee decisions that explain policy changes |
| Template | `HR-TPL-###` | 10 | Offer letters, agreement terms, termination, warning, PIP, verification and other letters |
| Memo | `HR-MEMO-YYYY-###` | 19 | Dated announcements of changes and reminders, one superseded |
| Archived version | `HR-ARC-###` | 7 | Superseded policy versions and a 2024 FAQ with the old values |
| Draft | `HR-DRAFT-###` | 2 | Proposals that are not approved and not in effect |
| FAQ | `HR-FAQ-###` | 2 | Plain-language employee FAQ and a French FAQ for Quebec |
| Reference | `HR-REF-###` | 4 | Glossary, retention schedule, Canada and US jurisdiction quick references |
| Form | `FORM-HR-###` | 37 | The forms the policies cite, as an employee sees them |
| How-to article | `HOW-###` | 50 | Step-by-step instructions for one task, three in French |
| Job description | `JD-####` | 53 | Roles across the business units, tied to the nine pay bands |

Every document starts with a metadata table: Document ID, Document type, Version, Status (Current, Superseded or
Draft), Effective date, review dates, owner, Audience (Employees, Managers, HR only or HR leadership), Jurisdiction
and Language (English or French).

## Data tables

| File | Rows | What it holds |
| --- | ---: | --- |
| `policy_register.csv` | 262 | One row per document, generated from the documents' own metadata |
| `pay_bands.csv` | 9 | Salary ranges, incentive targets and overtime eligibility by band |
| `job_catalogue.csv` | 53 | Each job's band, family, reporting line, pay ranges and classification |
| `forms_catalogue.csv` | 37 | Each form and its owning policy |
| `holidays_2026.csv` | 159 | Paid holidays by province, territory and the US |
| `pay_dates_2026.csv` | 52 | Biweekly pay dates for Canada and the US |
| `benefit_premiums_2026.csv` | 10 | Employee premiums by plan |
| `hr_directory.csv` | 12 | HR contact points and hours |
| `training_catalogue.csv` | 7 | Mandatory training |
| `compliance_calendar.csv` | 23 | Recurring HR deadlines |
| `employee_roster.csv` | 400 | Fictional employees by number, with job, location, status and hire date |
| `leave_balances_2026.csv` | 400 | 2026 leave entitlements and use, as of 2026-10-26 |
| `policy_exceptions_log.csv` | 30 | Policy exceptions, HR only |

[`profile.yaml`](profile.yaml) describes all of this for RI #5's tool generator (`find_identifier`, `outline`,
`open_section`, `sql`). The tables are generated with a fixed seed from the same facts as the documents:



## Built-in features for testing

- **Changed values.** Hybrid work moved from 2 to 3 office days, Canadian sick days from 8 to 10 (US 6 to 8),
  vacation carryover from 3 to 5 days, the performance improvement plan from 90 to 60 days, the overtime
  approval threshold from 10 to 8 hours, the tuition cap from $4,000 to $5,000, and parental leave top-ups.
  Memos, committee minutes and archived versions record each change, so an out-of-date answer can be told from
  the current one.
- **Traps.** Archived versions and drafts quote values that are not in force. A superseded memo states an old
  carryover rule.
- **Rules that differ** by country, province or state, and by job band.
- **Answers that span documents:** a policy, its form, its how-to article, its memo and a quick-reference table.
- **Audience.** HR-only procedures, the exceptions log, templates and leadership minutes are not for employees,
  so an employee-facing assistant should refuse to expose them.
- **Plain-language vocabulary.** The FAQs and how-to articles use everyday words ("PTO", "mat leave", "raise")
  that differ from the policy wording.
- **French.** The Quebec supplement, the Quebec FAQ and three how-to articles are in French.
- **Unanswerable questions.** The FAQs include questions the documents do not answer.
- **Structured lookups.** Holidays by province, pay dates, premiums, pay bands and fictional employees' leave
  balances answer questions that need a table rather than a paragraph.

## Using the documents

- Point at this folder (`FOLDER`, `PATTERNS = ("HR-*.md", "FORM-HR-*.md", "HOW-*.md", "JD-*.md")`), or load `profile.yaml`.
- This README is not a corpus document, and the patterns above exclude it.

## Conventions

The fictional organization is "the Bank". Spelling is Canadian English. Amounts are CAD for Canada and USD for the
US. The fiscal and performance year runs 1 November to 31 October; vacation, sick days, personal days and benefits
run on the calendar year. The documents describe the position as of 26 October 2026.
