# Data Protection Impact Assessment

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-092 |
| Title | Data Protection Impact Assessment |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-02-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | Chief Privacy Officer |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-016, HR-POL-017, HR-POL-019, FORM-HR-091, HR-MEMO-2026-004, HR-PRC-008 |

## 1. Purpose and when to use this form

A Data Protection Impact Assessment (DPIA) is a deeper assessment required, in addition to a PIA (FORM-HR-091 Privacy Impact Assessment), for high-risk processing of employee information under HR-POL-016 Employee Data Privacy Policy:

- employee monitoring;
- biometrics;
- automated or AI-assisted decisions about employees;
- large-scale sensitive data (health, disability, biometric or diversity self-identification); or
- cross-border transfers.

Every AI-assisted HR use needs a DPIA (see HR-MEMO-2026-004).

## 2. Who completes it and who approves

The system owner completes it with the Privacy Office. The Privacy Office, the CISO and Legal review it. The Privacy Governance Committee decides.

## 3. Where and when to submit (deadline, channel, processing time)

Submit in the HR Case Portal (Privacy > Impact Assessment) or email privacy@bank.example. The Privacy Governance Committee decides within 30 days, so the project plan must allow for that period; a system may not go live without a decision. A DPIA is reassessed annually.

## 4. Form fields

### 4.1 Project details

| Field | Required | Notes |
| --- | --- | --- |
| Project name, system owner, PIA reference | Yes | The PIA is completed first |
| High-risk trigger | Yes | Monitoring, biometrics, automated or AI-assisted decisions, large-scale sensitive data, cross-border transfer |
| Planned go-live date | Yes | Allow for the 30-day decision |

### 4.2 Questions

| No. | Question | Required |
| --- | --- | --- |
| 1 | What is the documented purpose, and why can a less intrusive option not achieve it? | Yes |
| 2 | Which individuals and how many are affected, and which sensitive data is used? | Yes |
| 3 | For monitoring: what is monitored, is it disclosed to employees, and how is covert monitoring excluded? | If monitoring |
| 4 | For biometrics: what is collected, where is the template stored, and what is the alternative for employees who prefer not to use it? | If biometrics |
| 5 | For automated or AI-assisted decisions: what does the tool recommend, what data does it use, and is it a Bank-approved tool? | If AI |
| 6 | Who makes the final decision on any employment outcome? A human must; name the role. | If AI |
| 7 | How are bias, fairness and explainability tested, and how can an employee ask for an explanation of the tool's contribution? | If AI |
| 8 | For cross-border transfers: which countries, which vendor, which contract safeguards, and how is the employee notice updated? | If transfer |
| 9 | Who has access, under what documented reason, and how is access logged and reviewed? | Yes |
| 10 | What technical safeguards apply (HR-POL-017 IT Acceptable Use and Information Security Policy)? | Yes |
| 11 | How long is data kept and how is it destroyed? | Yes |
| 12 | How can employees see, correct and challenge their data? | Yes |
| 13 | What are the residual risks, their likelihood and severity, and the mitigations? | Yes |

## 5. Declarations and signatures

I confirm that the answers are complete, that no hiring, rating, discipline, pay or termination decision will be made without a human decision-maker, and that the system will not go live before the Committee decides. System owner signature and date: ____________. CISO review and date: ____________. Legal review and date: ____________.

## 6. What happens next

The Privacy Office coordinates the review and presents the DPIA to the Privacy Governance Committee, which approves, approves with conditions, or declines. Conditions are tracked until met. AI screening tools may never be the sole basis for rejecting a candidate (see HR-POL-019 Recruitment and Selection Policy).

## 7. Related documents

- HR-POL-016 Employee Data Privacy Policy
- FORM-HR-091 Privacy Impact Assessment
- HR-POL-019 Recruitment and Selection Policy

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-02-01 | Added AI and biometric question sets and the annual reassessment. |
| 1.0 | 2024-02-01 | Initial form. |
