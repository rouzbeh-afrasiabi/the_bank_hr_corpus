# Resignation Notice

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-080 |
| Title | Resignation Notice |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-10-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-015, HR-POL-006, HR-GDE-006, FORM-HR-081, FORM-HR-082, HR-TPL-010 |

## 1. Purpose and when to use this form

Use this form to give written notice that you are resigning or retiring from the Bank. It is the only accepted way to start a resignation under HR-POL-015 Resignation and Offboarding Policy. It is not used for involuntary exits.

## 2. Who completes it and who approves

You complete it. Your manager receives it and informs the HRBP the same day. HR Operations acknowledges it. A resignation needs no approval, but shortened notice needs written agreement, and withdrawal needs the written agreement of your manager and HRBP before your last day of employment.

## 3. Where and when to submit (deadline, channel, processing time)

Submit in MyHR (Employment > Resignation Notice) to your manager and HR Operations. The notice period starts the day after you submit.

| Job band | Notice period |
| --- | --- |
| Bands 1 to 4 | 2 weeks |
| Bands 5 and 6 | 4 weeks |
| Bands 7 and above | 8 weeks |

Retirement requires at least 3 months' notice. HR Operations acknowledges within 2 business days. If you have no acknowledgement by then, contact HR Connect (1-800-555-0142).

## 4. Form fields

| Field | Required | Notes |
| --- | --- | --- |
| Full name and employee ID | Yes | Pre-filled from MyHR |
| Band, business unit, manager | Yes | Pre-filled; the band sets your notice period |
| Province or state of work | Yes | Sets the final pay deadline |
| Type of notice | Yes | Resignation or Retirement |
| Date notice is given | Yes | Today's date |
| Proposed last day of employment | Yes | Must meet the notice period; HR Operations confirms it |
| Reason for leaving | No | Optional |
| Personal mailing address and email | Yes | Used for tax slips and the Record of Employment |
| Request for shortened notice | No | Explain; needs written agreement |

## 5. Declarations and signatures

By signing, I confirm that:

- the information is accurate;
- I will return all equipment within 5 business days after my last day;
- the Annual Incentive Plan is paid only to employees on payroll on the payment date;
- I repay 100% of tuition reimbursed in the last 12 months (HR-POL-012 Learning and Development Policy);
- confidentiality and other continuing obligations apply after I leave.

Employee signature and date: ____________. Manager acknowledgement and date: ____________.

## 6. What happens next

HR Operations acknowledges in writing, opens FORM-HR-081 Offboarding Checklist, and your manager agrees a handover plan with you within 3 business days. You are offered a voluntary exit interview in your final week (FORM-HR-082). System access ends at 17:00 on your last day. Final pay is issued on the next regular pay date, never later than the legal deadline for your province or state.

## 7. Related documents

- HR-POL-015 Resignation and Offboarding Policy
- HR-POL-006 Vacation and Paid Time Off Policy
- HR-GDE-006 Job Architecture and Pay Bands Guide

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-10-01 | Added retirement option, final pay deadline field and declarations. |
| 1.0 | 2020-06-01 | Initial form. |
