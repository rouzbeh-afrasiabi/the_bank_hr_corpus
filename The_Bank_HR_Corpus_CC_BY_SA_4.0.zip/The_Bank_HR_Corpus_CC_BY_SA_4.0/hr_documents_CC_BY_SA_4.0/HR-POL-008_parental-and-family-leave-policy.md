# Parental and Family Leave Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-008 |
| Title | Parental and Family Leave Policy |
| Document type | Policy |
| Version | 5.1 |
| Status | Current |
| Effective date | 2025-11-01 |
| Last reviewed | 2026-08-03 |
| Next review | 2027-08-03 |
| Policy owner | SVP Total Rewards |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Applies to | All Canadian and US employees (see Scope) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-007, HR-POL-009, HR-POL-018, FORM-HR-012, FORM-HR-013 |

## 1. Purpose

This policy describes the leave and Bank-paid top-up available to employees who become parents, and the unpaid leave available to employees who must care for a family member. It explains how Bank pay is coordinated with government benefits. Where applicable law gives a greater right, the law applies.

## 2. Scope and definitions

### 2.1 Scope

The policy applies to regular full-time and regular part-time employees in Canada and the US, and to fixed-term employees with a contract of 6 months or more. Statutory leave rights apply to every employee whatever their category.

### 2.2 Definitions

- **Birth parent:** the person who gives birth to the child.
- **Non-birth parent:** a parent who does not give birth, including a spouse or partner.
- **Adoptive parent:** a person who adopts a child, including in the US a foster placement.
- **Surrogacy-intended parent:** a person who is the intended parent of a child born through a surrogacy arrangement.
- **Top-up:** the amount the Bank pays so that total pay equals 100% of base salary.
- **Leaves team:** the Tier 2 specialist team in HR Operations that administers leaves.

## 3. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Employee | Give notice, apply to the government programs, and tell the Leaves team of any government benefit received. |
| Manager | Plan coverage, keep contact limited and respectful, and agree the phased return. |
| Leaves team | Confirms eligibility, calculates the top-up, and tracks dates and return notices. |
| Payroll Services | Pays the top-up and keeps retirement contributions and benefits correct. |
| Benefits Administration | Maintains benefit coverage during leave. |
| HR Business Partner (HRBP) | Resolves exceptions and return-to-role issues. |

## 4. Canada

Eligibility for the Bank top-up is 6 months of continuous service. Employees with less service are entitled to the leave allowed by law but receive no top-up.

| Parent | Job-protected leave | Bank top-up to 100% of base salary |
| --- | --- | --- |
| Birth parent, pregnancy leave | Up to 17 weeks; may start up to 13 weeks before the due date | 17 weeks |
| Birth parent, parental leave | Total job-protected leave up to 18 months combined | Included in the 17 weeks above |
| Non-birth parent | Parental leave under applicable law, up to 18 months | 8 weeks |
| Adoptive parent | Same as non-birth parent | 8 weeks |
| Surrogacy-intended parent | Same as non-birth parent | 8 weeks |

Parental leave must begin within 78 weeks of the birth or placement. In Quebec the government benefit is paid by the Quebec Parental Insurance Plan; elsewhere it is paid under Employment Insurance. The government benefit is paid by the government, and the Bank cannot guarantee it.

### 4.1 How the top-up works

During the top-up period the Bank pays the difference between the government benefit and 100% of base salary, so total pay equals 100%. In any week where the employee receives no government benefit, such as a waiting week, the Bank pays 100% of base salary for weeks inside the top-up period. Employees must apply to the government as early as possible and give the Leaves team the benefit notice within 5 business days of receiving it. The Bank adjusts the top-up if the government benefit changes.

## 5. United States

| Item | Entitlement |
| --- | --- |
| Paid parental leave | 12 weeks at 100% of base salary for any new parent (birth, adoption or foster) |
| Job protection | 12 weeks under the Family and Medical Leave Act (FMLA) |
| FMLA eligibility | 12 months of service, 1,250 hours worked and 50 employees within 75 miles |
| Birth parent medical recovery | Short-term disability, up to 6 weeks (vaginal birth) or 8 weeks (caesarean) |

The 12 weeks of paid leave run concurrently with FMLA leave and with any state paid family leave program. Where a state program pays a benefit, the Bank pays the balance so that total pay equals 100% of base salary. Medical recovery is paid under short-term disability as described in HR-POL-007 Sick Leave and Personal Leave Policy. The Leaves team confirms the sequence of the two entitlements in writing. An employee who is not eligible for FMLA still receives the 12 weeks of Bank-paid leave and the Bank holds the role for the same period.

## 6. Notice and application

- **Start of leave:** give notice at least 4 weeks before the leave starts where possible, using FORM-HR-012 Parental Leave Notice and Top-Up Application. If the leave starts unexpectedly, give notice as soon as practicable.
- **Evidence:** a medical certificate showing the due date, or placement or adoption documents, or a surrogacy agreement, submitted to the Leaves team. These are held confidentially.
- **Return:** give 4 weeks' notice of the return date. If the employee wishes to return earlier than planned, the Leaves team will confirm the return within 5 business days.
- **Confirmation:** the Leaves team confirms the leave dates, the top-up amount and the return conditions in writing within 5 business days of receiving a complete application.

## 7. Adoption, foster care and surrogacy

Leave for an adoptive, foster or surrogacy-intended parent starts when the child is placed with the employee or when the employee assumes custody, and in some cases may start up to 2 weeks earlier for travel to complete an adoption. The Bank top-up and US paid leave rules are the same as for other parents. Documentation of the placement or arrangement should be submitted within 30 days of the placement.

## 8. Benefits and pay during leave

- The Bank continues its share of benefits during Bank-paid leave and, in Canada, throughout the job-protected leave of up to 18 months. Employees continue to pay their own share while on Bank-paid leave through payroll; during unpaid periods Benefits Administration arranges payment.
- Vacation accrual continues during the top-up period (see HR-POL-006 Vacation and Paid Time Off Policy).
- Retirement contributions continue on top-up pay.
- Bank-paid parental leave counts as earned salary for Annual Incentive Plan purposes (see HR-POL-009 Compensation and Payroll Policy).
- Service is continuous during the leave.

## 9. Return to work

An employee returns to the same or a comparable role at the same pay band. Where the role has changed, the manager and HRBP explain the changes before return. A **phased return** of up to 4 weeks at a reduced schedule of 80% of normal hours is available, paid for hours worked, arranged with the manager and the Leaves team. Employees who need accommodation when they return, for example for breastfeeding or lactation, should contact the Accommodation Specialist (HR-POL-018 Workplace Accommodation and Accessibility Policy).

## 10. Caregiver and family leave

Caregiver leave is unpaid and job-protected. It is requested on FORM-HR-013 Family Caregiver Leave Request, with a medical certificate supporting the need for care, where the law allows.

| Leave | Canada | US |
| --- | --- | --- |
| Compassionate care (seriously ill family member) | Up to 28 weeks | FMLA caregiver leave, up to 12 weeks |
| Critical illness of a child | Up to 37 weeks | FMLA, up to 12 weeks |
| Critical illness of an adult | Up to 17 weeks | FMLA, up to 12 weeks |
| Military caregiver | Not applicable | Up to 26 weeks |

Employees may use sick days for family care (up to 5 per calendar year, see HR-POL-007) and vacation during these leaves. Government caregiver benefits, where available, are applied for by the employee; the Bank does not top them up. Benefit arrangements during caregiver leave are described in HR-GDE-001 Employee Benefits Guide.

## 11. Worked example

A Canadian employee with 4 years of service earns $78,000 a year, or $1,500 a week, and is the birth parent. Assume (for illustration only) the government benefit is $650 a week. The Bank pays a top-up of $850 a week for 17 weeks, a total of $14,450, so the employee receives $1,500 a week. If the same employee were a non-birth parent, the top-up would last 8 weeks.

A US employee earning $104,000 a year ($2,000 a week) takes 12 weeks of parental leave. If a state program pays an illustrative $900 a week, the Bank pays $1,100, so total pay is $2,000 a week for 12 weeks, a total of $24,000.

## 12. Exceptions, consequences and contacts

Exceptions are approved by the SVP Total Rewards. Retaliation for taking leave is prohibited under HR-POL-001 Code of Conduct and Ethics. Questions: HR Connect, 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time, hrconnect@bank.example, or live chat in MyHR.

## 13. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 5.1 | 2025-11-01 | Canada top-up for non-birth, adoptive and surrogacy-intended parents increased from 6 weeks to 8 weeks. US paid parental leave increased from 8 weeks to 12 weeks. |
| 5.0 | 2024-11-01 | Non-birth parent top-up 6 weeks; US paid parental leave 8 weeks. Added surrogacy-intended parents. |
