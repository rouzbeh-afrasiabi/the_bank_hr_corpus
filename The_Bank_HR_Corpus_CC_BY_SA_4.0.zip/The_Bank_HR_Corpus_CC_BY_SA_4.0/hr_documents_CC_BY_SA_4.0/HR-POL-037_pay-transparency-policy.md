# Pay Transparency Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-037 |
| Title | Pay Transparency Policy |
| Document type | Policy |
| Version | 1.2 |
| Status | Current |
| Effective date | 2026-01-12 |
| Last reviewed | 2026-09-28 |
| Next review | 2027-09-28 |
| Policy owner | SVP Total Rewards |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-POL-019, HR-POL-009, HR-POL-024, HR-POL-016, HR-SUP-002 |

## 1. Purpose

The Bank believes that fair pay is easier to see and to defend when pay information is open. This policy sets out what the Bank discloses about pay ranges, what employees are free to say about their own pay, what the Bank will not ask candidates, and what HR staff and managers must keep confidential. Where applicable law gives a greater right, the law applies.

## 2. Scope

The policy applies to all employees and applicants in Canada and the US. It covers every internal and external job posting, every offer and every conversation about pay. Contractors and agency workers are not placed in bands and are outside this policy (see HR-POL-014 Employment Status and Classification Policy). Promotions and transfers are handled separately. State and provincial pay transparency laws may add requirements; for California see HR-SUP-002 California Supplement.

## 3. Definitions

| Term | Meaning |
| --- | --- |
| Pay range | The minimum and the maximum annual base salary of the band for the role, in the currency and for the jurisdiction where the role is based. |
| Band | One of the nine job levels in HR-GDE-006 Job Architecture and Pay Bands Guide. |
| Posting | An internal or external advertisement for a role, including a recruiter message that describes the role. |
| Salary history | What a candidate earns now or has earned in a past job, including benefits and incentive pay. |
| Pay secrecy | Any rule or request that stops employees from discussing or disclosing their pay. |
| AIP target | The target Annual Incentive Plan percentage for the band (see HR-POL-009 Compensation and Payroll Policy). |

## 4. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| SVP Total Rewards | Owns this policy and the band ranges held in `pay_bands.csv`. |
| Total Rewards | Verifies the range for every posting before it is published and answers range questions. |
| Recruiters | Publish the verified range in every posting and share it with candidates on request. |
| HRBPs | Check that offers fall within the range and advise managers. |
| Hiring managers | Never ask about salary history and never promise pay outside the range. |
| Managers | Explain an employee's band and range; never discourage pay discussions. |
| HR staff, Payroll Services and Benefits Administration | Keep the pay of other individuals confidential when it comes to them through their work. |
| Employees | Decide for themselves whether to share their own pay. |

## 5. Rules

### 5.1 Pay ranges in postings

The pay range appears in every internal and every external job posting. The range is the minimum and maximum of the band range for the jurisdiction of the role: Canada in CAD, US in USD (see HR-GDE-006 for the table and `pay_bands.csv` for the source of truth). The posting also shows the AIP target. A posting may not be published until Total Rewards has verified the range. Where a role can be filled in more than one jurisdiction, the posting shows the range for each. Postings remain open for at least 5 business days (see HR-POL-019 Recruitment and Selection Policy).

### 5.2 Ranges for candidates

A candidate may ask the recruiter to confirm the pay range at any time. The recruiter replies in writing within 1 business day. If the candidate asks before the first interview, the range is shown to them before that interview takes place. The Bank does not require a candidate to name an expectation first.

### 5.3 Salary history

The Bank does not ask candidates or employees about their salary history, in interviews, on application forms or through references or screening vendors (see HR-POL-020 Pre-Employment Screening Policy). If a candidate volunteers it, the recruiter does not record it and does not use it to set the offer.

### 5.4 Offers

Offers are made inside the range, usually between the minimum and the midpoint. An offer above the midpoint needs the approval of the HRBP and Total Rewards, as set out in HR-GDE-006. No offer is made below the minimum or above the maximum.

### 5.5 Employees' own pay

Employees may discuss and disclose their own pay with anyone, inside or outside the Bank, including colleagues, family and the press, subject to the confidentiality limit in section 5.6. There is no pay-secrecy rule. The Bank does not retaliate against an employee for asking about, discussing or disclosing pay, or for raising a concern about pay (see HR-POL-001 Code of Conduct and Ethics).

### 5.6 Confidentiality of other people's pay

Employees who learn another person's pay through their job, such as HR, Payroll Services, Benefits Administration, Total Rewards or managers who approve pay, must not disclose it, except as their role requires and as HR-POL-016 Employee Data Privacy Policy allows. The limit does not stop employees from sharing their own pay, or what a colleague has freely told them.

### 5.7 Seeing your own range

Employees can see the band and pay range for their own job in MyHR at any time. A manager explains where the employee's pay sits in the range when asked, within 10 business days of the request. An employee who believes the job is in the wrong band can ask the manager to raise a case in the HR Case Portal; Total Rewards responds within 15 business days (see HR-GDE-006).

## 6. Procedures and deadlines

| Step | Who | Deadline |
| --- | --- | --- |
| Verify the range before publication | Total Rewards | 1 business day from the recruiter's request |
| Publish the range in the posting | Recruiter | On the day the posting goes live |
| Provide the range to a candidate on request | Recruiter | Within 1 business day; before the first interview if asked earlier |
| Correct a wrong or missing range | Recruiter with Total Rewards | Within 1 business day of the error being reported; the posting is paused until fixed |
| Update ranges after the annual market review | Total Rewards | By 1 March, with the salary review (see HR-GDE-006) |
| Answer an employee's question about their range | Manager | Within 10 business days |
| Respond to a band review case | Total Rewards | Within 15 business days |

## 7. Exceptions

- A confidential search for an executive role may be shared with search firms without publication; the range is given to every candidate on request and before the first interview.
- Where a local law requires a different format, such as showing the range as an hourly figure for hourly roles, the recruiter follows the local rule and Total Rewards confirms the conversion.
- A posting for a role in a band that has been moved by a market update shows the new range from the effective date.
- No other exceptions to sections 5.1, 5.3 or 5.5 are available.

## 8. Worked examples

**A Canadian posting.** A Senior Analyst role in Band 4 in Ontario is posted with: "Pay range: $72,000 to $108,000 CAD per year. AIP target: 8% of base salary." The same Band 4 role in the US shows "$70,000 to $106,000 USD per year" and the same AIP target.

**A candidate asks before an interview.** A candidate emails the recruiter on Monday asking about the range for a role with a first interview on Thursday. The recruiter replies the same day or by Tuesday, within 1 business day, and the range is in the candidate's hands before the interview.

**An offer.** A candidate for a Band 3 role has experience above the minimum. The offer is within the range and below the midpoint, so the HRBP approves it as usual. If the recruiter wished to offer above the midpoint, Total Rewards would also need to approve.

**A colleague conversation.** An employee tells a team member how much they earn. The manager hears of it and tells them to stop. This is a breach of this policy by the manager. The employee has done nothing wrong and the manager must withdraw the instruction.

## 9. Consequences

Publishing a posting without a verified range, asking about salary history, telling an employee not to discuss their pay, or disclosing another person's pay without authority is a breach of this policy and may lead to corrective action under HR-POL-021 Employee Relations and Progressive Discipline Policy. Retaliation for discussing pay is serious misconduct. Concerns may be raised with HR Connect, the Ombuds Office or the Speak-Up Line.

## 10. Related documents

- HR-GDE-006 Job Architecture and Pay Bands Guide (band ranges and how to read a posting)
- HR-POL-019 Recruitment and Selection Policy
- HR-POL-009 Compensation and Payroll Policy
- HR-POL-024 Diversity, Equity, Inclusion and Belonging Policy
- HR-POL-034 Employment Equity and Pay Equity Policy
- HR-POL-016 Employee Data Privacy Policy

## 11. Contacts

| Need | Contact |
| --- | --- |
| Questions about pay ranges and bands | HR Connect, 1-800-555-0142, hrconnect@bank.example (Monday to Friday 8:00 to 20:00 Eastern Time) |
| Managers | Manager Hotline, 1-800-555-0143 |
| Confidential informal advice | Ombuds Office, ombuds@bank.example |
| Anonymous reports | Speak-Up Line, 1-800-555-0177 (24 hours, 7 days) |

## 12. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.2 | 2026-01-12 | The pay range now appears in every internal and external posting; employees may discuss and disclose their pay; the range is shown to candidates on request before the first interview; employees can see the range for their own band in MyHR. |
| 1.1 | 2025-03-03 | Added the salary history rule. |
| 1.0 | 2024-03-04 | First issue of the policy. |
