# How to use the Wellspring Support Program

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-043 |
| Title | How to use the Wellspring Support Program |
| Document type | How-to article |
| Version | 1.0 |
| Status | Current |
| Effective date | 2025-05-01 |
| Last reviewed | 2026-06-10 |
| Next review | 2027-06-10 |
| Policy owner | Head of Workplace Safety |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-023, HR-GDE-001, HR-POL-007 |

## 1. Short answer

Call the Wellspring Support Program at 1-800-555-0166, any time of day, for free and confidential counselling: up to 8 sessions per issue per calendar year for you and the members of your household.

## 2. Who this applies to

All employees in Canada and the US, including casual, student and fixed-term employees who are not eligible for other benefits, and the members of their households. Your manager is not told that you have used the program, and use is not reported to the Bank.

## 3. Steps

1. Call 1-800-555-0166 (24 hours a day, 7 days a week) or follow the Wellspring link in MyHR > Benefits.
2. Say that you are a Bank employee or a member of an employee's household. You do not need your manager's permission or a referral.
3. Describe what you need. Wellspring arranges counselling for personal, family or work stress, and gives legal, financial and elder-care referrals.
4. Book your sessions. Each separate issue has its own limit of 8 free sessions per calendar year.
5. If a session falls in your working hours, tell your manager you have an appointment; you do not have to say why. Medical appointments are a permitted use of sick days, with a minimum of half a day (see HR-POL-007 Sick Leave and Personal Leave Policy).
6. If you need more support than the program provides, ask the counsellor about options, including mental health practitioner coverage under your Maplewood Benefits plan (see HR-GDE-001 Employee Benefits Guide).

## 4. Deadlines

There is no application deadline. The 8-session limit is counted per issue per calendar year, from 1 January to 31 December. After a robbery or threat at a branch, employees are offered Wellspring support and a debrief within 24 hours.

## 5. What happens next

You and the counsellor agree a plan for your sessions. The service is confidential, and your use of it is not reported to the Bank. If the Bank-paid sessions run out for an issue, the counsellor can point you to other supports, and your benefit plan may reimburse part of the cost of a registered practitioner.

## 6. Common mistakes

- Waiting until a crisis. Call early; the line is open every day.
- Assuming your manager or HR will be told. They will not.
- Thinking you need to be on a benefits plan. Wellspring is open to every employee.
- Using Wellspring in an emergency. If anyone is in danger, call 911 first, then Corporate Security, 1-800-555-0119.

## 7. Who to call

- Wellspring Support Program: 1-800-555-0166 (24/7, confidential).
- Benefits and eligibility questions: HR Connect, 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time, hrconnect@bank.example.
- Practitioner claims: Maplewood Benefits claims line, 1-800-555-0190.
- Informal, confidential advice about work: Ombuds Office, ombuds@bank.example.

## 8. Related documents

- HR-POL-023 Workplace Health, Safety and Wellness Policy
- HR-GDE-001 Employee Benefits Guide
- HR-POL-007 Sick Leave and Personal Leave Policy

## 9. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.0 | 2025-05-01 | First edition, aligned with HR-POL-023 version 3.3. |
