# Parental and Family Leave Policy (version 5.0)

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

> **Archived version.** Kept for reference only. Do not rely on it. See HR-POL-008 Parental and Family Leave Policy.

| Field | Value |
| --- | --- |
| Document ID | HR-ARC-006 |
| Title | Parental and Family Leave Policy (version 5.0) |
| Document type | Archived version |
| Version | 5.0 |
| Status | Superseded |
| Superseded by | HR-POL-008 Parental and Family Leave Policy, version 5.1 (effective 2025-11-01) |
| Effective date | 2024-11-01 |
| Last reviewed | Not applicable |
| Next review | Not applicable |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-008, HR-POL-007, HR-POL-009, HR-POL-018, FORM-HR-012, FORM-HR-013 |

## 1. Status of this version

Version 5.0 was in force from 1 November 2024 to 31 October 2025. Version 5.1 replaced it on 1 November 2025 and increased two entitlements. Only the Canadian top-up for non-birth, adoptive and surrogacy-intended parents and the length of US paid parental leave differ from the current policy; all other rules shown here are the same as in HR-POL-008.

## 2. Purpose, scope and definitions

The policy described leave and Bank-paid top-up for employees who became parents, and unpaid leave to care for a family member, and how Bank pay was coordinated with government benefits. It applied to regular full-time and regular part-time employees and to fixed-term employees with a contract of 6 months or more, in Canada and the US. Statutory leave rights applied to every employee. Where applicable law gave a greater right, the law applied. The top-up was the amount the Bank paid so that total pay equalled 100% of base salary. The Leaves team administered leaves.

## 3. Canada (version 5.0)

Eligibility for the Bank top-up was 6 months of continuous service.

| Parent | Job-protected leave | Bank top-up to 100% of base salary |
| --- | --- | --- |
| Birth parent, pregnancy leave | Up to 17 weeks; may start up to 13 weeks before the due date | 17 weeks |
| Birth parent, parental leave | Total job-protected leave up to 18 months combined | Included in the 17 weeks above |
| Non-birth parent | Parental leave under applicable law, up to 18 months | **6 weeks** |
| Adoptive parent | Same as non-birth parent | **6 weeks** |
| Surrogacy-intended parent | Same as non-birth parent | **6 weeks** |

Parental leave had to begin within 78 weeks of the birth or placement. The government benefit was paid under Employment Insurance, or in Quebec the Quebec Parental Insurance Plan, and the Bank could not guarantee it. During the top-up period the Bank paid the difference between the government benefit and 100% of base salary. The employee gave the Leaves team the benefit notice within 5 business days of receiving it.

## 4. United States (version 5.0)

| Item | Entitlement |
| --- | --- |
| Paid parental leave | **8 weeks** at 100% of base salary for any new parent (birth, adoption or foster) |
| Job protection | 12 weeks under the Family and Medical Leave Act (FMLA) |
| FMLA eligibility | 12 months of service, 1,250 hours worked and 50 employees within 75 miles |
| Birth parent medical recovery | Short-term disability, up to 6 weeks (vaginal birth) or 8 weeks (caesarean) |

The paid weeks ran concurrently with FMLA leave and any state paid family leave program, and the Bank paid the balance so that total pay equalled 100% of base salary. Medical recovery was paid under short-term disability (HR-POL-007 Sick Leave and Personal Leave Policy). An employee not eligible for FMLA still received the Bank-paid leave and the Bank held the role for the same period.

## 5. Notice, benefits and return

- **Notice:** at least 4 weeks before the leave on FORM-HR-012 where possible; 4 weeks' notice of return. The Leaves team confirmed the leave in writing within 5 business days of a complete application.
- **Benefits:** the Bank continued its share of benefits during Bank-paid leave and, in Canada, throughout the job-protected leave of up to 18 months. Vacation accrual and retirement contributions continued during the top-up period (HR-POL-006 Vacation and Paid Time Off Policy). Bank-paid parental leave counted as earned salary for the Annual Incentive Plan (HR-POL-009 Compensation and Payroll Policy).
- **Return:** same or comparable role at the same pay band; phased return of up to 4 weeks at 80% of normal hours, paid for hours worked.

## 6. Caregiver and family leave

Unpaid and job-protected, on FORM-HR-013. Canada: compassionate care up to 28 weeks; critical illness of a child up to 37 weeks and of an adult up to 17 weeks. US: FMLA caregiver leave up to 12 weeks; military caregiver leave up to 26 weeks. Up to 5 sick days a calendar year could be used for family care.

## 7. Worked example (version 5.0)

A Canadian employee earning $78,000 a year ($1,500 a week) and receiving an illustrative government benefit of $650 a week was a non-birth parent. The Bank paid a top-up of $850 a week for 6 weeks, a total of $5,100. A US employee earning $104,000 a year ($2,000 a week) took 8 weeks of paid parental leave at 100% of base salary, a total of $16,000.

## 8. Exceptions and contacts

Exceptions were approved by the SVP Total Rewards. Questions: HR Connect, 1-800-555-0142, hrconnect@bank.example.

## 9. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 5.0 | 2024-11-01 | Non-birth parent top-up 6 weeks; US paid parental leave 8 weeks. Added surrogacy-intended parents. |
| 5.1 | 2025-11-01 | Superseded this version; non-birth top-up raised to 8 weeks and US paid leave to 12 weeks (see HR-POL-008) |
