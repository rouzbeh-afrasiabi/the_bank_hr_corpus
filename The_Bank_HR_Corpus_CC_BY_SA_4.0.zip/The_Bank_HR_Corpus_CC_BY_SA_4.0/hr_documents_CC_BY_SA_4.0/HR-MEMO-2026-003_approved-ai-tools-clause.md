# Approved AI Tools Only: New Clause in the IT Acceptable Use Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-MEMO-2026-003 |
| Title | Approved AI Tools Only: New Clause in the IT Acceptable Use Policy |
| Document type | Memo |
| Version | 1.0 |
| Status | Current |
| Effective date | 2026-03-30 |
| Last reviewed | Not applicable |
| Next review | Not applicable |
| Policy owner | Chief Information Security Officer |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-017, HR-POL-016, HR-POL-001 |

**Use only Bank-approved AI tools, and keep personal data out of public ones.**

**From:** Chief Information Security Officer

**To:** All employees and contractors in Canada and the US

**Date:** 30 March 2026

**Subject:** Approved AI tools clause, HR-POL-017 version 8.1, effective 1 April 2026

## 1. What is changing

HR-POL-017 IT Acceptable Use and Information Security Policy version 8.1 adds an AI clause. You may use only Bank-approved AI tools for Bank work. You must not enter client or employee personal data into public AI tools.

## 2. Who is affected

Everyone who uses Bank systems, including employees, contractors and agency workers.

## 3. Effective date

1 April 2026.

## 4. What to do

1. Before using an AI tool for work, confirm it is Bank-approved. If unsure, ask the Security Operations Centre.
2. Never paste client or employee personal data into a public AI tool. Confidential and Restricted data stay on Bank-issued devices.
3. If you think personal data was entered into an unapproved tool, report it to the SOC immediately and no later than 1 hour, and to the Privacy Office within 24 hours.
4. Complete Privacy and Information Security Awareness training in the Learning Hub within the annual window.

Using AI in an HR process also needs a privacy assessment under HR-POL-016.

## 5. Who to call

Security Operations Centre: 1-800-555-0155 (24/7), soc@bank.example. Privacy Office: privacy@bank.example. General questions: HR Connect, 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays).

## 6. Related documents

- HR-POL-017 IT Acceptable Use and Information Security Policy
- HR-POL-016 Employee Data Privacy Policy
- HR-POL-001 Code of Conduct and Ethics
