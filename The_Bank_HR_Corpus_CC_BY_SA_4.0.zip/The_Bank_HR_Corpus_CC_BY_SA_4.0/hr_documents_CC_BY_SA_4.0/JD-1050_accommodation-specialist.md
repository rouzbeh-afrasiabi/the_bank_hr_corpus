# Accommodation Specialist

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1050 |
| Title | Accommodation Specialist |
| Document type | Job description |
| Version | 1.2 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-06-30 |
| Next review | 2027-06-30 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-018, HR-PRC-007, HR-POL-035, HR-GDE-006, HR-FWK-001, HR-POL-007 |

## 1. Role summary

The Accommodation Specialist manages workplace accommodation cases for employees in Canada and the US. The specialist works with employees, managers, HRBPs and medical providers to find effective, timely solutions to the point of undue hardship, and supports graduated and modified return to work. The role is Band 4 (Senior Professional): it handles complex, sensitive work and advises managers and HR colleagues. See HR-GDE-006 Job Architecture and Pay Bands Guide.

## 2. Key responsibilities

- Receive accommodation requests from the manager, HR Connect or accommodations@bank.example, whether or not the word "accommodation" is used.
- Acknowledge each request within 2 business days and decide within 10 business days of complete information, or 3 business days in urgent cases, as set by HR-POL-018 Workplace Accommodation and Accessibility Policy.
- Run the interactive process: gather functional limitations through the medical supplement (FORM-HR-041), without asking for a diagnosis, and agree interim measures while a request is pending.
- Maintain separate, confidential accommodation files following HR-PRC-007 Accommodation Case Management Procedure; share only functional limitations and expected duration with managers.
- Request funding from the central Accommodation Fund so costs are not charged to team budgets.
- Coordinate graduated return to work (up to 12 weeks) and modified duties with the Leaves team, Maplewood Benefits and Workplace Safety, linked to HR-POL-007 Sick Leave and Personal Leave Policy.
- Arrange accessible formats within 10 business days and ergonomic assessments within 30 days of request.
- Support the Accommodation Review Panel, which reviews decisions within 10 business days on request.
- Advise managers and recruiters on accessible hiring and workplace design in line with HR-POL-035 Multi-Year Accessibility Plan 2025 to 2028.
- Reimburse employees for medical forms up to $150 CAD / $120 USD and track the case metrics for the Head of Accessibility and Inclusion.
- Provide manager and employee training on accommodation obligations and respectful communication.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in human resources, occupational health, rehabilitation, disability management or a related field.
- Five to eight years of experience in accommodation, disability management or return-to-work.
- Working knowledge of human rights legislation in Canada and the Americans with Disabilities Act and state laws in the US.
- Skilled in sensitive conversations; strict discipline over medical privacy.

### 3.2 Preferred

- A disability management or occupational health certificate.
- Experience with assistive technology and accessible design.
- Bilingual English and French.

## 4. Competencies

Competency names follow HR-FWK-001 Competency and Leadership Model (Practitioner level, Bands 3 to 4).

- Inclusive Leadership
- Customer Obsession
- Judgement and Decision Quality
- Collaboration
- Risk and Conduct Awareness
- Adaptability

## 5. Compensation and classification

| Item | Detail |
| --- | --- |
| Band | 4 (Senior Professional) |
| Canada range | $72,000 to $108,000 CAD per year |
| US range | $70,000 to $106,000 USD per year |
| Incentive target | 8% of base salary (Annual Incentive Plan) |
| Overtime eligibility, Canada | Yes (non-managerial) |
| FLSA classification, US | Exempt |
| Work arrangement | Hybrid |

## 6. Working conditions and accessibility

Office-based and hybrid by default, with at least 3 days a week in the office; Tuesday and Thursday are anchor days (HR-POL-002 Remote and Hybrid Work Policy; FORM-HR-030). Occasional site visits for workplace assessments are required. The Bank provides accommodation to the point of undue hardship, including for this role (HR-POL-018 Workplace Accommodation and Accessibility Policy).

## 7. Reporting line

Reports to the Head of Accessibility and Inclusion. The role has no direct reports.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.2 | 2026-03-01 | Pay band aligned with the 2026 pay bands |
| 1.1 | 2025-08-01 | Updated for HR-POL-018 version 3.2 timelines |
| 1.0 | 2025-01-01 | First issue |
