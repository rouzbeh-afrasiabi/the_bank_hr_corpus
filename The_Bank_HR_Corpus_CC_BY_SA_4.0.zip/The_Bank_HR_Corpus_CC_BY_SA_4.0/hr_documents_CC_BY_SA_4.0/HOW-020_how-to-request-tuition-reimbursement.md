# How to request tuition reimbursement

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-020 |
| Title | How to request tuition reimbursement |
| Document type | How-to article |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-11-01 |
| Last reviewed | 2026-09-22 |
| Next review | 2027-09-22 |
| Policy owner | SVP Talent and Learning |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-012, FORM-HR-060, HR-POL-011 |

## 1. The short answer

Get approval on FORM-HR-060 (Part A) in MyHR > Career and Learning > Tuition Reimbursement at least 15 business days before the course starts, then claim (Part B) within 60 days of completing it.

## 2. Who this applies to

Regular full-time and regular part-time employees in Canada (including Quebec) and the US who have at least 6 months of service and a last rating of Meets Expectations or higher. Casual, fixed-term, student, co-op and intern employees are not eligible. The course must be a job-related or career-related degree or diploma course. Professional designations use FORM-HR-061 (see HOW-021), and the $2,000 professional development budget is separate.

## 3. Steps

1. Choose a job-related or career-related degree or diploma course.
2. Open MyHR > Career and Learning > Tuition Reimbursement and complete **Part A** of FORM-HR-060: institution, course, dates, the link to your work or career, and the estimated cost (tuition, mandatory course fees, required books).
3. Submit at least **15 business days** before the course starts. Your manager approves that the course is job-related or career-related; the HRBP confirms your eligibility.
4. Take the course. Study is normally outside working hours; agree any use of work time with your manager.
5. Within **60 days** of the completion date, complete **Part B** with the receipt and proof of grade.

## 4. Deadlines and what happens next

Payroll Services pays approved reimbursement on a regular pay date; any taxable amount is included in your pay.

| Grade | Reimbursement |
| --- | --- |
| 70% or higher, or a pass | 100% of eligible costs |
| 60% to 69% | 50% |
| Below 60% | 0% |

The annual cap is $5,000 CAD (Canada) or $5,250 USD (US) per fiscal year (1 November to 31 October), counted in the fiscal year in which the course ends. Example: $1,800 CAD at 65% pays $900 CAD.

If you resign within 12 months of your last reimbursement, you repay 100% of reimbursements paid in that period. No repayment applies if your employment ends by involuntary termination without cause, restructuring, or during a Bank-approved leave.

## 5. Common mistakes

- Registering for the course before approval, or submitting Part A inside the 15 business days.
- Missing the 60-day claim window. Late claims are not paid unless the SVP Talent and Learning approves an exception.
- Claiming application fees, travel, parking or equipment. They are not covered.
- Forgetting the cap applies to the fiscal year in which the course ends.
- Losing the transcript or receipt.

## 6. Who to call

- Your manager or HRBP for approval questions.
- HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example.

## 7. Related documents

- HR-POL-012 Learning and Development Policy (the owning document)
- FORM-HR-060 Learning Approval and Tuition Reimbursement Claim
- HR-POL-011 Performance Management Policy

Where applicable law gives a greater right, the law applies.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-11-01 | Cap raised to $5,000 CAD / $5,250 USD from $4,000 (HR-POL-012 version 3.2). |
| 1.0 | 2025-01-01 | First version. |
