# How to update your tax withholding

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-006 |
| Title | How to update your tax withholding |
| Document type | How-to article |
| Version | 1.0 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-009, FORM-HR-022, HR-GDE-003 |

## 1. The short answer

Upload your completed tax forms with FORM-HR-022 Direct Deposit and Tax Withholding Update in MyHR by the payroll cut-off, 17:00 Eastern Time five business days before the pay date.

## 2. Who this applies to

| Country | Forms you upload |
| --- | --- |
| Canada (all provinces and territories, including Quebec) | The federal and provincial personal tax credit return forms for your province of work |
| US | Form W-4 and your state withholding form |

New hires complete these during onboarding (Canadian new hires by day 1; see HR-GDE-003 New Employee Onboarding Guide). Existing employees update them whenever their personal situation changes. No manager approval is needed.

## 3. Steps

1. Complete the correct tax forms yourself. HR and Payroll Services cannot give tax advice or fill them in for you.
2. Select **MyHR > Pay > Tax Withholding**, then **Update tax forms** (FORM-HR-022, update type "Tax withholding").
3. Upload the completed forms.
4. Confirm that you are responsible for the accuracy of your tax forms, then sign electronically.
5. Note the **effective pay date** that MyHR shows and submit.

## 4. Deadlines to remember

A change entered after 17:00 Eastern Time, five business days before the pay date, is processed on the next pay date. For the Canada pay date of 2026-03-05, the cut-off is 2026-02-26. Submit as soon as your situation changes.

## 5. What happens next

Payroll Services verifies the forms and applies them to the next eligible pay date. Check the deduction lines on your pay statement in MyHR (see HOW-007) to confirm the new withholding. Statutory deductions come off first: income tax, Canada Pension Plan or Quebec Pension Plan and Employment Insurance or Quebec Parental Insurance Plan in Canada, and Social Security, Medicare and state taxes in the US. Court-ordered garnishments are applied as the law requires and you are notified.

## 6. Common mistakes

- Uploading incomplete, unsigned or out-of-date forms.
- Using the wrong province or state for your place of work.
- Missing the cut-off and expecting a change on the next pay date.
- Not updating your address. Tax slips (T4 and Relevé 1 by 28 February; W-2 by 31 January) are issued from the address on file; change it using FORM-HR-022 as well.

## 7. Who to call

HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, or live chat in MyHR. For tax questions about your own situation, contact the relevant tax authority or a tax adviser.

## 8. Related documents

- HR-POL-009 Compensation and Payroll Policy
- FORM-HR-022 Direct Deposit and Tax Withholding Update
- HR-GDE-003 New Employee Onboarding Guide

## 9. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.0 | 2025-09-01 | First edition, written for the combined MyHR form FORM-HR-022. |
