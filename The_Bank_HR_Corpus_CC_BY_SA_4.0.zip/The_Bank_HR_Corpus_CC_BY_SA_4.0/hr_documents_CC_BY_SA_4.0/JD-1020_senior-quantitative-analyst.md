# Senior Quantitative Analyst

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1020 |
| Title | Senior Quantitative Analyst |
| Document type | Job description |
| Version | 1.0 |
| Status | Current |
| Effective date | 2025-06-01 |
| Last reviewed | 2026-08-03 |
| Next review | 2027-08-03 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-POL-002, HR-POL-029, HR-POL-032 |

## 1. Role summary

The Senior Quantitative Analyst develops, validates and maintains the pricing, valuation and risk models used by Capital Markets. The role turns market problems into mathematical and statistical models, implements them in production-quality code and explains their assumptions and limits to traders, risk managers and model validators. The analyst advises junior quantitative staff and is recognized for depth in a field such as derivatives pricing, curve construction or market-risk measurement.

## 2. Key responsibilities

- Design and implement pricing and valuation models for rates, credit, foreign exchange or equity products.
- Build and calibrate yield and volatility curves, and monitor calibration quality daily.
- Develop and run back-tests, sensitivity analyses and stress scenarios for desk and enterprise market-risk reporting.
- Write clear model documentation covering purpose, methodology, assumptions, limitations and use restrictions.
- Work with independent model validation to resolve findings within agreed deadlines.
- Optimize numerical code for speed and accuracy, and review colleagues' code before release.
- Investigate model breaks, unexpected profit-and-loss explain results and data-quality issues, and report root causes.
- Respond to traders' requests for analytics and new-product support while protecting model governance steps.
- Mentor Professional-level quantitative analysts through code reviews and design discussions.
- Present research findings to desk heads and to the Head of Quantitative Research.

## 3. Qualifications

### 3.1 Required

- Master's degree or doctorate in mathematics, statistics, physics, engineering, computer science or financial engineering.
- Typically 5 to 8 years of quantitative development or research experience in financial markets.
- Strong programming ability in a compiled language and in a scripting language used for data analysis.
- Solid grounding in stochastic calculus, numerical methods and statistics.

### 3.2 Preferred

- CFA designation or a recognized financial risk designation.
- Experience with machine-learning techniques applied to market data.
- Publications or conference presentations in quantitative finance.

### 3.3 Licences and certifications

No securities registration is required for pure research duties. If Compliance designates the analyst for any client- or desk-facing duties, HR-POL-029 Licensing, Registration and Qualification Policy applies and the Bank pays the exam and registration fees. All analysts in Capital Markets are covered persons under HR-POL-032 Personal Trading and Restricted Lists Policy.

## 4. Competencies

Measured against HR-FWK-001 Competency and Leadership Model at the Practitioner level:

- Judgement and Decision Quality
- Drive for Results
- Risk and Conduct Awareness
- Collaboration
- Developing Others
- Adaptability

## 5. Compensation and classification

| Item | Value |
| --- | --- |
| Band | 4 (Senior Professional) |
| Canada range | $72,000 to $108,000 CAD |
| US range | $70,000 to $106,000 USD |
| Incentive target | 8% of base salary (Annual Incentive Plan) |
| Overtime eligibility, Canada | Yes (non-managerial Band 4) |
| FLSA classification, US | Exempt |
| Work arrangement | On-site (Capital Markets) |

Band definitions are in HR-GDE-006 Job Architecture and Pay Bands Guide.

## 6. Working conditions and accessibility

This is an on-site role in Capital Markets, working next to the desks the models support; the work-arrangement categories are set out in HR-POL-002 Remote and Hybrid Work Policy. Research staff may be asked to sit on the trading floor during product launches or model go-lives. Work with market data follows the Bank's information-security rules. The Bank provides accommodation to the point of undue hardship; see HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to: Head of Quantitative Research. Direct reports: none (provides technical guidance to junior analysts).

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.0 | 2025-06-01 | First issue |
