# Learning and Development Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-012 |
| Title | Learning and Development Policy |
| Document type | Policy |
| Version | 3.2 |
| Status | Current |
| Effective date | 2025-11-01 |
| Last reviewed | 2026-09-22 |
| Next review | 2027-09-22 |
| Policy owner | SVP Talent and Learning |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Applies to | All Canadian and US employees (see Scope) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-011, HR-POL-014, HR-POL-015, HR-POL-009, FORM-HR-060, FORM-HR-061 |

## 1. Purpose

This policy describes how the Bank supports employees to build skills and careers. It covers the annual development budget, tuition reimbursement, professional designations, study leave, mandatory training, leadership programs and repayment of support when an employee leaves.

## 2. Scope

The policy applies to regular full-time and regular part-time employees in Canada and the US. Eligibility for individual benefits differs by employment category (see HR-POL-014 Employment Status and Classification Policy): tuition reimbursement is not available to casual employees, fixed-term employees, students, co-op placements or interns. Mandatory training applies to all employees, and also to contractors and agency workers engaged by the Bank. Where applicable law gives a greater right, the law applies.

## 3. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Employee | Plans development with the manager, requests approval before spending, completes mandatory training on time, keeps receipts and grades. |
| Manager | Approves development requests, supports study time, monitors mandatory training status of the team in MyHR, and escalates overdue completions. |
| HR Business Partner | Reviews exceptions and escalations. |
| SVP Talent and Learning | Owns the policy, the Learning Hub, mandatory curriculum and leadership programs. |
| Payroll Services | Processes reimbursements and recovers repayments. |

## 4. Professional development budget

Each employee has a professional development budget of $2,000 per fiscal year (1 November to 31 October), in CAD for employees in Canada and USD for employees in the US. The budget covers courses, conferences, workshops and books that support the employee's current role or career goals. It is available from the start date and is pro-rated for part-time employees. Unused budget does not carry forward. The manager approves the request before the employee commits to a cost; employees submit claims in MyHR with receipts within 60 days of the expense. The budget cannot be used for tuition for degree or diploma courses (see section 5), for memberships (see section 6), or for items that are purchased for personal use.

Employees are encouraged to complete 24 hours of learning a year, which may include Learning Hub content, courses funded from the budget and mentoring. Mandatory training does not count toward the 24 hours.

## 5. Tuition reimbursement

### 5.1 Eligibility

Tuition reimbursement is available for degree or diploma courses that are job-related or career-related. To be eligible, an employee must have at least 6 months of service, be a regular full-time or regular part-time employee, and have a last rating of Meets Expectations or higher (see HR-POL-011 Performance Management Policy).

### 5.2 Annual cap

| Country | Maximum reimbursement per fiscal year |
| --- | --- |
| Canada | $5,000 CAD |
| US | $5,250 USD |

Since version 3.2 (effective 2025-11-01) the cap is $5,000 for Canadian employees; the previous cap was $4,000. Reimbursed costs are assigned to the fiscal year in which the course ends. Tuition, mandatory course fees and required books may be claimed. Application fees, travel, parking and equipment are not covered.

### 5.3 Approval and claim steps

1. Submit FORM-HR-060 Learning Approval and Tuition Reimbursement Claim at least 15 business days before the course starts. The manager approves that the course is job-related or career-related, and the HRBP confirms eligibility.
2. Take the course. Study is normally outside working hours; any use of work time must be agreed with the manager.
3. Submit the completed claim section of FORM-HR-060 within 60 days of the course completion date, with the receipt and proof of grade. Late claims are not reimbursed unless the SVP Talent and Learning approves an exception.
4. Payroll Services pays the reimbursement on a regular pay date after approval. Tax treatment depends on applicable law and the country; Payroll Services includes any taxable amount in pay.

### 5.4 Reimbursement by result

| Grade | Reimbursement |
| --- | --- |
| 70% or higher, or a pass | 100% of eligible costs |
| 60% to 69% | 50% of eligible costs |
| Below 60% | 0% |

### 5.5 Examples

- A Canadian employee takes a course costing $1,800 CAD and earns 82%. The reimbursement is $1,800 CAD.
- The same employee earns 65%. The reimbursement is 50%, or $900 CAD.
- A Canadian employee completes two courses in the same fiscal year costing $3,200 CAD and $2,600 CAD and earns 75% in both. Eligible costs are $5,800 CAD; the reimbursement is capped at $5,000 CAD.
- A US employee completes a course costing $2,400 USD and earns 55%. The reimbursement is $0.

## 6. Professional designations

For recognized professional designations (for example CFA, CPA, CFP, PMP and CISSP), the Bank reimburses 100% of registration and exam fees on approval. The employee submits FORM-HR-061 Professional Designation Reimbursement Request before registering. The Bank also pays annual membership fees for designations that the role requires. Designation fees do not count against the tuition cap or the professional development budget.

## 7. Study leave

An employee approved for a designation receives 5 paid study days per designation exam. Study days are taken before the exam, requested in MyHR as study leave and approved by the manager at least 10 business days before the first day, or less where the exam date was set later. Study days are not deducted from vacation, sick or personal days (see HR-POL-006 Vacation and Paid Time Off Policy). They do not carry forward and cannot be paid out.

## 8. Mandatory training

All employees complete the following in the Learning Hub. New hires complete all courses within 30 days of their start date (see HR-GDE-003 New Employee Onboarding Guide). Existing employees complete them in the annual window, 1 August to 31 October.

| Course | Frequency | Due for existing employees | Due for new hires |
| --- | --- | --- | --- |
| Code of Conduct and Ethics | Annually | 31 October | 30 days from start |
| Anti-Money Laundering and Sanctions | Annually | 31 October | 30 days from start |
| Privacy and Information Security Awareness | Annually | 31 October | 30 days from start |
| Workplace Harassment and Violence Prevention | Annually | 31 October | 30 days from start |
| Workplace Health and Safety | Annually | 31 October | 30 days from start |
| Fraud Awareness | Annually | 31 October | 30 days from start |
| Accessibility and Human Rights | Every 2 years | 31 October of the due year | 30 days from start |

### 8.1 Escalation for late completion

| Days after due date | Action |
| --- | --- |
| 7 days | Automatic reminder to the employee. |
| 14 days | The employee's manager is notified. |
| 30 days | AIP eligibility and the "how" component of the year-end rating are affected (see HR-POL-011). |

Employees on approved leave have their due dates extended by the length of the leave. Persistent non-completion may be addressed under HR-POL-021 Employee Relations and Progressive Discipline Policy. Training records are kept for 7 years (see HR-REF-002).

## 9. Leadership programs

Leadership programs are offered to employees in Band 5 and above. Participants are nominated by the Director with HRBP agreement and selected by the SVP Talent and Learning.

| Program | Audience | Format |
| --- | --- | --- |
| Emerging Leaders | Band 5 | Cohort program over 6 months with peer coaching. |
| Leading Leaders | Bands 6 and 7 | Cohort program over 9 months with executive sponsor and project work. |
| Executive Forum | Band 8 and above | Annual forum with external speakers and senior mentoring. |

Program fees are paid by Talent and Learning and not charged to the business unit or the individual's budget. Participation does not guarantee promotion; promotions and transfers are handled separately.

## 10. Repayment

An employee who resigns within 12 months of the last tuition reimbursement must repay 100% of the reimbursements paid in that period. Repayment is requested in writing and may be recovered from final pay where law permits and written consent is obtained first (where required), or by a repayment plan agreed with Payroll Services of up to 12 months (see HR-POL-009 Compensation and Payroll Policy). No repayment is required if the employment ends by involuntary termination without cause, restructuring, or because the employee is on a Bank-approved leave. Designation fees are not repayable unless the employee has not completed the exam and resigns within 12 months of reimbursement (decided by the SVP Talent and Learning).

## 11. Exceptions and consequences

Exceptions require written approval of the SVP Talent and Learning. False claims or altered receipts are misconduct under HR-POL-001 Code of Conduct and Ethics.

## 12. Related documents and contacts

HR-POL-011 Performance Management Policy; HR-POL-014 Employment Status and Classification Policy; HR-POL-015 Resignation and Offboarding Policy; HR-GDE-003 New Employee Onboarding Guide. Contact HR Connect at 1-800-555-0142 or hrconnect@bank.example.

## 13. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 3.2 | 2025-11-01 | Raised the annual tuition reimbursement cap to $5,000 CAD / $5,250 USD from the previous $4,000; clarified claim timing and grade-based reimbursement. |
| 3.1 | 2024-11-01 | Added study leave of 5 paid days per designation exam; aligned mandatory training dates with the annual 1 August to 31 October window. |
