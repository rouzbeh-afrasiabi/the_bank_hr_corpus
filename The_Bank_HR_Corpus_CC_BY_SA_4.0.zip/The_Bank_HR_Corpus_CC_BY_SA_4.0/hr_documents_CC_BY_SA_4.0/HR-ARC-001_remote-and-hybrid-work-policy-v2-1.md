# Remote and Hybrid Work Policy (version 2.1)

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

> **Archived version.** Kept for reference only. Do not rely on it. See HR-POL-002 Remote and Hybrid Work Policy.

| Field | Value |
| --- | --- |
| Document ID | HR-ARC-001 |
| Title | Remote and Hybrid Work Policy (version 2.1) |
| Document type | Archived version |
| Version | 2.1 |
| Status | Superseded |
| Superseded by | HR-POL-002 Remote and Hybrid Work Policy, version 3.0 (effective 2026-01-05) |
| Effective date | 2023-09-01 |
| Last reviewed | Not applicable |
| Next review | Not applicable |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-002, HR-POL-003, HR-POL-004, HR-POL-017, FORM-HR-030, FORM-HR-031 |

## 1. Status of this version

Version 2.1 of the Remote and Hybrid Work Policy was in force from 1 September 2023 to 4 January 2026. It was replaced by version 3.0 on 5 January 2026, which raised the hybrid requirement from 2 to 3 office days a week and introduced anchor days. This archived copy shows the rules as they stood in version 2.1. Only the hybrid attendance rule differs from the current policy; all other rules shown here are the same as in HR-POL-002.

## 2. Purpose and scope

This policy explained where and how Bank employees work: on-site, hybrid or remote; temporary work from elsewhere; and equipment, security and safety conditions. It applied to all regular full-time, regular part-time and fixed-term employees in Canada and the US. Casual employees, students, co-op students and interns followed the arrangement in their engagement letter. Contractors were not covered (HR-POL-014 Employment Status and Classification Policy). Where applicable law gave a greater right, the law applied.

## 3. Arrangement types

| Arrangement | Who it was for | Where the employee worked | Approval |
| --- | --- | --- | --- |
| On-site | Customer-facing branch and operations roles | At the office, on a posted schedule | None; set by the role |
| Hybrid | Default for eligible office roles | **At least 2 days per week** in the office, the rest from home | Recorded on FORM-HR-030 |
| Remote | Roles designated remote by the business unit | From home, with up to 4 planned in-person events per year | Approved on FORM-HR-030 |

## 4. Hybrid schedule

### 4.1 Requirement

From 1 September 2023 to 4 January 2026, hybrid employees worked in the office **at least 2 days per week**. There were **no anchor days**: the employee and manager agreed which days, and the schedule was recorded on FORM-HR-030 in MyHR. Tuesday and Thursday were not required days.

### 4.2 Holidays, absences and core hours

An in-office day that fell on a Bank holiday or an approved absence was not a missed day. All hybrid and remote employees were available online between 10:00 and 15:00 local time (HR-POL-003 Working Hours and Overtime Policy). When a closure was announced under HR-POL-004 Attendance and Absenteeism Policy, hybrid and remote employees worked from home.

## 5. Exceptions to office attendance

A manager could approve up to 12 office-attendance exception days per calendar year per employee. Any request beyond 12 days needed the approval of the HRBP. Vacation, sick leave, personal days and other approved leave were not exception days, and accommodation needs did not count against the 12 days (HR-POL-018 Workplace Accommodation and Accessibility Policy).

## 6. Remote eligibility

A Remote arrangement required all of the following: the business unit head had designated the role remote-eligible; the employee had completed probation; the last rating was Meets Expectations or higher; there was no active performance improvement plan; and the home address was in a jurisdiction on the approved employment-jurisdiction list. The manager responded to FORM-HR-030 within 5 business days. An employee moving to a different province or state needed approval at least 30 days before the move. Remote employees attended up to 4 planned team or client events in person each year.

## 7. Temporary work from elsewhere

| Location | Limit per calendar year | Request lead time |
| --- | --- | --- |
| Within the employee's home country | Up to 20 working days | At least 5 business days ahead |
| Across the Canada-US border | Up to 10 working days | At least 10 business days ahead |
| Any other country | Not permitted by default | At least 30 days ahead, Global Mobility and Legal approval |

Requests were made on FORM-HR-031.

## 8. Equipment, security and safety

The Bank provided a laptop, a headset and one external monitor on request. A home office setup allowance was available once every 3 years: Hybrid $300 CAD / $225 USD; Remote $600 CAD / $450 USD. There was no ongoing internet or phone reimbursement. Canadian employees could request a signed form T2200 from HR Operations. Security rules were those in HR-POL-017 IT Acceptable Use and Information Security Policy: VPN always on, no public Wi-Fi without the VPN, a private workspace and a locked screen. Incidents went to the Security Operations Centre immediately and no later than 1 hour. An injury arising from work was reported to the manager and Corporate Security immediately and in MyHR within 24 hours.

## 9. Ending or changing an arrangement

The employee gave 4 weeks' notice through FORM-HR-030. The Bank gave at least 30 calendar days' written notice for business reasons, or could end an arrangement immediately for a security breach, a conduct issue or when remote eligibility conditions were no longer met.

## 10. Contacts

HR Connect, 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time, hrconnect@bank.example. Managers: Manager Hotline, 1-800-555-0143.

## 11. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2022-03-01 | Introduced hybrid work as the default for eligible office roles |
| 2.1 | 2023-09-01 | Hybrid requirement of 2 office days per week, with no anchor days (in force until 2026-01-04) |
| 3.0 | 2026-01-05 | Superseded this version; hybrid requirement raised to 3 office days per week with anchor days Tuesday and Thursday (see HR-POL-002) |
