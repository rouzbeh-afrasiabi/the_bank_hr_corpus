# Sick Leave and Personal Leave Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-007 |
| Title | Sick Leave and Personal Leave Policy |
| Document type | Policy |
| Version | 3.0 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-09-15 |
| Next review | 2027-09-15 |
| Policy owner | SVP Total Rewards |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Applies to | All Canadian and US employees (see Scope) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-004, HR-POL-006, HR-POL-008, HR-POL-018, FORM-HR-010, FORM-HR-011 |

## 1. Purpose

This policy describes the paid and unpaid time away available when an employee is ill or injured, needs a personal day, or needs a longer personal leave of absence. It also sets out the short-term disability and long-term disability programs and the graduated return to work. Where applicable law gives a greater right, the law applies.

## 2. Scope and definitions

### 2.1 Scope

The policy applies to regular full-time, regular part-time and fixed-term employees in Canada and the US. Casual employees receive statutory sick leave only (see HR-POL-014 Employment Status and Classification Policy). Work-related injuries are covered by workers' compensation and by HR-POL-023 Workplace Health, Safety and Wellness Policy.

### 2.2 Definitions

- **Sick day:** a paid day of absence for illness, injury, a medical appointment or family care.
- **Personal day:** a paid day taken for any reason without explanation.
- **Working day:** a day the employee is scheduled to work.
- **Waiting period:** the first 5 consecutive working days of absence, covered by sick days.
- **Maplewood Benefits:** the insurance carrier that administers short-term and long-term disability claims in both countries.

## 3. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Employee | Report absences on time, provide certificates when required, and apply for disability benefits promptly. |
| Manager | Record the absence, respect confidentiality, ask for functional information only, and support return to work. |
| Leaves team (Tier 2) | Reviews certificates, manages leaves, and coordinates with Maplewood Benefits. |
| Accommodation Specialist | Coordinates graduated return to work and workplace accommodation. |
| HR Business Partner (HRBP) | Co-approves personal leave and agrees to certificate requests tied to holiday patterns. |
| Maplewood Benefits | Decides disability claims. The Bank does not decide medical eligibility. |

## 4. Paid sick days

### 4.1 Entitlement

| Country | Sick days per calendar year (since 2026-01-01) | Previous (v2.2) |
| --- | --- | --- |
| Canada | 10 | 8 |
| US | 8 | 6 |

Sick days are credited on 1 January and are available from the start date. They are pro-rated for new hires, rounded up to the nearest half day. The minimum use is a half day. Unused sick days do not carry over and are not paid out.

### 4.2 Permitted use

Sick days may be used for the employee's own illness or injury, medical appointments, and family care. Up to 5 of the sick days may be used for family care in a calendar year. US state sick leave laws (for example California, New York and New Jersey) are satisfied by this entitlement; where a state law gives more, the more generous rule applies.

### 4.3 Reporting an absence

Report an absence to your manager before your scheduled start, or within 30 minutes after it if you are unable to. Use a phone call or message; email alone is not enough on the day. Branch employees also notify the branch manager. Enter the absence in Time Tracker on return. The attendance rules are in HR-POL-004 Attendance and Absenteeism Policy.

### 4.4 Medical certificates

A certificate is required from the 4th consecutive working day of absence, using FORM-HR-011 Medical Certificate and Fitness-to-Work, or an equivalent provider note. A certificate may also be requested when absences are adjacent to a holiday more than twice in 12 months, but only with the agreement of the manager and the HRBP. In Quebec the Bank asks for evidence only after 3 consecutive days of absence.

Certificates show functional limitations and expected duration, not diagnosis. They are sent to the Leaves team through MyHR, not to the manager, and are due within 5 business days of the request. Personal days never need a certificate.

### 4.5 Return-to-work conversation

After an absence of 5 or more days, the manager holds a return-to-work conversation within 2 business days of the return.

## 5. Personal days

Each employee receives 3 personal days per calendar year, for any reason. The rules are:

- 24 hours' notice where possible, requested in MyHR.
- Minimum half day.
- No carryover, no payout and no certificate.
- Pro-rated for new hires, rounded up to the nearest half day.
- Approved personal days are protected absences and never count towards an attendance review.

## 6. Short-term disability

Short-term disability is employer-paid and administered by Maplewood Benefits.

| Period | Pay |
| --- | --- |
| Days 1 to 5 (waiting period) | Sick days at 100% of base salary |
| Weeks 1 to 13 after the waiting period | 100% of base salary |
| Weeks 14 to 26 | 75% of base salary |

The program starts after 5 consecutive working days of absence. If the sick-day balance is exhausted before day 5, the employee may use vacation or personal days or take the remaining days unpaid. Birth parents in the US also receive short-term disability for medical recovery, up to 6 weeks (vaginal birth) or 8 weeks (caesarean); see HR-POL-008 Parental and Family Leave Policy.

## 7. Long-term disability

From week 27, long-term disability pays 66 2/3% of base salary to a maximum of $15,000 per month, to age 65. For the first 24 months the "own occupation" test applies: the employee qualifies if unable to perform their own job. After that Maplewood Benefits applies the broader test in the plan contract. Benefit continuation during disability is described in HR-GDE-001 Employee Benefits Guide.

### 7.1 How to apply

Apply to Maplewood Benefits through MyHR within 5 business days of going off work. Maplewood Benefits makes the claims decision. The Maplewood Benefits claims line is 1-800-555-0190. Employees should also notify the Leaves team so that payroll and vacation records are updated.

### 7.2 Vacation and service

Vacation continues to accrue during short-term disability. It stops accruing during long-term disability. Service is continuous throughout.

## 8. Personal unpaid leave of absence

An employee with at least 2 years of service may request an unpaid personal leave of up to 6 months. The request is made on FORM-HR-010 Leave of Absence Request, at least 30 days ahead where possible, and is approved by the Director and the HRBP.

- Benefits continue if the employee pays both the employee and Bank shares of the premiums.
- Vacation stops accruing after 30 days of leave.
- The employee returns to the same or a comparable role.
- Statutory and Bank-approved leaves are separate and are not affected.

## 9. Graduated return to work

A graduated return of up to 12 weeks is available after illness or injury, arranged with the Accommodation Specialist, the manager and the Leaves team, with input from the treating provider's functional recommendations. The employee is paid for hours worked; the remaining hours are covered by sick days or disability benefits as determined by Maplewood Benefits. Accommodation rules are in HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 10. Confidentiality

Medical information is held by the Leaves team separately from the personnel file. Managers receive only functional limitations and expected duration, never a diagnosis. Access is logged. See HR-POL-016 Employee Data Privacy Policy. Employees should not be asked about their condition by colleagues or managers.

## 11. Worked example

A Canadian employee earns $78,000 a year (about $1,500 a week, $6,500 a month) and is off for 40 weeks. The employee uses 5 of their 10 sick days at 100% for days 1 to 5. Weeks 1 to 13 after the waiting period are paid at 100%, $1,500 a week. Weeks 14 to 26 are paid at 75%, $1,125 a week. From week 27 long-term disability pays 66 2/3% x $6,500 = about $4,333 a month. An employee earning $300,000 would calculate $16,667 a month and receive the $15,000 maximum.

## 12. Exceptions, consequences and contacts

Falsifying a certificate or misusing sick days is misconduct under HR-POL-001 Code of Conduct and Ethics and may lead to action under HR-POL-021 Employee Relations and Progressive Discipline Policy. Exceptions require approval of the SVP Total Rewards. Contact HR Connect, 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time, hrconnect@bank.example.

## 13. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 3.0 | 2026-01-01 | Sick days increased from 8 to 10 in Canada and from 6 to 8 in the US. Clarified graduated return and certificate handling. |
| 2.2 | 2024-01-01 | Canada 8 sick days, US 6 sick days. Short-term and long-term disability terms unchanged. |
