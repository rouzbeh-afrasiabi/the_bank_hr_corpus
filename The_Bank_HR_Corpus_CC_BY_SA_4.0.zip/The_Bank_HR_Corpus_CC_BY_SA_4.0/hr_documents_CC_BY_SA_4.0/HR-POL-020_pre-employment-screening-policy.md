# Pre-Employment Screening Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-020 |
| Title | Pre-Employment Screening Policy |
| Document type | Policy |
| Version | 2.2 |
| Status | Current |
| Effective date | 2025-05-01 |
| Last reviewed | 2026-05-20 |
| Next review | 2027-05-20 |
| Policy owner | VP HR Operations |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Applies to | All Canadian and US employees (see Scope) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-019, HR-POL-016, HR-POL-018, HR-REF-002, HR-GDE-003, FORM-HR-111 |

## 1. Purpose

The Bank handles money and sensitive information, and customers, regulators and colleagues rely on the integrity of the people it hires. This policy describes the checks made before a person starts work, the rules that make those checks fair and lawful, and how results are used.

## 2. Scope

The policy applies to all external candidates who receive a conditional offer for a regular, fixed-term, casual, student, co-op or intern role in Canada or the US, and to employees in the roles listed in section 11 who are re-screened. It also applies to contractors and agency workers, whose checks are arranged through Procurement. Recruitment is covered by HR-POL-019 Recruitment and Selection Policy. Where applicable law gives a greater right, the law applies.

## 3. Definitions

| Term | Meaning |
| --- | --- |
| Conditional offer | An offer of employment that depends on satisfactory screening results. |
| Individualized assessment | A documented, job-related review of a result, considering the nature of the issue, the time that has passed and the duties of the role. |
| Pre-adverse action notice | Written notice, with a copy of the report, sent before a decision is made not to proceed because of a screening result. |
| Sensitive role | Band 6 and above, and roles in treasury, payments, fraud, or with privileged technology access. |

## 4. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Candidate | Gives consent, provides accurate information and documents, and responds to queries on time. |
| Recruiter | Starts screening only after a conditional offer and consent, and tracks turnaround. |
| HR Operations (Screening team) | Runs the checks with the Bank's contracted screening provider, reviews results, sends notices and records outcomes. |
| HR Business Partner | Takes part in the individualized assessment for adverse results. |
| Chief Compliance Officer | Advises on regulatory requirements for insured-institution and licensed roles. |
| VP HR Operations | Owns the policy and approves exceptions. |

## 5. Principles

1. Consent comes first: no check starts until the candidate signs FORM-HR-111 Consent to Pre-Employment Screening.
2. Checks are made only after a conditional offer (fair-chance principle), so that early hiring decisions are based on ability.
3. Checks are proportionate to the role and the law of the place where the role is located.
4. Results are confidential and used only for the hiring decision.
5. A human makes every decision based on a result (see HR-POL-016 Employee Data Privacy Policy).

## 6. Consent and procedure

### 6.1 Steps

1. The recruiter issues the conditional offer and FORM-HR-111 together.
2. The candidate returns the signed consent by the date in the offer letter, normally within 2 business days.
3. HR Operations orders the checks that apply to the role (section 7).
4. The target turnaround is 5 business days from receipt of consent and complete information.
5. HR Operations reviews the results. A clear result is recorded and the recruiter is told the candidate has cleared screening. Where there is a discrepancy, section 9 applies.
6. The candidate may start only when the required checks are satisfactory, or when HR Operations has approved a start with outstanding items that are not required before access to systems.

### 6.2 Candidate information

The candidate must give complete and accurate information. A material false statement or omission is a reason to withdraw an offer or, after start, can be a reason for discipline under HR-POL-021.

## 7. Checks

| Check | Who | Notes |
| --- | --- | --- |
| Identity and right to work | All candidates | Original documents verified; see HR-GDE-003 New Employee Onboarding Guide for the documents needed on day 1. |
| Criminal record | All candidates, subject to local law | Canada: police information check. US: check under the Fair Credit Reporting Act. |
| Credit check | Only roles with financial authority | Not run for other roles. |
| Education | All candidates | Highest qualification relevant to the role. |
| Employment history | All candidates | The previous 7 years. |
| Professional licences and designations | Roles that require them | Confirmed with the issuing body. |
| Sanctions screening | All candidates | Checked against applicable sanctions lists. |
| Section 19 screening (US) | Roles at insured institutions | Screening under Section 19 of the Federal Deposit Insurance Act. |

## 8. Fair-chance and local-law rules

### 8.1 US

The Bank follows fair-chance rules: criminal record checks happen only after a conditional offer. A criminal record does not automatically disqualify a candidate, except where federal law (for example Section 19 for insured institution roles) prohibits employment. HR Operations carries out an individualized assessment that considers the nature and gravity of the offence, the time since it occurred and its relevance to the duties. State and city fair-chance laws apply where they give more protection.

### 8.2 Canada

A criminal record check is requested only for roles where the result is relevant. In Quebec, a criminal record is considered only where it is related to the job. Human rights law protects against discrimination on the ground of a record of offences for which a pardon has been granted, where applicable.

## 9. Adverse results and pre-adverse action

If a result may lead to withdrawal of the offer, the following steps apply:

| Step | Action | Timing |
| --- | --- | --- |
| 1 | Individualized assessment by HR Operations and the HRBP. | Within 3 business days of the result. |
| 2 | Pre-adverse action notice sent with a copy of the report and a summary of rights. | At the end of step 1. |
| 3 | Candidate may respond, correct errors or give context. | 5 business days to respond. |
| 4 | Final decision by the VP HR Operations (or delegate) with the hiring manager informed of the outcome only. | After the response, or after 5 business days. |
| 5 | Adverse action notice if the offer is withdrawn. | Immediately after the decision. |

The recruiter and hiring manager see only the decision, not the details.

## 10. Conditional employment

Employment is conditional on satisfactory results. If a check is outstanding, HR Operations decides whether the candidate may start. If an unsatisfactory result is found after the start date, the employee is told in writing and the matter is handled with Employee Relations under HR-POL-021 Employee Relations and Progressive Discipline Policy.

## 11. Re-screening

Employees in sensitive roles (Band 6 and above, treasury, payments, fraud, privileged technology access) and in roles with financial authority are re-screened every 5 years, with consent. Re-screening covers criminal record, sanctions and professional licences. Employees must tell Compliance within 2 business days if they are charged with or convicted of an offence that could be relevant to their duties, or lose a required licence, as set out in HR-POL-030 Fit and Proper and Conduct Standards Policy and HR-POL-029 Licensing, Registration and Qualification Policy. Employees in other roles are re-screened only where role requirements or law change.

## 12. Accommodation and accessibility

Candidates who need accommodation in the screening process (for example accessible formats or extra time) may ask the recruiter or write to accommodations@bank.example (see HR-POL-018 Workplace Accommodation and Accessibility Policy). Medical information is never part of screening.

## 13. Records and privacy

Screening results are stored separately from the general personnel file with restricted access. Results are kept for 7 years if the candidate is hired and 12 months if not (see HR-REF-002 Employee Records Retention Schedule). Candidates may request access under HR-POL-016. Any new screening vendor or tool needs a privacy impact assessment first.

## 14. Exceptions and consequences

Exceptions need written approval of the VP HR Operations and, for insured-institution roles, the Chief Compliance Officer. A manager who lets a person start work or access systems before clearance without approval is in breach of this policy.

## 15. Related documents and contacts

HR-POL-019 Recruitment and Selection Policy; HR-POL-016 Employee Data Privacy Policy; HR-POL-018 Workplace Accommodation and Accessibility Policy; HR-GDE-003 New Employee Onboarding Guide. Contact HR Connect at 1-800-555-0142 or hrconnect@bank.example.

## 16. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.2 | 2025-05-01 | Added the 5-day response window in the pre-adverse action step, re-screening every 5 years for sensitive roles and the 5-business-day target turnaround. |
| 2.1 | 2023-05-01 | Introduced Section 19 screening for US insured-institution roles and the individualized assessment. |
