# Operations Clerk

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1023 |
| Title | Operations Clerk |
| Document type | Job description |
| Version | 1.1 |
| Status | Current |
| Effective date | 2025-02-03 |
| Last reviewed | 2026-06-16 |
| Next review | 2027-06-16 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-POL-003, HR-POL-018, HR-SUP-004 |

## 1. Role summary

The Operations Clerk performs defined back-office tasks that keep customer accounts and transactions accurate: indexing and verifying documents, keying and checking data, filing, and preparing items for review by senior operations staff. The role follows set procedures under close guidance and is an entry point into the Technology and Operations family.

## 2. Key responsibilities

- Receive, scan, index and verify customer and internal documents against procedure checklists.
- Key data into core banking and workflow systems and check it against source documents.
- Prepare daily batches and balance them to control totals before hand-off.
- Follow dual-control and segregation-of-duties steps for every item that requires them.
- Identify exceptions and missing information, and route them to the correct team within the same day.
- Answer internal queries from branches and other departments about the status of requests.
- Maintain accurate records and retain or destroy documents according to the retention schedule.
- Record time worked, meal periods and any overtime in Time Tracker each week.
- Complete mandatory training, including privacy and fraud awareness, in the Learning Hub.

## 3. Qualifications

### 3.1 Required

- High school diploma or equivalent.
- 0 to 1 year of office or clerical experience; training is provided.
- Accuracy, attention to detail and comfort with repetitive, deadline-driven work.
- Basic computer skills, including keyboard speed and spreadsheets.

### 3.2 Preferred

- Post-secondary coursework in business or office administration.
- Prior experience in a financial services or records environment.
- Bilingual English and French.

### 3.3 Licences and certifications

None required.

## 4. Competencies

Measured against HR-FWK-001 Competency and Leadership Model at the Foundation level:

- Risk and Conduct Awareness
- Drive for Results
- Collaboration
- Adaptability
- Customer Obsession

## 5. Compensation and classification

| Item | Value |
| --- | --- |
| Band | 1 (Associate Support) |
| Canada range | $38,000 to $54,000 CAD |
| US range | $36,000 to $52,000 USD |
| Incentive target | 5% of base salary (Annual Incentive Plan) |
| Overtime eligibility, Canada | Yes (non-managerial Band 1) |
| FLSA classification, US | Non-exempt |
| Work arrangement | On-site (operations centre) |

Overtime must be pre-approved and is paid under HR-POL-003 Working Hours and Overtime Policy. A shift premium of $2.00 per hour applies for hours worked between 18:00 and 06:00 on extended-hours teams. Band definitions are in HR-GDE-006 Job Architecture and Pay Bands Guide.

## 6. Working conditions and accessibility

This is an on-site role in an operations centre that follows posted schedules, published at least 14 days ahead (see HR-SUP-004 Branch Operations Scheduling Supplement for the principles that apply to scheduled work). Duties are mainly seated at a workstation. Some teams run extended hours. Hybrid work does not generally apply. The Bank provides accommodation to the point of undue hardship; see HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to: Team Lead, Operations. Direct reports: none.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.1 | 2025-02-03 | Added shift premium and time-recording wording |
| 1.0 | 2023-06-01 | First issue |
