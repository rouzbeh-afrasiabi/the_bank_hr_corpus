# Employee Records Retention Schedule

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-REF-002 |
| Title | Employee Records Retention Schedule |
| Document type | Reference |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-02-01 |
| Last reviewed | 2026-09-01 |
| Next review | 2027-09-01 |
| Policy owner | Chief Privacy Officer |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Applies to | All Canadian and US employees (see Scope) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-016, HR-POL-015, HR-POL-020, HR-POL-022, HR-REF-001 |

## 1. Purpose

This schedule states how long the Bank keeps each type of employee and candidate record, what starts the retention clock, who owns the record, where it is stored and how it is destroyed. It exists so that records are kept long enough to meet legal, audit, payroll and employee-service needs, and are not kept longer than necessary. Keeping personal information beyond its purpose creates privacy and security risk, as set out in HR-POL-016 Employee Data Privacy Policy.

The retention periods in this schedule are Bank minimums and maximums for HR records. Where applicable law requires a longer period, the longer period applies and Legal will tell the record owner. Where applicable law gives a greater right to an individual, the law applies.

## 2. Scope

This schedule applies to:

- all HR records about employees, former employees, candidates and, where the Bank holds their information, dependants and beneficiaries, in paper or electronic form, including email, chat messages, scanned images, system data and backups;
- Canadian and US operations, with the differences described in sections 10 and 11;
- records held by HR Operations, Payroll Services, Benefits Administration, Employee Relations, the Leaves team, the Ethics Office, Corporate Security and managers, and records held for the Bank by vendors (see section 5).

This schedule does not cover client records, financial and tax records of the Bank as a business, or records of contractors and agency workers, which are governed by the Bank's enterprise records policy and procurement agreements. Business-unit working files kept by managers that are not part of an HR record must not duplicate HR records (see section 4).

## 3. Definitions

Terms are explained in HR-REF-001 HR Glossary. The terms below are used in a specific way in this schedule.

- **Record**: Any information, in any format, created or received by the Bank about an individual in the course of the employment relationship or hiring process.
- **Record owner**: The function accountable for the accuracy, security, retention and destruction of a record type, as shown in the retention table.
- **Retention trigger**: The event from which the retention period is counted, such as the end of employment or the closing of a case.
- **Closing of a case**: The date on which the final written outcome and any review of that outcome are complete.
- **Legal hold**: A written instruction from Legal that suspends destruction (section 7).
- **Secure destruction**: Destruction that makes the information permanently unreadable and unrecoverable, as described in section 8.
- **Employment ends**: The last day of employment, as recorded by HR Operations under HR-POL-015 Resignation and Offboarding Policy.

## 4. Principles

### Minimum necessary

The Bank collects and keeps only the personal information that is necessary for an identified purpose. Managers must not keep private copies of HR records such as performance reviews, warnings, medical notes or screening results; the system of record held by HR is the only official copy. Duplicates and working drafts are destroyed once the final record is saved.

### Retention for a defined period

Each record type has a retention period and a trigger. Records are destroyed at the end of the period unless a legal hold applies. Records are not kept "just in case". Where a record contains information covered by more than one row of the retention table, the longest applicable period applies to the whole record unless the record can be separated.

### Legal hold overrides destruction

When Legal issues a legal hold, destruction of the covered records stops, whatever the retention period says (section 7).

### Secure destruction

Records are destroyed in a way that matches their sensitivity. Records classified Confidential or Restricted under HR-POL-017 IT Acceptable Use and Information Security Policy are destroyed using the methods in section 8 and a destruction certificate is kept.

### Separation of medical files

Medical, disability and accommodation information is held separately from the general personnel file, with restricted access that is logged and reviewed quarterly. Managers receive only functional limitations and expected duration. See HR-POL-018 Workplace Accommodation and Accessibility Policy and HR-POL-016.

### Accuracy and access

Records are kept accurate and up to date. Employees may see and request correction of their own information (section 9).

## 5. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Chief Privacy Officer | Owns this schedule; approves changes with the HR Policy Committee; is accountable for privacy compliance and for the annual retention audit |
| Privacy Office | Maintains the destruction calendar, reviews destruction lists, issues destruction certificates with record owners, answers questions on retention |
| Legal | Issues and releases legal holds; advises on statutory retention periods; confirms that a record may be destroyed when a matter is open |
| VP HR Operations | Accountable for the HR record systems and for the destruction cycle for the personnel file and offboarding records |
| Payroll Services | Record owner for payroll, tax and time and attendance records |
| Benefits Administration | Record owner for benefit enrolment and savings plan records, and the contact for Maplewood Benefits and Evergreen Retirement Services |
| Employee Relations (ER) | Record owner for discipline, investigation and complaint records |
| Leaves team | Record owner for leave, workers' compensation and return-to-work records |
| Head of Ethics Office | Record owner for Speak-Up case files |
| Head of Workplace Safety | Record owner for safety incident records |
| Accommodation Specialist | Record owner for accommodation case files |
| HR Business Partners (HRBPs) and managers | Send records to HR rather than keeping them; carry out legal holds when notified |
| Technology and Operations | Runs deletion jobs, manages backups and media sanitization, and provides logs of deletions |
| Vendors (Maplewood Benefits, Evergreen Retirement Services, Clearline, screening providers) | Keep and destroy records as the Bank's contract with them requires and certify destruction on request |

## 6. Retention table

Periods are counted from the retention trigger. "After employment ends" means after the last day of employment. All periods in this section are in years unless stated otherwise. The storage location is the system of record; copies in email or on shared drives are not official records.

### Employment and personnel records

| Record type | Retention period | Trigger | Owner | Storage location | Destruction method |
| --- | --- | --- | --- | --- | --- |
| Personnel file (offer letter, employment contract, status and job changes, compensation history, acknowledgements) | 7 years | After employment ends | VP HR Operations | MyHR employee record and the HR document repository | Electronic deletion; paper cross-cut shredding |
| Performance reviews and goal records | 7 years | After employment ends | SVP Talent and Learning | MyHR performance module | Electronic deletion |
| Performance improvement plan records (FORM-HR-070) | Removed from the active file 12 months after successful completion, then held in the restricted archive with the performance reviews for 7 years | Successful completion of the plan; then end of employment | VP Employee Relations | Restricted ER archive | Electronic deletion |
| Training records | 7 years | After employment ends | SVP Talent and Learning | Learning Hub | Electronic deletion |
| Electronic monitoring logs (email and messaging scans, web filtering, endpoint, badge, VPN and application logs) | 13 months | After the log is created | Chief Information Security Officer | Security logging platform | Automated deletion |
| Call recordings in Capital Markets and Wealth Management | 7 years | After the recording is made | Chief Compliance Officer | Voice recording archive | Electronic deletion |
| Offboarding records (resignation notice, checklist, equipment return) | 7 years | After employment ends | VP HR Operations | MyHR and the HR document repository | Electronic deletion; paper cross-cut shredding |
| Exit interview questionnaires (FORM-HR-082) | 2 years | After employment ends | VP HR Operations | HR analytics repository | Electronic deletion; reports keep only aggregated data |
| Voluntary self-identification data | 2 years for individual-level records; aggregated, de-identified data may be kept without limit | After employment ends | Head of Inclusion and Belonging | Restricted HR data store | Electronic deletion; de-identification of aggregate data |

### Pay, time, benefits and savings records

| Record type | Retention period | Trigger | Owner | Storage location | Destruction method |
| --- | --- | --- | --- | --- | --- |
| Payroll records (pay statements, deductions, tax and withholding forms, tax slips, Record of Employment, direct deposit forms) | 7 years | After employment ends | Payroll Services | Payroll system | Electronic deletion; paper cross-cut shredding |
| Time and attendance records (Time Tracker entries, overtime approvals, time in lieu) | 7 years | End of the year in which the time was worked | Payroll Services | Time Tracker | Electronic deletion |
| Expense records and reimbursement claims, including tuition and designation claims | 7 years | End of the fiscal year in which the claim was paid | Payroll Services | Expense system and MyHR | Electronic deletion |
| Benefit enrolment records and beneficiary designations | 7 years | After employment ends, or after coverage ends for a dependant if later | Benefits Administration | Benefits administration system and Maplewood Benefits | Electronic deletion; vendor certifies deletion |
| Leave records (vacation, sick, personal, parental and family, other leaves; FORM-HR-010, FORM-HR-012, FORM-HR-013) | 7 years | After the leave ends | Leaves team | MyHR and the leaves case file | Electronic deletion |
| Pension and savings plan records (enrolment, contribution elections, vesting, transfers) | 7 years | After the member's entitlements are fully paid out or transferred, and not earlier than 7 years after employment ends | Benefits Administration | Evergreen Retirement Services and the HR document repository | Electronic deletion; vendor certifies deletion |

### Health, safety and accommodation records

| Record type | Retention period | Trigger | Owner | Storage location | Destruction method |
| --- | --- | --- | --- | --- | --- |
| Medical files and medical certificates (FORM-HR-011) | 7 years | After employment ends | Leaves team | Restricted medical file, separate from the personnel file | Electronic deletion; paper cross-cut shredding |
| Accommodation case files (FORM-HR-040, FORM-HR-041) | 7 years | After employment ends | Accommodation Specialist | Restricted accommodation case system | Electronic deletion; paper cross-cut shredding |
| Safety incident records and workers' compensation files | 10 years | After the incident is closed | Head of Workplace Safety | Safety incident system | Electronic deletion; paper cross-cut shredding |
| Short-term and long-term disability claim copies held by HR | 7 years | After employment ends; Maplewood Benefits keeps its own claim file under its contract | Benefits Administration | Restricted benefits case file | Electronic deletion |

### Conduct, investigation and complaint records

| Record type | Retention period | Trigger | Owner | Storage location | Destruction method |
| --- | --- | --- | --- | --- | --- |
| Harassment and violence investigation files (FORM-HR-050 and evidence) | 10 years | After the case is closed | VP Employee Relations | Restricted ER case system | Electronic deletion; paper cross-cut shredding |
| Discipline investigation files | 10 years | After the case is closed | VP Employee Relations | Restricted ER case system | Electronic deletion; paper cross-cut shredding |
| Written warnings and final written warnings (FORM-HR-071) | 7 years in the personnel file; active for 12 months (written) or 24 months (final) for discipline purposes | After employment ends | VP Employee Relations | MyHR personnel file | Electronic deletion |
| Grievance and complaint intake records | 10 years | After the matter is closed | VP Employee Relations | Restricted ER case system | Electronic deletion; paper cross-cut shredding |
| Speak-Up case files (reports, triage, investigation, outcome) | 7 years | After the case is closed | Head of Ethics Office | Ethics case system; Clearline holds report intake data as the contract requires | Electronic deletion; vendor certifies deletion |

### Recruitment, screening and work-authorization records

| Record type | Retention period | Trigger | Owner | Storage location | Destruction method |
| --- | --- | --- | --- | --- | --- |
| Recruitment records of unsuccessful candidates (application, interview notes, assessments) | 12 months | After the requisition is closed | SVP Talent and Learning | Applicant tracking system | Electronic deletion |
| Recruitment records of candidates who are hired (application, interview notes, offer approvals, references) | 7 years | After employment ends, as part of the personnel file | SVP Talent and Learning | Applicant tracking system and personnel file | Electronic deletion |
| Background check results, successful candidates | 7 years | After the candidate is hired | VP HR Operations | Restricted screening vendor portal and HR repository | Electronic deletion; vendor certifies deletion |
| Background check results, unsuccessful or withdrawn candidates | 12 months | After the screening decision | VP HR Operations | Restricted screening vendor portal | Electronic deletion; vendor certifies deletion |
| Screening consent forms (FORM-HR-111) | Same period as the related screening result | Same trigger as the related screening result | VP HR Operations | Restricted screening vendor portal and HR repository | Electronic deletion |
| US Form I-9 and supporting documents | 3 years after the date of hire, or 1 year after employment ends, whichever is later | Date of hire; end of employment | VP HR Operations | Restricted HR document repository, separate from the personnel file | Electronic deletion; paper cross-cut shredding |
| Canadian work permit and right-to-work proof | 2 years | After employment ends | VP HR Operations | Restricted HR document repository | Electronic deletion; paper cross-cut shredding |

### Privacy and governance records

| Record type | Retention period | Trigger | Owner | Storage location | Destruction method |
| --- | --- | --- | --- | --- | --- |
| Personal information access request files (FORM-HR-090) | 7 years | After the request is closed | Chief Privacy Officer | Privacy Office case system | Electronic deletion |
| Privacy impact assessments and data protection impact assessments (FORM-HR-091, FORM-HR-092) | 7 years | After the system or process is retired | Chief Privacy Officer | Privacy Office repository | Electronic deletion |
| Privacy breach records | 7 years | After the breach is closed | Chief Privacy Officer | Privacy Office case system | Electronic deletion |
| Destruction certificates and destruction logs | 7 years | Date of destruction | Privacy Office | Privacy Office repository | Electronic deletion |

Records of types not listed here are kept for 7 years after the retention trigger unless the Privacy Office sets a different period in writing. Requests for a new row are made to the Privacy Office at privacy@bank.example.

## 7. Legal holds

### When a hold applies

Legal issues a legal hold when the Bank reasonably expects litigation, a regulatory inquiry, an audit or an investigation, or receives a request to preserve records. A hold may cover records that would otherwise be due for destruction, as well as records created later.

### How a hold works

1. Legal drafts a written hold notice that names the matter by a reference code (not by the employee's name where this is avoidable), the record types, the people and systems covered and the date range.
2. Legal sends the notice to the Privacy Office, the affected record owners, HRBPs, Technology and Operations and any vendors within 2 business days of the decision to hold.
3. Each recipient confirms in writing within 5 business days that destruction is suspended and that automatic deletion rules for the covered records are switched off.
4. The Privacy Office flags the records in the destruction calendar so that they are removed from every destruction list.
5. Legal sends a reminder to custodians every 90 days. Record owners report any new location of covered records.
6. Legal releases the hold in writing. Records then return to the normal schedule; any record already past its retention period is destroyed in the next destruction cycle.

### Limits

A legal hold does not allow broader access. Only those who need to see held records for the matter may do so, and the personal information in held records remains protected by HR-POL-016. Held records are not edited, merged or moved without Legal's approval. Employees under a legal hold who are asked to preserve records must not delete, alter or hide covered records and must not discuss the hold outside the need-to-know group.

## 8. Destruction procedure and certification

### Quarterly destruction cycle

1. **List**: Within 10 business days after the end of each calendar quarter, each record owner and Technology and Operations produce a list of records whose retention period has ended.
2. **Hold check**: The Privacy Office removes any record subject to a legal hold and any record the Chief Privacy Officer has flagged for an open privacy request or complaint.
3. **Approval**: The record owner reviews the list and approves it in writing within 10 business days. The Privacy Office confirms that the list matches this schedule.
4. **Destruction**: Destruction is completed within 30 days of approval.
5. **Certification**: The record owner and the Privacy Office sign a destruction certificate that states the record types, the date range, the volume, the method, the date and who carried it out. Vendor-held records are covered by the vendor's written certificate.
6. **Retention of the certificate**: Certificates and logs are kept for 7 years (see the privacy and governance records table in section 6).

### Methods

| Format | Method |
| --- | --- |
| Paper | Cross-cut shredding in locked secure-disposal bins or through a certified shredding provider, with a certificate of destruction |
| Electronic records in systems | Secure deletion of the record and its indexes, with a deletion log; where a system cannot delete a record, anonymization that cannot be reversed |
| Backups | Overwritten on the normal backup cycle, no later than 90 days after deletion from the live system; restored backups must have deletions re-applied |
| Devices and removable media | Sanitization to a recognized industry standard, or physical destruction, performed by Technology and Operations |
| Vendor-held records | Deletion by the vendor under contract, with written certification within 30 days of the Bank's instruction |

### Early destruction

Records are not destroyed before the end of the retention period, except to meet a lawful request for erasure that Legal and the Privacy Office have approved, or to correct a record that was created in error. Destruction of any record that was never needed (for example, a copy collected by mistake) is reported to the Privacy Office.

## 9. Employee access and privacy

Employees and former employees may ask to see the personal information the Bank holds about them and may ask for correction of errors. Requests are made on FORM-HR-090 and answered within 30 days, with an extension of up to a further 30 days with notice, as described in HR-POL-016 Employee Data Privacy Policy. The retention schedule is not a reason to refuse access, and a request for access places the records concerned on hold until the request is closed.

Employees may ask HR Connect (1-800-555-0142) what is kept about them and for how long. The Privacy Office can be reached at privacy@bank.example. Records are used only for the purposes for which they were collected. HR access to restricted files is logged and the logs are reviewed quarterly. A suspected privacy breach involving a record is reported to the Privacy Office immediately and within 24 hours of discovery.

Before a new HR system, vendor or tool that stores employee records is launched, the system owner completes a Privacy Impact Assessment (FORM-HR-091) that must confirm the retention rules in this schedule can be applied in the system. High-risk tools need a Data Protection Impact Assessment (FORM-HR-092). See HR-POL-016.

## 10. Canada and US differences

| Topic | Canada | US |
| --- | --- | --- |
| Storage | Canadian employee records are primarily stored in Canada | US employee records are stored in the US or in approved Bank environments |
| Work-authorization records | Work permit or right-to-work proof kept 2 years after employment ends | Form I-9 kept for 3 years after hire or 1 year after employment ends, whichever is later |
| Year-end tax records | T4 and Relevé 1 slips and the Record of Employment, kept 7 years with payroll records | W-2 and Form W-4, kept 7 years with payroll records |
| Screening | Police information check; criminal record only where related to the job in Quebec | Fair Credit Reporting Act checks; fair-chance rules; pre-adverse action notice |
| Voluntary self-identification | Four designated groups, reported in aggregate | US equal employment opportunity categories, reported in aggregate |
| Injury and illness records | Workers' compensation claim file held 10 years after the incident closes | Same 10-year Bank period for the incident record, and any government-mandated log is kept as the law requires |
| Employee access request | Provincial and federal privacy laws; 30 days with possible 30-day extension | State privacy laws where they apply (for example California); 30-day Bank standard applies to all employees |

Where the law of a province or state requires a longer retention period than this schedule for a specific record, the longer period applies to employees in that jurisdiction only. Legal maintains the list of such exceptions and tells the record owner. Where applicable law gives a greater right, the law applies.

## 11. Quebec notes

- HR records for Quebec employees are provided in French on request or by default; English versions are available.
- Quebec's private-sector privacy law (Law 25) requires a Privacy Impact Assessment before personal information is transferred outside Quebec; this includes a transfer to a vendor or system outside Quebec (see HR-POL-016).
- Quebec employee information is destroyed or de-identified once the purpose for which it was collected has been achieved and any required retention period has ended; the Privacy Office checks this in each quarterly destruction cycle.
- Criminal-record information for Quebec candidates and employees is kept only where the check was related to the job, and is destroyed on the schedule for background check results (see HR-POL-020 Pre-Employment Screening Policy).
- Medical evidence from Quebec employees is requested only after 3 consecutive days of sick absence (HR-POL-007 Sick Leave and Personal Leave Policy), so earlier days will not have a certificate on file.
- Relevé 1 slips and other Quebec tax and payroll records are kept with payroll records for 7 years after employment ends.

## 12. Exceptions

An exception to a retention period, whether longer or shorter, needs the written approval of the Chief Privacy Officer and Legal, and must be recorded by the Privacy Office with the reason and the date it ends. A record owner who cannot meet a destruction deadline, for example because a system cannot delete a single record, must tell the Privacy Office before the deadline and put in place compensating controls such as restricted access and anonymization until deletion is possible.

## 13. Consequences of non-compliance

Keeping records past the retention period without a legal hold, destroying records early, destroying records covered by a legal hold, or keeping private copies of HR records is a breach of this schedule and of HR-POL-016. It may lead to discipline up to and including termination under HR-POL-021 Employee Relations and Progressive Discipline Policy. Intentional destruction of records to hide misconduct is serious misconduct. Concerns can be raised without fear of retaliation through the Speak-Up Line (1-800-555-0177), as described in HR-POL-022 Whistleblower and Speak-Up Policy.

## 14. Related documents

- HR-POL-016 Employee Data Privacy Policy
- HR-POL-015 Resignation and Offboarding Policy
- HR-POL-020 Pre-Employment Screening Policy
- HR-POL-022 Whistleblower and Speak-Up Policy
- HR-POL-018 Workplace Accommodation and Accessibility Policy
- HR-POL-017 IT Acceptable Use and Information Security Policy
- HR-POL-021 Employee Relations and Progressive Discipline Policy
- HR-REF-001 HR Glossary

## 15. Contacts

| Need | Contact |
| --- | --- |
| Retention questions, destruction certificates, new record types | Privacy Office, privacy@bank.example |
| Access to your own records | FORM-HR-090 through MyHR; HR Connect 1-800-555-0142 (Monday to Friday 8:00 to 20:00 Eastern Time) |
| Suspected privacy breach or lost device | Privacy Office immediately; Security Operations Centre 1-800-555-0155 (24/7) |
| Legal hold questions | Legal, through your HRBP |
| Concerns about records being kept or destroyed improperly | Speak-Up Line 1-800-555-0177 (24/7, anonymous option) or ethics@bank.example |

## 16. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.0 | 2024-04-01 | First issue of the retention schedule covering personnel, payroll, benefits, screening and investigation records |
| 1.1 | 2025-01-15 | Added time and attendance, expense, safety incident and training records; clarified Quebec notes |
| 2.0 | 2026-02-01 | Added a legal-hold section and Speak-Up case files (7 years after closing); added the quarterly destruction cycle and certification steps |
