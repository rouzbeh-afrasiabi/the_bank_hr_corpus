# Advisor and Sales Incentive Plan Document

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-PLN-002 |
| Title | Advisor and Sales Incentive Plan Document |
| Document type | Plan document |
| Version | 3.0 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-09-30 |
| Next review | 2027-09-30 |
| Policy owner | SVP Total Rewards |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-PLN-001, HR-POL-031, HR-POL-029, HR-POL-030, HR-POL-009, HR-GDE-006 |

## 1. Purpose

1.1 This document sets out the terms of the Advisor and Sales Incentive Plan (the "Plan"). The Plan rewards advisors and sales specialists for serving customers well, growing the business and managing risk and conduct, measured every quarter on a balanced scorecard.

1.2 The Plan replaces the Annual Incentive Plan (HR-PLN-001 Annual Incentive Plan Document) for the Plan Year for the roles in section 3. It has no single-product incentive: no payout is tied to the sale of one product alone.

## 2. Definitions

| Term | Meaning |
| --- | --- |
| Plan Year | The calendar year, 1 January to 31 December. |
| Quarter | A three-month period ending 31 March, 30 June, 30 September or 31 December. |
| Annual target | Annual base salary x the target percentage in section 4. |
| Quarterly target | The annual target divided by 4. |
| Scorecard score | The weighted result of the three scorecard measures, expressed as a percentage. |
| Sales-practice breach | A breach of the Bank's sales and conduct standards that has been substantiated by Compliance or Employee Relations (see HR-POL-030 Fit and Proper and Conduct Standards Policy and HR-POL-021 Employee Relations and Progressive Discipline Policy). |
| Base salary | Annual base salary rate, excluding incentive pay, overtime, premiums and allowances. |

## 3. Eligibility

3.1 **Covered roles.** The Plan applies to Personal Banking Advisors, Senior Personal Banking Advisors, Mortgage Specialists and Wealth Advisors.

3.2 **Conditions for a quarterly payout.** The participant must:

- (a) be in a covered role on the last day of the Quarter;
- (b) be on payroll on the payment date (section 8); and
- (c) hold every licence or registration required for the role that is active during the Quarter (see HR-POL-029 Licensing, Registration and Qualification Policy).

3.3 A participant who is in a covered role for only part of a Quarter, or who takes approved unpaid leave, receives a quarterly target pro-rated by the days in the role and at work.

3.4 **No double participation.** A participant receives no Annual Incentive Plan payout for any period covered by this Plan. For the part of a fiscal year spent outside a covered role, base salary earned counts under HR-PLN-001 in the usual way.

## 4. Target awards

| Role | Target (% of base salary) | Annual target on a $90,000 base (illustration) | Quarterly target |
| --- | --- | --- | --- |
| Personal Banking Advisor | 8% | $7,200 | $1,800 |
| Senior Personal Banking Advisor | 10% | $9,000 | $2,250 |
| Mortgage Specialist | 12% | $10,800 | $2,700 |
| Wealth Advisor | 20% | $18,000 | $4,500 |

The percentages in this table replace the band-based Annual Incentive Plan targets in HR-GDE-006 Job Architecture and Pay Bands Guide for these roles. The dollar columns are illustrations only.

## 5. The quarterly scorecard

5.1 Each Quarter the participant is measured on three components.

| Component | Weight | What it measures |
| --- | --- | --- |
| Customer experience | 40% | Customer feedback, complaint outcomes, and quality of advice and service |
| Growth | 30% | Net new business, customer relationships deepened and balance growth against the role's goals |
| Risk and conduct | 30% | Compliance with policy, file quality, suitability and know-your-customer documentation, and conduct standards |

5.2 Each component is scored against its goal, where 100% means the goal was met. The scorecard score is the sum of each component score multiplied by its weight.

5.3 Business units publish the goals and the scoring scales for each role before the start of each Quarter. Goals must not create an incentive to sell a product that does not suit the customer.

## 6. Payout calculation

6.1 **Formula.** Payout = quarterly target x scorecard score, subject to sections 6.2 to 6.4.

6.2 **Range.** The payout ranges from 0% to 200% of the quarterly target. A scorecard score above 200% is treated as 200%.

6.3 **Minimum threshold.** No payout is made if the scorecard score is below 50%.

6.4 **Conduct gate.** If a sales-practice breach by the participant is substantiated, the payout for the Quarter in which the breach occurred is set to zero, whatever the scorecard score.

6.5 **Worked examples.**

| Participant | Quarterly target | Component scores (customer experience, growth, risk and conduct) | Scorecard score | Payout |
| --- | --- | --- | --- | --- |
| Personal Banking Advisor, $70,000 base (8%: annual target $5,600) | $1,400 | 110%, 90%, 100% | 0.4 x 110 + 0.3 x 90 + 0.3 x 100 = 101% | $1,414 |
| Wealth Advisor, $90,000 base (20%: annual target $18,000) | $4,500 | 140%, 120%, 120% | 56 + 36 + 36 = 128% | $5,760 |
| Mortgage Specialist, $90,000 base | $2,700 | 40%, 50%, 60% | 16 + 15 + 18 = 49% | $0 (below 50%) |
| Wealth Advisor, $90,000 base, substantiated sales-practice breach | $4,500 | any | any | $0 (conduct gate) |

6.6 Payouts are in the currency of pay (CAD in Canada, USD in the US).

## 7. Prohibited practices and risk controls

7.1 No participant may open or alter an account, product or application without the customer's knowledge and consent, manipulate referrals or scoring, or split transactions to affect a scorecard result. A participant who does so is subject to the conduct gate and to the discipline process.

7.2 Managers must not set targets that conflict with the scorecard. Compliance reviews a sample of files for each business unit each Quarter and reports the results to the Total Rewards team before payouts are approved.

## 8. Payment

8.1 Quarterly payouts are paid within 45 days after the end of the Quarter, through payroll, with statutory deductions.

8.2 Total Rewards confirms scorecard results with the business unit head and the HRBP before submitting payouts to Payroll Services by the payroll cut-off in HR-POL-009 Compensation and Payroll Policy.

8.3 The Plan does not use the Annual Incentive Plan funding factor or rating multipliers.

## 9. Termination of employment and leave

| Reason employment ends | Treatment |
| --- | --- |
| Resignation or termination for cause before the payment date | The payout for any Quarter not yet paid is forfeited. |
| Involuntary termination without cause | Payouts for completed Quarters are paid on the regular date; no payout for the Quarter of exit, unless approved by the SVP Total Rewards. |
| Retirement (age 55 with 10 years of service) or death | Payouts for completed Quarters and, pro-rated, the current Quarter are paid. |

9.1 **Leave.** Bank-paid parental leave is treated as time at work for the quarterly target (HR-POL-008 Parental and Family Leave Policy). Other approved unpaid leave is pro-rated under section 3.3.

## 10. Clawback

10.1 The Bank may recover payouts made under this Plan, applying the principles of HR-POL-031 Incentive Deferral and Clawback Policy, where there was misconduct, a sales-practice breach found after payment or a payout based on materially inaccurate results. Written notice is given and the participant has 15 business days to respond. Recovery is subject to applicable law.

10.2 The deferral rules of HR-POL-031 do not apply to payouts under this Plan unless the participant is within the scope of that policy.

## 11. Administration

11.1 The SVP Total Rewards administers the Plan with the business unit heads. The HR Policy Committee approves changes to weights, targets and the covered roles.

11.2 Questions about a scorecard are raised with the manager within 30 days of receiving the result; unresolved questions go to Total Rewards through the HR Case Portal.

11.3 The Plan is discretionary and does not create a guaranteed entitlement.

## 12. Amendment

12.1 The Bank may amend the Plan for any future Quarter by giving participants at least 30 days' notice. A change cannot reduce a payout already earned for a closed Quarter, except under section 10.

## 13. Related documents and contacts

HR-PLN-001 Annual Incentive Plan Document; HR-POL-029 Licensing, Registration and Qualification Policy; HR-POL-030 Fit and Proper and Conduct Standards Policy; HR-POL-031 Incentive Deferral and Clawback Policy. Questions: HR Connect, 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time, hrconnect@bank.example.

## 14. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 3.0 | 2026-01-01 | Moved to a quarterly scorecard with weights of 40%, 30% and 30%; added the 50% minimum threshold, the 200% cap and the conduct gate. |
| 2.0 | 2025-01-01 | Annual re-issue. |
