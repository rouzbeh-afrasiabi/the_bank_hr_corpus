# Dress Code Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-040 |
| Title | Dress Code Policy |
| Document type | Policy |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-07-01 |
| Last reviewed | 2026-06-23 |
| Next review | 2027-06-23 |
| Policy owner | VP HR Operations |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-002, HR-POL-018, HR-POL-023, HR-POL-021, HR-POL-005 |

## 1. Purpose

This policy sets out what the Bank expects employees to wear at work so that customers and colleagues see a professional, welcoming and safe workplace. It explains the standards for office, branch, contact-centre and client-facing roles, the uniform arrangements, when safety footwear is needed, and how religious, cultural and disability-related attire is respected. The aim is simple standards that are applied fairly and do not exclude anyone.

## 2. Scope

The policy applies to all employees in Canada and the US when they are working at a Bank office, branch or operations centre, representing the Bank at a client or public event, or taking part in a video meeting with customers or external parties. It applies to hybrid and remote employees on the days and occasions described in section 6. Contractors and agency workers follow the standard of the site they work at. Where applicable law gives a greater right, the law applies.

## 3. Definitions

- **Business casual:** neat, clean, professional clothing that is comfortable for a normal office day. Examples are trousers, skirts, dresses, collared shirts, blouses, knitwear, tailored shorts of a professional length in summer, and closed or smart open footwear.
- **Business attire:** a more formal standard, such as a suit or jacket with trousers or a skirt, a dress, a shirt or blouse, and dress shoes. A tie is optional.
- **Uniform:** the clothing issued to branch employees under the Bank brand and uniform guidelines.
- **Brand and uniform guidelines:** the design standards for uniforms, name badges and branch presentation, held by the Retail Banking business unit.
- **Badge:** the Bank photo identification card used for building access.

## 4. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Employee | Dresses to the standard for the role, wears the badge, keeps uniforms in good condition, asks early if the standard creates a barrier |
| Manager | Explains the standard, applies it consistently, raises concerns privately and respectfully, passes accommodation needs to the Accommodation Specialist the same business day |
| HRBP | Advises managers and resolves disagreements |
| Accommodation Specialist | Handles religious, cultural, disability, pregnancy and other attire needs under HR-POL-018 |
| Head of Workplace Safety | Decides where safety footwear and protective clothing are required (HR-POL-023) |
| VP HR Operations | Owns this policy |

## 5. Standards by role

| Role type | Standard |
| --- | --- |
| Office roles (head office and regional offices) | Business casual every working day |
| Branch employees | The Bank uniform and badge visible, following the brand and uniform guidelines |
| Contact-centre employees | The brand and uniform guidelines for the site; where no uniform is issued, business casual with the badge visible |
| Operations and technology centres | Business casual with the badge visible |
| Client meetings, in person or on camera | Business attire |

There is no separate "casual Friday" rule. The standard for the role applies every day, so an office employee wears business casual on Friday as on any other day, and a branch employee wears the uniform every scheduled shift.

### 5.1 Badge

The badge is worn visibly above the waist while on Bank premises, and is never lent to anyone else. A lost badge is reported to Corporate Security (1-800-555-0119) at once.

### 5.2 What is not acceptable

Clothing is not acceptable if it is torn or unclean, carries offensive, discriminatory or sexually explicit images or slogans, promotes alcohol, drugs, politics or a competitor, or presents a safety risk. Beachwear and sleepwear are not business casual. These rules apply to everyone equally and are not applied differently because of gender, age, body shape, race or religion.

## 6. Hybrid and remote employees

Hybrid employees follow business casual on in-office days under HR-POL-002 Remote and Hybrid Work Policy. When working from home, employees need to be presentable on camera for team, customer and external meetings. Client-facing video meetings follow the business attire standard from the waist up at least. There is no standard for clothing that is not seen on camera.

## 7. Uniforms

1. The Bank supplies uniforms to branch employees at no cost.
2. Uniforms are replaced **every 12 months**, or sooner if worn, damaged or no longer fitting. The employee asks the branch manager, who orders the replacement within 10 business days.
3. A new branch employee receives a uniform set before the first shift where possible, and in any case within the first week.
4. Uniforms are Bank property, are worn only at work and are returned when the employee leaves, within 5 business days of the last day under HR-POL-015 Resignation and Offboarding Policy.
5. Uniform sizes are available for different body shapes, pregnancy and religious or cultural needs. An employee who needs an alternative cut or fabric asks the branch manager or HR Connect.

## 8. Safety footwear and protective clothing

Safety footwear, high-visibility clothing or other protective equipment is required where the Head of Workplace Safety identifies a hazard, for example in mail rooms, loading areas, facilities and maintenance work, or during construction or move activity on Bank premises. The manager tells the employee before the work begins and provides the equipment at no cost to the employee (see HR-POL-023 Workplace Health, Safety and Wellness Policy). An employee who cannot wear the required equipment for medical or other protected reasons asks for accommodation, and work is assigned safely until a solution is found.

## 9. Religious, cultural and disability-related attire

The Bank respects religious, cultural and disability-related attire, including head coverings, religious symbols, beards, modest dress, hair styles and assistive items. These are not treated as breaches of the standard. Employees do not need to prove a faith or give medical details. Where the Bank's uniform or a safety rule seems to conflict with a personal need, the manager must not refuse; the manager passes the request to the Accommodation Specialist on the same business day and the process in HR-POL-018 Workplace Accommodation and Accessibility Policy applies, including interim measures while the request is pending. Pregnancy-related adjustments (for example maternity uniforms or comfort footwear) are provided on request without a medical certificate where the need is straightforward.

The 2 floating Cultural and Religious Observance Days in HR-POL-010 Statutory Holidays Policy are separate from this policy.

## 10. Procedure when there is a concern

1. The manager who sees a concern speaks to the employee privately and respectfully, on the same day where possible, and refers to the standard, not to the employee's body or personal characteristics.
2. The employee is given the chance to correct it. An employee may be asked to change clothing only where that can be done reasonably, and time spent changing at the manager's instruction is paid working time.
3. If the issue is repeated, the manager records a short note and informs the HRBP within 5 business days.
4. Persistent breaches are handled under HR-POL-021 Employee Relations and Progressive Discipline Policy, starting with a coaching conversation.
5. An employee who feels singled out, or who is told to change an item connected to religion, culture, disability or gender identity, may contact the HRBP, the Ombuds Office (ombuds@bank.example) or the Speak-Up Line (1-800-555-0177) without fear of reprisal. Comments about someone's appearance or attire that harass them are handled under HR-POL-005 Workplace Harassment and Violence Prevention Policy.

## 11. Worked examples

**Example 1: Friday in the office.** An employee at a regional office wears jeans and a clean sweater on a Friday. Jeans in neat condition meet business casual, and there is no casual Friday rule that changes it, so the standard is met. Torn or stained jeans would not be.

**Example 2: client video call.** A hybrid employee works from home and joins a client meeting by video. She wears a jacket and shirt, which is business attire from the waist up, and the standard is met.

**Example 3: head covering.** A branch employee asks to wear a head covering in the Bank's brand colours with the uniform. The branch manager approves the same day and the Accommodation Specialist records it for the file; no medical or religious proof is requested.

**Example 4: uniform replacement.** A teller received a uniform 13 months ago and asks the branch manager for a replacement. The 12-month interval has passed, so the manager orders it within 10 business days.

## 12. Exceptions

A manager may approve a temporary variation for a business reason (for example a branch event or a heatwave) for a defined period. Permanent variations for personal reasons are handled through accommodation. A business unit head may set a stricter standard for a site only with the written agreement of the VP HR Operations, and may not remove any right in section 9.

## 13. Consequences

Failure to follow the standard after a reminder is addressed through HR-POL-021, starting with coaching. A person must never be disciplined for attire that is part of an accommodation or protected by law.

## 14. Related documents and contacts

Related: HR-POL-002 Remote and Hybrid Work Policy; HR-POL-018 Workplace Accommodation and Accessibility Policy; HR-POL-023 Workplace Health, Safety and Wellness Policy; HR-POL-021 Employee Relations and Progressive Discipline Policy. Contact HR Connect at 1-800-555-0142 (Monday to Friday 8:00 to 20:00 Eastern Time) or hrconnect@bank.example. Accommodation requests: accommodations@bank.example. Managers may call the Manager Hotline at 1-800-555-0143.

## 15. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.0 | 2019-04-01 | First dress code policy, with a casual Friday |
| 1.2 | 2022-09-01 | Added the hybrid-work and on-camera standard |
| 2.0 | 2025-07-01 | Removed the casual Friday rule, aligned the standard to business casual for office roles, added the 12-month uniform replacement and the attire protections in section 9 |
