# Secondment Request

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-121 |
| Title | Secondment Request |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-042, HR-POL-011, HR-POL-014, FORM-HR-128 |

## 1. Purpose and when to use this form

Use this form to request a temporary secondment to another business unit (HR-POL-042 Secondment and Job Sharing Policy). A secondment lasts 3 to 18 months. Your band, pay and benefits do not change, and you return to the same or a comparable role. Promotions and transfers are handled separately.

## 2. Who completes it and who approves

You complete it with your current manager and the receiving manager. Both managers and the HRBP approve it.

| Eligibility | Rule |
| --- | --- |
| Service | At least 12 months |
| Last rating | Meets Expectations or higher (HR-POL-011 Performance Management Policy) |
| Performance improvement plan | None active |
| Length | 3 to 18 months; one extension of up to 6 months |

## 3. Where and when to submit (deadline, channel, processing time)

Submit in MyHR (Career and Learning > Secondment Request) at least 30 days before the proposed start date, after agreeing the outline with both managers. The HRBP confirms eligibility within 3 business days; both managers and the HRBP each respond within 10 business days of the complete request, and the HRBP confirms the decision and the start date in writing. Submit an extension request on this form at least 30 days before the end date; only one extension, of up to 6 months, is allowed.

## 4. Form fields

| Field | Required | Notes |
| --- | --- | --- |
| Name, employee ID, band, current business unit | Yes | Pre-filled |
| Current manager and receiving manager | Yes | |
| Receiving business unit and team | Yes | |
| Purpose and objectives of the secondment | Yes | Skills, project or coverage need |
| Proposed start and end dates | Yes | 3 to 18 months |
| Request type | Yes | New or extension |
| Secondment work location and arrangement | Yes | Hybrid, remote or on-site (see HR-POL-002 Remote and Hybrid Work Policy) |
| Backfill and handover plan for the home team | Yes | Agreed with the current manager |
| Who gives performance feedback during the secondment | Yes | Agreed before start |
| Employee's reasons and development goals | No | |

## 5. Declarations and signatures

I confirm that I meet the eligibility rules, that my band, pay and benefits stay unchanged, and that I will return to the same or a comparable role at the end. Employee signature and date: ____________. Current manager: ____________. Receiving manager: ____________. HRBP: ____________.

## 6. What happens next

If approved, HR Operations records the secondment dates in the HR system, and the receiving manager sets objectives. Performance feedback from the receiving manager feeds your year-end review. Before the end date, your current manager and the receiving manager plan your return.

## 7. Related documents

- HR-POL-042 Secondment and Job Sharing Policy
- FORM-HR-128 Job Sharing Request
- HR-POL-014 Employment Status and Classification Policy

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-09-01 | Added extension request and the 12-month service eligibility. |
| 1.0 | 2024-09-01 | Initial form. |
