# How to request vacation in MyHR

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-001 |
| Title | How to request vacation in MyHR |
| Document type | How-to article |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-09-15 |
| Next review | 2027-09-15 |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-006, HR-POL-010, HR-POL-007, FORM-HR-010 |

## 1. The short answer

Submit a vacation request in MyHR under Time and Absence at least 4 weeks ahead for 5 or more days, or at least 5 business days ahead for fewer than 5 days, and wait for your manager's approval.

## 2. Who this applies to

Regular full-time, part-time and fixed-term employees in Canada (including Quebec) and the US, with the same entitlement in both countries (15, 20, 25 or 30 days by completed service at 1 January). Part-time employees accrue pro rata. Casual employees have no vacation days; they receive 6% vacation pay on every paycheque. New hires may request vacation from day 1 but take it only after 3 months of service.

## 3. Steps

1. Sign in to MyHR and select **MyHR > Time and Absence > Request Time Off**.
2. Choose **Vacation**, enter the first and last day, and check the balance shown. Statutory holidays inside your dates are not charged to your balance.
3. Check the business unit's blackout notice (for example the last 2 weeks of December for some branch roles, or fiscal year-end week in Capital Markets).
4. Submit. Your manager must respond within 5 business days. If there is no response, MyHR escalates the request to your manager's manager; silence is never approval.
5. Do not book non-refundable travel until you see **Approved**.
6. To cancel, withdraw at least 2 business days before the start date; the days return to your balance.

## 4. Deadlines to remember

| Item | Rule |
| --- | --- |
| Request for 5 or more days | At least 4 weeks ahead |
| Request for fewer than 5 days | At least 5 business days ahead |
| Mandatory block | 10 consecutive business days, scheduled by 30 June and completed by 31 December |
| Carryover | Up to 5 unused days, used by 31 March; the rest is forfeited |
| Advance | Up to 5 days ahead of accrual, with manager approval |

## 5. What happens next

Approved vacation appears in Time Tracker and your balance updates. Vacation is not paid out during employment; unused earned vacation is paid in final pay when you leave. Unpaid time away is a different request: FORM-HR-010 Leave of Absence Request (2 years of service, up to 6 months).

## 6. Common mistakes

- Taking time off before approval, or assuming no reply means yes.
- Leaving the 10-day block until December. Employees in Capital Markets, Wealth Management and Finance are audited, and their system access is suspended during the block.
- Forgetting the 31 March carryover deadline.

## 7. Who to call

HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, or live chat in MyHR; English and French. Managers: Manager Hotline, 1-800-555-0143.

## 8. Related documents

- HR-POL-006 Vacation and Paid Time Off Policy (the rules)
- HR-POL-010 Statutory Holidays Policy
- HR-POL-007 Sick Leave and Personal Leave Policy (personal days)
- FORM-HR-010 Leave of Absence Request

## 9. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-01-01 | Carryover updated from 3 to 5 days (HR-POL-006 version 4.0). |
| 1.0 | 2025-03-03 | First edition. |
