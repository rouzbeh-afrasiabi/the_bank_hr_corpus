# Workplace Accommodation and Accessibility Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-018 |
| Title | Workplace Accommodation and Accessibility Policy |
| Document type | Policy |
| Version | 3.2 |
| Status | Current |
| Effective date | 2025-08-01 |
| Last reviewed | 2026-06-30 |
| Next review | 2027-06-30 |
| Policy owner | Head of Accessibility and Inclusion |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Applies to | All Canadian and US employees and job applicants (see Scope) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-007, HR-POL-010, HR-POL-016, HR-POL-019, HR-POL-023, FORM-HR-040, FORM-HR-041 |

## 1. Purpose

The Bank is committed to a workplace where every person can contribute fully. This policy explains how employees and applicants request workplace accommodation, how the Bank responds, who is responsible for what, how medical information is protected, and how the Bank identifies and removes barriers through its accessibility plan.

## 2. Scope

The policy applies to all employees (regular, part-time, casual, fixed-term, student, co-op and intern) and applicants in Canada and the US. It applies to every employment matter, including recruitment, hiring, work arrangements, training, evaluation and termination. Contractors and agency workers should contact their engagement contact. Where applicable law gives a greater right, the law applies.

## 3. Legal framework

In Canada, the Bank accommodates to the point of undue hardship under federal and provincial human rights legislation and accessibility laws. In the US, the Bank provides reasonable accommodation unless it would cause undue hardship under the Americans with Disabilities Act, the Pregnant Workers Fairness Act, Title VII and state and local laws. Accommodation is required for needs related to protected grounds, including disability, religion or creed, family status, pregnancy, sex, age and other grounds recognized by law. The standard that gives the employee the greater protection applies.

## 4. Definitions

| Term | Meaning |
| --- | --- |
| Accommodation | A change to a rule, practice, process, tool or environment that removes a barrier related to a protected ground so a person can do their job or take part equally. |
| Functional limitations | What a person can and cannot do (for example "cannot lift more than 5 kg", "needs breaks every 45 minutes"), without a diagnosis. |
| Undue hardship | A level of cost, health and safety risk or business disruption that cannot reasonably be met (see section 9). |
| Accommodation Specialist | The HR specialist who manages requests and is the single point of contact. |
| Accommodation Fund | A central budget that pays accommodation costs. |
| Accommodation Review Panel | A panel that reviews decisions (see section 11). |
| Accessible format | Content provided in a form such as large print, screen-reader compatible documents, captioning, sign language interpretation or plain language. |

## 5. Who may request accommodation

Any employee or applicant may request accommodation, and so may a manager, HRBP or a representative on their behalf with the person's consent. The request may be made to the manager, HR Connect (1-800-555-0142) or accommodations@bank.example. The word "accommodation" does not have to be used: any statement that a person needs a change because of a protected ground starts the process. FORM-HR-040 Accommodation Request is optional. A manager who hears about a possible need must pass it to the Accommodation Specialist the same business day and must not wait for a form.

## 6. Process and timelines

| Step | What happens | Timeline |
| --- | --- | --- |
| 1. Request | Employee or applicant, or the manager, contacts the manager, HR Connect or accommodations@bank.example | Any time |
| 2. Acknowledgement | The Accommodation Specialist acknowledges the request | Within 2 business days |
| 3. Information | If needed, the employee is asked for functional information using FORM-HR-041 Medical Information Supplement for Accommodation | Employee supplies it as soon as reasonably possible; extra time is available on request |
| 4. Interim measures | Temporary adjustments are put in place while the request is pending | Immediately where possible |
| 5. Decision | The Accommodation Specialist, with the manager and HRBP, proposes and records the accommodation in writing | Within 10 business days of complete information; urgent cases within 3 business days |
| 6. Implementation | The measures are put in place and a review date is set | As agreed, normally within 10 business days of the decision for equipment and accessible formats |
| 7. Review | The accommodation is reviewed at the agreed date or when the need changes | At least once a year for long-term needs |
| 8. Panel review (if asked) | The Accommodation Review Panel reviews the decision | Within 10 business days of the request |

Urgent cases include a need that affects safety, an imminent return to work or a hiring deadline. The process is collaborative. The employee takes part, and the Accommodation Specialist considers several solutions, preferring those that respect dignity and independence.

## 7. Medical information limits

Employees are not required to share a diagnosis. The Bank asks only for the information needed to understand the functional limitations, restrictions and expected duration, normally through FORM-HR-041, which can be completed by a health care provider. Managers receive only the functional limitations and the expected duration, never diagnosis, treatment, test results or medical history. Medical and accommodation information is held separately from the general personnel file, access is logged and reviewed quarterly, and the records are kept for 7 years after employment ends (see HR-POL-016 Employee Data Privacy Policy and HR-REF-002 Employee Records Retention Schedule). The Bank reimburses up to $150 CAD or $120 USD for the cost of completing medical forms for an accommodation request.

## 8. Responsibilities

| Role | Responsibilities |
| --- | --- |
| Employee or applicant | Tell the Bank about the need, take part in finding solutions, provide the information requested, follow the agreed accommodation and say when a need changes. |
| Manager | Respond to a request the same business day by passing it to the Accommodation Specialist, put agreed measures in place, keep the information confidential, treat the person fairly and not penalize them for requesting accommodation. |
| HRBP | Support the manager, resolve conflicts with job requirements and help with team impacts. |
| Accommodation Specialist | Manage the request, gather information, propose options, coordinate with Corporate Security, IT, Workplace Safety, and Leaves, and monitor timelines. |
| Head of Accessibility and Inclusion | Own this policy, chair the Accommodation Review Panel and report annually. |
| Legal | Advise on undue hardship decisions and legal obligations. |
| All employees | Respect confidentiality and cooperate with accommodations that affect their work. |

## 9. Undue hardship

Accommodation is provided unless it would cause undue hardship. Only the Head of Accessibility and Inclusion, with Legal, may decide that a request causes undue hardship, and only after all reasonable options, including partial or alternative solutions, have been considered and documented. The factors are:

- the cost, after funding from the Accommodation Fund and any external funding;
- health and safety risk;
- the impact on the Bank's operations and legal obligations, to the extent they cannot be managed.

The following are not undue hardship: a manager's or colleagues' preference, a risk of morale impact, a customer preference, an inconvenience, or the cost to a team budget. If a request cannot be met as asked, the Bank offers the best alternative and explains the decision in writing.

## 10. Funding

Accommodation costs are met by the central Accommodation Fund, not the team budget, so a manager's budget is never a reason to refuse or delay a request. The fund covers equipment, software, assistive technology, interpretation, accessible formats, modified furniture and temporary support. Equipment remains Bank property unless otherwise agreed.

## 11. Review and appeals

An employee who disagrees with an accommodation decision, a delay or a refusal may ask for review by the Accommodation Review Panel within 10 business days of the decision. The panel is chaired by the Head of Accessibility and Inclusion with an Employee Relations consultant and a representative of Legal, none of whom took part in the original decision. The panel reviews the file, meets the employee (who may bring a support person) and gives written reasons within 10 business days of the request. The panel's decision is final under this policy. Employees may also use the Ombuds Office (ombuds@bank.example) for informal advice, the Speak-Up Line, and any external right of complaint at any time. No one may be disadvantaged for requesting accommodation or asking for review.

## 12. Particular situations

### 12.1 Disability and leave

Accommodation and leave work together. An employee on sick leave or disability benefits may be supported by a graduated return to work of up to 12 weeks, coordinated with the Accommodation Specialist (see HR-POL-007 Sick Leave and Personal Leave Policy). Modified duties for a work-related injury are covered by HR-POL-023 Workplace Health, Safety and Wellness Policy and may last up to 12 weeks.

### 12.2 Religious and creed accommodation

The Bank accommodates religious observance, practices and dress, such as prayer time and space, schedule changes, and observance days not in the holiday calendar. The 2 floating Cultural and Religious Observance Days per calendar year are available in both countries (see HR-POL-010 Statutory Holidays Policy) and are separate from accommodation: an employee whose needs go beyond them may request accommodation. The employee does not need to prove membership of a faith group.

### 12.3 Family status and caregiving

The Bank accommodates caregiving responsibilities (for example care of a child or dependent adult) that conflict with working hours or location, for example through a modified schedule, a hybrid arrangement or a temporary change of duties. The request follows the same timeline. Leaves are in HR-POL-008 Parental and Family Leave Policy.

### 12.4 Pregnancy and breastfeeding

Pregnant and breastfeeding employees are entitled to accommodation such as modified duties, extra breaks, seating, a private space and flexible scheduling, without a medical diagnosis where the need is straightforward.

### 12.5 Recruitment

Applicants may ask for accommodation at any stage of recruitment, for example extra time in a test, an interpreter or an accessible interview format. Recruiters tell candidates in each posting and interview invitation how to ask (see HR-POL-019 Recruitment and Selection Policy). Requests are handled by the Accommodation Specialist within the same timelines and are not shared with the hiring panel beyond what is needed to arrange the adjustment.

## 13. Accessible formats

Employees and applicants may ask for any HR document, form, training, meeting or communication in an accessible format by contacting accessibility@bank.example, HR Connect or the Accommodation Specialist. The Bank provides the format within 10 business days of request, faster where a deadline requires it. The Bank provides accessible versions of its HR documents, Learning Hub courses and MyHR on request.

## 14. Accessibility plan

The Bank maintains a multi-year accessibility plan that identifies, removes and prevents barriers in employment, the built environment, information and communications, technology, procurement and the delivery of services. The Head of Accessibility and Inclusion leads the plan with the Abilities Network employee resource group, employees with lived experience and business leaders. The plan is reviewed every 3 years, progress is reported annually, and the plan and feedback process are published in accessible formats. Employees and the public may give feedback at accessibility@bank.example. Feedback is acknowledged within 2 business days and answered in the format requested.

## 15. Consequences

Failing to pass on a request, disclosing accommodation information without authority, refusing a request without following this process or retaliating against anyone who requests accommodation is a breach of the Code of Conduct and may lead to discipline.

## 16. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 3.2 | 2025-08-01 | Clarified that the Accommodation Fund pays all costs, added the 3-business-day urgent timeline and the accessible format timeline of 10 business days. |
| 3.0 | 2023-06-01 | Added the Accommodation Review Panel and the accessibility plan review cycle. |
| 2.0 | 2020-04-01 | Extended the policy to applicants and to family status and religious accommodation. |
