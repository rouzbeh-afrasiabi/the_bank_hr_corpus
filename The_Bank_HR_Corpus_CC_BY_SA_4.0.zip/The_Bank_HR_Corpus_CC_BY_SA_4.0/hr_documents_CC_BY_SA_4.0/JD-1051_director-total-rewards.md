# Director, Total Rewards

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1051 |
| Title | Director, Total Rewards |
| Document type | Job description |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-09-28 |
| Next review | 2027-09-28 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-009, HR-GDE-006, HR-GDE-001, HR-PLN-001, HR-PRC-005, HR-FWK-001 |

## 1. Role summary

The Director, Total Rewards leads the Bank's compensation, incentive, benefits and payroll-policy programmes for Canada and the US. The Director designs the pay and benefits strategy, manages market pricing and the annual salary cycle and ensures programmes are competitive, compliant and fair. The role is Band 7 (Director): it leads a function, shaping strategy and budget for the area. See HR-GDE-006 Job Architecture and Pay Bands Guide.

## 2. Key responsibilities

- Develop and maintain the Total Rewards strategy, targeting the market median (P50) of the defined peer group, pay for performance and annual pay-equity review.
- Own the pay band structure and propose range changes to the HR Policy Committee after the annual market pricing, effective 1 March.
- Lead the annual salary planning cycle, including the merit budget and guides in HR-PRC-005 Calibration and Salary Planning Guidelines.
- Administer the Annual Incentive Plan (HR-PLN-001 Annual Incentive Plan Document) and recommend the business funding factor (0 to 1.5) for Board HR Committee approval; oversee deferral and clawback processes.
- Oversee benefits and retirement programmes with Maplewood Benefits and Evergreen Retirement Services, including annual enrolment (2 to 16 November 2026).
- Lead the Payroll Services interface with the HR Case Portal and keep correction, overpayment and pay-statement standards up to date under HR-POL-009 Compensation and Payroll Policy.
- Sponsor the owner documents of Total Rewards policies, including vacation, sick leave, parental leave and holidays, with the SVP Total Rewards.
- Report on pay equity and pay transparency compliance (HR-POL-037 Pay Transparency Policy).
- Manage a team of compensation, benefits and payroll professionals, including goals, ratings and development.
- Manage the Total Rewards budget, vendor contracts and service levels.
- Represent Total Rewards to executives, regulators, auditors and external survey providers.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in business, finance, human resources or a related field; master's degree preferred.
- Twelve to sixteen years of experience in compensation and benefits, including at least 5 years leading teams.
- Deep knowledge of incentive plan design, benefits strategy and pay-equity requirements in Canada and the US.
- Proven record of influencing executives and managing budgets.

### 3.2 Preferred

- A recognized compensation or benefits designation.
- Experience in a large regulated financial institution.
- Experience presenting to a board committee.

## 4. Competencies

Competency names follow HR-FWK-001 Competency and Leadership Model (Enterprise Leader level, Bands 7 to 9).

- Judgement and Decision Quality
- Drive for Results
- Risk and Conduct Awareness
- Developing Others
- Inclusive Leadership
- Collaboration

## 5. Compensation and classification

| Item | Detail |
| --- | --- |
| Band | 7 (Director) |
| Canada range | $140,000 to $210,000 CAD per year |
| US range | $138,000 to $206,000 USD per year |
| Incentive target | 20% of base salary (Annual Incentive Plan) |
| Overtime eligibility, Canada | No |
| FLSA classification, US | Exempt |
| Work arrangement | Hybrid |

Deferral and clawback rules for Band 7 and above are in HR-POL-031 Incentive Deferral and Clawback Policy; the role is also eligible for the Long-Term Incentive Plan (HR-PLN-003 Long-Term Incentive Plan Document).

## 6. Working conditions and accessibility

Office-based and hybrid by default, with at least 3 days a week in the office; Tuesday and Thursday are anchor days (HR-POL-002 Remote and Hybrid Work Policy; FORM-HR-030). Some travel is expected for vendor, board and regional meetings. The Bank provides accommodation to the point of undue hardship (HR-POL-018 Workplace Accommodation and Accessibility Policy).

## 7. Reporting line

Reports to the SVP Total Rewards. Direct reports: managers in compensation, benefits and payroll policy.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-03-01 | Pay band and incentive target aligned with the 2026 pay bands |
| 1.0 | 2025-01-01 | First issue |
