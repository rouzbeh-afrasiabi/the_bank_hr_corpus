# Reminder: Vacation Carryover into 2025

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-MEMO-2024-001 |
| Title | Reminder: Vacation Carryover into 2025 |
| Document type | Memo |
| Version | 1.0 |
| Status | Superseded |
| Superseded by | HR-MEMO-2025-006 |
| Effective date | 2024-12-02 |
| Last reviewed | Not applicable |
| Next review | Not applicable |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-006, HR-MEMO-2025-006 |

**Use it or carry it: up to 3 vacation days can roll into 2025.**

**From:** SVP Total Rewards

**To:** All employees in Canada and the US

**Date:** 2 December 2024

**Subject:** Vacation carryover from 2024 into 2025

## 1. What is changing

Nothing is changing. This is a reminder of the carryover rule in HR-POL-006 Vacation and Paid Time Off Policy (version 3.0). You may carry up to 3 unused vacation days from 2024 into 2025. Carried days must be used by 31 March 2025.

## 2. Who is affected

All employees with unused vacation at 31 December 2024. Days above 3 are forfeited, except where you were on approved leave or the law requires payment. Where applicable law gives a greater right, the law applies.

## 3. Effective date

The rule applies to balances at year end on 31 December 2024.

## 4. What to do

1. Check your balance in MyHR.
2. Request days of 5 or more at least 4 weeks ahead; request fewer than 5 days at least 5 business days ahead. Managers respond within 5 business days.
3. Book carried days so they are taken by 31 March 2025.
4. Remember that mandatory block leave (10 consecutive business days once a year) still applies.

## 5. Who to call

HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, or live chat in MyHR.

## 6. Related documents

- HR-POL-006 Vacation and Paid Time Off Policy
- HR-POL-010 Statutory Holidays Policy
- HR-MEMO-2025-006 (supersedes this memo for carryover from 2025 into 2026)
