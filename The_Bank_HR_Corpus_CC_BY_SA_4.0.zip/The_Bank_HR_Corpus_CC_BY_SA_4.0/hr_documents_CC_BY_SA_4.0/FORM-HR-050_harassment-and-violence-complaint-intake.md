# Harassment and Violence Complaint Intake

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-050 |
| Title | Harassment and Violence Complaint Intake |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | VP Employee Relations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-005, HR-POL-021, HR-POL-022 |

## 1. Purpose and when to use this form

Use this form to report harassment, discrimination or violence. **If anyone is in immediate danger, call 911 first, then Corporate Security, 1-800-555-0119.** A verbal report is also accepted; the designated recipient completes the form with you.

## 2. Who completes it and who approves

You complete it, or the designated recipient in Employee Relations completes it with you. There is no approval step. You do not need to tell the person involved first.

## 3. Where and when to submit

Submit through the HR Case Portal in MyHR, or give it to your manager, HRBP, or the designated recipient. You can also use the Speak-Up Line, 1-800-555-0177 (24 hours, anonymous option, operated by Clearline). Complaints are encouraged within 12 months of the last incident, but there is no hard deadline. It is a P1 urgent matter: first response within 4 business hours.

## 4. Form fields

| Field | Required | Notes |
| --- | --- | --- |
| Your name and contact details | Yes | Not needed if you report anonymously through the Speak-Up Line |
| Person or people involved | Yes | Name or role |
| Dates, times and location | Yes | Include remote, online and event settings |
| What happened | Yes | Facts in your own words |
| Witnesses | No | |
| Documents, messages or images | No | |
| Interim measures you would like | No | For example a change of seating or schedule |
| Previous reports | No | |

## 5. Declarations and signatures

- I am reporting in good faith. I understand a knowingly false complaint made in bad faith is misconduct.
- I will keep the matter confidential, but I may speak to a lawyer, representative, regulator or counsellor.
- I understand retaliation against me is prohibited.

## 6. What happens next

| Step | Timeline |
| --- | --- |
| Acknowledgement | Within 2 business days |
| Interim measures where needed | Within 5 business days |
| Investigation by an impartial investigator | Completed within 60 calendar days |
| Written outcome to both parties | Within 10 business days after the report |
| Request for review of the outcome | Within 10 business days of the outcome, to the VP Employee Relations |

Either party may bring a support person who is not legal counsel. The Wellspring Support Program, 1-800-555-0166, offers up to 8 free counselling sessions per issue per calendar year. Investigation files are kept for 10 years after closing. You may also file with a human rights commission, the EEOC or another agency at any time. Where applicable law gives a greater right, the law applies.

## 7. Related documents

- HR-POL-005 Workplace Harassment and Violence Prevention Policy
- HR-POL-021 Employee Relations and Progressive Discipline Policy
- HR-POL-022 Whistleblower and Speak-Up Policy

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-09-01 | Aligned with HR-POL-005 version 5.0 timelines. |
