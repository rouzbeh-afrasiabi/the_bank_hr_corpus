# Checklist for returning from a leave

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-037 |
| Title | Checklist for returning from a leave |
| Document type | How-to article |
| Version | 1.1 |
| Status | Current |
| Effective date | 2025-11-01 |
| Last reviewed | 2026-08-03 |
| Next review | 2027-08-03 |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-008, HR-POL-007, HR-POL-018, HR-GDE-001, FORM-HR-011 |

## 1. Short answer

Give 4 weeks' notice of your return date, confirm your pay, benefits and schedule, and, after 5 or more absence days, expect a return-to-work conversation with your manager within 2 business days of your return.

## 2. Who this applies to

Employees in Canada and the US returning from parental leave, caregiver leave, a medical absence, short-term disability or an unpaid personal leave. You return to the same or a comparable role at the same pay band. Where applicable law gives a greater right, the law applies.

## 3. Checklist

1. **Four weeks before:** tell your manager and the Leaves team your return date. To return earlier than planned, the Leaves team confirms within 5 business days.
2. **Medical absence:** if your provider says you are fit, upload FORM-HR-011 Medical Certificate and Fitness-to-Work to the Leaves team through MyHR. It goes to the Leaves team, not your manager.
3. **Pick your schedule.** After parental leave, a phased return of up to 4 weeks at 80% of normal hours is available, paid for hours worked. After illness or injury, a graduated return of up to 12 weeks is arranged with the Accommodation Specialist, your manager and the Leaves team.
4. **Check your role.** Your manager and HRBP explain any change before you return.
5. **Check benefits** in MyHR > Benefits. If your leave was unpaid, pay any invoiced premiums; missed premiums can lapse coverage after 60 days.
6. **Check pay and balances** in MyHR > Pay and MyHR > Time and Absence. Vacation accrues during short-term disability and the Bank-paid top-up period, but stops during long-term disability and after 30 days of personal leave.
7. **Ask for accommodation** if you need it, for example for lactation, through accommodations@bank.example or HR Connect.
8. **After 5 or more absence days,** book the return-to-work conversation with your manager.

## 4. Deadlines

| Item | Deadline |
| --- | --- |
| Return notice | 4 weeks before the return |
| Early return confirmation | Within 5 business days |
| Return-to-work conversation | Within 2 business days of return, after 5 or more absence days |
| Phased return | Up to 4 weeks at 80% of hours |
| Graduated return | Up to 12 weeks |

## 5. What happens next

The Leaves team confirms your return conditions in writing, and Payroll Services pays you for hours worked in a phased or graduated return. Remaining graduated hours are covered by sick days or disability benefits as Maplewood Benefits decides. Service is continuous.

## 6. Common mistakes

- Returning without telling the Leaves team, so payroll and benefits are not updated.
- Sending a medical certificate to your manager.
- Forgetting unpaid-leave premiums.
- Assuming a phased return is automatic; arrange it first.

## 7. Who to call

HR Connect, 1-800-555-0142, hrconnect@bank.example. Wellspring Support Program, 1-800-555-0166, 24 hours a day. Managers: Manager Hotline, 1-800-555-0143.

## 8. Related documents

- HR-POL-008 Parental and Family Leave Policy
- HR-POL-007 Sick Leave and Personal Leave Policy
- HR-POL-018 Workplace Accommodation and Accessibility Policy

## 9. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.1 | 2025-11-01 | Aligned with HR-POL-008 version 5.1. |
| 1.0 | 2025-01-01 | First issue. |
