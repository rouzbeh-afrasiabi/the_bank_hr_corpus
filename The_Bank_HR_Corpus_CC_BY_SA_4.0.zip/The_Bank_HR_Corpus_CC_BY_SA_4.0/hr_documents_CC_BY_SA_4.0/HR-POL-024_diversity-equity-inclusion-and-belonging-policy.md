# Diversity, Equity, Inclusion and Belonging Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-024 |
| Title | Diversity, Equity, Inclusion and Belonging Policy |
| Document type | Policy |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-10-01 |
| Last reviewed | 2026-09-09 |
| Next review | 2027-09-09 |
| Policy owner | Head of Inclusion and Belonging |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Applies to | All Canadian and US employees (see Scope) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-005, HR-POL-009, HR-POL-016, HR-POL-018, HR-POL-019 |

## 1. Purpose

The Bank serves customers and communities of every background, and it performs best when its workforce reflects them and every employee can do their best work. This policy sets out the Bank's commitment to diversity, equity, inclusion and belonging, the principles that guide it, and the practices and accountabilities that turn the commitment into results.

## 2. Scope

This policy applies to all employees in Canada and in the US, and to all stages of the employment relationship: attraction, hiring, onboarding, pay, development, assignments, recognition, leave, accommodation and exit. Promotions and transfers are handled separately. Employment equity and equal opportunity laws apply in each country, and where applicable law gives a greater right, the law applies.

## 3. Definitions

- **Diversity:** the range of differences among people, including race, ethnicity, Indigenous identity, sex, gender identity and expression, sexual orientation, age, disability, religion or creed, family status, veteran status, language and background, as well as differences in experience and thinking.
- **Equity:** fair treatment, access and opportunity, recognizing that people may need different supports to reach the same outcomes.
- **Inclusion:** an environment in which differences are valued and every person is respected and heard.
- **Belonging:** the sense that you can be yourself at work and that you are a valued member of the team.
- **Self-identification:** a voluntary choice to tell the Bank about your membership in a group, so that the Bank can measure representation and remove barriers.

## 4. Principles

1. **Respect and dignity.** Everyone is treated with respect. Discrimination and harassment are not tolerated (see HR-POL-005 Workplace Harassment and Violence Prevention Policy).
2. **Merit and fairness.** Decisions about people are based on skills, experience, performance and potential, and on the Bank's values: Integrity, Customer Focus, Accountability, Collaboration and Inclusion.
3. **Equal opportunity.** Every employee and applicant has access to the same opportunity, and barriers are identified and removed.
4. **Accessibility.** The Bank designs its workplaces, tools and processes so that people with disabilities can participate fully (see HR-POL-018 Workplace Accommodation and Accessibility Policy).
5. **Voluntary and private.** Participation in self-identification, and in employee resource groups, is always voluntary and confidential.
6. **Accountability.** Leaders are responsible for results and are measured on them.
7. **No quotas.** The Bank does not use quotas or set aside positions based on group membership. Goals are aspirations that guide outreach and the removal of barriers, and they never override the selection of the best qualified candidate.

## 5. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Head of Inclusion and Belonging | Owns this policy, sets the annual plan, runs the employee resource groups, publishes the annual report. |
| Business unit heads | Own the inclusion plan for the unit and report progress each quarter. |
| Managers | Build inclusive teams, support accommodation requests, apply fair processes, take part in inclusion training. |
| HRBPs | Review the diversity of slates and the fairness of pay and ratings in their business unit. |
| Head of Accessibility and Inclusion | Leads accessibility and accommodation (HR-POL-018). |
| Executive sponsors | Senior leaders who sponsor each employee resource group. |
| All employees | Treat colleagues inclusively, complete training, speak up about exclusion or bias. |

## 6. Inclusive hiring

The Bank's hiring process is designed to be fair and free from bias. The details are in HR-POL-019 Recruitment and Selection Policy. The key commitments of this policy are:

- job postings use inclusive and plain language, include the pay range, and state that accommodation is available during the process;
- **diverse interview slates** are required for roles in **Band 5 and above**, meaning that the shortlist of candidates includes qualified people from groups that are under-represented in the role, as far as the market allows;
- structured interviews and a panel that is itself varied are used, and interviewers complete unconscious bias training before they interview;
- AI screening tools are never the sole basis for rejecting a candidate, and any AI-assisted tool is first reviewed for bias and privacy under HR-POL-016 Employee Data Privacy Policy;
- the Bank partners with community, Indigenous, newcomer, veteran and disability organizations, and with colleges and universities, to broaden its pool of candidates;
- applicants who need an accommodation during recruitment are supported without disadvantage.

Candidate data is kept for 12 months and used only for the purposes stated.

## 7. Pay equity

The Bank pays for performance and is committed to equal pay for equal or comparable work. Pay equity is reviewed **every year** as part of the compensation cycle, as described in HR-POL-009 Compensation and Payroll Policy. The review examines base pay, incentive and rating outcomes by gender and, where data allow, by other groups, after adjusting for role, band, location and experience. Unexplained differences are corrected, and the Head of Inclusion and Belonging reports the findings and actions to the HR Policy Committee. Pay ranges are disclosed in job postings, and the Bank does not ask candidates for their pay history (see HR-POL-037 Pay Transparency Policy).

## 8. Self-identification and privacy

Employees in Canada may voluntarily self-identify as women, Indigenous peoples, persons with disabilities, or members of visible minorities. Employees in the US may voluntarily self-identify using the federal equal employment opportunity categories. Self-identification is voluntary: choosing not to respond has no effect on any employment decision and a person may update or withdraw their answers at any time in MyHR.

- Answers are used only for statistical and equity analysis, and to meet legal reporting obligations.
- Individual answers are not shared with managers, hiring panels or in any decision about hiring, pay, performance, promotion or discipline.
- Data is held in a restricted system, separately from the general personnel file, and results are reported only in aggregate, with small groups suppressed to prevent re-identification.
- Because self-identification data is sensitive, its use is reviewed through a data protection impact assessment under HR-POL-016 Employee Data Privacy Policy.

## 9. Employee resource groups

Employee resource groups (ERGs) are voluntary, employee-led communities that build belonging, share learning and advise the Bank. Membership is open to all employees, including allies. The Bank has eight ERGs:

| ERG | Focus |
| --- | --- |
| Women's Network | Gender equity and women's career development |
| Pride Alliance | 2SLGBTQ+ employees and allies |
| Black Professionals Network | Black employees and community partnership |
| Indigenous Peoples Circle | First Nations, Inuit, Métis and other Indigenous employees |
| Abilities Network | Employees with disabilities and caregivers |
| Multicultural Network | Cultural, language and newcomer inclusion |
| Parents and Caregivers Network | Employees balancing care responsibilities |
| Veterans and Military Network | Veterans, reservists and military families |

Each ERG has an **executive sponsor**, who is a senior leader that advocates for the group, helps secure resources and links it to business priorities. ERGs receive an annual budget from the Inclusion and Belonging office. Reasonable time (generally up to 2 hours a month) is available for ERG activities with manager agreement, and ERG leadership roles are recognized in performance conversations. ERGs do not handle complaints; those go to the channels in HR-POL-005.

## 10. Accessibility and accommodation

Accessibility is a shared duty. Employees may request accommodation at any time, and the process, timelines and rights are set out in HR-POL-018 Workplace Accommodation and Accessibility Policy. Feedback on accessibility can be sent to accessibility@bank.example, and accommodation requests to accommodations@bank.example.

## 11. Accountability and measurement

- Each business unit head has a documented inclusion plan, approved by the CHRO, with actions on hiring, development and engagement.
- Inclusion outcomes are part of leaders' objectives and are considered in their "how" rating under the values of the performance framework.
- Managers are expected to complete inclusion learning in the Learning Hub, and the Accessibility and Human Rights course is repeated every 2 years.
- Engagement survey results on inclusion are reviewed by each business unit with its HRBP.

## 12. Reporting

The Head of Inclusion and Belonging publishes an **annual pay-equity and representation report** covering representation by band and business unit, hiring, attrition, pay-equity review results, and progress on the plan. The report goes to the HR Policy Committee, the Executive Committee and the Board, and a summary is shared with all employees in MyHR. The report is based on aggregated data and does not name individuals.

## 13. Raising a concern

An employee who experiences or sees discrimination, exclusion or bias should speak to their manager, HRBP or HR Connect (1-800-555-0142), use the Ombuds Office (ombuds@bank.example) for confidential informal advice, or use the Speak-Up Line (1-800-555-0177) anonymously if they prefer. No one will be retaliated against for raising a concern in good faith.

## 14. Consequences

Behaviour that breaches this policy, including discrimination, harassment, retaliation and misuse of self-identification data, may lead to corrective action up to termination under HR-POL-021 Employee Relations and Progressive Discipline Policy.

## 15. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-10-01 | Current version. Added belonging to the policy title and scope, set diverse interview slates for Band 5 and above, confirmed the annual pay-equity and representation report, and affirmed that no quotas are used. |
