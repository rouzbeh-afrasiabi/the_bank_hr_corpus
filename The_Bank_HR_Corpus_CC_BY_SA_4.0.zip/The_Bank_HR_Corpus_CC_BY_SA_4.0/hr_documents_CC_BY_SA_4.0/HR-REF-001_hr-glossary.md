# HR Glossary

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-REF-001 |
| Title | HR Glossary |
| Document type | Reference |
| Version | 1.4 |
| Status | Current |
| Effective date | 2026-06-01 |
| Last reviewed | 2026-10-05 |
| Next review | 2027-10-05 |
| Policy owner | VP HR Operations |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Applies to | All Canadian and US employees (see Scope) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-004, HR-GDE-006, HR-REF-002, HR-POL-014 |

## 1. Purpose and how to use this glossary

This glossary gives one plain-language definition for each term, abbreviation and system name used across the Bank's HR policies, guides, forms and the Employee HR FAQ. It supports consistent reading of HR documents by employees, managers, HR Business Partners (HRBPs) and Employee Relations (ER) consultants.

Each entry follows the pattern **Term**: definition (document ID, document title). The document named in brackets is the governing document for that term. If a definition here appears to differ from the governing document, the governing document applies and HR Operations must be told through the HR Case Portal so that this glossary can be corrected.

This glossary covers employees in Canada and in the US. Where a term applies to only one country, the entry says so. Where applicable law gives a greater right, the law applies. For the full rules on any topic, see the governing document and not only this summary; for example, see HR-GDE-004 HR Service and Support Guide for how to reach HR Connect and how service levels work.

Terms are listed alphabetically within each letter. Abbreviations are listed under the abbreviation itself (for example, AIP) and the full name is given in the definition. There are no entries for letters not used by any term.

## A

- **Accessibility plan**: The Bank's multi-year plan that sets out how barriers for employees and candidates with disabilities are identified, prevented and removed; it is reviewed every 3 years (HR-POL-018, Workplace Accommodation and Accessibility Policy).
- **Accommodation**: A change to a job, workplace, process, schedule or format that lets an employee work, or a candidate apply, despite a barrier connected to a protected ground such as disability, religion or creed, family status or pregnancy, unless it would cause undue hardship (HR-POL-018, Workplace Accommodation and Accessibility Policy).
- **Accommodation Fund**: The central fund that pays the cost of approved accommodations so that the cost is not charged to the employee's team budget (HR-POL-018, Workplace Accommodation and Accessibility Policy).
- **Accommodation Review Panel**: The panel that reviews an accommodation decision on request, within 10 business days of the request for review (HR-POL-018, Workplace Accommodation and Accessibility Policy).
- **Accommodation Specialist**: The HR specialist who assesses accommodation requests, recommends solutions and coordinates graduated return to work (HR-POL-018, Workplace Accommodation and Accessibility Policy).
- **AI-assisted decision**: Any recommendation, score or ranking about an employee or candidate produced in whole or in part by an automated or artificial-intelligence tool; it requires a Data Protection Impact Assessment (DPIA), and a human must make the final decision on any employment outcome (HR-POL-016, Employee Data Privacy Policy).
- **AIP (Annual Incentive Plan)**: The Bank's annual variable pay plan. Payout equals base salary earned multiplied by the band target percentage, the business funding factor (0 to 1.5) and the individual multiplier, and is paid on the first pay date in February (HR-POL-009, Compensation and Payroll Policy).
- **Anchor days**: The days on which hybrid employees are expected in the office: Tuesday and Thursday. The third office day is chosen by the team (HR-POL-002, Remote and Hybrid Work Policy).
- **Annual enrolment**: The yearly period in which employees choose or change benefits for the next plan year; for 2026 it runs from 2 to 16 November for coverage starting 1 January 2027 (HR-GDE-001, Employee Benefits Guide).
- **Attendance plan**: The written Stage 2 plan, prepared on FORM-HR-071, that sets attendance expectations and support after a pattern review (HR-POL-004, Attendance and Absenteeism Policy).
- **Auto-enrolment**: Automatic enrolment of an eligible employee in the retirement or savings plan at a default contribution rate unless the employee opts out (HR-GDE-002, Retirement and Savings Plan Guide).

## B

- **Band**: One of the nine job levels (Band 1 Associate Support to Band 9 Senior Vice President) that group roles of similar scope and pay range; Executive Committee roles sit outside the bands (HR-GDE-006, Job Architecture and Pay Bands Guide).
- **Base salary**: The annual or hourly rate of pay for the role, excluding incentive pay, premiums, allowances and overtime; it is the basis for most percentage-based entitlements (HR-POL-009, Compensation and Payroll Policy).
- **Benefits plan year**: The calendar year from 1 January to 31 December for which benefit elections apply (HR-GDE-001, Employee Benefits Guide).
- **Bereavement leave**: Paid leave on the death of a family member or close friend, with the number of days depending on the relationship, plus unpaid travel days (HR-POL-026, Bereavement, Jury Duty and Other Leaves Policy).
- **Blackout period**: A period set by a business unit during which vacation requests are normally refused, for example the last 2 weeks of December for some branch roles (HR-POL-006, Vacation and Paid Time Off Policy).
- **Block leave**: The mandatory risk-control rule that every employee takes at least 10 consecutive business days of vacation once per calendar year; Capital Markets, Wealth Management and Finance roles are audited for compliance (HR-POL-006, Vacation and Paid Time Off Policy).
- **Business funding factor**: The multiplier, from 0 to 1.5, set each year according to the Bank's results and applied to every incentive payout (HR-POL-009, Compensation and Payroll Policy).

## C

- **Calibration**: The review meeting in which leaders compare proposed performance ratings across teams to check consistency and fairness; it runs from 11 December to 10 January (HR-POL-011, Performance Management Policy).
- **Call-out minimum**: The minimum of 3 hours' pay at the applicable rate when an employee on call is required to work (HR-POL-003, Working Hours and Overtime Policy).
- **Casual employee**: An on-call employee who works under 20 hours a week on average; casual employees receive 6% vacation pay on every paycheque and are not eligible for the Bank benefit plans except the employee assistance program (HR-POL-014, Employment Status and Classification Policy).
- **Cliff vesting**: Vesting that happens all at once at a set point; in the US 401(k) Savings Plan the Bank contributions vest after 2 years of service (HR-GDE-002, Retirement and Savings Plan Guide).
- **COBRA**: The US continuation-coverage law that lets a former employee keep group health coverage at their own cost; the election notice is sent within 14 days, the election window is 60 days, and coverage can last up to 18 months (HR-GDE-001, Employee Benefits Guide).
- **Compa-ratio**: A person's base salary divided by the midpoint of the pay band for the role, shown as a decimal or percentage; it shows where pay sits in the range (HR-GDE-006, Job Architecture and Pay Bands Guide).
- **Compassionate care leave**: Unpaid, job-protected Canadian leave of up to 28 weeks to care for a family member with a serious medical condition and a significant risk of death (HR-POL-008, Parental and Family Leave Policy).
- **Conflict of interest**: A situation in which a personal, family or financial interest could, or could appear to, influence an employee's work for the Bank; it must be disclosed within 10 business days of becoming aware, using FORM-HR-100 (HR-POL-001, Code of Conduct and Ethics).
- **Contractor**: An individual or agency worker who is not an employee and is not covered by HR policies other than the Code of Conduct, IT acceptable use and mandatory training; contractors are engaged through Procurement and Legal (HR-POL-014, Employment Status and Classification Policy).
- **Core hours**: The period from 10:00 to 15:00 local time during which office-based staff are expected to be available (HR-POL-003, Working Hours and Overtime Policy).
- **Critical illness leave**: Unpaid, job-protected Canadian leave to care for a critically ill child (up to 37 weeks) or adult (up to 17 weeks) (HR-POL-008, Parental and Family Leave Policy).

## D

- **Data classification**: The four labels used to rate information by sensitivity: Public, Internal, Confidential and Restricted (HR-POL-017, IT Acceptable Use and Information Security Policy).
- **Defined contribution pension plan**: A pension plan in which the benefit depends on contributions and investment results; the Bank Savings and Pension Plan in Canada is of this type (HR-GDE-002, Retirement and Savings Plan Guide).
- **Dependant**: A person covered through an employee's benefits: a spouse, common-law or domestic partner, and children to age 21 (to 26 if a full-time student) in Canada or to age 26 in the US (HR-GDE-001, Employee Benefits Guide).
- **Designated recipient**: The Employee Relations team member who receives harassment and violence complaints and starts the process (HR-POL-005, Workplace Harassment and Violence Prevention Policy).
- **Destruction certificate**: The signed record that confirms that records were destroyed in line with the retention schedule, kept by the Privacy Office (HR-REF-002, Employee Records Retention Schedule).
- **Direct deposit**: Payment of net pay into the employee's bank account; it is mandatory and is set up or changed on FORM-HR-022 (HR-POL-009, Compensation and Payroll Policy).
- **DPIA (Data Protection Impact Assessment)**: The deeper privacy assessment (FORM-HR-092) required for high-risk processing such as employee monitoring, biometrics, AI-assisted decisions, large-scale sensitive data or cross-border transfers; it is decided by the Privacy Governance Committee within 30 days and reassessed annually (HR-POL-016, Employee Data Privacy Policy).
- **Domestic and family violence leave**: Confidential paid leave of 10 days per year for employees affected by domestic or family violence, with referral to the employee assistance program and workplace safety planning (HR-POL-026, Bereavement, Jury Duty and Other Leaves Policy).

## E

- **EAP (employee assistance program)**: The confidential counselling and support service, provided by the Wellspring Support Program, available 24 hours a day at no cost to employees and household members (HR-GDE-001, Employee Benefits Guide).
- **EEOC (Equal Employment Opportunity Commission)**: The US federal agency that enforces workplace anti-discrimination laws; EEO categories are used for voluntary self-identification in the US (HR-POL-024, Diversity, Equity, Inclusion and Belonging Policy).
- **Employee Relations (ER)**: The HR team that advises on conduct, discipline, investigations and terminations, and whose approval is needed before termination (HR-POL-021, Employee Relations and Progressive Discipline Policy).
- **Employment Insurance (EI)**: The Canadian federal program that pays benefits such as maternity and parental benefits; the Bank top-up is coordinated so that total pay equals the stated percentage of base salary (HR-POL-008, Parental and Family Leave Policy).
- **Evergreen Retirement Services**: The recordkeeper for the Bank's pension and savings plans in both countries (HR-GDE-002, Retirement and Savings Plan Guide).
- **Exempt**: In the US, an employee who is not entitled to overtime under the Fair Labor Standards Act (FLSA) because of the duties and pay level of the role; exempt employees record absences only in Time Tracker (HR-POL-003, Working Hours and Overtime Policy).
- **Exit interview**: A voluntary conversation held in the final week by HR Operations (not the manager); results are aggregated quarterly (HR-POL-015, Resignation and Offboarding Policy).
- **Extra hours**: In Canada, hours worked between 37.5 and 40 per week, paid at straight time or banked 1:1 (HR-POL-003, Working Hours and Overtime Policy).

## F

- **Fair-chance rules**: Laws and Bank practice that limit criminal-record checks until after a conditional offer and require an individualized assessment (HR-POL-020, Pre-Employment Screening Policy).
- **Final written warning**: The step before termination in progressive discipline; it stays active for 24 months and may include an unpaid suspension of up to 3 days (HR-POL-021, Employee Relations and Progressive Discipline Policy).
- **Fiscal year**: The Bank's financial and performance year, from 1 November to 31 October (HR-POL-011, Performance Management Policy).
- **Fixed-term employee**: An employee hired for a defined period of up to 24 months, after which the role converts to regular or ends; benefits eligibility depends on whether the term is 6 months or more (HR-POL-014, Employment Status and Classification Policy).
- **FLSA (Fair Labor Standards Act)**: The US federal law that sets minimum wage and overtime rules; the Bank classifies US roles as exempt or non-exempt under it (HR-POL-003, Working Hours and Overtime Policy).
- **Floating days**: Two Cultural and Religious Observance Days per calendar year, taken on 24 hours' notice, with no carryover (HR-POL-010, Statutory Holidays Policy).
- **FMLA (Family and Medical Leave Act)**: The US federal law that gives eligible employees up to 12 weeks of job-protected leave; Bank paid parental leave runs at the same time (HR-POL-008, Parental and Family Leave Policy).
- **FORM-HR**: The prefix for all HR forms, followed by a three-digit number; the catalogue of forms is kept in HR-GDE-004, HR Service and Support Guide.

## G

- **Garden leave**: A period during notice when a departing employee is paid but relieved of work and access; the Bank may place Band 7 and above employees on paid garden leave (HR-POL-015, Resignation and Offboarding Policy).
- **Garnishment**: A court-ordered deduction from pay to satisfy a debt or support order; Payroll Services complies with the order and notifies the employee (HR-POL-009, Compensation and Payroll Policy).
- **Gifts and entertainment**: Items or hospitality given or received in connection with Bank business; up to $100 per occasion and $250 cumulative per source per calendar year may be accepted, and cash and gift cards are never accepted (HR-POL-001, Code of Conduct and Ethics).
- **Graduated return to work**: A planned increase in hours and duties after illness or injury, up to 12 weeks, coordinated with the Accommodation Specialist (HR-POL-007, Sick Leave and Personal Leave Policy).

## H

- **Hardship withdrawal**: A withdrawal from the US 401(k) Savings Plan permitted for an immediate and heavy financial need, subject to plan rules (HR-GDE-002, Retirement and Savings Plan Guide).
- **HR Case Portal**: The case-management tool inside MyHR where employees and managers raise HR requests and report payroll errors (HR-GDE-004, HR Service and Support Guide).
- **HR Connect**: The HR contact centre, reached at 1-800-555-0142 or by live chat in MyHR, Monday to Friday 8:00 to 20:00 Eastern Time (HR-GDE-004, HR Service and Support Guide).
- **HRBP (HR Business Partner)**: The HR advisor assigned to a business unit who supports leaders on people matters, approves performance improvement plans before the meeting and is consulted before written warnings (HR-GDE-005, Manager's HR Procedures Guide).
- **HSA (health savings account)**: A US tax-advantaged account paired with the Saver HDHP; the Bank deposits $750 (individual) or $1,500 (family) in January (HR-GDE-001, Employee Benefits Guide).
- **Hybrid work**: The default arrangement for eligible office roles, with at least 3 days a week in the office, including the anchor days (HR-POL-002, Remote and Hybrid Work Policy).

## I

- **I-9 (Form I-9)**: The US form that verifies identity and authorization to work, completed within 3 business days of the start date (HR-GDE-003, New Employee Onboarding Guide).
- **Incidental personal use**: Limited personal use of Bank systems that does not interfere with work or breach policy; it is allowed, and Bank systems are monitored in a disclosed, non-covert way (HR-POL-017, IT Acceptable Use and Information Security Policy).
- **Interim measures**: Temporary steps, such as changing reporting lines or schedules, put in place within 5 business days of a harassment or violence report to protect the people involved (HR-POL-005, Workplace Harassment and Violence Prevention Policy).

## J

- **Job-protected leave**: A leave during which the employee has the right to return to the same or a comparable role at the same pay band (HR-POL-008, Parental and Family Leave Policy).
- **Jury duty**: Court service during which the Bank pays full salary for up to 10 business days, after which only the court allowance is received (HR-POL-026, Bereavement, Jury Duty and Other Leaves Policy).

## L

- **Law 25**: Quebec's private-sector privacy law reform, which among other things requires a privacy impact assessment before information is transferred outside Quebec (HR-POL-016, Employee Data Privacy Policy).
- **Learning Hub**: The Bank's online training platform where mandatory and elective courses are assigned and completed (HR-POL-012, Learning and Development Policy).
- **Leaves team**: The HR Operations specialist team that administers leaves of absence and files workers' compensation claims within 3 business days of learning of an injury (HR-POL-023, Workplace Health, Safety and Wellness Policy).
- **Least privilege**: The security rule that users receive only the access needed for their role; access is reviewed quarterly (HR-POL-017, IT Acceptable Use and Information Security Policy).
- **Legal hold**: A written instruction from Legal that suspends the destruction of records that may be relevant to litigation, an investigation or a regulatory matter until it is released (HR-REF-002, Employee Records Retention Schedule).
- **Lock-in**: The rule that Canadian pension assets cannot be withdrawn as cash before age 55 (HR-GDE-002, Retirement and Savings Plan Guide).
- **Long-term disability**: Income protection that begins in week 27 of an absence and pays 66 2/3% of base salary to a maximum of $15,000 per month, to age 65, with an "own occupation" test for the first 24 months (HR-POL-007, Sick Leave and Personal Leave Policy).

## M

- **Manager Hotline**: The dedicated line for managers (1-800-555-0143), with a response within 4 business hours (HR-GDE-004, HR Service and Support Guide).
- **Mandatory training**: Courses every employee must complete in the Learning Hub, such as Code of Conduct and Ethics and Privacy and Information Security Awareness; new hires complete them within 30 days (HR-POL-012, Learning and Development Policy).
- **Maplewood Benefits**: The insurance carrier and claims administrator for health, life and disability coverage in both countries (HR-GDE-001, Employee Benefits Guide).
- **Medical certificate**: A health-care provider's note required from the 4th consecutive working day of sick absence (after 3 consecutive days in Quebec); it is submitted on FORM-HR-011 or equivalent (HR-POL-007, Sick Leave and Personal Leave Policy).
- **Mental health first aider**: A trained employee volunteer who offers first-line support and directs colleagues to professional help (HR-POL-023, Workplace Health, Safety and Wellness Policy).
- **Merit increase**: The annual base-salary increase effective 1 March, based on the year-end rating; an employee on an active performance improvement plan is not eligible (HR-POL-009, Compensation and Payroll Policy).
- **MFA (multi-factor authentication)**: A sign-in method that needs two or more proofs of identity; it is required for Bank systems (HR-POL-017, IT Acceptable Use and Information Security Policy).
- **MyHR**: The employee and manager self-service portal for pay statements, leave and vacation requests, benefits, forms and the HR Case Portal (HR-GDE-004, HR Service and Support Guide).

## N

- **No-call/no-show**: Failure to report for 3 consecutive scheduled days without contact; after at least 3 documented contact attempts and a letter, it may be treated as presumed job abandonment (HR-POL-004, Attendance and Absenteeism Policy).
- **Non-exempt**: In the US, an employee who is entitled to overtime under the FLSA and who records start, end and meal times in Time Tracker (HR-POL-003, Working Hours and Overtime Policy).
- **Notice period**: The advance written notice an employee gives on resigning: 2 weeks for Bands 1 to 4, 4 weeks for Bands 5 and 6, and 8 weeks for Band 7 and above (HR-POL-015, Resignation and Offboarding Policy).

## O

- **Ombuds Office**: The independent, confidential and informal resource for employees; it is always available if a service level is missed or an issue is unresolved (HR-GDE-004, HR Service and Support Guide).
- **On-call allowance**: The weekly payment for being available outside normal hours: $200 CAD or $150 USD per week (HR-POL-003, Working Hours and Overtime Policy).
- **Onboarding buddy**: A peer assigned to a new hire to answer practical questions during the first weeks (HR-GDE-003, New Employee Onboarding Guide).
- **Outplacement**: Career transition support after involuntary termination without cause: 12 weeks for Bands 1 to 6 and 26 weeks for Band 7 and above (HR-POL-025, Involuntary Termination and Severance Policy).
- **Outside business activity**: Work, business or external board service outside the Bank that requires prior approval on FORM-HR-102 (HR-POL-001, Code of Conduct and Ethics).
- **Overtime**: Hours worked beyond the weekly or daily threshold set for the jurisdiction, paid at 1.5 times (2 times in some cases) and pre-approved in Time Tracker (HR-POL-003, Working Hours and Overtime Policy).
- **Own occupation**: The test, applied in the first 24 months of long-term disability, of whether the employee can perform the essential duties of their own job (HR-POL-007, Sick Leave and Personal Leave Policy).

## P

- **P1 to P4 (priority levels)**: The four HR service priorities. P1 urgent has a first response within 4 business hours; P2 high within 1 business day; P3 standard within 2 business days; P4 low or information within 3 business days (HR-GDE-004, HR Service and Support Guide).
- **Part-time employee (regular)**: An employee who works 20 to under 35 hours per week; entitlements are pro-rated by hours (HR-POL-014, Employment Status and Classification Policy).
- **Pay band**: The salary range (minimum, midpoint and maximum) for a band, set separately for Canada and the US (HR-GDE-006, Job Architecture and Pay Bands Guide).
- **Pay in lieu of notice**: Payment made instead of working through the notice period on termination without cause (HR-POL-025, Involuntary Termination and Severance Policy).
- **Performance year**: The period from 1 November to 31 October against which goals and results are assessed (HR-POL-011, Performance Management Policy).
- **Personal days**: Three days per calendar year for any reason, taken in half-day minimums, with no carryover, payout or certificate (HR-POL-007, Sick Leave and Personal Leave Policy).
- **Personal leave of absence**: Unpaid leave of up to 6 months after 2 years of service, requested on FORM-HR-010 and approved by the Director and HRBP (HR-POL-007, Sick Leave and Personal Leave Policy).
- **Personnel file**: The employee's main HR record, kept for 7 years after employment ends; medical and accommodation information is held separately (HR-REF-002, Employee Records Retention Schedule).
- **PIA (Privacy Impact Assessment)**: The assessment (FORM-HR-091) required before launching or materially changing an HR system, process, vendor or tool that handles employee personal information; the Privacy Office reviews it within 15 business days (HR-POL-016, Employee Data Privacy Policy).
- **PIP (performance improvement plan)**: A written plan on FORM-HR-070, normally 60 days long (range 30 to 90), with weekly check-ins, used for sustained underperformance (HR-POL-013, Performance Improvement Policy).
- **PIPEDA**: Canada's federal private-sector privacy law, the Personal Information Protection and Electronic Documents Act, one of the laws behind the Bank's privacy principles (HR-POL-016, Employee Data Privacy Policy).
- **Pre-adverse action notice**: In the US, the notice sent to a candidate before a decision based on a screening result, with 5 business days to respond (HR-POL-020, Pre-Employment Screening Policy).
- **Privacy Governance Committee**: The committee that decides DPIAs and co-approves the Employee Data Privacy Policy with the CHRO (HR-POL-016, Employee Data Privacy Policy).
- **Probation**: The first 3 months of employment, extendable once to 6 months with written notice before the end of month 3 (HR-POL-014, Employment Status and Classification Policy).
- **Protected absence**: An absence that never counts toward an attendance pattern review, such as statutory leave, accommodated absence, vacation or bereavement (HR-POL-004, Attendance and Absenteeism Policy).

## Q

- **QPIP (Quebec Parental Insurance Plan)**: The Quebec government program that pays maternity, paternity, parental and adoption benefits in place of Employment Insurance; the Bank top-up is coordinated with it (HR-POL-008, Parental and Family Leave Policy).
- **Quarterly access review**: The review each quarter of who has access to systems and HR records, to confirm least privilege; HR access to medical files is logged and reviewed quarterly (HR-POL-016, Employee Data Privacy Policy).

## R

- **Rating scale**: The five performance ratings: 1 Outstanding, 2 Exceeds Expectations, 3 Meets Expectations, 4 Needs Improvement and 5 Unsatisfactory (HR-POL-011, Performance Management Policy).
- **Real risk of significant harm**: The test the Privacy Office applies after a privacy breach to decide whether regulators and individuals must be notified (HR-POL-016, Employee Data Privacy Policy).
- **Record of Employment (ROE)**: The Canadian electronic record of an employee's insurable earnings and hours, issued within 5 calendar days after the end of the pay period in which employment ends (HR-POL-015, Resignation and Offboarding Policy).
- **Rehire eligibility**: The code, Eligible or Not Eligible, recorded at exit to guide future hiring (HR-POL-015, Resignation and Offboarding Policy).
- **Relevé 1**: The Quebec income tax slip issued by 28 February, along with the federal T4 (HR-POL-009, Compensation and Payroll Policy).
- **Remote work**: A role-designated and approved arrangement in which the employee works from home, subject to eligibility criteria and up to 4 planned in-person events a year (HR-POL-002, Remote and Hybrid Work Policy).
- **Retention period**: The length of time a record type must be kept, and its trigger, before secure destruction (HR-REF-002, Employee Records Retention Schedule).
- **Right to disconnect**: The principle that employees are not expected to respond to work communications outside working hours except when on call (HR-POL-003, Working Hours and Overtime Policy).
- **RRSP (Registered Retirement Savings Plan)**: A Canadian individual savings plan available as an optional Group RRSP through payroll, with no Bank match (HR-GDE-002, Retirement and Savings Plan Guide).

## S

- **Service date**: The date from which continuous service is counted for entitlements; a rehire within 12 months restores prior service (HR-POL-014, Employment Status and Classification Policy).
- **Severance**: Notice or pay in lieu on termination without cause, the greater of the statutory minimum and the Bank formula (HR-POL-025, Involuntary Termination and Severance Policy).
- **Shift premium**: A premium of $2.00 per hour for hours worked between 18:00 and 06:00 in Technology and Operations and extended-hours branches (HR-POL-003, Working Hours and Overtime Policy).
- **Short-term disability**: Employer-paid income protection through Maplewood Benefits that starts after 5 consecutive working days of absence, at 100% of base salary for weeks 1 to 13 and 75% for weeks 14 to 26 (HR-POL-007, Sick Leave and Personal Leave Policy).
- **SIN (Social Insurance Number)**: The Canadian number provided to Payroll Services within 3 business days of the start date (HR-GDE-003, New Employee Onboarding Guide).
- **SOC (Security Operations Centre)**: The 24/7 team that receives reports of suspected security incidents and lost devices, no later than 1 hour after discovery (HR-POL-017, IT Acceptable Use and Information Security Policy).
- **Speak-Up Line**: The confidential line, operated 24 hours a day by Clearline, with an anonymous option, for reporting concerns about misconduct (HR-POL-022, Whistleblower and Speak-Up Policy).
- **Statutory holiday**: A paid holiday recognized by law and observed by the Bank, such as Canada Day or Thanksgiving, listed each year in the policy (HR-POL-010, Statutory Holidays Policy).
- **Straight time**: Pay at the regular hourly rate, without an overtime premium (HR-POL-003, Working Hours and Overtime Policy).
- **Support person**: A colleague or other person, who may not be legal counsel, who accompanies an employee to a meeting about a performance plan or discipline (HR-POL-021, Employee Relations and Progressive Discipline Policy).

## T

- **T2200**: The Canadian form, Declaration of Conditions of Employment, that a remote or hybrid employee may request from HR Operations for tax purposes (HR-POL-002, Remote and Hybrid Work Policy).
- **T4**: The Canadian employment income slip issued by 28 February (HR-POL-009, Compensation and Payroll Policy).
- **Target-date fund**: The default investment option, which adjusts its mix of investments as the employee approaches retirement age (HR-GDE-002, Retirement and Savings Plan Guide).
- **Temporary work from elsewhere**: Working for a limited time from a location other than the usual one, requested on FORM-HR-031; up to 20 working days per calendar year within the home country and up to 10 across the Canada-US border (HR-POL-002, Remote and Hybrid Work Policy).
- **TFSA (Tax-Free Savings Account)**: A Canadian savings account available through payroll as an option, with no Bank match (HR-GDE-002, Retirement and Savings Plan Guide).
- **Tier 1, Tier 2 and Tier 3**: The HR support levels. Tier 1 is the HR Connect agent, Tier 2 the specialist teams (Payroll, Benefits, Leaves, Total Rewards, HR Operations) and Tier 3 the HRBP, Employee Relations, Legal and the Privacy Office (HR-GDE-004, HR Service and Support Guide).
- **Time in lieu**: Canada only. Paid time off banked at 1.5 hours per overtime hour worked, at the employee's request and with manager approval; capped at 40 hours and taken within 3 months (HR-POL-003, Working Hours and Overtime Policy).
- **Time Tracker**: The system where non-exempt employees enter hours and all employees enter absences, due by Friday at 17:00 local time (HR-POL-003, Working Hours and Overtime Policy).
- **Tuition reimbursement**: Reimbursement of fees for approved job-related or career-related courses, up to $5,000 CAD or $5,250 USD per fiscal year, based on the grade achieved (HR-POL-012, Learning and Development Policy).

## U

- **Undue hardship**: The legal limit on accommodation: the point at which the cost, health and safety risk or business impact of an accommodation is excessive; it is assessed case by case (HR-POL-018, Workplace Accommodation and Accessibility Policy).

## V

- **Vacation advance**: Use of up to 5 vacation days ahead of accrual, with manager approval; the amount is recovered from final pay if the employee leaves (HR-POL-006, Vacation and Paid Time Off Policy).
- **Vesting**: The point at which employer contributions to a retirement plan become the employee's own; Canadian pension contributions vest immediately and US 401(k) contributions vest after 2 years (HR-GDE-002, Retirement and Savings Plan Guide).
- **Voluntary self-identification**: Optional disclosure of demographic information, used only for equity reporting and held separately from personnel decisions (HR-POL-024, Diversity, Equity, Inclusion and Belonging Policy).

## W

- **W-2**: The US annual wage and tax statement issued by 31 January (HR-POL-009, Compensation and Payroll Policy).
- **W-4**: The US federal withholding form completed by a new hire at onboarding (HR-GDE-003, New Employee Onboarding Guide).
- **WARN Act**: The US federal law requiring 60 days' notice of plant closings and mass layoffs (HR-POL-025, Involuntary Termination and Severance Policy).
- **Wellness spending account**: An annual allowance of $500 CAD or $400 USD per calendar year for wellness expenses, claimed by 31 March of the following year (HR-GDE-001, Employee Benefits Guide).
- **Wellspring Support Program**: The Bank's employee assistance program provider, available at 1-800-555-0166, with up to 8 counselling sessions per issue per calendar year (HR-GDE-001, Employee Benefits Guide).
- **Work arrangement**: The classification of a role as On-site, Hybrid or Remote, recorded through FORM-HR-030 (HR-POL-002, Remote and Hybrid Work Policy).
- **Workers' compensation**: The statutory insurance program that covers work-related injury and illness; workplace injuries must be reported to the manager and Corporate Security immediately and in MyHR within 24 hours (HR-POL-023, Workplace Health, Safety and Wellness Policy).
- **Written warning**: The progressive discipline step after a verbal warning; it stays active for 12 months, and the HRBP is consulted beforehand (HR-POL-021, Employee Relations and Progressive Discipline Policy).

## Document and form numbering

### Prefixes

Every HR document and form carries an identifier made of a prefix and a three-digit sequence number. The number never changes, even when the document is revised or renamed.

| Prefix | Meaning | Example |
| --- | --- | --- |
| HR-POL | Policy: the binding rules, with an owner and approval body | HR-POL-006 Vacation and Paid Time Off Policy |
| HR-GDE | Guide: how-to and explanatory material that applies the policies | HR-GDE-001 Employee Benefits Guide |
| HR-FAQ | Frequently asked questions: plain answers that point to the owning document | HR-FAQ-001 Employee HR FAQ |
| HR-REF | Reference: glossaries, schedules and other lookup material | HR-REF-002 Employee Records Retention Schedule |
| HR-PLN | Plan document: the formal terms of an incentive, benefits or savings plan | HR-PLN-001 Annual Incentive Plan Document |
| HR-FWK | Framework: models and processes for talent and development | HR-FWK-001 Competency and Leadership Model |
| HR-PRC | Procedure: internal operating procedures for HR staff (audience HR only) | HR-PRC-002 Workplace Investigation Procedure |
| HR-SUP | Supplement: rules specific to a province, state or business unit | HR-SUP-002 California Supplement |
| HR-GOV | Governance record: minutes of the HR Policy Committee | HR-GOV-002 HR Policy Committee Minutes, 18 September 2025 |
| HR-TPL | Template: standard letters and agreement terms used by HR | HR-TPL-001 Offer Letter (Canada) |
| HR-MEMO | Memo: a dated announcement of a change or reminder | HR-MEMO-2025-002 Hybrid Three Office Days |
| HR-ARC | Archived version: a superseded document kept for reference | HR-ARC-001 Remote and Hybrid Work Policy (version 2.1) |
| HR-DRAFT | Draft: a proposal that is not approved and not in effect | HR-DRAFT-002 Proposed Change to Vacation Carryover |
| HOW | How-to article: step-by-step instructions for one task | HOW-001 How to request vacation in MyHR |
| JD | Job description: the role profile for a job in the job catalogue | JD-1005 Personal Banking Advisor |
| FORM-HR | Form: a request, notice or record completed by an employee, manager or HR | FORM-HR-010 Leave of Absence Request |

Forms are grouped by number range: 010 to 019 leaves; 020 to 029 pay and overtime; 030 to 039 work arrangements; 040 to 049 accommodation; 050 to 059 harassment and violence complaints; 060 to 069 learning; 070 to 079 performance and discipline; 080 to 089 resignation and offboarding; 090 to 099 privacy; 100 to 109 conduct and ethics; 110 to 119 recruitment and screening; and 120 to 139 banking, licensing, mobility, travel and other programs. The full catalogue of forms is maintained in HR-GDE-004 HR Service and Support Guide.

### Version and review conventions

- Policies and references use a major.minor version number (for example 4.2). A major change, such as a new entitlement or a change in who is covered, raises the major number; a clarification or small adjustment raises the minor number.
- Guides and the FAQ that follow the benefits plan year or are updated several times a year use a year.release number (for example 2026.1 or 2026.3).
- The effective date is the date the version applies; the last reviewed date is the date the owner last confirmed the content is accurate and complete.
- Every document is reviewed at least every 12 months. The next review date is the last reviewed date plus one year.
- Only one version has the status "Current". Earlier versions are archived by HR Operations and remain available on request for audit purposes.
- Each document ends with a Change history table that lists each version, its effective date and a summary of the change.
- Related documents named in the metadata table are the documents most often read together with it; they are not a full list of dependencies.

## Document index

| Document ID | Title | Version | Effective date | Owner |
| --- | --- | --- | --- | --- |
| HR-POL-001 | Code of Conduct and Ethics | 6.0 | 2026-01-01 | Head of Ethics Office |
| HR-POL-002 | Remote and Hybrid Work Policy | 3.0 | 2026-01-05 | VP HR Operations |
| HR-POL-003 | Working Hours and Overtime Policy | 4.2 | 2025-07-01 | SVP Total Rewards |
| HR-POL-004 | Attendance and Absenteeism Policy | 3.1 | 2025-04-01 | VP Employee Relations |
| HR-POL-005 | Workplace Harassment and Violence Prevention Policy | 5.0 | 2025-09-01 | VP Employee Relations |
| HR-POL-006 | Vacation and Paid Time Off Policy | 4.0 | 2026-01-01 | SVP Total Rewards |
| HR-POL-007 | Sick Leave and Personal Leave Policy | 3.0 | 2026-01-01 | SVP Total Rewards |
| HR-POL-008 | Parental and Family Leave Policy | 5.1 | 2025-11-01 | SVP Total Rewards |
| HR-POL-009 | Compensation and Payroll Policy | 7.2 | 2026-03-01 | SVP Total Rewards |
| HR-POL-010 | Statutory Holidays Policy | 3.0 | 2026-01-01 | SVP Total Rewards |
| HR-POL-011 | Performance Management Policy | 4.1 | 2025-11-01 | SVP Talent and Learning |
| HR-POL-012 | Learning and Development Policy | 3.2 | 2025-11-01 | SVP Talent and Learning |
| HR-POL-013 | Performance Improvement Policy | 2.1 | 2025-06-01 | VP Employee Relations |
| HR-POL-014 | Employment Status and Classification Policy | 2.3 | 2025-03-01 | VP HR Operations |
| HR-POL-015 | Resignation and Offboarding Policy | 3.0 | 2025-10-01 | VP HR Operations |
| HR-POL-016 | Employee Data Privacy Policy | 4.0 | 2026-02-01 | Chief Privacy Officer |
| HR-POL-017 | IT Acceptable Use and Information Security Policy | 8.1 | 2026-04-01 | Chief Information Security Officer |
| HR-POL-018 | Workplace Accommodation and Accessibility Policy | 3.2 | 2025-08-01 | Head of Accessibility and Inclusion |
| HR-POL-019 | Recruitment and Selection Policy | 3.0 | 2025-06-15 | SVP Talent and Learning |
| HR-POL-020 | Pre-Employment Screening Policy | 2.2 | 2025-05-01 | VP HR Operations |
| HR-POL-021 | Employee Relations and Progressive Discipline Policy | 4.0 | 2025-04-01 | VP Employee Relations |
| HR-POL-022 | Whistleblower and Speak-Up Policy | 3.1 | 2025-09-01 | Head of Ethics Office |
| HR-POL-023 | Workplace Health, Safety and Wellness Policy | 3.3 | 2025-05-01 | Head of Workplace Safety |
| HR-POL-024 | Diversity, Equity, Inclusion and Belonging Policy | 2.0 | 2025-10-01 | Head of Inclusion and Belonging |
| HR-POL-025 | Involuntary Termination and Severance Policy | 2.4 | 2025-02-01 | VP Employee Relations |
| HR-POL-026 | Bereavement, Jury Duty and Other Leaves Policy | 2.1 | 2025-12-01 | SVP Total Rewards |
| HR-POL-027 | Social Media and External Communications Policy | 2.0 | 2025-07-01 | Head of Ethics Office |
| HR-GDE-001 | Employee Benefits Guide | 2026.1 | 2026-01-01 | SVP Total Rewards |
| HR-GDE-002 | Retirement and Savings Plan Guide | 3.0 | 2026-01-01 | SVP Total Rewards |
| HR-GDE-003 | New Employee Onboarding Guide | 4.0 | 2026-02-02 | VP HR Operations |
| HR-GDE-004 | HR Service and Support Guide | 2.5 | 2026-03-16 | VP HR Operations |
| HR-GDE-005 | Manager's HR Procedures Guide | 3.2 | 2026-02-02 | SVP Talent and Learning |
| HR-GDE-006 | Job Architecture and Pay Bands Guide | 2.0 | 2026-03-01 | SVP Total Rewards |
| HR-FAQ-001 | Employee HR FAQ | 2026.3 | 2026-10-26 | VP HR Operations |
| HR-REF-001 | HR Glossary | 1.4 | 2026-06-01 | VP HR Operations |
| HR-REF-002 | Employee Records Retention Schedule | 2.0 | 2026-02-01 | Chief Privacy Officer |
| HR-POL-028 | Staff Banking Privileges and Employee Loans Policy | 2.0 | 2025-09-01 | Chief Compliance Officer |
| HR-POL-029 | Licensing, Registration and Qualification Policy | 3.0 | 2025-06-01 | Chief Compliance Officer |
| HR-POL-030 | Fit and Proper and Conduct Standards Policy | 2.1 | 2025-10-01 | Chief Compliance Officer |
| HR-POL-031 | Incentive Deferral and Clawback Policy | 2.0 | 2026-01-01 | SVP Total Rewards |
| HR-POL-032 | Personal Trading and Restricted Lists Policy | 4.0 | 2025-08-01 | Chief Compliance Officer |
| HR-POL-033 | Electronic Monitoring and Right to Disconnect Policy | 2.0 | 2025-11-01 | Chief Information Security Officer |
| HR-POL-034 | Employment Equity and Pay Equity Policy | 3.0 | 2025-04-01 | Head of Inclusion and Belonging |
| HR-POL-035 | Multi-Year Accessibility Plan 2025 to 2028 | 1.1 | 2025-01-01 | Head of Accessibility and Inclusion |
| HR-POL-036 | US Equal Employment Opportunity and Required Notices Policy | 3.1 | 2025-07-01 | VP Employee Relations |
| HR-POL-037 | Pay Transparency Policy | 1.2 | 2026-01-12 | SVP Total Rewards |
| HR-POL-038 | Business Travel and Expense Policy | 5.0 | 2025-12-01 | SVP Total Rewards |
| HR-POL-039 | Relocation and Global Mobility Policy | 3.2 | 2025-06-01 | VP HR Operations |
| HR-POL-040 | Dress Code Policy | 2.0 | 2025-07-01 | VP HR Operations |
| HR-POL-041 | Substance Use and Fitness for Work Policy | 2.2 | 2025-05-01 | Head of Workplace Safety |
| HR-POL-042 | Secondment and Job Sharing Policy | 1.3 | 2025-09-01 | VP HR Operations |
| HR-POL-043 | Recognition and Awards Policy | 3.0 | 2026-01-01 | SVP Total Rewards |
| HR-POL-044 | Business Continuity and Severe Weather Policy | 2.3 | 2025-11-01 | Head of Workplace Safety |
| HR-PLN-001 | Annual Incentive Plan Document | 2026.1 | 2025-11-01 | SVP Total Rewards |
| HR-PLN-002 | Advisor and Sales Incentive Plan Document | 3.0 | 2026-01-01 | SVP Total Rewards |
| HR-PLN-003 | Long-Term Incentive Plan Document | 2.0 | 2026-01-01 | SVP Total Rewards |
| HR-PLN-004 | Group Benefits Booklet (Canada) | 2026.1 | 2026-01-01 | SVP Total Rewards |
| HR-PLN-005 | Bank Savings and Pension Plan Text Summary (Canada) | 3.0 | 2026-01-01 | SVP Total Rewards |
| HR-PLN-006 | US 401(k) Savings Plan Summary Plan Description | 2026.1 | 2026-01-01 | SVP Total Rewards |
| HR-PLN-007 | Benefits Claims and Appeals Guide | 2.1 | 2026-01-01 | SVP Total Rewards |
| HR-PLN-008 | Sample Total Rewards Statement | 2026.1 | 2026-03-01 | SVP Total Rewards |
| HR-FWK-001 | Competency and Leadership Model | 3.0 | 2025-11-01 | SVP Talent and Learning |
| HR-FWK-002 | Career Paths and Job Families Guide | 2.0 | 2025-11-01 | SVP Talent and Learning |
| HR-FWK-003 | Talent Review and Succession Process | 2.2 | 2026-02-01 | SVP Talent and Learning |
| HR-FWK-004 | Employee Engagement Survey Guide | 2026.1 | 2026-08-24 | SVP Talent and Learning |
| HR-SUP-001 | Supplément pour le Québec | 2.0 | 2026-01-01 | VP HR Operations |
| HR-SUP-002 | California Supplement | 2.1 | 2025-07-01 | VP Employee Relations |
| HR-SUP-003 | Capital Markets Addendum | 2.0 | 2025-08-01 | Chief Compliance Officer |
| HR-SUP-004 | Branch Operations Scheduling Supplement | 3.0 | 2025-04-01 | VP HR Operations |
| HR-REF-003 | Canada Jurisdiction Quick Reference | 1.1 | 2026-01-01 | VP HR Operations |
| HR-REF-004 | US Jurisdiction Quick Reference | 1.1 | 2026-01-01 | VP HR Operations |
| HR-FAQ-002 | Foire aux questions pour les employés du Québec | 2026.1 | 2026-10-26 | VP HR Operations |

HR-only procedures (HR-PRC), governance minutes (HR-GOV), templates (HR-TPL), memos (HR-MEMO), archived versions (HR-ARC), drafts (HR-DRAFT), how-to articles (HOW), job descriptions (JD) and forms (FORM-HR) are not listed in this index. The forms are in HR-GDE-004 HR Service and Support Guide and the job descriptions in `job_catalogue.csv`.

## Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.0 | 2024-02-01 | First issue of the glossary with core terms for pay, leave, benefits and privacy |
| 1.1 | 2024-09-01 | Added terms for performance management, calibration and progressive discipline |
| 1.2 | 2025-04-01 | Added accommodation, accessibility and harassment terms and the form numbering explanation |
| 1.3 | 2025-11-01 | Updated parental leave, tuition reimbursement and performance improvement plan entries |
| 1.4 | 2026-06-01 | Added legal hold, DPIA, AI-assisted decision and retention terms; added the Document index |
