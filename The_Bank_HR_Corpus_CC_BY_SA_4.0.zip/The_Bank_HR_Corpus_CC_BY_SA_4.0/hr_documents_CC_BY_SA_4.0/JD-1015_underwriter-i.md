# Underwriter I

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1015 |
| Title | Underwriter I |
| Document type | Job description |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-08-25 |
| Next review | 2027-08-25 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-POL-003, HR-POL-002, HR-POL-018 |

## 1. Role summary

The Underwriter I reviews and decides credit applications from small and mid-sized commercial borrowers that fall within defined risk and size limits. The role independently assesses repayment capacity, collateral and risk, applies the Bank's credit policy and delegated limits, and records clear approval rationale. The Underwriter I is independent of the sales team and protects the Bank by ensuring that lending decisions are sound and consistent. This is a Band 3 (Professional) role in the Commercial Banking family; see HR-GDE-006 Job Architecture and Pay Bands Guide.

## 2. Key responsibilities

- Review commercial credit applications and supporting financial, collateral and legal documentation.
- Analyze borrower cash flow, leverage, liquidity and industry risk, and assign internal risk ratings.
- Approve, decline or refer applications according to delegated authority and credit policy.
- Document decisions, conditions and exceptions clearly so another underwriter could follow the reasoning.
- Request missing information from relationship managers and borrowers within agreed turnaround times.
- Verify collateral valuations, insurance and registration of security before funding.
- Identify indicators of fraud, misrepresentation or financial crime and escalate to the appropriate team.
- Meet turnaround, quality and accuracy standards, with decisions subject to quality assurance sampling.
- Maintain independence from sales: no pressure from sales objectives may influence a credit decision.
- Provide feedback to relationship managers on common application gaps and credit policy interpretation.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in finance, accounting, economics or business, or equivalent experience.
- Two to five years of experience in commercial credit analysis, underwriting or lending operations.
- Strong understanding of financial statements, cash flow analysis and credit risk concepts.
- Sound judgement, attention to detail and the confidence to decline a request when justified.
- Satisfactory results in pre-employment screening, including credit check for roles with financial authority.

### 3.2 Preferred

- Progress towards a credit-risk designation or the CFA program.
- Experience with an automated credit decisioning platform.
- Fluency in English and French.

### 3.3 Licences and certifications

No licence is required. Credit authority is granted in writing and reviewed periodically, and the role is subject to re-screening every 5 years where it carries financial authority.

## 4. Competencies

Competencies are defined in HR-FWK-001 Competency and Leadership Model; this role works at the Practitioner level.

- **Judgement and Decision Quality**: makes independent, well-reasoned credit decisions.
- **Risk and Conduct Awareness**: protects the Bank's credit quality and spots misrepresentation.
- **Drive for Results**: meets turnaround and accuracy standards.
- **Collaboration**: works constructively with sales and credit partners without compromising independence.
- **Customer Obsession**: gives clients clear, timely decisions.
- **Adaptability**: adjusts to evolving credit policy and economic conditions.

## 5. Compensation and classification

| Item | Detail |
| --- | --- |
| Band | 3 (Professional) |
| Canada salary range | $56,000 to $84,000 CAD per year |
| US salary range | $55,000 to $82,000 USD per year |
| Incentive target | Annual Incentive Plan (AIP): 5% of base salary |
| Overtime eligibility (Canada) | Yes (non-managerial Band 1 to 4 role) |
| FLSA classification (US) | Non-exempt |
| Work arrangement | Hybrid: at least 3 days a week in the office |

## 6. Working conditions and accessibility

This is a hybrid office role performed at a workstation. Because the role is non-exempt in the US and overtime-eligible in Canada, time is recorded in Time Tracker, and overtime must be pre-approved under HR-POL-003 Working Hours and Overtime Policy. Hybrid arrangements follow HR-POL-002 Remote and Hybrid Work Policy, with at least 3 days a week in the office and anchor days on Tuesday and Thursday. The Bank provides accommodation to the point of undue hardship (Canada) or reasonable accommodation (US); see HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to the Senior Manager, Credit.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-03-01 | Pay ranges updated to the 2026 pay bands; added independence and overtime language |
| 1.0 | 2024-05-06 | First issue |
