# Performance Improvement Policy (version 2.0)

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

> **Archived version.** Kept for reference only. Do not rely on it. See HR-POL-013 Performance Improvement Policy.

| Field | Value |
| --- | --- |
| Document ID | HR-ARC-004 |
| Title | Performance Improvement Policy (version 2.0) |
| Document type | Archived version |
| Version | 2.0 |
| Status | Superseded |
| Superseded by | HR-POL-013 Performance Improvement Policy, version 2.1 (effective 2025-06-01) |
| Effective date | 2023-06-01 |
| Last reviewed | Not applicable |
| Next review | Not applicable |
| Policy owner | VP Employee Relations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-013, HR-POL-011, HR-POL-021, HR-POL-018, HR-POL-025, FORM-HR-070 |

## 1. Status of this version

Version 2.0 was in force from 1 June 2023 to 31 May 2025. Version 2.1 replaced it on 1 June 2025 and shortened the standard plan length. Only the plan lengths differ from the current policy; the triggers, steps, support, outcomes and all other rules shown here are the same as in HR-POL-013.

## 2. Purpose and scope

The policy set out a fair, structured and supportive process for helping an employee whose performance was below expectations to improve, through a written performance improvement plan (PIP). It applied to regular full-time and regular part-time employees, and to fixed-term employees of 6 months or more, in Canada and the US, after the 3-month probation (HR-POL-014 Employment Status and Classification Policy). Conduct issues were managed under HR-POL-021 Employee Relations and Progressive Discipline Policy. Where applicable law gave a greater right, the law applied.

## 3. Roles

The manager identified and documented gaps, held coaching conversations, wrote the plan with the HRBP and held weekly check-ins. The HRBP approved the PIP before the meeting. The Employee Relations consultant reviewed unsuccessful outcomes before progressive discipline. The VP Employee Relations owned the policy and approved exceptions.

## 4. Triggers

A PIP could start when the employee received a year-end rating of Needs Improvement or Unsatisfactory (HR-POL-011 Performance Management Policy), or when the manager had documented sustained underperformance after at least one documented coaching conversation. A PIP was not mandatory after a rating of 4 or 5, but the manager and HRBP recorded why one was not started. A PIP could not be used to retaliate against an employee who raised a complaint, requested an accommodation, took protected leave or contacted the Speak-Up Line.

## 5. Steps and timing

| Step | Action | Timing |
| --- | --- | --- |
| 1 | Coaching conversation held and documented | Before any PIP, except where a rating triggers the PIP |
| 2 | Manager drafts the plan in FORM-HR-070 and sends it with evidence to the HRBP | At least 3 business days before the meeting |
| 3 | HRBP approves the plan | Before the meeting |
| 4 | Kickoff meeting | Within 10 business days of the trigger |
| 5 | Weekly check-ins, 30 minutes | Every week |
| 6 | Mid-point review | Half-way through the plan |
| 7 | Final review and written outcome | Within 5 business days of the end date |

## 6. Length of the plan (version 2.0)

| Length | When used |
| --- | --- |
| 30 days | Narrow, clearly defined gaps that can be corrected quickly |
| 90 days (standard) | Most cases |
| 120 days | Complex roles or goals that need a longer cycle; needed HRBP and Employee Relations approval |

The standard length was **90 days**. The permitted range was **30 to 120 days**.

## 7. Content, meetings and support

FORM-HR-070 stated the performance gaps with examples, the measurable standard, targets and dates, the support the Bank would provide, the start and end dates, the weekly check-in time, how progress was measured and the consequences. At the kickoff meeting the employee could bring a support person who was not legal counsel and could add written comments within 5 business days; the signature showed receipt, not agreement. Support could include Learning Hub training (HR-POL-012 Learning and Development Policy), coaching and a review of workload. The Wellspring Support Program (1-800-555-0166) and the Ombuds Office were available at any time.

## 8. Outcomes

Successful completion closed the PIP. One extension of up to 30 days could be approved by the HRBP; no second extension was allowed. An unsuccessful PIP moved to progressive discipline under HR-POL-021, up to termination, with Employee Relations approval; severance followed HR-POL-025 Involuntary Termination and Severance Policy. A plan could be paused during a protected absence of more than 5 consecutive business days.

## 9. Accommodation, restrictions and records

The manager and HRBP considered whether a protected ground might be affecting performance and applied HR-POL-018 Workplace Accommodation and Accessibility Policy first where a need was known or suspected. During an active PIP the employee was not eligible for a merit increase or an internal transfer, and remote work required no active PIP. Records stayed in the confidential file and were removed from the active file 12 months after successful completion.

## 10. Exceptions and contacts

Exceptions needed the written approval of the VP Employee Relations. Managers: Manager Hotline, 1-800-555-0143. Employees: HR Connect, 1-800-555-0142.

## 11. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2023-06-01 | Introduced FORM-HR-070, weekly check-ins, a standard length of 90 days (range 30 to 120 days) and the single 30-day extension |
| 2.1 | 2025-06-01 | Superseded this version; standard length reduced to 60 days (range 30 to 90 days) (see HR-POL-013) |
