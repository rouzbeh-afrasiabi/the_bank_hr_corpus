# Recruitment and Selection Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-019 |
| Title | Recruitment and Selection Policy |
| Document type | Policy |
| Version | 3.0 |
| Status | Current |
| Effective date | 2025-06-15 |
| Last reviewed | 2026-05-20 |
| Next review | 2027-05-20 |
| Policy owner | SVP Talent and Learning |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Applies to | All Canadian and US employees (see Scope) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-020, HR-POL-009, HR-POL-016, HR-POL-024, HR-POL-018, HR-REF-002 |

## 1. Purpose

This policy ensures that the Bank hires the best qualified people through a fair, consistent, transparent and lawful process. It sets out approval of vacancies, posting, interviewing, offers, referrals and handling of candidate data.

## 2. Scope

The policy applies to all external hiring into regular full-time, regular part-time and fixed-term roles in Canada and the US, and to the hiring managers, recruiters, panel members and HR staff who take part. Engagement of contractors and agency workers goes through Procurement and Legal. Promotions and transfers are handled separately. Pre-employment checks are covered by HR-POL-020 Pre-Employment Screening Policy. Where applicable law gives a greater right, the law applies.

## 3. Definitions

| Term | Meaning |
| --- | --- |
| Requisition | The approved request to fill a position, recorded in MyHR. |
| Structured interview | An interview in which every candidate for the role is asked the same job-related questions and scored against the same criteria. |
| Conditional offer | An offer of employment that depends on satisfactory screening results (see HR-POL-020). |
| Time-to-fill | Calendar days from the requisition approval date to the date the offer is accepted. |

## 4. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Hiring manager | Defines the role, owns the requisition, leads the panel, decides on the hire and keeps interview records. |
| Recruiter (Talent Acquisition) | Posts the role, manages candidates, runs the process, prepares offers and tracks the time-to-fill. |
| HR Business Partner | Advises on the process, band, and equity. |
| Interview panel | At least 3 trained interviewers who score candidates against the criteria. |
| SVP Talent and Learning | Owns the policy and reviews hiring metrics. |

## 5. Requisition approval

A role may be posted only after the requisition is approved by the level shown. Approval confirms the business need, the band and the budget.

| Band of the role | Approver |
| --- | --- |
| Bands 1 to 4 | Director |
| Bands 5 and 6 | Vice President |
| Bands 7 and above | SVP and the CHRO |

The hiring manager records the band, the work arrangement (see HR-POL-002 Remote and Hybrid Work Policy), the employment category (see HR-POL-014) and the language requirements. Roles in Quebec follow applicable language-of-work rules.

## 6. Job postings

Postings include the role summary, essential requirements, work arrangement and the pay range for the role (see HR-GDE-006 Job Architecture and Pay Bands Guide). A posting must be open for at least 5 business days. Postings must be free of language that discourages any group and must include the Bank's equity statement and an invitation to request accommodation during the process (see HR-POL-018 Workplace Accommodation and Accessibility Policy). Postings are in English and, in Quebec, in French as well.

## 7. Sourcing and fair practice

Recruiters source candidates through the Bank's careers site, professional networks, partners and employee referrals. For Band 5 and above, the shortlist must be a diverse interview slate (see HR-POL-024 Diversity, Equity, Inclusion and Belonging Policy). No quotas are used. The Bank does not ask about protected personal characteristics.

## 8. Interviews and assessment

### 8.1 Structure

Hiring uses structured interviews with a panel of at least 3 panel members and at least 2 interview stages. Questions come from a bank agreed with the recruiter and map to the role criteria and the Bank values. Panel members score each candidate independently before the group discussion and record the scores in the system. Notes must be job-related and factual. Where assessments (for example technical exercises) are used, they must be job-related and be offered in an accessible format on request.

### 8.2 Accommodation in the process

Candidates may request accommodation at any stage. Recruiters arrange it without asking for a diagnosis and do not share the request with the panel beyond what is needed.

### 8.3 Automated tools

Automated or AI-assisted screening tools may help to organize applications but must never be the sole basis for rejecting a candidate. A recruiter or hiring manager reviews every rejection that a tool recommends. Tools must have an approved data protection impact assessment under HR-POL-016 Employee Data Privacy Policy.

## 9. References

Two reference checks are required for every finalist, one of whom must be a recent manager. References are taken with the candidate's consent and are recorded in the system. Reference checks are separate from the background screening described in HR-POL-020.

## 10. Selection decision and offers

### 10.1 Decision

The panel agrees a recommendation on the evidence. The hiring manager makes the decision, and the HRBP checks that the process was followed. A candidate cannot be hired into a role that reports to a relative (see 12.1).

### 10.2 Offer

Offers must be within the pay band for the role. New hires are normally paid between the minimum and the midpoint of the band (see HR-POL-009 Compensation and Payroll Policy). An offer above the midpoint needs the approval of the HRBP and Total Rewards (see HR-GDE-006 Job Architecture and Pay Bands Guide). The recruiter prepares the written offer. The offer is conditional on satisfactory screening results and right to work. An offer is valid for 5 business days. Verbal offers may be made only after the recruiter confirms the approved terms.

### 10.3 Time-to-fill

The Bank's target time-to-fill is 45 days. The recruiter reports each requisition that passes 45 days to the hiring manager and HRBP.

### 10.4 Unsuccessful candidates

Unsuccessful interviewed candidates are told within 5 business days of the decision. Feedback is given on request. Candidate data is kept for 12 months (see HR-REF-002 Employee Records Retention Schedule).

## 11. Employee referrals

Employees may refer candidates for open roles. A referral bonus is paid after the referred hire completes 6 months of service, provided the referring employee is still employed on the payment date.

| Role | Bonus (Canada) | Bonus (US) |
| --- | --- | --- |
| Band 1 to Band 5 | $1,000 CAD | $750 USD |
| Band 6 and above, and hard-to-fill roles | $1,500 CAD | $1,100 USD |

Recruiters, HR staff involved in the hire, and the hiring manager of the role are not eligible. A referral must be submitted before the candidate applies. Only one bonus is paid per hire. Referral bonuses are paid through payroll and are taxable.

## 12. Conflicts of interest and relatives

### 12.1 Relatives

No employee may hire, or directly or indirectly report to, a relative (including spouse or partner, parent, child, sibling and other members of the household or close family). A person must declare a personal relationship with a candidate as soon as they become aware and must withdraw from the panel (see HR-POL-001 Code of Conduct and Ethics).

### 12.2 Former employees

Rehire follows the same process. Rehire eligibility coded Eligible or Not Eligible at exit applies (see HR-POL-015 Resignation and Offboarding Policy). Service credit rules are in HR-POL-014.

## 13. Candidate data and privacy

Candidate information is used only for recruitment. Candidates may request access to their data (see HR-POL-016). Data is kept for 12 months unless the candidate is hired, in which case it joins the personnel file.

## 14. Exceptions and consequences

Exceptions need written approval of the SVP Talent and Learning. Breach of this policy, including hiring without an approved requisition, may lead to discipline under HR-POL-021 Employee Relations and Progressive Discipline Policy.

## 15. Related documents and contacts

HR-POL-020 Pre-Employment Screening Policy; HR-POL-009 Compensation and Payroll Policy; HR-POL-024 Diversity, Equity, Inclusion and Belonging Policy; HR-GDE-006 Job Architecture and Pay Bands Guide. Contact HR Connect at 1-800-555-0142 or hrconnect@bank.example. Managers may call the Manager Hotline at 1-800-555-0143.

## 16. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 3.0 | 2025-06-15 | Added pay ranges in all postings, a minimum of 2 interview stages and 3 panel members, the 45-day time-to-fill target, and the rule that automated tools are never the sole basis for rejection. |
| 2.0 | 2022-06-15 | Introduced structured interviews, requisition approval levels by band and the employee referral bonus. |
