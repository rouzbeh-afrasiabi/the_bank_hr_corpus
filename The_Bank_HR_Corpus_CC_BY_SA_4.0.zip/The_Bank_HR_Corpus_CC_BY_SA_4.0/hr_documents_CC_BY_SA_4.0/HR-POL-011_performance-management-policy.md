# Performance Management Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-011 |
| Title | Performance Management Policy |
| Document type | Policy |
| Version | 4.1 |
| Status | Current |
| Effective date | 2025-11-01 |
| Last reviewed | 2026-10-01 |
| Next review | 2027-10-01 |
| Policy owner | SVP Talent and Learning |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Applies to | All Canadian and US employees (see Scope) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-009, HR-POL-012, HR-POL-013, HR-POL-021, HR-REF-002, HR-GDE-005 |

## 1. Purpose

This policy sets out how the Bank sets goals, gives feedback, assesses and rates performance, and links the result to pay. It aims to make performance conversations regular, fair and evidence-based, and to make sure that ratings are consistent across business units.

## 2. Scope

The policy applies to all regular full-time and regular part-time employees in Canada and the US, and to fixed-term employees of 6 months or more. Casual employees, students, co-op placements and interns receive feedback from their managers but are not rated or covered by the Annual Incentive Plan (AIP) (see HR-POL-014 Employment Status and Classification Policy). Contractors and agency workers are not covered. Promotions and transfers are handled separately. Where applicable law gives a greater right, the law applies.

## 3. Definitions

| Term | Meaning |
| --- | --- |
| Performance year | The Bank's fiscal year, 1 November to 31 October. |
| "What" | The results delivered against 3 to 5 documented goals. |
| "How" | The way results are achieved, measured against the Bank values: Integrity, Customer Focus, Accountability, Collaboration and Inclusion. |
| Calibration | The structured review in which managers and HR compare proposed ratings across a business unit to confirm consistency. |
| Year-end rating | The single overall rating (1 to 5) that combines "what" and "how". |
| HRBP | The HR Business Partner assigned to the business unit. |

## 4. Roles and responsibilities

### 4.1 Employees

Employees draft and agree their goals, keep evidence of results, seek feedback, take part in every check-in, complete the year-end self-assessment on time, and raise concerns about a rating through the dispute process in section 12.

### 4.2 Managers

Managers set goals with each team member, hold at least one informal check-in every quarter and one formal mid-year check-in, give timely written feedback, complete assessments by the due dates, prepare for and attend calibration, communicate ratings, and keep records. Managers should use HR-GDE-005 Manager's HR Procedures Guide for step-by-step instructions and may call the Manager Hotline (1-800-555-0143) for advice.

### 4.3 HR Business Partners

HRBPs coach managers, facilitate calibration, check ratings for consistency and bias, and decide or review rating disputes with the manager's manager.

### 4.4 SVP Talent and Learning

The SVP Talent and Learning owns this policy, sets the annual calendar, publishes the calibration guidelines and reports rating distributions to the HR Policy Committee each year.

## 5. Performance calendar

All dates apply to every business unit in both countries. Dates that fall on a weekend or Bank holiday move to the next business day.

| Milestone | Date or window | Owner |
| --- | --- | --- |
| Performance year starts | 2025-11-01 (each year 1 November) | HR |
| Goals set and agreed in MyHR | By 15 December (new hires within 30 days of start) | Employee and manager |
| Quarterly informal check-ins | At least once per quarter | Manager |
| Mid-year check-in | 1 May to 15 June | Manager |
| Performance year ends | 31 October | HR |
| Year-end self-assessment due | 15 November | Employee |
| Manager assessment due | 10 December | Manager |
| Calibration | 11 December to 10 January | Manager, HRBP, business unit head |
| Ratings communicated to employees | By 15 January | Manager |
| AIP paid | First pay date in February | Payroll Services |
| Salary increases effective | 1 March | Payroll Services |

An employee is eligible for a year-end rating if they were employed for at least 3 months in the performance year, meaning they started on or before 31 July. Employees who start after 31 July set goals within 30 days but receive feedback only, and are rated in the following performance year. Employees on approved leave are rated on the period worked.

## 6. Goals

### 6.1 Setting goals

Each employee has 3 to 5 goals recorded in MyHR. Goals must be specific, measurable, achievable, relevant and time-bound, and must connect to the team or business unit plan. Goals should describe outcomes rather than activities. At least one goal should address personal development (see HR-POL-012 Learning and Development Policy).

### 6.2 Changing goals

Goals may be changed during the year when priorities change. The manager and employee record the change in MyHR within 10 business days of agreeing it. Goals must not be rewritten after 31 October to fit results already achieved.

### 6.3 New hires

New hires set goals with their manager within 30 days of their start date, as part of onboarding (see HR-GDE-003 New Employee Onboarding Guide).

## 7. Check-ins and feedback

Managers hold an informal check-in at least once per quarter, 15 to 30 minutes, covering progress against goals, obstacles, workload, wellbeing and development. The mid-year check-in, held between 1 May and 15 June, is a documented conversation that includes a view of how the employee is tracking against expectations (not a rating). Managers record a short summary in MyHR within 5 business days of each check-in. Feedback should be given as close to the event as possible, and concerns about performance must be raised when they arise and not saved for year-end.

## 8. Rating scale

The year-end rating uses a five-point scale. Each rating reflects both "what" and "how".

| Rating | Label | Definition |
| --- | --- | --- |
| 1 | Outstanding | Results and behaviours far exceed expectations across all goals; a role model for the Bank values; impact beyond the role. |
| 2 | Exceeds Expectations | Results consistently above expectations on most goals; strong demonstration of the Bank values. |
| 3 | Meets Expectations | Delivers the agreed goals to the expected standard and demonstrates the Bank values. The full and sound performance of the role. |
| 4 | Needs Improvement | Delivers some goals but falls short in important areas, or behaviours do not consistently reflect the Bank values; improvement is required. |
| 5 | Unsatisfactory | Results or behaviours are well below the minimum required; immediate and sustained improvement is required. |

A rating of Needs Improvement or Unsatisfactory can trigger a performance improvement plan (see HR-POL-013 Performance Improvement Policy).

## 9. Calibration and ratings guidance

### 9.1 Calibration

From 11 December to 10 January, each business unit holds calibration sessions led by the business unit head and facilitated by the HRBP. Managers present the proposed rating with evidence. The group tests the rating against the definitions in section 8, compares similar roles, and checks for bias (for example recency, similarity, tenure, part-time or remote status, or leave history). A rating may be changed only with a recorded reason. No rating is final until calibration closes.

### 9.2 Distribution guidance

The following ranges are guidance and are not forced quotas. A manager is never required to give a rating to meet a range, and a business unit must explain material differences to the SVP Talent and Learning.

| Rating | Guidance for the business unit |
| --- | --- |
| 1 Outstanding | 5% to 10% |
| 2 Exceeds Expectations | 20% to 30% |
| 3 Meets Expectations | 50% to 60% |
| 4 Needs Improvement and 5 Unsatisfactory | The remainder |

### 9.3 Use of automated tools

Analytics or AI-assisted tools may be used to prepare summaries, but a human must make the final decision about every rating. Any such tool must have completed the assessment required by HR-POL-016 Employee Data Privacy Policy before use.

## 10. Link to pay

### 10.1 Annual Incentive Plan

The AIP payout equals base salary earned multiplied by the target percentage for the band, the business funding factor (0 to 1.5) and the individual multiplier from the year-end rating:

| Rating | Individual multiplier |
| --- | --- |
| Outstanding | 1.5 |
| Exceeds Expectations | 1.2 |
| Meets Expectations | 1.0 |
| Needs Improvement | 0.5 |
| Unsatisfactory | 0 |

Example: a Band 3 employee earned $80,000 CAD in base salary in the performance year. The target is 5%, so $4,000. With a business funding factor of 0.9 and a rating of Exceeds Expectations, the payout is $4,000 x 0.9 x 1.2 = $4,320. The AIP is paid on the first pay date in February. Eligibility rules, band targets and the treatment of leave are in HR-POL-009 Compensation and Payroll Policy.

### 10.2 Salary increases

Annual salary increases take effect on 1 March and are based on the year-end rating, the employee's position in the pay band and the merit guidelines published by the SVP Total Rewards. An employee on an active performance improvement plan is not eligible for a merit increase. Promotion increases are handled separately.

### 10.3 Other consequences

A rating of Meets Expectations or higher is a condition for remote work eligibility (HR-POL-002 Remote and Hybrid Work Policy) and for tuition reimbursement (HR-POL-012).

## 11. Communicating ratings

Managers communicate the final rating in a one-to-one conversation (in person or by video) by 15 January, and explain the reasons using examples. The rating is then released to the employee in MyHR. Managers must not share ratings with other employees. Employees who are absent on leave receive the rating on return or at a time agreed with the manager and HRBP.

## 12. Rating disputes

An employee who disagrees with a rating may submit a written request to the HRBP within 10 business days of being told the rating. The request must describe the facts or process errors relied on. The manager's manager and the HRBP review the rating, the evidence and the calibration record, and give a written decision within 15 business days of receiving the request. The decision is final. A dispute does not delay the AIP or salary increase; any correction is paid on the next regular pay date. No employee is penalised for raising a dispute in good faith. Concerns about discrimination or harassment follow HR-POL-005 and the Ombuds Office is always available for confidential, informal advice.

## 13. Documentation and records

Goals, check-in summaries, assessments, calibration notes, ratings and dispute decisions are kept in MyHR. Performance reviews are kept for 7 years (see HR-REF-002 Employee Records Retention Schedule). Performance records are confidential and are available only to the employee, the manager chain, HR and, where required, Legal.

## 14. New hires and leavers

New hires set goals within 30 days of their start date and are rated if they started on or before 31 July. A new hire is on probation for 3 months (see HR-POL-014). Employees who resign or are terminated before the end of the performance year are not rated, but the manager records a summary of performance for the file. AIP for leavers is paid only if the employee was on payroll on the payment date (see HR-POL-015 Resignation and Offboarding Policy).

## 15. Exceptions and consequences

Exceptions to the calendar require written approval of the SVP Talent and Learning. A manager who does not complete assessments by 10 December is reported to the business unit head and the HRBP, and the matter may be addressed under the performance expectations of the manager's own role.

## 16. Related documents and contacts

HR-POL-009 Compensation and Payroll Policy; HR-POL-012 Learning and Development Policy; HR-POL-013 Performance Improvement Policy; HR-POL-021 Employee Relations and Progressive Discipline Policy; HR-REF-002 Employee Records Retention Schedule; HR-GDE-005 Manager's HR Procedures Guide. Questions: HR Connect, 1-800-555-0142, hrconnect@bank.example, or your HRBP.

## 17. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 4.1 | 2025-11-01 | Aligned rating guidance ranges and AIP multiplier wording with HR-POL-009; clarified calibration window and new-hire goal timing. |
| 4.0 | 2024-11-01 | Introduced the combined "what" and "how" rating using the Bank values; moved goals and check-in summaries into MyHR. |
