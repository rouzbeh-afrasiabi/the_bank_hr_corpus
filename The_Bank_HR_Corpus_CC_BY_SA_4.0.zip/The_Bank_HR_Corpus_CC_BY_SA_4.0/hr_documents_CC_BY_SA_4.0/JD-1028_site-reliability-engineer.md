# Site Reliability Engineer

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1028 |
| Title | Site Reliability Engineer |
| Document type | Job description |
| Version | 1.2 |
| Status | Current |
| Effective date | 2025-08-01 |
| Last reviewed | 2026-08-25 |
| Next review | 2027-08-25 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-POL-002, HR-POL-003, HR-POL-044 |

## 1. Role summary

The Site Reliability Engineer keeps the Bank's digital channels and core platforms available, fast and recoverable. The role applies software engineering to operations: automating toil, defining service-level objectives, building monitoring and leading incident response and post-incident learning. A Band 4 engineer handles complex reliability problems that cross systems and advises development teams on how to build services that can be operated safely.

## 2. Key responsibilities

- Define service-level indicators and objectives with product teams, and report error-budget use.
- Build and maintain monitoring, alerting and dashboards that detect customer-impacting problems early.
- Automate deployment, scaling, recovery and routine operations through code rather than manual steps.
- Take part in the on-call rotation, lead incident response and coordinate technical and business communications.
- Write blameless post-incident reviews and track corrective actions to completion.
- Run capacity planning and performance tests before peak periods such as year-end and tax season.
- Test failover and recovery plans regularly with the teams that own critical services (see HR-POL-044 Business Continuity and Severe Weather Policy).
- Review designs and releases for operational readiness, resilience and security.
- Manage infrastructure-as-code changes through reviewed, version-controlled pipelines.
- Mentor Professional-level engineers and share runbooks and good practice.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in computer science, engineering or a related field, or equivalent experience.
- Typically 5 to 8 years of experience in site reliability, platform or infrastructure engineering.
- Strong scripting and programming skills, and experience with infrastructure as code and container orchestration.
- Experience operating production systems and managing incidents under pressure.

### 3.2 Preferred

- Experience on public cloud platforms and with observability tooling.
- Knowledge of resilience and disaster-recovery requirements in regulated financial services.
- Cloud or systems-operations certification.

### 3.3 Licences and certifications

None required.

## 4. Competencies

Measured against HR-FWK-001 Competency and Leadership Model at the Practitioner level:

- Judgement and Decision Quality
- Drive for Results
- Adaptability
- Collaboration
- Risk and Conduct Awareness
- Customer Obsession

## 5. Compensation and classification

| Item | Value |
| --- | --- |
| Band | 4 (Senior Professional) |
| Canada range | $72,000 to $108,000 CAD |
| US range | $70,000 to $106,000 USD |
| Incentive target | 8% of base salary (Annual Incentive Plan) |
| Overtime eligibility, Canada | Yes (non-managerial Band 4) |
| FLSA classification, US | Exempt |
| Work arrangement | Hybrid (at least 3 days a week in the office) |

On-call allowance, call-out minimum and the shift premium are set out in HR-POL-003 Working Hours and Overtime Policy. Band definitions are in HR-GDE-006 Job Architecture and Pay Bands Guide.

## 6. Working conditions and accessibility

This is an office role with a hybrid arrangement under HR-POL-002 Remote and Hybrid Work Policy: at least 3 days a week in the office, including the Tuesday and Thursday anchor days. The role includes a regular on-call rotation, evening or weekend maintenance windows and occasional call-outs outside working hours; the right to disconnect applies outside on-call periods. The Bank provides accommodation to the point of undue hardship; see HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to: Technology Team Lead. Direct reports: none.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.2 | 2025-08-01 | Added service-level objective and recovery testing duties |
| 1.1 | 2024-09-01 | Added on-call wording |
| 1.0 | 2023-08-01 | First issue |
