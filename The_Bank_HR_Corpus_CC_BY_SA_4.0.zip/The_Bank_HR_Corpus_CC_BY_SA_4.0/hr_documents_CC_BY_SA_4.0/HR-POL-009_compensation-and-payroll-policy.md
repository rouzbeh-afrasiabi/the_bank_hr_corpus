# Compensation and Payroll Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-009 |
| Title | Compensation and Payroll Policy |
| Document type | Policy |
| Version | 7.2 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-09-28 |
| Next review | 2027-09-28 |
| Policy owner | SVP Total Rewards |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Applies to | All Canadian and US employees (see Scope) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-003, HR-POL-011, HR-POL-008, HR-GDE-006, HR-GDE-002, HR-GDE-004, FORM-HR-021, FORM-HR-022 |

## 1. Purpose

This policy sets out how the Bank pays its employees: when and how pay is issued, how errors and overpayments are corrected, how salaries are reviewed, how the Annual Incentive Plan (AIP) works, what is deducted from pay, and how pay equity is monitored. The Bank's pay philosophy is to target the market median (P50) of a defined peer group, to pay for performance, to review pay equity every year and to disclose pay ranges in job postings.

## 2. Scope

This policy applies to all employees in Canada and the US. Contractors and agency workers are paid under their commercial agreements and are outside this policy. Overtime rules are in HR-POL-003 Working Hours and Overtime Policy. Pay bands are in HR-GDE-006 Job Architecture and Pay Bands Guide. Where applicable law gives a greater right, the law applies.

## 3. Definitions

- **Base salary**: annual rate of pay before deductions, excluding incentive pay, overtime, premiums and allowances.
- **Pay period**: the two-week period that ends on the Saturday immediately before the pay date.
- **Payroll cut-off**: 17:00 Eastern Time, five business days before the pay date.
- **Fiscal year**: 1 November to 31 October, also the performance year.
- **Net pay**: pay after statutory and other deductions.

## 4. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Employee | Keep banking, address and tax information current; check each pay statement; report errors promptly |
| Manager | Approve time and absences on time; submit pay changes before the cut-off |
| Payroll Services | Run payroll, correct errors, manage overpayment recovery, issue tax slips |
| Total Rewards | Maintain pay bands, run the salary review and the AIP |
| HR Business Partner (HRBP) | Advise managers and review pay decisions for equity |
| SVP Total Rewards | Owns this policy and approves the pay-equity review results |

## 5. Pay frequency and statements

Employees are paid biweekly in arrears, giving 26 pay dates per year. Employees in Canada are paid on Thursdays and employees in the US on Fridays. Pay is by direct deposit only; set up or change your account in MyHR using FORM-HR-022 Direct Deposit and Tax Withholding Update. Pay statements are available in MyHR 2 business days before the pay date.

## 6. 2026 pay dates

The pay period ends on the Saturday immediately before the pay date. Where the scheduled US pay date is a Bank holiday, pay is issued the preceding business day, as shown.

| Pay period ends (Saturday) | Canada pay date (Thursday) | US pay date (Friday) |
| --- | --- | --- |
| 2026-01-03 | 2026-01-08 | 2026-01-09 |
| 2026-01-17 | 2026-01-22 | 2026-01-23 |
| 2026-01-31 | 2026-02-05 | 2026-02-06 |
| 2026-02-14 | 2026-02-19 | 2026-02-20 |
| 2026-02-28 | 2026-03-05 | 2026-03-06 |
| 2026-03-14 | 2026-03-19 | 2026-03-20 |
| 2026-03-28 | 2026-04-02 | 2026-04-03 |
| 2026-04-11 | 2026-04-16 | 2026-04-17 |
| 2026-04-25 | 2026-04-30 | 2026-05-01 |
| 2026-05-09 | 2026-05-14 | 2026-05-15 |
| 2026-05-23 | 2026-05-28 | 2026-05-29 |
| 2026-06-06 | 2026-06-11 | 2026-06-12 |
| 2026-06-20 | 2026-06-25 | 2026-06-26 |
| 2026-07-04 | 2026-07-09 | 2026-07-10 |
| 2026-07-18 | 2026-07-23 | 2026-07-24 |
| 2026-08-01 | 2026-08-06 | 2026-08-07 |
| 2026-08-15 | 2026-08-20 | 2026-08-21 |
| 2026-08-29 | 2026-09-03 | 2026-09-04 |
| 2026-09-12 | 2026-09-17 | 2026-09-18 |
| 2026-09-26 | 2026-10-01 | 2026-10-02 |
| 2026-10-10 | 2026-10-15 | 2026-10-16 |
| 2026-10-24 | 2026-10-29 | 2026-10-30 |
| 2026-11-07 | 2026-11-12 | 2026-11-13 |
| 2026-11-21 | 2026-11-26 | 2026-11-25 (scheduled Friday 2026-11-27 is a holiday) |
| 2026-12-05 | 2026-12-10 | 2026-12-11 |
| 2026-12-19 | 2026-12-24 | 2026-12-24 (scheduled Friday 2026-12-25 is a holiday) |

## 7. Payroll cut-offs

Changes to bank details, tax forms, new hires and bonuses must be entered by 17:00 Eastern Time five business days before the pay date. A change received after the cut-off is processed on the next pay date. For example, for the Canada pay date of 2026-03-05 the cut-off is 17:00 Eastern Time on 2026-02-26. Hours worked, overtime and absences follow the time-entry deadlines in HR-POL-003.

## 8. Pay corrections

### 8.1 Underpayments

Report a suspected error through the HR Case Portal in MyHR using FORM-HR-021 Payroll Correction Request. Payroll Services confirms the error and then corrects it as follows:

| Net underpayment | Correction |
| --- | --- |
| $250 or more | Paid off-cycle within 3 business days of confirmation |
| Under $250 | Corrected on the next regular pay date |

Amounts are in the currency of pay (CAD in Canada, USD in the US). Retroactive corrections go back up to 24 months. A missed pay is a P1 urgent case: first response within 4 business hours (see HR-GDE-004 HR Service and Support Guide).

### 8.2 Overpayments

Payroll Services notifies the employee in writing of any overpayment, with the amount, dates and cause. The employee may repay by:

1. a lump sum;
2. payroll deduction of no more than 15% of net pay per pay period; or
3. a repayment plan of up to 12 months agreed with Payroll Services.

Where law requires written consent before deductions are made (for example in California), consent is obtained first. Recovery of overpayments from final pay is subject to the same limits and to applicable law.

## 9. Annual salary review

Salaries are reviewed once a year, effective 1 March, based on the year-end rating under HR-POL-011 Performance Management Policy. Increases are placed within the pay band for the role (see HR-GDE-006). Increases linked to promotion are handled separately and are not part of the annual review. Total Rewards sets the annual review budget and publishes guidance to HRBPs and managers before the review opens.

## 10. Annual Incentive Plan

### 10.1 Target

The AIP target is a percentage of base salary earned that depends on the job band: Bands 1 to 3 are 5%, Band 4 is 8%, Band 5 is 10%, Band 6 is 15%, Band 7 is 20%, Band 8 is 30% and Band 9 is 45%. The full table is in HR-GDE-006.

### 10.2 Eligibility

To receive a payout the employee must:

- have been hired on or before 31 July of the fiscal year;
- be on payroll on 31 October and on the payment date; and
- not have a last rating of Unsatisfactory.

### 10.3 Calculation

Payout = base salary earned x target % x business funding factor x individual multiplier.

The business funding factor ranges from 0 to 1.5. The individual multiplier is:

| Rating | Multiplier |
| --- | --- |
| Outstanding | 1.5 |
| Exceeds Expectations | 1.2 |
| Meets Expectations | 1.0 |
| Needs Improvement | 0.5 |
| Unsatisfactory | 0 |

Base salary earned already reflects pro-ration for approved unpaid leave. Bank-paid parental leave counts as earned salary (see HR-POL-008 Parental and Family Leave Policy). The AIP is paid on the first pay date in February after the fiscal year ends. For the fiscal year that ended on 31 October 2025, that was 2026-02-05 in Canada and 2026-02-06 in the US.

### 10.4 Worked examples

An employee in Band 4 earns a base salary of $90,000 for the full fiscal year, the business funding factor is 1.0 and the rating is Meets Expectations. Payout = $90,000 x 8% x 1.0 x 1.0 = $7,200.

The same employee has a funding factor of 1.1 and a rating of Exceeds Expectations: $90,000 x 8% x 1.1 x 1.2 = $9,504.

An employee in Band 4 takes 2 months of approved unpaid leave, so base salary earned is $75,000. With a funding factor of 0.9 and a rating of Exceeds Expectations: $75,000 x 8% x 0.9 x 1.2 = $6,480.

An employee in Band 4 hired on 1 September is not eligible for that fiscal year because the hire date is after 31 July.

## 11. Deductions and garnishments

Deductions are made for statutory items first, then benefit premiums, savings contributions and optional items. They include:

| Type | Canada | US |
| --- | --- | --- |
| Income tax | Federal and provincial | Federal and state |
| Social programs | Canada Pension Plan or Quebec Pension Plan; Employment Insurance or Quebec Parental Insurance Plan | Social Security and Medicare |
| Benefits | Premiums (see HR-GDE-001 Employee Benefits Guide) | Premiums (see HR-GDE-001) |
| Savings | Pension and savings contributions (see HR-GDE-002 Retirement and Savings Plan Guide) | 401(k) contributions |
| Optional | Charitable giving | Charitable giving |

Update your name, address or tax withholding through MyHR using FORM-HR-022. The Bank complies with garnishment and support orders as required by court order and law, and notifies the employee.

## 12. Tax slips

| Slip | Deadline |
| --- | --- |
| T4 and Relevé 1 (Canada) | 28 February |
| W-2 (US) | 31 January |

Slips are available in MyHR. Employees who have left the Bank receive their slips at the address on file, so keep your address up to date.

## 13. New hire pay

New hires are paid inside the pay band for the role, usually between the minimum and the midpoint of the band. Offers are approved by the HRBP; an offer above the midpoint also needs the approval of Total Rewards to ensure internal equity (see HR-GDE-006 Job Architecture and Pay Bands Guide). A new hire whose paperwork is complete by the payroll cut-off is paid on the next pay date. Canadian new hires provide federal and provincial personal tax credit return forms; US new hires provide Form W-4 and state withholding forms. See HR-GDE-006 for how placement in the band works.

## 14. Pay equity

Total Rewards reviews pay equity every year across gender, race and ethnicity (where self-identified), disability, and other protected groups, with unexplained gaps addressed through adjustments at the following salary review. Results are reported to the HR Policy Committee. The Bank complies with applicable pay equity and pay transparency law in each jurisdiction.

## 15. Exceptions and consequences

Exceptions to this policy require the written approval of the SVP Total Rewards. Falsifying time or pay records, or failing to report an overpayment that you know about, is a breach of HR-POL-001 Code of Conduct and Ethics and may result in discipline.

## 16. Contacts

Questions: HR Connect, 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time, hrconnect@bank.example, or live chat in MyHR.

## 17. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 7.2 | 2026-03-01 | Raised the net underpayment threshold for off-cycle correction from $200 to $250; 2026 pay date tables updated |
| 7.1 | 2025-03-01 | Set the net underpayment threshold for off-cycle correction at $200 |
