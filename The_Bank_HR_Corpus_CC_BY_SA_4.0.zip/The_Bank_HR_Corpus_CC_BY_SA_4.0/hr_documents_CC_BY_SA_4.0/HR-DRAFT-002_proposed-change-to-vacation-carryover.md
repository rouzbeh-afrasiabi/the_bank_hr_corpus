# Proposed Change to Vacation Carryover

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

> **DRAFT: do not rely on this document.**

| Field | Value |
| --- | --- |
| Document ID | HR-DRAFT-002 |
| Title | Proposed Change to Vacation Carryover |
| Document type | Draft |
| Version | 0.2 |
| Status | Draft |
| Approval status | Not approved. Not in effect. Under review by the HR Policy Committee. |
| Effective date | 2026-08-24 |
| Last reviewed | Not applicable |
| Next review | Not applicable |
| Policy owner | SVP Total Rewards |
| Audience | HR leadership |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-006, HR-ARC-003, HR-POL-009, HR-POL-015 |

## 1. Status of this draft

This is a working draft dated 24 August 2026. It has not been approved by the HR Policy Committee and is not in effect. The current rule in HR-POL-006 Vacation and Paid Time Off Policy version 4.0 stays in force: up to 5 unused vacation days may be carried into the next calendar year and used by 31 March, and the rest is forfeited except where the employee was on approved leave or the law requires payment. Employees must not plan around any of the proposals below.

## 2. Background

The carryover limit was 3 days under version 3.0 (see HR-ARC-003 Vacation and Paid Time Off Policy (version 3.0)) and has been 5 days since 1 January 2026. Employee feedback and the annual engagement survey show that some employees, especially in project-based teams, cannot use their full entitlement by year-end. The proposal tests whether a higher limit, together with a cash-out option, would be appropriate.

## 3. The proposal

| Item | Current rule (HR-POL-006) | Proposed |
| --- | --- | --- |
| Carryover limit | 5 days, used by 31 March | 10 days, used by 31 March |
| Cash-out | None; vacation is not paid out during employment | Employee may elect, by 30 November, to be paid for up to 5 unused days above the first 5 carried, at the base daily rate |
| Payment | Not applicable | First regular pay date of January, as taxable earnings |
| Condition | Not applicable | Mandatory 10-day block leave taken in the year; balance not below the statutory minimum |
| Forfeiture | Days above the limit | Days above 10 (or above the days carried after cash-out) |
| Start | In force since 2026-01-01 | Balances at 31 December 2027, if approved |

Other rules (entitlement table, 31 March deadline, advances, final pay on leaving under HR-POL-015 Resignation and Offboarding Policy) would not change.

## 4. Open questions

| No. | Question | Owner | Needed by |
| --- | --- | --- | --- |
| 1 | Does a cash-out during employment conflict with the current statement that vacation is not paid out during employment, and with statutory vacation rules in each province, territory and state? | Legal | 2026-10-30 |
| 2 | Should cash-out be limited to days above the statutory minimum? | Legal and SVP Total Rewards | 2026-10-30 |
| 3 | Would cash-out weaken the purpose of the mandatory block leave as a risk control, and should it be barred for audited roles in Capital Markets, Wealth Management and Finance? | Chief Compliance Officer | 2026-11-13 |
| 4 | How should the first-quarter coverage burden be managed, given that carried days must be used by 31 March? | Business unit heads | 2026-11-13 |
| 5 | Is the 31 March deadline still appropriate for a 10-day carryover? | SVP Total Rewards | 2026-11-13 |
| 6 | What accounting treatment applies to the additional accrued liability? | Finance | 2026-11-27 |
| 7 | What transition rule applies to 2026 balances (proposed: the current limit of 5)? | SVP Total Rewards | 2026-11-27 |

## 5. Cost and impact analysis

The figures are planning estimates for discussion only. They are not budgeted or approved.

**Assumptions:** 36,000 employees in scope; blended average base daily rate of $330 (CAD and USD combined for planning); at year-end 70% of employees (25,200) have 5 or fewer unused days, 20% (7,200) have 6 to 10 unused days (average 8, so 3 more days carried than today), and 10% (3,600) have more than 10 (5 more days carried than today).

| Item | Calculation | Estimate |
| --- | --- | --- |
| Additional days carried (no cash-out) | 7,200 x 3 + 3,600 x 5 | 39,600 days |
| Value of those days (accrued liability) | 39,600 x $330 | $13,068,000 |
| Cash-out cost at 30% uptake | 30% of 10,800 employees = 3,240; 11,880 days x $330 | $3,920,400 |
| Remaining additional carried days | 39,600 minus 11,880 | 27,720 days ($9,147,600 of liability) |
| First-quarter backfill | 15% of 27,720 days (4,158) x $330 | $1,372,140 |
| System and payroll configuration (one time) | MyHR election and Payroll Services changes | $240,000 |
| **Estimated first-year cash cost at 30% uptake** | $3,920,400 + $1,372,140 + $240,000 | **$5,532,540** |

**Sensitivity to cash-out uptake:**

| Uptake | Employees electing | Days cashed out | Cash-out cost |
| --- | --- | --- | --- |
| 15% | 1,620 | 5,940 | $1,960,200 |
| 30% | 3,240 | 11,880 | $3,920,400 |
| 50% | 5,400 | 19,800 | $6,534,000 |

Impact notes: the extra carried days are days that are forfeited today, so the liability value above is also the forfeiture saving the Bank would give up. Employee wellbeing and retention benefits are expected but are not quantified.

## 6. Next steps

1. Legal to answer open questions 1 and 2.
2. Total Rewards to refine the cost model with actual 31 December 2025 balances.
3. Return a costed version to the HR Policy Committee for a decision on whether to proceed. No change to HR-POL-006 would be published before approval.

## 7. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 0.1 | 2026-07-20 | First draft of a higher carryover limit |
| 0.2 | 2026-08-24 | Added the cash-out option, open questions and the cost and impact analysis |
