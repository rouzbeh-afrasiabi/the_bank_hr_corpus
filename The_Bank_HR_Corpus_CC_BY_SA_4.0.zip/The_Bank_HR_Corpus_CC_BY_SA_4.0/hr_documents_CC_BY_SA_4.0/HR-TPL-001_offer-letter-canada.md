# Offer Letter (Canada)

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-TPL-001 |
| Title | Offer Letter (Canada) |
| Document type | Template |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-06-30 |
| Next review | 2027-06-30 |
| Policy owner | VP HR Operations |
| Audience | HR only |
| Jurisdiction | Canada |
| Language | English |
| Related documents | HR-POL-019, HR-POL-020, HR-POL-025, HR-TPL-003 |

## 1. Purpose and when to use this template

This template is the standard offer of employment for a regular full-time, regular part-time or fixed-term employee hired in Canada. HR Operations issues it after the offer has been approved under HR-POL-019 Recruitment and Selection Policy. For hires in the US use HR-TPL-002 Offer Letter (US). The signed offer is supported by the standard terms in HR-TPL-003 Employment Agreement Standard Terms (Canada).

## 2. How to use this template

1. Confirm the requisition approval (Bands 1 to 4 Director; Bands 5 and 6 VP; Band 7 and above SVP and CHRO) and that the salary is inside the pay band in `pay_bands.csv`.
2. Replace every `[placeholder]`. Delete options that do not apply (for example the Quebec paragraph).
3. Send the letter from MyHR with HR-TPL-003 attached. For Quebec hires send the French version as well.
4. Record the date sent. The offer is valid for 5 business days from that date.

## 3. Letter text

**[Date]**

**[Candidate full name]**
[Candidate address]

**Subject: Offer of employment, [Job title], Band [Band]**

Dear [Candidate first name],

We are pleased to offer you employment with the Bank as **[Job title]** in **[Business unit]**, reporting to **[Manager name]**. Your work location is **[Work location, province]** and your work arrangement is **[On-site / Hybrid / Remote]**. Your start date is **[Start date]**.

**Compensation.** Your annual base salary is **[Base salary] CAD**, paid biweekly by direct deposit on Thursdays. You are eligible for the Annual Incentive Plan with a target of **[AIP target %]** of base salary for Band **[Band]**, subject to the plan terms, including being hired on or before 31 July of the fiscal year and being on payroll on 31 October and on the payment date.

**Probation.** Your first 3 months of employment are a probation period. The Bank may extend probation once, to a total of 6 months, by written notice before the end of month 3.

**Benefits and pension.** You are eligible for group benefits from your first day. Enrol within 31 days of your start date; if you make no election you are placed in the Standard plan. You are eligible for the Bank Savings and Pension Plan from day 1.

**Time off.** You are entitled to **[Vacation days]** vacation days in your first calendar year, pro-rated from your start date and rounded up to the nearest half day (15 days a year in the first 3 years of service). You also receive 10 paid sick days and 3 personal days per calendar year, pro-rated in your first year, and the Bank-observed paid holidays for your province. Your standard work week is 37.5 hours.

**Conditions of this offer.** This offer is conditional on satisfactory pre-employment screening under HR-POL-020 Pre-Employment Screening Policy (you will receive FORM-HR-111 Consent to Pre-Employment Screening), proof of your right to work in Canada, and your Social Insurance Number within 3 business days of starting.

**Termination and notice.** If the Bank ends your employment without cause, you will receive notice or pay in lieu of notice equal to the greater of the minimum required by law and the amount set by HR-POL-025 Involuntary Termination and Severance Policy. If you resign, you agree to give the notice for your band set out in HR-POL-015 Resignation and Offboarding Policy.

**Confidentiality and non-solicitation.** You will keep Bank and client information confidential during and after your employment, and for **[Non-solicitation period]** after employment ends you will not solicit Bank employees or clients. The full terms are in the attached standard terms.

**Policies.** You agree to follow Bank policies, including the Code of Conduct and Ethics, and to complete the mandatory training and Code attestation within 30 days of your start date.

[Quebec only: A French version of this letter is attached. You may sign either version.]

This offer is open for acceptance for **5 business days** from the date above. To accept, sign and return this letter through MyHR.

Sincerely,
**[Hiring manager name]**, [Hiring manager title]
**[Recruiter name]**, Talent Acquisition

I accept this offer. Signature: ____________  Date: ____________

## 4. Required clauses checklist

| Clause | Required content |
| --- | --- |
| Compensation | Base salary, pay frequency, AIP target by band |
| Probation | 3 months, one extension to 6 months |
| Benefits | From day 1, enrol within 31 days, default Standard |
| Vacation | Entitlement for the first year, pro-rated |
| Conditions | Screening under HR-POL-020, right to work |
| Termination | Reference to the minimums in HR-POL-025 |
| Confidentiality and non-solicitation | Present, with the period inserted |
| Validity | 5 business days |

## 5. Drafting notes for HR

- AIP target by band: B1 5%, B2 5%, B3 5%, B4 8%, B5 10%, B6 15%, B7 20%, B8 30%, B9 45%. For sales incentive roles state the target in HR-PLN-002 Advisor and Sales Incentive Plan Document (8%, 10%, 12% or 20%) and delete the AIP sentence.
- New hires are usually paid between the band minimum and midpoint. Pay ranges are disclosed in postings (HR-POL-037 Pay Transparency Policy).
- Add the vacation tier from completed service if prior service is credited. Do not promise a start-date pension or benefit value beyond this letter.
- Do not add terms that differ from the standard terms without Legal review.

## 6. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.0 | 2023-04-03 | First standard Canadian offer letter |
| 2.0 | 2025-09-01 | Added probation extension wording, screening conditions and the 5-business-day validity period |
