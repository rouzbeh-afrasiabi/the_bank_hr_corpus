# Career Paths and Job Families Guide

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-FWK-002 |
| Title | Career Paths and Job Families Guide |
| Document type | Framework |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-11-01 |
| Last reviewed | 2026-09-22 |
| Next review | 2027-09-22 |
| Policy owner | SVP Talent and Learning |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-POL-012, HR-POL-011, HR-FWK-003 |

## 1. Purpose

This guide explains how jobs at the Bank are grouped into job families, what career tracks exist in each family and how employees can grow within and across them. It helps employees think about their next role and helps managers hold career conversations.

## 2. Scope

The guide applies to all employees in Canada and the US. It describes career paths and does not state eligibility rules for moving between roles; promotions and transfers are handled separately. Executive Committee roles sit outside the bands and are not covered. Where applicable law gives a greater right, the law applies.

## 3. Sources of truth

- **Bands and pay:** HR-GDE-006 Job Architecture and Pay Bands Guide and `pay_bands.csv` define the nine bands and their pay ranges.
- **Jobs:** `job_catalogue.csv`, held in the same folder as the HR documents, lists the Bank's jobs with their band and job family. If this guide and `job_catalogue.csv` differ, the catalogue is the source of truth for the job's band and family.
- **Behaviours:** HR-FWK-001 Competency and Leadership Model describes what is expected at each level.

## 4. The seven job families

| Family | What it covers |
| --- | --- |
| Retail Banking | Branches, advisors, mortgages and contact centre serving personal customers |
| Commercial Banking | Business customers, underwriting and relationship management |
| Wealth Management | Wealth advisors, portfolio management and investment services |
| Capital Markets | Trading, quantitative research and markets support |
| Technology and Operations | Software, data, security, payments and operations |
| Risk and Compliance | Credit risk, operational risk, financial crime and compliance |
| Corporate Functions | Finance, Human Resources, Legal and other enterprise support (HR roles sit here) |

## 5. Two tracks

Every family has two tracks up to Band 8.

| Band | Individual-contributor track | Manager track |
| --- | --- | --- |
| 1 | Associate Support | Not applicable |
| 2 | Associate | Not applicable |
| 3 | Professional | Not applicable |
| 4 | Senior Professional | Not applicable |
| 5 | Senior Specialist | Team Lead / Manager I |
| 6 | Principal Specialist | Manager II / Senior Manager |
| 7 | Senior Principal | Director |
| 8 | Senior Director | Vice President |

- The **individual-contributor track** values deep expertise and influence without people management. A Band 6 Principal Specialist and a Band 6 Senior Manager are in the same band and have the same pay range.
- The **manager track** values leading people and organizations.
- Band 9 Senior Vice President and Managing Director roles are enterprise leadership roles that sit above the two tracks.
- The tracks are of equal standing: the band, not the track, sets the pay range (see HR-GDE-006).

## 6. Typical time in band

Time in band varies widely. The figures below are typical ranges for planning conversations only; they are not requirements and do not create any entitlement. They are separate from the experience guidance in HR-GDE-006, which describes the typical experience of someone in the job.

| Band | Typical time in band |
| --- | --- |
| 1 | 1 to 2 years |
| 2 | 1 to 3 years |
| 3 | 2 to 3 years |
| 4 | 2 to 4 years |
| 5 | 2 to 4 years |
| 6 | 2 to 4 years |
| 7 | 3 to 5 years |

## 7. Example roles by family and band

The tables show examples of jobs. Use `job_catalogue.csv` for the full list.

### 7.1 Retail Banking

| Band | Examples |
| --- | --- |
| 1 | Teller; Customer Service Representative I |
| 2 | Customer Service Representative II; Financial Services Representative |
| 3 | Personal Banking Advisor |
| 4 | Mortgage Specialist; Senior Personal Banking Advisor |
| 5 | Assistant Branch Manager; Branch Manager |
| 6 | Regional Manager, Retail |
| 7 | Director, Retail Distribution |

### 7.2 Commercial Banking

| Band | Examples |
| --- | --- |
| 3 | Commercial Banking Analyst; Underwriter I |
| 4 | Relationship Manager, Small Business |
| 5 | Senior Relationship Manager, Commercial |
| 8 | Vice President, Commercial Banking |

### 7.3 Wealth Management and Capital Markets

| Family | Band | Examples |
| --- | --- | --- |
| Wealth Management | 4 | Wealth Advisor |
| Wealth Management | 6 | Portfolio Manager |
| Capital Markets | 3 | Trading Analyst |
| Capital Markets | 4 | Senior Quantitative Analyst |
| Capital Markets | 6 | Senior Trader |
| Capital Markets | 9 | Managing Director, Capital Markets |

### 7.4 Technology and Operations

| Band | Examples |
| --- | --- |
| 1 | Operations Clerk |
| 2 | Payments Processor |
| 3 | Software Developer; Data Analyst; Information Security Analyst |
| 4 | Senior Software Developer; Site Reliability Engineer; Business Analyst |
| 5 | Senior Data Scientist; Technology Team Lead |
| 6 | Senior Manager, Technology Delivery |
| 7 | Director, Cloud Platforms |

### 7.5 Risk and Compliance

| Band | Examples |
| --- | --- |
| 3 | AML Investigator; Credit Risk Analyst |
| 4 | Compliance Officer |
| 6 | Senior Manager, Operational Risk |

### 7.6 Corporate Functions

| Band | Examples |
| --- | --- |
| 2 | HR Connect Agent |
| 3 | Financial Analyst; HR Coordinator; Payroll Specialist; Recruiter |
| 4 | Senior Financial Analyst; HR Generalist; Compensation Analyst; Accommodation Specialist |
| 5 | HR Business Partner I; Employee Relations Consultant |
| 6 | HR Business Partner II |
| 7 | Director, Total Rewards |
| 8 | Vice President, HR Operations |
| 9 | Senior Vice President, Talent and Learning |

## 8. Growing your career

### 8.1 Growing in role

Take on broader scope, build depth, use the development budget and learning opportunities under HR-POL-012 Learning and Development Policy, and ask for feedback against HR-FWK-001. Mentoring, projects and short assignments can also help.

### 8.2 Lateral moves

A lateral move is a move to a role in the same band, in the same or a different family, to build breadth. Lateral moves are a valid way to build a career. How a move is requested, approved and filled is handled separately and is not covered by this guide.

### 8.3 Moving between tracks

An employee in Band 4 or above may talk to their manager and HRBP about moving between the individual-contributor and manager tracks. Any move is handled separately.

## 9. Career conversations

Employees and managers should discuss career interests at least once a year, usually at the mid-year check-in (1 May to 15 June) under HR-POL-011 Performance Management Policy. Managers should record agreed development actions in the development goal in MyHR. Talent review and succession planning for senior roles are described in HR-FWK-003 Talent Review and Succession Process.

## 10. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Employee | Own their career: reflect, raise interests and act on development plans |
| Manager | Hold career conversations, give honest feedback and support learning |
| HRBP | Advise on paths, families and development options |
| Total Rewards | Maintains the job catalogue and bands |
| SVP Talent and Learning | Owns this guide |

## 11. Contacts

HR Connect, 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time, hrconnect@bank.example, or your HRBP.

## 12. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-11-01 | Seven job families; added individual-contributor and manager tracks to Band 8, typical time in band and example roles. |
| 1.0 | 2023-11-01 | First issue. |
