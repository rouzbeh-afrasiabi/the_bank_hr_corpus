# How to enrol in benefits or change your election after a life event

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-011 |
| Title | How to enrol in benefits or change your election after a life event |
| Document type | How-to article |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-10-20 |
| Next review | 2027-10-20 |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-001, HR-PLN-004, HR-PLN-007, HOW-013 |

## 1. The short answer

Enrol in MyHR under Benefits within 31 days of your start date, and change your election outside annual enrolment only within 31 days of a qualifying life event.

## 2. Who this applies to

Regular full-time and part-time employees and fixed-term employees of 6 months or more, in Canada and the US, from day 1 (others: HR-POL-014). Quebec employees use the public drug plan or the Bank plan as the law requires. With no election you are enrolled by default: Standard, employee-only (Canada) or Choice PPO, employee-only (US).

## 3. Steps for a new hire

1. Select **MyHR > Benefits > Enrol**.
2. Choose your plan: Essential, Standard or Enhanced (Canada), or Choice PPO or Saver HDHP (US), and your coverage level (employee only or family).
3. Add dependants and name your life insurance beneficiaries.
4. Review the premiums, then submit within 31 days of your start date. Coverage starts on your first day if you submit in time.

## 4. Steps after a qualifying life event

Qualifying life events are: marriage, common-law or domestic partnership; birth or adoption of a child; loss of other coverage; change in dependant status; and divorce, separation or death of a covered person.

1. Select **MyHR > Benefits > Life Event Change**.
2. Enter the event date and choose the change; it must be consistent with the event.
3. Upload supporting documents, such as a marriage certificate or birth record.
4. Submit within 31 days of the event. Coverage for a new dependant starts on the event date.

## 5. Deadlines to remember

| Item | Date |
| --- | --- |
| New hire enrolment | Within 31 days of the start date |
| Life event change | Within 31 days of the event |
| Annual enrolment (plan year 2027) | 2 to 16 November 2026; changes allowed until 17:00 Eastern Time on 16 November; coverage from 1 January 2027 |

If you miss a 31-day window, you must wait for annual enrolment. At annual enrolment your current elections roll over if you do nothing, except US flexible spending accounts, which must be re-elected each year.

## 6. What happens next

Benefits Administration processes the election, and premiums are deducted from pay (monthly in Canada, each pay period in the US). Optional employee life above 4x salary or $750,000 needs evidence of insurability.

## 7. Common mistakes

- Missing the 31-day window and assuming a late change will be accepted.
- Making a change that does not match the event.
- Forgetting to upload documents or review beneficiaries.

## 8. Who to call

HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, or live chat in MyHR. Enrolment problems or premium errors: raise a case in the HR Case Portal. Maplewood Benefits: 1-800-555-0190.

## 9. Related documents

- HR-GDE-001 Employee Benefits Guide
- HR-PLN-004 Group Benefits Booklet (Canada)
- HOW-013 How to add or remove a dependant

## 10. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-01-01 | Updated for plan year 2026 and annual enrolment for plan year 2027. |
| 1.0 | 2025-01-06 | First edition. |
