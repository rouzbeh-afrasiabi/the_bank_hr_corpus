# How to refer a candidate and claim a referral bonus

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-039 |
| Title | How to refer a candidate and claim a referral bonus |
| Document type | How-to article |
| Version | 1.1 |
| Status | Current |
| Effective date | 2025-06-15 |
| Last reviewed | 2026-05-20 |
| Next review | 2027-05-20 |
| Policy owner | SVP Talent and Learning |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-019, HR-POL-001, HR-POL-016, HR-GDE-006 |

## 1. Short answer

Submit your referral before the candidate applies; if the referred person is hired and completes 6 months of service while you are still employed, you receive a bonus of $1,000 CAD or $750 USD, or $1,500 CAD or $1,100 USD for Band 6 and above and hard-to-fill roles.

## 2. Who this applies to

Employees in Canada and the US who refer candidates for open roles. Recruiters, HR staff involved in the hire and the hiring manager of the role are not eligible. Only one bonus is paid per hire. No employee may hire, or report directly or indirectly to, a relative, so declare any personal relationship with a candidate as soon as you know and withdraw from the panel (see HR-POL-001 Code of Conduct and Ethics).

## 3. Steps

1. **Find the role.** Browse open roles in MyHR > Career and Learning; each posting shows the pay range.
2. **Ask the candidate** to agree to your sharing their details, and tell them not to apply before you refer them.
3. **Submit the referral** in MyHR > Career and Learning before the candidate applies. A late referral is not eligible.
4. **Let the recruiter run the process.** Do not influence the decision.
5. **Confirm the tier** with your recruiter.
6. **Track payment** in MyHR > Pay after the referred hire's 6-month anniversary.

| Role | Bonus (Canada) | Bonus (US) |
| --- | --- | --- |
| Band 1 to Band 5 | $1,000 CAD | $750 USD |
| Band 6 and above, and hard-to-fill roles | $1,500 CAD | $1,100 USD |

## 4. Deadlines

| Item | Rule |
| --- | --- |
| Referral | Before the candidate applies |
| Bonus eligibility | Referred hire completes 6 months of service |
| Your status | Still employed on the payment date |
| Payment | Through payroll; taxable |

## 5. What happens next

The recruiter manages the candidate as for any applicant: screening under HR-POL-020, references and an offer within the pay band. Candidate data is used only for recruitment and kept for 12 months unless the person is hired. When the 6 months are complete, Payroll Services pays the bonus through payroll, less tax. Your recruiter can tell you whether the role counted as hard-to-fill.

## 6. Common mistakes

- Referring someone who has already applied.
- Leaving the Bank before the payment date.
- Referring a relative you would report to or supervise; that hire is not allowed.
- Expecting more than one bonus for the same hire.
- Sharing a person's details without their agreement (see HR-POL-016 Employee Data Privacy Policy).

## 7. Who to call

The recruiter for the role. HR Connect, 1-800-555-0142 (Monday to Friday 8:00 to 20:00 Eastern Time), hrconnect@bank.example, for payment questions. Managers: Manager Hotline, 1-800-555-0143.

## 8. Related documents

- HR-POL-019 Recruitment and Selection Policy
- HR-POL-001 Code of Conduct and Ethics
- HR-GDE-006 Job Architecture and Pay Bands Guide

## 9. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.1 | 2025-06-15 | Aligned with HR-POL-019 version 3.0. |
| 1.0 | 2025-01-01 | First issue. |
