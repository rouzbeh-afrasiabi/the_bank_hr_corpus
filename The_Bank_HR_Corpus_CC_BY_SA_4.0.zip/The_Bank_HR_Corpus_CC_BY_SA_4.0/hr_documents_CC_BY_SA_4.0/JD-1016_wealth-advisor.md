# Wealth Advisor

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1016 |
| Title | Wealth Advisor |
| Document type | Job description |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-09-30 |
| Next review | 2027-09-30 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-PLN-002, HR-POL-029, HR-POL-032, HR-POL-018 |

## 1. Role summary

The Wealth Advisor provides investment, retirement and wealth planning advice to affluent individuals and families. The Advisor builds a deep understanding of each client's goals, risk tolerance and circumstances, designs suitable investment strategies, and monitors them over time with the support of Bank investment and planning specialists. The role is licensed and held to the highest standards of suitability, disclosure and conduct. This is a Band 4 (Senior Professional) role in the Wealth Management family; see HR-GDE-006 Job Architecture and Pay Bands Guide.

## 2. Key responsibilities

- Build and manage a book of wealth clients, and grow it through referrals from branch and commercial colleagues.
- Complete comprehensive know-your-client and financial planning discovery, documenting goals, time horizon and risk tolerance.
- Recommend and implement suitable investment solutions, including funds, managed portfolios and registered plans.
- Review client portfolios regularly and rebalance in line with the client's plan, and meet clients at least annually.
- Provide retirement, education, estate and tax-aware planning guidance, collaborating with specialist planners.
- Disclose fees, conflicts and risks clearly and keep accurate records of advice.
- Comply with personal trading rules and restricted lists under HR-POL-032 Personal Trading and Restricted Lists Policy.
- Protect client information and follow anti-money-laundering, sanctions and privacy requirements.
- Respond to client concerns and complaints promptly and escalate according to procedure.
- Meet quarterly scorecard goals for customer experience, growth, and risk and conduct.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in business, finance or a related field, or equivalent experience.
- Five to eight years of experience in wealth management, investment advice or private client service.
- Strong knowledge of investment products, portfolio construction and financial planning.
- Excellent client relationship, communication and listening skills.
- Ability to obtain and maintain the licences below.

### 3.2 Preferred

- CFP, CFA (or progress towards either) or a similar designation.
- An established book of clients or demonstrated business development success.
- Fluency in English and French.

### 3.3 Licences and certifications

Under HR-POL-029 Licensing, Registration and Qualification Policy, the Wealth Advisor in Canada must hold an active mutual fund dealing representative licence. In the US, the role holds the Series registrations the role needs (Series 7 and 63, with Series 65 or 66 as applicable). No licensed duties may be performed until the licence is active. The annual licence review is each 1 September, and the Wealth Advisor tells Compliance within 2 business days of any change in registration status, complaint or regulatory inquiry.

## 4. Competencies

Competencies are defined in HR-FWK-001 Competency and Leadership Model; this role works at the Practitioner level.

- **Customer Obsession**: puts the client's long-term goals ahead of product or revenue.
- **Risk and Conduct Awareness**: holds to the highest suitability, disclosure and personal trading standards.
- **Judgement and Decision Quality**: makes well-founded investment recommendations in uncertain markets.
- **Drive for Results**: grows assets and relationships responsibly.
- **Collaboration**: coordinates with planners, bankers and investment specialists.
- **Adaptability**: updates advice as markets and regulation change.

## 5. Compensation and classification

| Item | Detail |
| --- | --- |
| Band | 4 (Senior Professional) |
| Canada salary range | $72,000 to $108,000 CAD per year |
| US salary range | $70,000 to $106,000 USD per year |
| Incentive target | Advisor and Sales Incentive Plan (HR-PLN-002): 20% of base salary, paid quarterly; replaces the Annual Incentive Plan |
| Overtime eligibility (Canada) | Yes (non-managerial Band 1 to 4 role) |
| FLSA classification (US) | Exempt |
| Work arrangement | Hybrid: at least 3 days a week in the office, with client meetings scheduled around them |

## 6. Working conditions and accessibility

This is a hybrid role with scheduled client meetings in person and by video, and some evening appointments. As a covered person under the Bank's personal trading rules, the Wealth Advisor discloses brokerage accounts and pre-clears trades. Hybrid arrangements follow HR-POL-002 Remote and Hybrid Work Policy, with at least 3 days a week in the office and anchor days on Tuesday and Thursday. The Bank provides accommodation to the point of undue hardship (Canada) or reasonable accommodation (US); see HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to the Regional Manager, Wealth.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-01-01 | Moved to the Advisor and Sales Incentive Plan scorecard; added personal trading language |
| 1.0 | 2024-01-08 | First issue |
