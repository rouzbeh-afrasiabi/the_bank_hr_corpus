# Sick Leave and Personal Leave Policy (version 2.2)

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

> **Archived version.** Kept for reference only. Do not rely on it. See HR-POL-007 Sick Leave and Personal Leave Policy.

| Field | Value |
| --- | --- |
| Document ID | HR-ARC-002 |
| Title | Sick Leave and Personal Leave Policy (version 2.2) |
| Document type | Archived version |
| Version | 2.2 |
| Status | Superseded |
| Superseded by | HR-POL-007 Sick Leave and Personal Leave Policy, version 3.0 (effective 2026-01-01) |
| Effective date | 2024-01-01 |
| Last reviewed | Not applicable |
| Next review | Not applicable |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-007, HR-POL-004, HR-POL-006, HR-POL-008, FORM-HR-010, FORM-HR-011 |

## 1. Status of this version

Version 2.2 was in force from 1 January 2024 to 31 December 2025. Version 3.0 replaced it on 1 January 2026 and increased paid sick days. Only the number of sick days differs from the current policy; the personal days, disability terms and all other rules shown here are the same as in HR-POL-007.

## 2. Purpose and scope

The policy described paid and unpaid time away for illness or injury, personal days, and longer personal leave, together with short-term disability, long-term disability and graduated return to work. It applied to regular full-time, regular part-time and fixed-term employees in Canada and the US. Casual employees received statutory sick leave only (HR-POL-014 Employment Status and Classification Policy). Where applicable law gave a greater right, the law applied.

## 3. Paid sick days

### 3.1 Entitlement (version 2.2)

| Country | Sick days per calendar year |
| --- | --- |
| Canada | **8** |
| US | **6** |

Sick days were credited on 1 January and available from the start date. They were pro-rated for new hires, rounded up to the nearest half day. The minimum use was a half day. Unused sick days did not carry over and were not paid out.

### 3.2 Permitted use

Sick days covered the employee's own illness or injury, medical appointments, and family care (up to 5 of the sick days a calendar year). US state sick leave laws (for example California, New York and New Jersey) were satisfied; where a state law gave more, the more generous rule applied.

### 3.3 Reporting and certificates

Absences were reported to the manager before the scheduled start, or within 30 minutes after it if the employee was unable to (HR-POL-004 Attendance and Absenteeism Policy). A medical certificate on FORM-HR-011 was required from the 4th consecutive working day, or when absences were adjacent to a holiday more than twice in 12 months with the agreement of the manager and HRBP. In Quebec evidence was requested only after 3 consecutive days. Certificates showed functional limitations and expected duration, not diagnosis, and went to the Leaves team within 5 business days of the request. The manager held a return-to-work conversation within 2 business days after an absence of 5 or more days.

## 4. Personal days

Each employee received **3 personal days** per calendar year, for any reason, with 24 hours' notice where possible, a minimum of a half day, no carryover, no payout and no certificate. They were pro-rated for new hires and were protected absences.

## 5. Short-term and long-term disability

Short-term disability was employer-paid through Maplewood Benefits and started after 5 consecutive working days of absence (sick days covered days 1 to 5): 100% of base salary for weeks 1 to 13 after the waiting period and 75% for weeks 14 to 26. Long-term disability began at week 27 at 66 2/3% of base salary, to a maximum of $15,000 per month, to age 65, with the "own occupation" test for the first 24 months. Employees applied through MyHR within 5 business days of going off work; Maplewood Benefits decided claims (1-800-555-0190). Birth parents in the US received short-term disability for medical recovery (HR-POL-008 Parental and Family Leave Policy).

## 6. Personal unpaid leave and graduated return

An employee with at least 2 years of service could request an unpaid personal leave of up to 6 months on FORM-HR-010, approved by the Director and HRBP. Benefits continued if the employee paid both shares, and vacation stopped accruing after 30 days. A graduated return of up to 12 weeks was arranged with the Accommodation Specialist.

## 7. Worked example (version 2.2)

A Canadian employee earning $78,000 a year ($1,500 a week) was off for 40 weeks. The employee used 5 of their 8 sick days at 100% for days 1 to 5. Weeks 1 to 13 after the waiting period were paid at 100% ($1,500 a week) and weeks 14 to 26 at 75% ($1,125 a week). From week 27 long-term disability paid 66 2/3% of $6,500 a month, about $4,333 a month.

## 8. Confidentiality, exceptions and contacts

Medical information was held by the Leaves team separately from the personnel file (HR-POL-016 Employee Data Privacy Policy). Exceptions needed the approval of the SVP Total Rewards. HR Connect: 1-800-555-0142, hrconnect@bank.example.

## 9. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.2 | 2024-01-01 | Canada 8 sick days, US 6 sick days. Short-term and long-term disability terms unchanged. |
| 3.0 | 2026-01-01 | Superseded this version; sick days increased to 10 (Canada) and 8 (US) (see HR-POL-007) |
