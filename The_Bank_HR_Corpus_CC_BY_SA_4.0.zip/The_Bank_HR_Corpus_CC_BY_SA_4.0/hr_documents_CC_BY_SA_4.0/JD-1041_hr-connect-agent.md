# HR Connect Agent

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1041 |
| Title | HR Connect Agent |
| Document type | Job description |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-03-16 |
| Last reviewed | 2026-09-29 |
| Next review | 2027-09-29 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-004, HR-GDE-006, HR-FWK-001, HR-POL-002, HR-POL-016, HR-POL-018 |

## 1. Role summary

The HR Connect Agent is the Tier 1 point of contact for employees and managers who call, chat or email HR Connect. The agent answers questions about pay, benefits, leaves and policies, logs and triages cases in the HR Case Portal, and routes anything that needs a specialist to Tier 2 or Tier 3. The role is Band 2 (Associate): it handles a broader range of tasks with some judgement under general guidance. See HR-GDE-006 Job Architecture and Pay Bands Guide and HR-GDE-004 HR Service and Support Guide.

## 2. Key responsibilities

- Answer calls on 1-800-555-0142 and live chats in MyHR, Monday to Friday 8:00 to 20:00 Eastern Time, in English and French where bilingual.
- Verify the caller's identity before discussing personal information, in line with HR-POL-016 Employee Data Privacy Policy.
- Create and update cases in the HR Case Portal with accurate category, priority and notes.
- Apply the service levels in HR-GDE-004: first response within 4 business hours for P1 urgent cases (missed pay, safety, harassment, lockout from pay or benefits), 1 business day for P2, 2 business days for P3 and 3 business days for P4.
- Resolve routine requests at first contact, such as how to book vacation, update direct deposit (FORM-HR-022) or find a form.
- Transfer P1 cases to the right Tier 2 team immediately; route harassment or violence concerns to Employee Relations without discussing the details.
- Answer Manager Hotline queries (1-800-555-0143) within 4 business hours.
- Explain MyHR self-service steps and recommend the matching how-to article.
- Record recurring questions and gaps in the knowledge base and propose updates.
- Keep a respectful, empathetic tone with employees who are ill, on leave or distressed, and refer them to the Wellspring Support Program where appropriate.

## 3. Qualifications

### 3.1 Required

- High school diploma or equivalent; post-secondary education in business or human resources is an asset.
- One to three years of customer service or contact centre experience.
- Excellent verbal and written communication; comfort with multi-tasking in a case management system.
- Ability to protect confidential information.

### 3.2 Preferred

- Bilingual English and French, especially for supporting Quebec employees.
- Prior HR service desk or payroll support experience.
- Familiarity with Canadian and US employment basics.

## 4. Competencies

Competency names follow HR-FWK-001 Competency and Leadership Model (Foundation level, Bands 1 to 2).

- Customer Obsession
- Collaboration
- Adaptability
- Risk and Conduct Awareness
- Inclusive Leadership

## 5. Compensation and classification

| Item | Detail |
| --- | --- |
| Band | 2 (Associate) |
| Canada range | $44,000 to $64,000 CAD per year |
| US range | $43,000 to $62,000 USD per year |
| Incentive target | 5% of base salary (Annual Incentive Plan) |
| Overtime eligibility, Canada | Yes (non-managerial) |
| FLSA classification, US | Non-exempt |
| Work arrangement | On-site at the HR Connect contact centre |

## 6. Working conditions and accessibility

Work is scheduled in shifts that cover HR Connect hours. This is an on-site contact centre role; the work-arrangement categories are in HR-POL-002 Remote and Hybrid Work Policy. Start, end and meal times are recorded in Time Tracker; overtime must be pre-approved (HR-POL-003 Working Hours and Overtime Policy). Schedules are posted at least 14 days ahead. The role involves headset and screen work for long periods. The Bank provides accommodation to the point of undue hardship (HR-POL-018 Workplace Accommodation and Accessibility Policy).

## 7. Reporting line

Reports to the Team Lead, HR Connect. The role has no direct reports.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-03-16 | Service levels and hours aligned with HR-GDE-004 version 2.5; work arrangement confirmed as on-site |
| 1.0 | 2025-01-01 | First issue |
