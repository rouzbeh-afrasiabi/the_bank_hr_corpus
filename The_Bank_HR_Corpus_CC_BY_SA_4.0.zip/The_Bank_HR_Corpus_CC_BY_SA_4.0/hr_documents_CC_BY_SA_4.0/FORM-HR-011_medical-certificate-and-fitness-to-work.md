# Medical Certificate and Fitness-to-Work

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-011 |
| Title | Medical Certificate and Fitness-to-Work |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-007, HR-POL-006, HR-POL-004, FORM-HR-041 |

## 1. Purpose and when to use this form

Use this form to give the Bank evidence that you cannot work, or that you are fit to return. It is required from the 4th consecutive working day of absence. In Quebec the Bank asks for evidence only after 3 consecutive days. A certificate may also be requested when absences are adjacent to a holiday more than twice in 12 months, but only with the agreement of your manager and HRBP. Personal days never need a certificate.

## 2. Who completes it and who approves

Your treating health care provider completes the provider section; you complete the rest. The Leaves team reviews it. Your manager does not receive the form.

## 3. Where and when to submit

Upload it to the Leaves team through MyHR within 5 business days of the request. An equivalent provider note is accepted.

## 4. Form fields

| Field | Required | Notes |
| --- | --- | --- |
| Employee name and ID | Yes | Pre-filled |
| First day of absence | Yes | |
| Expected return date or review date | Yes | |
| Functional limitations | Yes | What you can and cannot do; for example "no lifting over 5 kg" |
| Fitness to work | Yes | Fit, fit with limitations, or not fit |
| Graduated return suggested | No | Up to 12 weeks |
| Provider name, licence or registration number, signature | Yes | |
| Diagnosis, treatment, test results | Do not provide | Never required |

## 5. Declarations and signatures

- The information is accurate and the certificate is genuine.
- I understand that falsifying a certificate is misconduct under HR-POL-001 Code of Conduct and Ethics.

## 6. What happens next

The Leaves team tells your manager only your functional limitations and expected duration. Records are held separately from your personnel file. After 5 or more absence days, your manager holds a return-to-work conversation within 2 business days of your return. If your absence may pass 5 consecutive working days, apply to Maplewood Benefits through MyHR for short-term disability within 5 business days of going off work. If you need ongoing adjustments, contact the Accommodation Specialist (FORM-HR-041 if functional information is needed). Where applicable law gives a greater right, the law applies.

## 7. Related documents

- HR-POL-007 Sick Leave and Personal Leave Policy
- HR-POL-004 Attendance and Absenteeism Policy
- HR-POL-018 Workplace Accommodation and Accessibility Policy

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-01-01 | Clarified that certificates show functional limitations only and go to the Leaves team. |
