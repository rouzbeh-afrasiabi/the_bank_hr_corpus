# How to get a letter of employment or income verification

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-024 |
| Title | How to get a letter of employment or income verification |
| Document type | How-to article |
| Version | 1.1 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-09-01 |
| Next review | 2027-09-01 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-014, HR-POL-016, HR-GDE-004, HR-REF-002 |

## 1. The short answer

Open a case in MyHR > HR Case Portal asking HR Operations for a letter; by default it confirms only your job title, dates of employment and employment status, and anything more, such as salary, needs your written consent.

## 2. Who this applies to

Current and former employees in Canada (including Quebec) and the US who need to prove employment to a landlord, lender, government body or future employer. Managers do not issue these letters; HR Operations does. Quebec employees may ask for the letter in French.

## 3. Steps

1. Decide what the recipient needs. For a standard letter (job title, dates of employment, status: regular full-time, regular part-time, fixed-term or casual) no consent is needed.
2. For salary, hours or other details, give written consent in MyHR > Personal Information > Consents, naming exactly what the Bank may disclose and to whom. For a reference, give written consent too.
3. Go to MyHR > HR Case Portal, select **New case**, and describe the request. Say who the letter is for and any closing date. Do not type sensitive details; attach them only if asked.
4. HR Operations confirms your identity (and the requester's), prepares the letter on Bank letterhead and sends it to you or to the named recipient.
5. Give the recipient the HR Operations contact if they want to confirm the letter; income details are never given by phone.

## 4. Deadlines and what happens next

A document request is normally Priority 4 (first response within 3 business days). If you have a closing date, say so, because a time-sensitive request can be Priority 2 (first response within 1 business day); see HR-GDE-004 HR Service and Support Guide. Each letter states that it is accurate as of its date and that the Bank provides no other information. HR keeps a copy of the letter and your consent in your case.

Former employees: personnel files are kept for 7 years after employment ends, and MyHR access for pay statements and tax slips remains for 24 months after your last day (see HR-REF-002 Employee Records Retention Schedule). After that, contact HR Connect.

## 5. Common mistakes

- Asking your manager to write the letter. They cannot.
- Expecting salary to be included without consent.
- Asking the lender or landlord to phone HR for income details. Ask them to use your consent in MyHR instead.
- Not stating a closing date.
- Requesting a reference without consent. If you were dismissed for cause, reference requests go to Employee Relations first.

## 6. Who to call

- HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, or live chat in MyHR.
- Privacy questions about what is shared: privacy@bank.example.

## 7. Related documents

- HR-POL-014 Employment Status and Classification Policy
- HR-POL-016 Employee Data Privacy Policy
- HR-GDE-004 HR Service and Support Guide

Where applicable law gives a greater right, the law applies.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.1 | 2025-09-01 | Added the consent-based options and the default of title, dates and status only. |
| 1.0 | 2025-01-01 | First version. |
