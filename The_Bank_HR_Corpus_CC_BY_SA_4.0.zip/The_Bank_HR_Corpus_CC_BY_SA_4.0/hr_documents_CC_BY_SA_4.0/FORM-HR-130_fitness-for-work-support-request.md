# Fitness-for-Work Support Request

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-130 |
| Title | Fitness-for-Work Support Request |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | Head of Workplace Safety |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-041, HR-POL-007, HR-POL-018, HR-POL-023, FORM-HR-040 |

## 1. Purpose and when to use this form

Use this form to ask confidentially for support if a dependency or a health condition, including alcohol, cannabis or other drug use, or a medication that affects safety, could affect your ability to work safely (HR-POL-041 Substance Use and Fitness for Work Policy). An employee who discloses a dependency before a violation receives support and accommodation. Asking for help is not misconduct.

## 2. Who completes it and who approves

You complete it. The HRBP and the Accommodation Specialist review it. Your manager is told only what is needed to put support in place, such as functional limitations and expected duration, and never a diagnosis (see HR-POL-018 Workplace Accommodation and Accessibility Policy).

## 3. Where and when to submit (deadline, channel, processing time)

Submit as soon as you need support, in MyHR (Health and Safety > Fitness-for-Work Support), or contact your HRBP, HR Connect (1-800-555-0142) or accommodations@bank.example. You may call the Wellspring Support Program (1-800-555-0166, 24 hours) at any time without using this form.

## 4. Form fields

| Field | Required | Notes |
| --- | --- | --- |
| Name and employee ID | Yes | Pre-filled |
| Preferred contact method and safe times | Yes | |
| Type of support needed | Yes | Employee assistance counselling, treatment leave, graduated return, temporary change of duties, other |
| Do your duties include safety-sensitive tasks, such as driving a Bank vehicle? | Yes | |
| Functional limitations and expected duration | If known | Do not give a diagnosis |
| Does a medication you take affect safety at work? | No | Say only that it does |
| Earliest date support is needed | Yes | |
| Medical information supplement attached | No | See FORM-HR-041 Medical Information Supplement for Accommodation |

## 5. Declarations and signatures

I confirm that I am asking for support voluntarily and that the information is accurate. I understand that this request is confidential and that medical information is held separately from my personnel file. Signature and date: ____________.

## 6. What happens next

HR acknowledges your request within 2 business days and the Accommodation Specialist contacts you within 5 business days, using your preferred method, and agrees a support plan. This may include the Wellspring Support Program, treatment leave under HR-POL-007 Sick Leave and Personal Leave Policy, and a graduated return to work. A first positive screen does not in itself lead to termination. There is no random testing; testing may occur only on reasonable grounds for safety-sensitive duties, after approval by the VP Employee Relations. If a manager believes you are impaired at work, you are sent home safely, never driving, and the manager reports to the HRBP the same business day.

## 7. Related documents

- HR-POL-041 Substance Use and Fitness for Work Policy
- HR-POL-007 Sick Leave and Personal Leave Policy
- HR-POL-018 Workplace Accommodation and Accessibility Policy

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-09-01 | Aligned with the support-first approach and confidentiality rules in HR-POL-041. |
| 1.0 | 2022-09-01 | Initial form. |
