# Termination Letter, Without Cause

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-TPL-004 |
| Title | Termination Letter, Without Cause |
| Document type | Template |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-06-30 |
| Next review | 2027-06-30 |
| Policy owner | VP Employee Relations |
| Audience | HR only |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-025, HR-POL-015, HR-PRC-004, HR-TPL-005 |

## 1. Purpose and when to use this template

This template is handed to an employee at the termination meeting when the Bank ends employment without cause. Severance and notice rules are owned by HR-POL-025 Involuntary Termination and Severance Policy. The meeting steps are in HR-PRC-004 Termination Checklist and Protocol. For a termination for cause use HR-TPL-005 Termination Letter, For Cause.

## 2. How to use this template

1. Obtain the approvals required by HR-PRC-004 before the meeting and hold the meeting on a Tuesday to Thursday where possible, with the HRBP present.
2. Keep one jurisdiction block (Canada or US) and delete the other.
3. Calculate the notice or severance weeks with Total Rewards and complete every `[placeholder]`.
4. Give the letter in the meeting and send a copy by MyHR or courier the same day.

## 3. Letter text

**[Date]**   **Personal and confidential**

**[Employee full name]**, [Employee ID]

**Subject: End of your employment**

Dear [Employee first name],

This letter confirms that the Bank has decided to end your employment as **[Job title]**, Band **[Band]**, without cause. Your employment ends on **[Termination date]**. Your last day of work is **[Last day worked]**. Your access to Bank systems ends **[immediately / at 17:00 on the last day]**.

**[Canada] Notice and severance.** You will receive **[Notice weeks] weeks** of base pay, which is the greater of the minimum required by law and the Bank formula (2 weeks of base pay per completed year of service, minimum 8 weeks, maximum 52 weeks), paid as **[pay in lieu / salary continuation]**. Your benefits continue through the notice period.

**[US] Severance.** You will receive **[Severance weeks] weeks** of base pay (1 week per completed year of service, minimum 4 weeks, maximum 26 weeks). Your health coverage ends on **[Last day of month]**. If you elect COBRA continuation coverage, the Bank pays 3 months of its premium share.

**Release.** The enhanced severance above any amount you are entitled to by law is conditional on your signing the attached release. **[Canada]** You have 14 days to consider it. **[US, age 40 or over]** You have 21 days to consider it (45 days if you are part of a group termination) and 7 days after signing to revoke it.

**Final pay.** You will receive all earned wages and unused earned vacation by the legal deadline for **[Work province or state]**, no later than the legal deadline. You are eligible for Annual Incentive Plan pay only if you are on payroll on the payment date. **[Canada]** Your Record of Employment will be issued electronically within 5 calendar days after the end of the pay period in which your employment ends. Your tax slip will be issued by 28 February (T4 and, in Quebec, Relevé 1). **[US]** Your Form W-2 will be issued by 31 January.

**Outplacement.** You are offered **[12 / 26] weeks** of outplacement support (12 weeks for Bands 1 to 6, 26 weeks for Band 7 and above). Contact HR Connect to activate it.

**Bank property and support.** Please return all Bank property within 5 business days (a prepaid shipping kit is provided for remote employees). The Wellspring Support Program, 1-800-555-0166, is available 24 hours a day, confidential and free. Your confidentiality obligations continue after your employment ends.

Questions: HR Connect, 1-800-555-0142, or your HRBP [HRBP name].

Sincerely,
**[Manager name]**, [Manager title]
**[HRBP name]**, HR Business Partner

## 4. Required clauses checklist

| Clause | Required content |
| --- | --- |
| Effective date and last day | Both stated |
| Notice or severance | Formula and weeks; Canada 2 per year (8 to 52); US 1 per year (4 to 26) |
| Benefits | Canada through the notice period; US end of month and COBRA |
| Release | 14 days Canada; 21 or 45 days plus 7 to revoke for US employees aged 40 or over |
| Outplacement | 12 or 26 weeks by band |
| Final pay and slips | Legal deadline, ROE, T4, Relevé 1, W-2 |

## 5. Drafting notes for HR

- Group terminations of 50 or more employees in Canada, and mass layoffs in the US, follow statutory notice rules (including the 60-day WARN Act notice); do not use this template for them without Legal.
- The letter never states the reason beyond "without cause".
- Notice under the law may exceed the Bank formula; the greater applies (HR-POL-025).
- US employees under 40 receive a consideration period set by Legal; confirm before issuing.
- Final pay deadlines by jurisdiction are in HR-POL-015 Resignation and Offboarding Policy.

## 6. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.0 | 2023-04-03 | First termination letter template |
| 2.0 | 2025-09-01 | Added release timelines, outplacement by band and ROE and slip wording |
