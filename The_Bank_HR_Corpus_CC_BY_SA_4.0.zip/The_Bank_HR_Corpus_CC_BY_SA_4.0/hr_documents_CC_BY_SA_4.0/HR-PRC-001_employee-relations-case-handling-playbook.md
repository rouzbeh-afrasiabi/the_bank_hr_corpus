# Employee Relations Case Handling Playbook

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-PRC-001 |
| Title | Employee Relations Case Handling Playbook |
| Document type | Procedure |
| Version | 3.1 |
| Status | Current |
| Effective date | 2025-04-01 |
| Last reviewed | 2026-07-14 |
| Next review | 2027-07-14 |
| Policy owner | VP Employee Relations |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | HR only |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-021, HR-POL-005, HR-POL-013, HR-POL-025, HR-PRC-002, HR-PRC-004, HR-PRC-007, FORM-HR-050, FORM-HR-071 |

## 1. Purpose

This playbook tells HR staff how to receive, triage, work and close an employee relations (ER) case in the HR Case Portal. It turns the rules in HR-POL-021 Employee Relations and Progressive Discipline Policy into daily steps, decision points and timelines. It adds operational detail only. If this playbook and an employee-facing policy ever appear to differ, the policy applies and the owner of this playbook must be told so the playbook can be corrected.

## 2. Scope

The playbook applies to HR Business Partners (HRBPs), Employee Relations consultants, HR Connect agents who open ER cases, and Legal and Privacy colleagues who support them. It covers conduct, performance, attendance, conflict, retaliation and related cases in Canada and the US. Harassment and violence investigations also follow HR-PRC-002 Workplace Investigation Procedure; terminations follow HR-PRC-004 Termination Checklist and Protocol; accommodation questions follow HR-PRC-007 Accommodation Case Management Procedure. Where applicable law gives a greater right, the law applies.

## 3. Roles

| Role | What they do in a case |
| --- | --- |
| HR Connect agent (Tier 1) | Opens the case, sets the first priority, routes it to Tier 3 within the same business day. |
| ER consultant (Tier 3) | Owns the case, advises the manager, runs the consistency review, approves terminations as set out in HR-POL-021. |
| HRBP | Supports the manager and employee, must be consulted before any written warning, helps arrange interim measures. |
| VP Employee Relations | Extends suspensions with pay beyond 10 business days, approves exceptions, approves terminations for cause with Legal. |
| Legal | Advises on threatened litigation, regulator contact, releases and protected circumstances. |
| Director (business unit) | Approves final written warnings and unpaid suspensions. |

## 4. Case types

| Code | Case type | Usual first step |
| --- | --- | --- |
| ER-CON | Workplace conflict or concern | Triage, then facilitated conversation or Ombuds Office referral |
| ER-CND | Conduct or policy breach | Fact-finding, then progressive discipline |
| ER-PRF | Performance concern | Confirm coaching, then HR-POL-013 Performance Improvement Policy |
| ER-ATT | Attendance pattern | Confirm no protected absence, then Stage 1 to 3 under HR-POL-004 Attendance and Absenteeism Policy |
| ER-HAR | Harassment, discrimination or violence complaint | P1; start HR-PRC-002 |
| ER-RET | Alleged retaliation | Treated as a new complaint under HR-POL-005 |
| ER-TRM | Proposed termination | HR-PRC-004 |
| ER-LEG | Threatened litigation or regulator contact | Same-day escalation to Legal |

A case may carry more than one code. The ER consultant sets the primary code at triage and records secondary codes in the case notes.

## 5. Step-by-step procedure

### 5.1 Intake

1. Open the HR Case Portal in MyHR and select **New case, Employee Relations**. Cases may arrive from a manager, an employee, an HRBP, the Speak-Up Line (through the Ethics Office), Corporate Security or a verbal report.
2. Record the reporter, the people involved, business unit, work location (province or state), dates, a factual summary and any evidence offered. Attach FORM-HR-050 for harassment or violence reports; a verbal report is accepted and the designated recipient completes the form with the reporter.
3. A manager who hears of a possible harassment or violence matter must refer it to Employee Relations on the same business day (HR-POL-005). Log the date and time of first knowledge, because every timeline runs from it.
4. Do not promise confidentiality that cannot be kept. Tell the reporter that information is shared only with those who need it.

### 5.2 Triage and priority

Set the priority using the service levels in HR-GDE-004 HR Service and Support Guide.

| Priority | Typical ER cases | First response |
| --- | --- | --- |
| P1 urgent | Harassment, violence, threats, safety, retaliation | 4 business hours |
| P2 high | Suspension questions, serious misconduct allegations, pending termination | 1 business day |
| P3 standard | Warnings, attendance plans, conflict | 2 business days |
| P4 low | General information requests | 3 business days |

Tier 3 cases have a 10 business day resolution target; an investigation follows the longer timelines in HR-PRC-002. If a target is missed, escalate to the HR Operations manager after the first missed deadline, then the VP HR Operations, then the Office of the CHRO.

### 5.3 Conflict-of-interest check

Before assignment, the intake owner checks that the ER consultant and HRBP have no personal relationship, reporting line or prior involvement with any party. If a conflict exists, assign another consultant and record the reason. An HRBP who supports the respondent's business unit may support the manager but does not act as investigator.

### 5.4 Assignment

The ER consultant is assigned within 1 business day of intake. The assignment note in the case names the consultant, HRBP and, where needed, Legal. For ER-HAR cases follow section 6.

### 5.5 Fact-finding and advice

1. Meet the manager. Confirm the facts, what was said or done, and what steps (coaching, earlier warnings) are already on file.
2. Check protected circumstances: an accommodation request, a leave, a pending complaint, a Speak-Up report or a rating dispute. If any is present, apply HR-PRC-007 where relevant, tell Legal, and pause any step until Legal has reviewed it.
3. Run the consistency review required by HR-POL-021 against comparable past cases (conduct, role, length of service, history, mitigating factors, possible bias). Record the comparators in the case.
4. Choose the step. Use the table in HR-POL-021 section 5 and the approvals table in section 8 of that policy.

### 5.6 Interim measures

Where a measure is needed, put it in place within 5 business days of the complaint for harassment or violence matters. Measures include separation, changed reporting lines, adjusted schedules or remote work, restricted system access, or paid leave. A suspension with pay pending investigation is up to 10 business days; extension requires written approval from the VP Employee Relations with the reason and a new end date. Record every measure as a neutral step, not a finding.

### 5.7 Delivering discipline

| Step | Approval before delivery | Record |
| --- | --- | --- |
| Verbal warning | Manager; HRBP informed | Confirmed in writing to the employee |
| Written warning | HRBP consulted | FORM-HR-071, active 12 months |
| Final written warning or unpaid suspension (up to 3 days) | HRBP and ER; Director approval | FORM-HR-071, active 24 months |
| Termination for cause | ER approval, then VP Employee Relations and Legal | HR-PRC-004 |

The employee receives the facts and may respond in writing within 5 business days and bring a support person who is not legal counsel. Upload the signed FORM-HR-071 (or a note that the employee declined to sign) within 2 business days of the meeting. Meetings are held privately, preferably Tuesday to Thursday.

## 6. Harassment and violence cases

Move the case to HR-PRC-002 on the day it is coded ER-HAR. Confirm that acknowledgement to the complainant is sent within 2 business days, interim measures are decided within 5 business days, and the 60 calendar day investigation clock has started. Offer the Wellspring Support Program (1-800-555-0166) to everyone involved. If anyone is in immediate danger, call 911 first, then Corporate Security at 1-800-555-0119.

## 7. Escalation to Legal

Escalate to Legal the same business day when any of these occurs:

- a lawyer's letter, a statement of claim or a threat to sue;
- contact from a regulator, human rights body or the EEOC;
- a proposed termination during a protected leave or with a pending accommodation (HR-POL-025);
- a group proposal affecting 5 or more employees;
- a request for a release that departs from the standard terms.

Record the date of escalation, the question asked and the advice received. Do not send documents outside the Bank without Legal approval.

## 8. Documentation standards

- Write facts, not conclusions. Quote words used. Separate what was observed from what was reported.
- Date and time every entry; use the Portal's notes field rather than email so that the file is complete.
- Keep medical information out of the ER case. Reference only functional limitations and expected duration, and hold anything more in the separate accommodation file (HR-PRC-007).
- Disciplinary records go to the confidential employee file. Investigation files are kept 10 years after closing and held separately from the personnel file (HR-REF-002 Employee Records Retention Schedule).
- Apply HR-PRC-008 Privacy Request and Incident Handling Procedure if case material is sent to the wrong person.

## 9. Closure codes

Close the case only when every action is complete, the employee and manager have been told the outcome, and the file is uploaded.

| Closure code | Meaning |
| --- | --- |
| CL-RES | Resolved informally |
| CL-COA | Coaching or conversation completed, no discipline |
| CL-WRN | Verbal, written or final written warning issued |
| CL-PIP | Moved to a performance improvement plan |
| CL-SUB | Substantiated, corrective action applied |
| CL-UNS | Not substantiated, no action against the respondent |
| CL-TRM | Employment ended (see HR-PRC-004) |
| CL-REF | Referred to another team or the Ombuds Office |
| CL-WDR | Withdrawn by the reporter (the Bank may still act) |

## 10. Checklist before closing

- [ ] Priority and first response met; any missed target explained.
- [ ] Conflict check and consistency review recorded.
- [ ] Required approvals attached.
- [ ] Employee given the right to respond and a support person.
- [ ] FORM-HR-071 or outcome letter uploaded.
- [ ] Retaliation watch note set where the case involved a complaint (HR-PRC-002).
- [ ] Closure code selected and retention class set.

## 11. Contacts

Managers may call the Manager Hotline, 1-800-555-0143, which responds within 4 business hours. Employees may contact HR Connect at 1-800-555-0142 or the Ombuds Office at ombuds@bank.example for informal advice.

## 12. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 3.1 | 2025-04-01 | Aligned the playbook with HR-POL-021 version 4.0: active periods, 10 business day suspension limit, Legal escalation list and closure codes. |
| 3.0 | 2023-09-01 | Introduced the HR Case Portal intake, conflict check and consistency review. |
