# Parental Leave Enhancements from 1 November 2025

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-MEMO-2025-004 |
| Title | Parental Leave Enhancements from 1 November 2025 |
| Document type | Memo |
| Version | 1.0 |
| Status | Current |
| Effective date | 2025-10-14 |
| Last reviewed | Not applicable |
| Next review | Not applicable |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-008, FORM-HR-012, HR-POL-007, HR-GDE-001 |

**New parents get more paid time: top-ups rise in both countries.**

**From:** SVP Total Rewards

**To:** All employees in Canada and the US

**Date:** 14 October 2025

**Subject:** Enhanced parental leave pay, HR-POL-008 version 5.1

## 1. What is changing

| Item | Old (version 5.0) | New (version 5.1) |
| --- | --- | --- |
| Canada: top-up to 100% of base salary for non-birth, adoptive and surrogacy-intended parents | 6 weeks | 8 weeks |
| US: paid parental leave at 100% of base salary for any new parent | 8 weeks | 12 weeks |

Birth-parent pregnancy leave top-up in Canada (17 weeks) is unchanged. US paid leave runs concurrently with FMLA and state programs.

## 2. Who is affected

Employees who become parents by birth, adoption, surrogacy or foster placement. In Canada the top-up needs 6 months of continuous service.

## 3. Effective date

1 November 2025.

## 4. What to do

1. Give notice at least 4 weeks before leave starts, where possible, using FORM-HR-012 in MyHR.
2. Give 4 weeks' notice again before you return. A phased return of up to 4 weeks at 80% of normal hours can be arranged with your manager and the Leaves team.
3. Apply for the government benefit (Employment Insurance, or the Quebec Parental Insurance Plan in Quebec) in Canada; the Bank cannot guarantee it.

## 5. Who to call

HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, or live chat in MyHR.

## 6. Related documents

- HR-POL-008 Parental and Family Leave Policy
- FORM-HR-012 Parental Leave Notice and Top-Up Application
- HR-GDE-001 Employee Benefits Guide
