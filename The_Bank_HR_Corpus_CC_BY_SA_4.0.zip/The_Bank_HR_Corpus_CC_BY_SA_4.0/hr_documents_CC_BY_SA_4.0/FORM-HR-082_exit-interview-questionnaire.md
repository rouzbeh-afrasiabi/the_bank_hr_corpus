# Exit Interview Questionnaire

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-082 |
| Title | Exit Interview Questionnaire |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-10-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-015, HR-POL-016, FORM-HR-080, FORM-HR-081 |

## 1. Purpose and when to use this form

This questionnaire guides the exit interview offered to every leaving employee. It helps the Bank understand why people leave and what could improve the employee experience (HR-POL-015 Resignation and Offboarding Policy).

## 2. Who completes it and who approves

You answer the questions. An HR Operations representative holds the interview and records your answers; your manager never conducts it. Taking part is voluntary. Declining has no effect on final pay or rehire eligibility.

## 3. Where and when to submit (deadline, channel, processing time)

HR Operations offers the interview in your final week, in person, by video or by phone, or you may complete the questionnaire in MyHR. Responses are confidential, are aggregated quarterly and are reported without names.

## 4. Form fields

| Field | Required | Notes |
| --- | --- | --- |
| Name, band, business unit, last day | No | Pre-filled; removed before reporting |
| Main reason for leaving | No | Career growth, pay, manager, workload, flexibility, relocation, retirement, other |
| Overall experience at the Bank | No | Rate 1 (poor) to 5 (excellent) |
| My manager supported my development | No | Rate 1 to 5 |
| My work was recognized | No | Rate 1 to 5 |
| I could work in a way that suited my role (see HR-POL-002 Remote and Hybrid Work Policy) | No | Rate 1 to 5 |
| I felt included and respected | No | Rate 1 to 5; comment encouraged |
| Did you see conduct you believe breached the Code of Conduct and Ethics? | No | Yes or No; if Yes, HR Operations explains how to report it |
| What would have kept you at the Bank? | No | Free text |
| Would you recommend the Bank as an employer? | No | Yes, Maybe, No |
| Would you consider returning? | No | Yes, Maybe, No |
| Other comments | No | Free text |

## 5. Declarations and signatures

I understand that my participation is voluntary and that my answers are used only in aggregated form, as set out in HR-POL-016 Employee Data Privacy Policy. A signature is optional: ____________.

## 6. What happens next

HR Operations records that the interview was offered and held on FORM-HR-081 Offboarding Checklist. Aggregated themes go to HR leadership each quarter. If you describe a serious concern such as harassment, HR Operations explains the formal channels, including the Speak-Up Line (1-800-555-0177), and does not act on your behalf without your agreement unless the law requires it.

## 7. Related documents

- HR-POL-015 Resignation and Offboarding Policy
- FORM-HR-080 Resignation Notice
- HR-POL-016 Employee Data Privacy Policy

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-10-01 | Added inclusion and conduct questions; confirmed quarterly aggregation. |
| 1.0 | 2023-04-01 | Initial form. |
