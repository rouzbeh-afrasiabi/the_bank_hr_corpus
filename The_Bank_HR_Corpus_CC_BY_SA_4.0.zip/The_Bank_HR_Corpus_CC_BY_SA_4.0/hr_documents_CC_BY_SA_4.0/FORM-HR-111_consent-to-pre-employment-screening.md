# Consent to Pre-Employment Screening

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-111 |
| Title | Consent to Pre-Employment Screening |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-020, HR-POL-016, HR-POL-018, HR-REF-002, HR-GDE-003 |

## 1. Purpose and when to use this form

No screening check starts until you sign this form (HR-POL-020 Pre-Employment Screening Policy). The recruiter issues it with your conditional offer, which depends on satisfactory results. The same form is used, with consent, when employees in sensitive roles are re-screened every 5 years.

## 2. Who completes it and who approves

You complete and sign it. HR Operations (Screening team) reviews it and orders the checks that apply to your role. No approval is needed from you beyond signature.

## 3. Where and when to submit (deadline, channel, processing time)

Return the signed form through the candidate portal link in your offer email by the date in the offer letter, normally within 2 business days. The target turnaround is 5 business days from receipt of consent and complete information. You may start only when required checks are satisfactory or HR Operations has approved a start with items outstanding.

## 4. Form fields

| Field | Required | Notes |
| --- | --- | --- |
| Full legal name and other names used | Yes | Include previous names |
| Date of birth, current address, 5-year address history | Yes | |
| Role, band and location of the role | Yes | Sets the checks and local law |
| Identity and right-to-work documents | Yes | Originals verified; see HR-GDE-003 New Employee Onboarding Guide |
| Criminal record check | Yes | Canada: police information check. US: check under the Fair Credit Reporting Act. In Quebec, only where related to the job |
| Credit check | Roles with financial authority only | Not run for other roles |
| Education | Yes | Highest qualification relevant to the role |
| Employment history, previous 7 years | Yes | Include references |
| Professional licences and designations | If required by the role | Confirmed with the issuing body |
| Sanctions screening | Yes | |
| Section 19 screening (US) | Roles at insured institutions | Section 19 of the Federal Deposit Insurance Act |
| Accommodation needed for screening | No | Email accommodations@bank.example or tell the recruiter |

## 5. Declarations and signatures

I consent to the checks listed above. I confirm that the information I have given is complete and accurate, and I understand that a material false statement or omission can lead to withdrawal of the offer or, after I start, discipline. Medical information is never part of screening. Signature and date: ____________.

## 6. What happens next

HR Operations orders the checks and records the results separately from your personnel file. If a result may lead to withdrawal of the offer, an individualized assessment is made within 3 business days, you receive a pre-adverse action notice with a copy of the report, and you have 5 business days to respond or correct errors. The final decision is made by the VP HR Operations or delegate. Results are kept for 7 years if you are hired and 12 months if not (HR-REF-002 Employee Records Retention Schedule). You may ask to see your information under HR-POL-016 Employee Data Privacy Policy.

## 7. Related documents

- HR-POL-020 Pre-Employment Screening Policy
- HR-POL-016 Employee Data Privacy Policy
- HR-POL-018 Workplace Accommodation and Accessibility Policy

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-09-01 | Added the 5-business-day response window and re-screening consent. |
| 1.0 | 2023-05-01 | Initial form. |
