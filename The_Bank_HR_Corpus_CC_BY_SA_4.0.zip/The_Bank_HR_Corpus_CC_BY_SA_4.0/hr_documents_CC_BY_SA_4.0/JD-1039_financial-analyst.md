# Financial Analyst

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1039 |
| Title | Financial Analyst |
| Document type | Job description |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-07-08 |
| Next review | 2027-07-08 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-POL-002, HR-POL-018, HR-POL-038 |

## 1. Role summary

The Financial Analyst supports the Finance team in Corporate Functions with budgeting, forecasting, month-end reporting and business-unit performance analysis. The analyst turns ledger data into clear variance explanations that business leaders use to manage costs and revenue. The role is Band 3 (Professional): it applies professional knowledge and works independently on assigned business units. See HR-GDE-006 Job Architecture and Pay Bands Guide.

## 2. Key responsibilities

- Prepare monthly management reports and variance analysis for assigned business units, with commentary within the close calendar.
- Build and update annual budget and quarterly forecast models.
- Reconcile general ledger accounts and investigate unexplained balances.
- Partner with business-unit managers to explain drivers of spend and revenue.
- Support the monthly and year-end close, including accruals and journal entry preparation with documented support.
- Track headcount and expense data and reconcile to payroll and HR reporting.
- Review business travel and expense data for policy compliance with HR-POL-038 Business Travel and Expense Policy.
- Respond to internal and external audit requests with complete, well-organized evidence.
- Identify opportunities to automate recurring reports.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in finance, accounting, economics or business.
- Two to five years of experience in financial analysis, accounting or FP&A.
- Strong spreadsheet and financial modelling skills.
- Accurate, timely work under month-end deadlines.

### 3.2 Preferred

- Progress toward a CPA or CFA designation; registration and exam fees are reimbursed, with 5 paid study days per exam (HR-POL-012 Learning and Development Policy, FORM-HR-061).
- Experience with an enterprise planning tool or a business-intelligence tool.

### 3.3 Licences, screening and conduct

No licence is required. The role has no lending authority. The standard Code of Conduct attestation applies (HR-POL-001 Code of Conduct and Ethics).

## 4. Competencies

Competency names follow HR-FWK-001 Competency and Leadership Model (Practitioner level, Bands 3 to 4).

- Judgement and Decision Quality
- Drive for Results
- Collaboration
- Customer Obsession
- Risk and Conduct Awareness

## 5. Compensation and classification

| Item | Detail |
| --- | --- |
| Band | 3 (Professional) |
| Canada range | $56,000 to $84,000 CAD per year |
| US range | $55,000 to $82,000 USD per year |
| Incentive target | 5% of base salary (Annual Incentive Plan) |
| Overtime eligibility, Canada | Yes (non-managerial) |
| FLSA classification, US | Exempt |
| Work arrangement | Hybrid |

## 6. Working conditions and accessibility

Office-based and hybrid by default: at least 3 days a week in the office, with Tuesday and Thursday as anchor days (HR-POL-002 Remote and Hybrid Work Policy). Month-end close weeks may involve longer days; Canadian employees in this role are overtime-eligible and must have overtime pre-approved in Time Tracker (HR-POL-003 Working Hours and Overtime Policy). The Bank provides accommodation to the point of undue hardship (HR-POL-018 Workplace Accommodation and Accessibility Policy).

## 7. Reporting line

Reports to the Senior Manager, Finance. The role has no direct reports.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-03-01 | Pay band and incentive target aligned with the 2026 pay bands |
| 1.0 | 2025-01-01 | First issue |
