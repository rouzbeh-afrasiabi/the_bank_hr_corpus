# California Supplement

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-SUP-002 |
| Title | California Supplement |
| Document type | Supplement |
| Version | 2.1 |
| Status | Current |
| Effective date | 2025-07-01 |
| Last reviewed | 2026-08-04 |
| Next review | 2027-08-04 |
| Policy owner | VP Employee Relations |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | Employees |
| Jurisdiction | California |
| Language | English |
| Related documents | HR-POL-003, HR-POL-007, HR-POL-009, HR-POL-015, HR-POL-016, HR-POL-037, HR-POL-038 |

## 1. Purpose

This supplement sets out the rules that apply to employees who work in California and that differ from the Bank's standard US rules. It works together with the base policies and does not repeat them in full. Where this supplement and a base policy differ, the supplement applies to California employees. Where applicable law gives a greater right, the law applies.

## 2. Scope

The supplement applies to all employees whose work location is in California, whether they work in a branch, an office or from home. A remote employee who lives in California is covered even if the manager is in another state. Contractors and agency workers are not covered (see HR-POL-014 Employment Status and Classification Policy).

## 3. Overtime and daily hours

California applies a daily overtime rule in addition to the weekly rule. It applies to non-exempt employees. Exempt employees record absences only (see HR-POL-003 Working Hours and Overtime Policy).

| Hours worked | Pay rate |
| --- | --- |
| Up to 8 hours in a day | Regular rate |
| Over 8 hours and up to 12 hours in a day | 1.5x |
| Over 12 hours in a day | 2x |
| Over 40 hours in a week (hours not already paid at a daily premium) | 1.5x |

**Example.** An employee paid $30 an hour works Monday 10 hours, Tuesday 8, Wednesday 13, Thursday 8 and Friday 8, a total of 47 hours. Daily overtime at 1.5x is 2 hours on Monday and 4 hours on Wednesday (6 hours); the 1 hour on Wednesday beyond 12 is paid at 2x. The remaining 40 hours are paid at the regular rate. Pay: 40 x $30 = $1,200, plus 6 x $45 = $270, plus 1 x $60 = $60, for $1,530.

Overtime is paid in cash. Compensatory time off is not available in the US. Overtime must be pre-approved in Time Tracker, and more than 8 overtime hours in a week needs Director approval and HR notification. Scheduling beyond 12 hours a day or 48 hours a week needs VP approval and the employee's written consent.

## 4. Meal periods and rest breaks

| Item | California rule |
| --- | --- |
| Meal period | 30 minutes, taken before the end of the 5th hour of work |
| Rest break | A paid 10-minute break for every 4 hours worked, or major fraction of 4 hours |

The standard 60-minute meal period may be shortened to 30 minutes with the manager's agreement. Employees record the start and end of every meal period in Time Tracker. Managers do not discourage, interrupt or schedule work over breaks. An employee whose meal period or rest break was missed, late or interrupted tells the manager the same day, or contacts HR Connect, and Payroll Services corrects the pay record as California law requires. The non-California rule of two paid 15-minute breaks per full shift does not apply in California.

## 5. Sick leave

The Bank's paid sick leave of 8 days per calendar year for US employees satisfies the California sick leave requirement, and the more generous rule applies where the law gives more (see HR-POL-007 Sick Leave and Personal Leave Policy). Sick days are credited on 1 January, are pro-rated for new hires and are available from the start date. They may be used for the employee's own illness, medical appointments and family care (up to 5 of the days). Personal days (3 per calendar year) are separate. Retaliation for using sick leave is prohibited.

## 6. Pay timing, wage statements and final pay

### 6.1 Regular pay and wage statements

US employees are paid biweekly on Fridays, in arrears (see HR-POL-009 Compensation and Payroll Policy). Pay statements are posted in MyHR 2 business days before the pay date and show gross and net pay, hours worked and rates for non-exempt employees, deductions and the pay period. An employee who finds an error uses FORM-HR-021 in the HR Case Portal. Underpayments of $250 or more (net) are paid off-cycle within 3 business days of confirmation.

### 6.2 Final pay

| Situation | Final pay deadline |
| --- | --- |
| Termination by the Bank | Immediately, on the last day of employment |
| Resignation without notice | Within 72 hours of the resignation |
| Resignation with notice | On the last day of employment |

Final pay includes earned, unused vacation (see HR-POL-006 Vacation and Paid Time Off Policy and HR-POL-015 Resignation and Offboarding Policy). Payroll Services issues an off-cycle payment where the deadline falls before the payroll cut-off.

### 6.3 Deductions and overpayments

The Bank makes deductions from pay only as the law permits. Where California law requires written consent for a deduction, such as repayment of an overpayment or a vacation advance, Payroll Services obtains it first.

## 7. Expense reimbursement

The Bank reimburses necessary business expenses. Employees submit them under HR-POL-038 Business Travel and Expense Policy: within 30 days of the expense, with receipts for any expense over $25, and the reimbursement is paid within 7 business days by direct deposit. The statement in HR-POL-002 Remote and Hybrid Work Policy that the Bank does not pay ongoing internet or phone costs does not limit any reimbursement that California law requires. A California employee who believes a work expense should be reimbursed raises it with the manager or HR Connect.

## 8. Privacy notice and rights

California employees, former employees and applicants have the privacy rights given by the California Consumer Privacy Act and the California Privacy Rights Act. These include knowing what personal information the Bank collects and why, asking to see it, asking for correction of inaccurate information and, where the law applies, asking for deletion or limits on the use of sensitive information. The Bank does not sell employee personal information and does not use it for marketing.

Requests are made on FORM-HR-090 Personal Information Access Request or to privacy@bank.example. The Privacy Office responds within 30 days, extendable by up to a further 30 days with written notice (see HR-POL-016 Employee Data Privacy Policy). The Bank does not retaliate against anyone for making a request.

## 9. Pay transparency

The pay range for the role appears in every job posting, employees may discuss and disclose their pay, and the Bank does not ask candidates for salary history (see HR-POL-037 Pay Transparency Policy).

## 10. Other rules that stay the same

Holidays (11 for US employees), shift premium ($2.00 USD per hour between 18:00 and 06:00 in Technology and Operations and branches with extended hours), on-call allowance ($150 USD per week, call-out minimum 3 hours' pay), health and safety and parental leave follow the base policies. Paid parental leave (12 weeks at 100% of base salary) runs concurrently with federal and state leave programs (see HR-POL-008 Parental and Family Leave Policy).

## 11. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Employee | Records time and meal periods accurately, reports missed breaks and pay errors promptly |
| Manager | Schedules breaks, approves overtime in advance, never pressures an employee to work through a break |
| Payroll Services | Applies daily overtime, corrects missed-break pay, meets final pay deadlines, obtains written consent for deductions |
| Privacy Office | Handles California privacy requests |
| HR Operations | Maintains California records and posters |
| VP Employee Relations | Owns this supplement |

## 12. Contacts

HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time, hrconnect@bank.example. Manager Hotline: 1-800-555-0143. Privacy Office: privacy@bank.example. Speak-Up Line: 1-800-555-0177 (24 hours, 7 days, anonymous option).

## 13. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2024-07-01 | Added the pay transparency section and the expense reimbursement section |
| 2.1 | 2025-07-01 | Aligned the overtime approval threshold with HR-POL-003 version 4.2 (8 hours a week) and updated the privacy notice section |
