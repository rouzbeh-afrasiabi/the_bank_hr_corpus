# Professional Designation Reimbursement Request

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-061 |
| Title | Professional Designation Reimbursement Request |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-11-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | SVP Talent and Learning |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-012, HR-POL-006, HR-POL-029, FORM-HR-060 |

## 1. Purpose and when to use this form

Use this form for a recognized professional designation such as CFA, CPA, CFP, PMP or CISSP. The Bank reimburses 100% of registration and exam fees on approval, pays annual membership fees for designations your role requires, and gives 5 paid study days per designation exam. For a regulatory licence needed for your role, use FORM-HR-123 instead.

## 2. Who completes it and who approves

You complete it. Your manager approves; the HRBP reviews exceptions. The SVP Talent and Learning decides repayment questions.

## 3. Where and when to submit

Submit in MyHR **before you register**. Request study days in MyHR as study leave, approved by your manager at least 10 business days before the first study day, or less where the exam date was set later.

## 4. Form fields

| Field | Required | Notes |
| --- | --- | --- |
| Designation and level or exam | Yes | |
| Awarding body | Yes | |
| Registration, exam and membership fees | Yes | Attach the fee schedule |
| Exam date(s) | Yes | |
| Study days requested | Yes | 5 per designation exam |
| Role requirement | Yes | Say whether the role requires the designation |
| Manager support | Yes | Pre-filled when approved |

## 5. Declarations and signatures

- The information is accurate and receipts will be genuine.
- I understand designation fees are not repayable unless I have not completed the exam and resign within 12 months of reimbursement; the SVP Talent and Learning decides.
- I understand study days are not deducted from vacation, sick or personal days and cannot be carried forward or paid out.

## 6. What happens next

Payroll Services reimburses approved fees on a regular pay date after approval. Designation fees do not count against the tuition cap ($5,000 CAD / $5,250 USD per fiscal year) or the $2,000 professional development budget. Keep your exam results. Where applicable law gives a greater right, the law applies. Questions: HR Connect, 1-800-555-0142.

## 7. Related documents

- HR-POL-012 Learning and Development Policy
- HR-POL-006 Vacation and Paid Time Off Policy
- HR-POL-029 Licensing, Registration and Qualification Policy

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-11-01 | Added study-day request steps and repayment wording (HR-POL-012 version 3.2). |
