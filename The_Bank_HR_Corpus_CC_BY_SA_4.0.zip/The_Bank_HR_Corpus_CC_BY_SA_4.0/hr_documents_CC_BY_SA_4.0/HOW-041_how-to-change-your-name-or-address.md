# How to change your name or address

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-041 |
| Title | How to change your name or address |
| Document type | How-to article |
| Version | 1.0 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-09-28 |
| Next review | 2027-09-28 |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-009, FORM-HR-022, HR-POL-002 |

## 1. Short answer

Update your name or address yourself in MyHR > Personal Information and submit FORM-HR-022 Direct Deposit and Tax Withholding Update; Payroll Services processes it for the next pay date if you submit it by the payroll cut-off. No manager approval is needed.

## 2. Who this applies to

All employees in Canada and the US. Employees who move to another province or state also update their tax forms. Remote employees who move must have approval at least 30 days before the move (see HR-POL-002 Remote and Hybrid Work Policy).

## 3. Steps

1. Sign in to MyHR and select Personal Information.
2. Select Name or Address and enter the new details.
3. Open FORM-HR-022 and choose the update type: Name or Address.
4. For a name change, upload a supporting document showing your new legal name.
5. If your move changes your tax situation, choose Tax withholding too and upload the new forms: in Canada the federal and provincial personal tax credit return forms; in the US Form W-4 and the state withholding form.
6. Check the effective pay date that MyHR shows after the cut-off check, then submit.
7. While in Personal Information, confirm your emergency contacts are still correct.

## 4. Deadlines

Payroll cut-off: 17:00 Eastern Time, five business days before the pay date. A change received later is processed on the next pay date. Example: for the Canada pay date of 5 March 2026, the cut-off was 17:00 Eastern Time on 26 February 2026. Pay statements appear in MyHR 2 business days before each pay date.

## 5. What happens next

Payroll Services verifies the request and may confirm it with you through MyHR before processing. The new name or address appears on your next eligible pay statement. Your tax slips (T4 and Relevé 1 by 28 February; W-2 by 31 January) are issued from the address on file, and employees who have left receive their slips at that address too. Quebec employees receive HR documents in French by default or on request.

## 6. Common mistakes

- Submitting after the cut-off and expecting the change on the next pay date.
- Changing the address but not the tax withholding forms after moving province or state.
- Forgetting the supporting document for a name change.
- Leaving an old address in MyHR after leaving the Bank, so the slips are lost.
- Using FORM-HR-022 to report a payment sent to the wrong account: raise a P1 case in MyHR > HR Case Portal with FORM-HR-021.

## 7. Who to call

HR Connect, 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time, hrconnect@bank.example, or live chat in MyHR. Payroll Services handles the change as a Tier 2 specialist team.

## 8. Related documents

- HR-POL-009 Compensation and Payroll Policy
- FORM-HR-022 Direct Deposit and Tax Withholding Update
- HR-POL-002 Remote and Hybrid Work Policy

## 9. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.0 | 2026-03-01 | First edition, aligned with HR-POL-009 version 7.2. |
