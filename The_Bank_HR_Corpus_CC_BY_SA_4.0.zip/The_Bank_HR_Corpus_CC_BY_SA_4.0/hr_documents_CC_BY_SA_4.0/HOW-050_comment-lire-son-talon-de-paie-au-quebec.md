# Comment lire son talon de paie au Québec

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

> **Document synthétique.** Contenu fictif produit pour des essais de recherche et de questions-réponses. Il ne constitue pas la politique d'une organisation réelle.

| Field | Value |
| --- | --- |
| Document ID | HOW-050 |
| Title | Comment lire son talon de paie au Québec |
| Document type | How-to article |
| Version | 1.0 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-09-28 |
| Next review | 2027-09-28 |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Quebec |
| Language | French |
| Related documents | HR-SUP-001, HR-POL-009, FORM-HR-021, FORM-HR-022 |

## 1. Réponse courte

Ouvrez MyHR > Paie > Talons de paie : votre talon est affiché 2 jours ouvrables avant la date de paie, un jeudi sur deux. Lisez-le dans l'ordre (période, revenus, retenues, paie nette, cumul de l'année) et signalez toute erreur avec FORM-HR-021 dans MyHR > Portail des cas RH.

## 2. À qui s'adresse cet article

À tous les employés de la Banque travaillant au Québec. La paie est versée toutes les 2 semaines, à terme échu (26 dates de paie par année), uniquement par dépôt direct. Vos documents de paie sont en français par défaut ou sur demande.

## 3. Étapes

1. Ouvrez MyHR > Paie > Talons de paie et choisissez la date de paie.
2. Vérifiez la période : elle se termine le samedi précédant la date de paie. Exemple : pour la paie du jeudi 29 octobre 2026, la période a pris fin le samedi 24 octobre 2026 et le talon était affiché au plus tard le mardi 27 octobre.
3. Lisez les revenus : salaire de base, heures supplémentaires (1,5 fois le taux normal après 40 heures par semaine, sans règle quotidienne au Québec), prime de quart de 2,00 $ l'heure entre 18 h et 6 h, indemnité de disponibilité de 200 $ par semaine, le cas échéant.
4. Lisez les retenues, dans l'ordre : d'abord les retenues obligatoires (impôt fédéral et provincial, Régime de rentes du Québec, Régime québécois d'assurance parentale et autres cotisations prévues par la loi), puis les primes d'avantages sociaux (HR-GDE-001), les cotisations d'épargne et de retraite (HR-GDE-002) et les dons facultatifs.
5. Repérez la paie nette, déposée dans le compte inscrit sur FORM-HR-022, puis le cumul de l'année, qui sert à vérifier votre Relevé 1.
6. Si un montant vous semble erroné, joignez le talon, vos entrées dans Time Tracker et le message d'approbation à FORM-HR-021.

## 4. Échéances

| Élément | Échéance |
| --- | --- |
| Talon dans MyHR | 2 jours ouvrables avant la date de paie |
| Changement de compte bancaire ou de formulaires fiscaux | 17 h (heure de l'Est), cinq jours ouvrables avant la date de paie (paie du 29 octobre 2026 : jeudi 22 octobre) |
| Sous-paiement net de 250 $ ou plus | Versé hors cycle dans les 3 jours ouvrables suivant la confirmation |
| Sous-paiement net de moins de 250 $ | Corrigé à la prochaine date de paie régulière |
| Relevé 1 et T4 | Au plus tard le 28 février |

Les corrections rétroactives remontent jusqu'à 24 mois. Une paie manquante est un cas urgent (P1) : première réponse dans les 4 heures ouvrables.

## 5. Et ensuite

Les Services de paie confirment l'erreur, puis la corrigent selon les montants ci-dessus. En cas de trop-payé, vous recevez un avis écrit et pouvez rembourser en une somme forfaitaire, par retenue d'au plus 15 % de la paie nette par période, ou selon un plan d'au plus 12 mois. Gardez votre adresse à jour pour vos feuillets fiscaux (voir HOW-041).

## 6. Erreurs fréquentes

- Ne pas vérifier le talon avant la date de paie, ou confondre salaire brut et paie nette.
- Modifier le compte bancaire après l'échéance et croire que le changement s'applique tout de suite.
- Attendre la fin de l'année pour signaler une erreur.

## 7. Personnes-ressources

RH Connect : 1-800-555-0142, du lundi au vendredi, de 8 h à 20 h (heure de l'Est), hrconnect@bank.example, clavardage dans MyHR, en français ou en anglais. Paie manquante : MyHR > Portail des cas RH.

## 8. Documents connexes

- HR-SUP-001 Supplément pour le Québec
- HR-POL-009 Compensation and Payroll Policy
- FORM-HR-021 Payroll Correction Request

## 9. Historique des modifications

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.0 | 2026-03-01 | Première version, conforme à HR-POL-009 version 7.2. |
