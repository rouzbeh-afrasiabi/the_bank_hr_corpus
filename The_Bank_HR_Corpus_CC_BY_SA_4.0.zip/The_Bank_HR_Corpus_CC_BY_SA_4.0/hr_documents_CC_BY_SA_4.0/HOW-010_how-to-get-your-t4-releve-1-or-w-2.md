# How to get your T4, Relevé 1 or W-2

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-010 |
| Title | How to get your T4, Relevé 1 or W-2 |
| Document type | How-to article |
| Version | 1.2 |
| Status | Current |
| Effective date | 2025-12-01 |
| Last reviewed | 2026-09-28 |
| Next review | 2027-09-28 |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-009, HR-POL-015, FORM-HR-022, FORM-HR-021 |

## 1. The short answer

Your tax slip is published in MyHR under Pay, Tax Slips: the T4 and Relevé 1 (Canada) by 28 February and the W-2 (US) by 31 January.

## 2. Who this applies to

| Slip | Who receives it | Deadline |
| --- | --- | --- |
| T4 | Employees in Canada, all provinces and territories | 28 February |
| Relevé 1 | Employees in Quebec, in addition to the T4 | 28 February |
| W-2 | Employees in the US | 31 January |

Former employees are included. Quebec employees may receive documents in French by default or on request. For the 2026 tax year, the slips are due by 31 January 2027 (W-2) and 28 February 2027 (T4 and Relevé 1).

## 3. Steps

1. Sign in to MyHR and select **MyHR > Pay > Tax Slips**.
2. Choose the tax year and the slip type.
3. Open or download the PDF and check your name, address, identification number and year-to-date amounts against your December pay statement (see HOW-007).
4. If you changed address during the year, confirm it under **MyHR > Personal Information > Address**; use FORM-HR-022 Direct Deposit and Tax Withholding Update to change it (see HOW-041).
5. If anything is wrong, raise a case in **MyHR > HR Case Portal > New case** (category Pay) with FORM-HR-021 Payroll Correction Request and explain the difference.

## 4. If you have left the Bank

Your MyHR access for pay statements and tax slips remains for 24 months after your last day. Slips are also sent to the mailing address on file, so keep it current by contacting HR Connect or using the MyHR former-employee page. This is the most common reason a former employee does not receive a slip.

## 5. What happens next

Payroll Services reconciles year-to-date amounts, corrects them where needed and publishes the slips. A correction that changes a slip is flagged for year-end, and a corrected slip is published in MyHR. Retroactive pay corrections go back up to 24 months (see HR-POL-009 Compensation and Payroll Policy).

## 6. Common mistakes

- Looking before the deadline: the slip may appear any time up to 31 January or 28 February.
- Not updating your address before year-end.
- Waiting for the paper copy; the MyHR copy is available first.
- Mixing up the Relevé 1 (Quebec provincial slip) with the T4 (federal); Quebec employees need both for their returns.

## 7. Who to call

HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, or live chat in MyHR; English and French. Payroll Services is the Tier 2 team behind HR Connect.

## 8. Related documents

- HR-POL-009 Compensation and Payroll Policy
- HR-POL-015 Resignation and Offboarding Policy
- FORM-HR-022 Direct Deposit and Tax Withholding Update
- FORM-HR-021 Payroll Correction Request

## 9. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.2 | 2025-12-01 | Added former-employee access (24 months) and the Quebec Relevé 1 note. |
| 1.0 | 2025-01-20 | First edition. |
