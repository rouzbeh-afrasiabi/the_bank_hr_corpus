# Customer Service Representative I

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1002 |
| Title | Customer Service Representative I |
| Document type | Job description |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-08-18 |
| Next review | 2027-08-18 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-POL-003, HR-POL-033, HR-POL-018 |

## 1. Role summary

The Customer Service Representative I (CSR I) answers inbound calls and chats from retail customers in the contact centre and resolves routine requests on the first contact. The role covers account enquiries, card and online banking support, password and security resets, and simple service requests. Calls are handled using scripts, knowledge articles and set verification steps, with coaching from the Team Lead. This is a Band 1 (Associate Support) role in the Retail Banking family; see HR-GDE-006 Job Architecture and Pay Bands Guide.

## 2. Key responsibilities

- Answer inbound calls, chats and secure messages from retail customers within service-level targets.
- Authenticate every caller using the required verification steps before discussing or changing an account.
- Resolve balance, transaction, statement, card activation and online banking enquiries on first contact.
- Report lost or stolen cards and initiate replacements and temporary blocks.
- Recognize signs of fraud or scams, and transfer the customer to the fraud team using the documented procedure.
- Log every interaction accurately in the customer relationship system with clear notes.
- Escalate complaints and complex enquiries to the Customer Service Representative II team or the Team Lead.
- Offer digital self-service tools where they suit the customer.
- Meet quality-monitoring, handle-time and customer satisfaction targets set by the Team Lead.
- Complete mandatory training and product refreshers in the Learning Hub.

## 3. Qualifications

### 3.1 Required

- High school diploma or equivalent.
- Clear, courteous telephone and written communication.
- Keyboarding accuracy and comfort moving between several applications while speaking with a customer.
- Ability to work a posted schedule including evenings and some weekends.
- Satisfactory results in pre-employment screening.

### 3.2 Preferred

- Six months or more of contact-centre, retail or hospitality customer service experience.
- Fluency in English and French.
- Post-secondary coursework in business, communications or finance.

### 3.3 Licences and certifications

None required. Calls on Bank telephone lines are recorded and monitored for quality and compliance, as disclosed in HR-POL-033 Electronic Monitoring and Right to Disconnect Policy.

## 4. Competencies

Competencies are defined in HR-FWK-001 Competency and Leadership Model; this role works at the Foundation level.

- **Customer Obsession**: listens first and resolves the customer's issue, not just the question.
- **Risk and Conduct Awareness**: verifies identity every time and escalates suspected fraud.
- **Drive for Results**: meets first-contact resolution and quality goals.
- **Adaptability**: handles varied call types and frequent updates to products and procedures.
- **Collaboration**: shares knowledge and hands customers over cleanly to specialist teams.

## 5. Compensation and classification

| Item | Detail |
| --- | --- |
| Band | 1 (Associate Support) |
| Canada salary range | $38,000 to $54,000 CAD per year |
| US salary range | $36,000 to $52,000 USD per year |
| Incentive target | Annual Incentive Plan (AIP): 5% of base salary |
| Overtime eligibility (Canada) | Yes (non-managerial Band 1 to 4 role) |
| FLSA classification (US) | Non-exempt |
| Work arrangement | On-site at the contact centre |

## 6. Working conditions and accessibility

This is an on-site role in the contact centre. Work is done at a workstation with a headset for most of the shift, to a posted schedule. A shift premium may apply for hours worked between 18:00 and 06:00, and overtime follows HR-POL-003 Working Hours and Overtime Policy. Business continuity arrangements for the contact centre are in HR-POL-044 Business Continuity and Severe Weather Policy. The Bank provides accommodation to the point of undue hardship (Canada) or reasonable accommodation (US); see HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to the Team Lead, Contact Centre.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-03-01 | Pay ranges updated to the 2026 pay bands; added call-monitoring disclosure |
| 1.0 | 2024-04-01 | First issue |
