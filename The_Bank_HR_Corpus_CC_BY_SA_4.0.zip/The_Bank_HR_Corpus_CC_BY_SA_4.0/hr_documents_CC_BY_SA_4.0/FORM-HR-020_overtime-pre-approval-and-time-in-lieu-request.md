# Overtime Pre-Approval and Time-in-Lieu Request

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-020 |
| Title | Overtime Pre-Approval and Time-in-Lieu Request |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-003, HR-POL-009, HR-POL-021 |

## 1. Purpose and when to use this form

Use this form for planned or recurring overtime, and to ask for overtime to be banked as time in lieu (Canada only). One-off overtime is pre-approved by your manager in Time Tracker. Emergency overtime is approved by your manager by the next business day. Only overtime-eligible employees (Canada Bands 1 to 4 non-managerial; US non-exempt) use it.

## 2. Who completes it and who approves

You complete it. Your manager approves. A Director must also approve when your overtime would exceed 8 hours in a week, and HR is notified. Scheduling beyond 12 hours a day or 48 hours a week needs VP approval and your written consent.

## 3. Where and when to submit

Submit in Time Tracker before the overtime is worked. Enter hours by Friday 17:00 local time; your manager approves by Monday 12:00 local time.

## 4. Form fields

| Field | Required | Notes |
| --- | --- | --- |
| Dates and expected hours | Yes | Planned or recurring pattern |
| Business reason | Yes | |
| Province or state | Yes | Sets the daily and weekly rules (for example British Columbia, Alberta, California) |
| Total overtime hours expected this week | Yes | Above 8 triggers Director approval |
| Payment choice | Canada only | Cash at 1.5x, or time in lieu |
| Time in lieu hours requested | Canada only | 1.5 hours banked per overtime hour |

## 5. Declarations and signatures

- I will record actual start, end and meal times.
- I have at least 8 hours of rest between shifts and 24 consecutive hours off each week.
- I understand time in lieu is capped at a 40-hour bank, must be taken within 3 months, and any unused balance is paid out at the overtime rate at expiry.
- I understand US non-exempt employees are paid overtime in cash; compensatory time is not available.

## 6. What happens next

Overtime is paid by Payroll Services at the applicable rate. Unapproved overtime is still paid, but repeated cases may be addressed under HR-POL-021 Employee Relations and Progressive Discipline Policy. Fix pay errors with FORM-HR-021. Where applicable law gives a greater right, the law applies.

## 7. Related documents

- HR-POL-003 Working Hours and Overtime Policy
- HR-POL-009 Compensation and Payroll Policy
- HR-POL-021 Employee Relations and Progressive Discipline Policy

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-09-01 | Director approval threshold lowered from 10 to 8 weekly overtime hours (HR-POL-003 version 4.2). |
