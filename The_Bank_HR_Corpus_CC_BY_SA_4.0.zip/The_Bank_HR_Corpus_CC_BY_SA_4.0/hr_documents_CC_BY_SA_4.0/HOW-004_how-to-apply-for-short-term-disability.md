# How to apply for short-term disability

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-004 |
| Title | How to apply for short-term disability |
| Document type | How-to article |
| Version | 1.1 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-09-15 |
| Next review | 2027-09-15 |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-007, HR-PLN-007, FORM-HR-011, HOW-002 |

## 1. The short answer

Apply to Maplewood Benefits through MyHR within 5 business days of going off work, and tell the Leaves team at the same time.

## 2. Who this applies to

Regular full-time, regular part-time and fixed-term employees in Canada, Quebec and the US. Short-term disability is employer-paid. It starts after 5 consecutive working days of absence, which sick days cover. Casual employees receive statutory sick leave only.

## 3. Steps

1. Report your absence to your manager each day as described in HOW-002.
2. Select **MyHR > Benefits > Disability Claim** and complete the Maplewood Benefits application within 5 business days of going off work.
3. Ask your treating provider to complete FORM-HR-011 Medical Certificate and Fitness-to-Work (functional limitations and expected duration, not diagnosis). Upload it through **MyHR > HR Case Portal** (case type Leave) within 5 business days of the request.
4. Notify the Leaves team in the same case so payroll and vacation records are updated.
5. Respond quickly if Maplewood Benefits asks for more information. Its claims line is 1-800-555-0190.

## 4. How you are paid

| Period | Pay |
| --- | --- |
| Days 1 to 5 (waiting period) | Sick days at 100% of base salary |
| Weeks 1 to 13 after the waiting period | 100% of base salary |
| Weeks 14 to 26 | 75% of base salary |
| Week 27 onward | Long-term disability: 66 2/3% of base salary, maximum $15,000 per month, to age 65 |

If your sick-day balance runs out before day 5, you may use vacation or personal days or take the remaining days unpaid. Vacation keeps accruing during short-term disability.

## 5. What happens next

Maplewood Benefits decides the claim; the Bank does not decide medical eligibility. Your manager sees only functional limitations and expected duration. When you are ready to return, a graduated return of up to 12 weeks can be arranged with the Accommodation Specialist, your manager and the Leaves team; you are paid for hours worked. US birth parents also receive short-term disability for medical recovery (up to 6 weeks vaginal, 8 weeks caesarean; see HR-POL-008 Parental and Family Leave Policy). If a claim is denied, you may appeal within 180 days (see HR-PLN-007 Benefits Claims and Appeals Guide).

## 6. Common mistakes

- Waiting until day 5 to apply, which misses the 5-business-day deadline.
- Sending medical details to your manager.
- Assuming the Bank approves the claim; Maplewood Benefits decides.
- Not telling the Leaves team, so pay and vacation records are wrong.

## 7. Who to call

Maplewood Benefits claims line: 1-800-555-0190. HR Connect (Leaves team): 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, or live chat in MyHR.

## 8. Related documents

- HR-POL-007 Sick Leave and Personal Leave Policy
- HR-PLN-007 Benefits Claims and Appeals Guide
- FORM-HR-011 Medical Certificate and Fitness-to-Work
- HOW-002 How to report an absence or a sick day

## 9. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.1 | 2026-01-01 | Sick-day references aligned with HR-POL-007 version 3.0. |
| 1.0 | 2025-02-03 | First edition. |
