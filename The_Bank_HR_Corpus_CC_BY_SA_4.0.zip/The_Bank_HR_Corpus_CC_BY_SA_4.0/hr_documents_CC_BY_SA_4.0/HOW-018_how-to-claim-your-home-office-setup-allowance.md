# How to claim your home office setup allowance

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-018 |
| Title | How to claim your home office setup allowance |
| Document type | How-to article |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-01-05 |
| Last reviewed | 2026-08-20 |
| Next review | 2027-08-20 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-002, FORM-HR-030, HR-POL-018, HR-POL-009 |

## 1. The short answer

Claim your allowance with receipts in MyHR > Pay > Allowances and Claims within 60 days of purchase; it is available once every 3 years.

## 2. Who this applies to

Employees in Canada (including Quebec) and the US with a Hybrid or Remote arrangement recorded on FORM-HR-030 (see HOW-016).

| Arrangement | Canada | US |
| --- | --- | --- |
| Hybrid | $300 CAD | $225 USD |
| Remote | $600 CAD | $450 USD |

The Bank also provides a laptop, a headset and, on request, one external monitor. These are not claimed through the allowance. Equipment you need because of a disability comes through the accommodation process (see HOW-019), not this allowance.

## 3. Steps

1. Confirm that your arrangement is recorded in MyHR > Personal Information > Work Arrangement.
2. Buy the items you need for your home workspace and keep the itemized receipts.
3. Go to MyHR > Pay > Allowances and Claims and select **Home office setup allowance**.
4. Enter the purchase date and amount, and attach the receipts.
5. Submit within 60 days of the purchase date.

## 4. Deadlines and what happens next

| Item | Rule |
| --- | --- |
| Claim deadline | 60 days from the purchase date |
| Frequency | Once every 3 years |
| Amount | Up to your arrangement's amount, shown above |

Your claim is reviewed in MyHR, where you can follow its status. If it needs more information, a note explains what is missing. Questions about how a reimbursement appears on your pay go to Payroll Services through HR Connect (see HR-POL-009 Compensation and Payroll Policy). If you work in Canada and need a signed form T2200 for tax purposes, see HOW-025.

## 5. Common mistakes

- Waiting more than 60 days after purchase. Late receipts are not accepted.
- Claiming again before 3 years have passed.
- Claiming without a recorded arrangement.
- Expecting the Bank to reimburse ongoing internet, phone, utility or rent costs. It does not.
- Claiming the Remote amount on a Hybrid arrangement.

## 6. Who to call

- HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, or live chat in MyHR.
- HR Operations, through MyHR > HR Case Portal, for arrangement records.

## 7. Related documents

- HR-POL-002 Remote and Hybrid Work Policy (section 9, the owning document)
- FORM-HR-030 Work Arrangement Request (Hybrid or Remote)
- HR-POL-018 Workplace Accommodation and Accessibility Policy

Where applicable law gives a greater right, the law applies.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-01-05 | Updated allowance amounts by arrangement under HR-POL-002 version 3.0. |
| 1.0 | 2025-01-01 | First version. |
