# Holiday Reminders for October to December 2026

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-MEMO-2026-008 |
| Title | Holiday Reminders for October to December 2026 |
| Document type | Memo |
| Version | 1.0 |
| Status | Current |
| Effective date | 2026-10-05 |
| Last reviewed | Not applicable |
| Next review | Not applicable |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-010, HR-POL-009, HR-POL-006 |

**Bank holidays and payroll timing for the last quarter of 2026.**

**From:** SVP Total Rewards

**To:** All employees in Canada and the US

**Date:** 5 October 2026

**Subject:** Holiday closures and US pay date changes, October to December 2026

## 1. What is changing

| Date | Holiday | Where |
| --- | --- | --- |
| Monday 12 October | Thanksgiving | Canada |
| Wednesday 11 November | Remembrance Day / Veterans Day | Canada and US |
| Thursday 26 November | Thanksgiving | US |
| Friday 27 November | Day after Thanksgiving | US |
| Friday 25 December | Christmas Day | Canada and US |
| Monday 28 December | Boxing Day (Saturday 26 December, observed) | Canada |

US pay dates move: the 27 November pay date is paid Wednesday 25 November, and the 25 December pay date is paid Thursday 24 December.

## 2. Who is affected

All employees in the countries shown. HR Connect is closed on Bank holidays.

## 3. Effective date

The dates above.

## 4. What to do

1. Plan coverage and time off with your manager; vacation over a holiday does not use a vacation day for the holiday.
2. If you work a holiday, you receive regular holiday pay plus 1.5x, or in Canada 1.5x time in lieu taken within 60 days (HR-POL-010).
3. Report any pay error in the HR Case Portal using FORM-HR-021.

## 5. Who to call

HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, or live chat in MyHR.

## 6. Related documents

- HR-POL-010 Statutory Holidays Policy
- HR-POL-009 Compensation and Payroll Policy
- HR-POL-006 Vacation and Paid Time Off Policy
