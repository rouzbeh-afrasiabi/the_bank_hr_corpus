# Foire aux questions pour les employés du Québec

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

> **Document synthétique.** Contenu fictif produit pour des essais de recherche et de questions-réponses. Il ne constitue pas la politique d'une organisation réelle.

| Field | Value |
| --- | --- |
| Document ID | HR-FAQ-002 |
| Title | Foire aux questions pour les employés du Québec |
| Document type | FAQ |
| Version | 2026.1 |
| Status | Current |
| Effective date | 2026-10-26 |
| Last reviewed | 2026-10-26 |
| Next review | 2027-10-26 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Quebec |
| Language | French |
| Related documents | HR-SUP-001, HR-FAQ-001, HR-POL-002, HR-POL-003, HR-POL-006, HR-POL-007, HR-POL-008, HR-POL-009, HR-POL-010, HR-POL-015, HR-POL-016, HR-GDE-001, HR-GDE-004, HR-REF-003 |

## 1. Objet et portée

Cette foire aux questions donne des réponses simples aux questions les plus fréquentes des employés qui travaillent au Québec. Chaque réponse nomme le document propriétaire de la règle; en cas de différence entre cette foire aux questions et ce document, le document propriétaire s'applique. Les règles propres au Québec sont résumées dans HR-SUP-001 Supplément pour le Québec, et les questions communes à tout le Canada et aux États-Unis se trouvent dans HR-FAQ-001 Employee HR FAQ. Lorsque la loi applicable accorde un droit plus grand, la loi s'applique. Si votre question n'est pas couverte, communiquez avec RH Connect au 1-800-555-0142 (service en français et en anglais).

## 2. Travail hybride et horaires

### Combien de jours par semaine dois-je être au bureau?

Les employés en mode hybride sont au bureau au moins 3 jours par semaine. Le mardi et le jeudi sont des jours d'ancrage, et l'équipe choisit le troisième jour. Cette règle s'applique depuis le 5 janvier 2026 (elle était de 2 jours auparavant). Votre gestionnaire peut approuver jusqu'à 12 jours d'exception par année civile; au-delà, il faut l'accord de votre partenaire d'affaires RH. Voir HR-POL-002 Remote and Hybrid Work Policy.

### Puis-je travailler de chez moi à temps plein?

Seulement si votre rôle est désigné admissible au télétravail et si vous êtes approuvé au moyen de FORM-HR-030. Vous devez avoir terminé la période de probation, avoir obtenu au dernier cycle la cote « Répond aux attentes » ou mieux, ne pas être visé par un plan d'amélioration du rendement et habiter dans un territoire figurant sur la liste approuvée. Un déménagement dans une autre province exige une approbation au moins 30 jours à l'avance. Les employés en télétravail se rendent sur place pour au plus 4 activités planifiées d'équipe ou de clients par année. Voir HR-POL-002 Remote and Hybrid Work Policy.

### Puis-je travailler temporairement d'un autre endroit?

Oui, au moyen de FORM-HR-031. Vous pouvez travailler d'ailleurs au Canada jusqu'à 20 jours ouvrables par année civile, avec une demande au moins 5 jours ouvrables à l'avance. Entre le Canada et les États-Unis, la limite est de 10 jours ouvrables par année civile, avec une demande au moins 10 jours ouvrables à l'avance. Tout autre pays exige l'approbation de la Mobilité mondiale et des Affaires juridiques au moins 30 jours à l'avance. Voir HR-POL-002 Remote and Hybrid Work Policy.

### Quelle est ma semaine normale de travail, et quelles sont mes pauses?

La semaine normale compte 37,5 heures (7,5 heures par jour, 5 jours), avec une période de repas non payée de 60 minutes; les heures de présence de base sont de 10 h à 15 h pour le personnel de bureau. Une période de repas non payée de 30 minutes est prévue après au plus 5 heures consécutives, et vous avez deux pauses payées de 15 minutes par quart complet. Les horaires sont affichés au moins 14 jours à l'avance; un changement avec moins de 96 heures de préavis exige votre consentement, et vous pouvez refuser un quart ajouté avec moins de 24 heures de préavis. Voir HR-POL-003 Working Hours and Overtime Policy.

### À partir de quand les heures supplémentaires sont-elles payées au Québec?

Au Québec, les heures au-delà de 40 heures par semaine sont payées à 1,5 fois le taux normal; il n'y a aucune règle quotidienne. Les heures entre 37,5 et 40 par semaine sont payées au taux normal ou mises en banque 1 pour 1. Seuls les employés des bandes 1 à 4 dans des rôles non gestionnaires y ont droit. Les heures supplémentaires sont approuvées d'avance dans Time Tracker, et plus de 8 heures supplémentaires dans une semaine exigent l'approbation d'un directeur et un avis aux RH. Voir HR-POL-003 Working Hours and Overtime Policy et HR-SUP-001 Supplément pour le Québec.

### Puis-je prendre du temps de congé plutôt que d'être payé pour mes heures supplémentaires?

Oui, à votre demande et avec l'approbation de votre gestionnaire, au moyen de FORM-HR-020. Vous obtenez 1,5 heure de congé par heure supplémentaire. La banque est limitée à 40 heures et le temps doit être pris dans les 3 mois; le solde non utilisé est payé au taux des heures supplémentaires à l'échéance. Voir HR-POL-003 Working Hours and Overtime Policy.

### Que se passe-t-il lors d'une tempête de neige?

La fermeture est annoncée au plus tard à 6 h 30 (heure locale) par une alerte MyHR, un message texte et la bannière de l'intranet. Les employés en mode hybride ou en télétravail travaillent de la maison ce jour-là. Si votre succursale est fermée, vous êtes payé pour la journée. Voir HR-POL-004 Attendance and Absenteeism Policy.

## 3. Jours fériés

### Quels sont les jours fériés payés au Québec en 2026?

Il y en a 11 : le Jour de l'An (1er janvier), le Vendredi saint (3 avril), la Journée nationale des patriotes (18 mai), la Fête nationale du Québec (24 juin), la Fête du Canada (1er juillet), la Fête du Travail (7 septembre), la Journée nationale de la vérité et de la réconciliation (30 septembre), l'Action de grâce (12 octobre), le Jour du Souvenir (11 novembre), Noël (25 décembre) et le lendemain de Noël. Comme le 26 décembre 2026 tombe un samedi, ce dernier est observé le lundi 28 décembre. La Banque a choisi le Vendredi saint plutôt que le lundi de Pâques. Voir HR-POL-010 Statutory Holidays Policy et HR-SUP-001 Supplément pour le Québec.

### Pourquoi la fête de la Reine, la fête de la Famille et le congé civique ne figurent-ils pas à mon calendrier?

Le jour où les autres provinces célèbrent la fête de la Reine (Victoria Day), soit le 18 mai 2026, est la Journée nationale des patriotes au Québec; vous avez donc ce congé, sous un autre nom. La fête de la Famille (16 février 2026) et le congé civique d'août (3 août 2026) ne sont pas observés au Québec. En échange, vous avez la Fête nationale du 24 juin, qui n'existe pas ailleurs. Au total, le Québec compte 11 jours fériés de la Banque. Voir HR-POL-010 Statutory Holidays Policy.

### Que reçois-je si je dois travailler un jour férié?

Vous recevez votre paie de jour férié habituelle, plus 1,5 fois votre taux pour les heures travaillées, ou 1,5 fois le temps en congé compensatoire pris dans les 60 jours. Votre gestionnaire consigne votre choix avant le jour férié au moyen de FORM-HR-020. Les employés à temps partiel reçoivent la rémunération quotidienne moyenne des 20 derniers jours ouvrables. Voir HR-POL-010 Statutory Holidays Policy.

### Que se passe-t-il si un jour férié tombe pendant mes vacances ou si je suis absent la veille?

Un jour férié qui tombe pendant vos vacances n'est pas déduit de votre solde de vacances et prolonge votre congé. Vous perdez la paie du jour férié seulement si vous avez une absence non justifiée à la fois lors du jour de travail prévu qui précède et de celui qui suit le jour férié. Les vacances, un jour personnel approuvé et une maladie signalée à temps sont des absences justifiées. Voir HR-POL-010 Statutory Holidays Policy.

### Qu'est-ce que les jours flottants?

Ce sont 2 jours d'observance culturelle et religieuse par année civile, accordés comme ailleurs à la Banque. Vous donnez un préavis de 24 heures dans Time Tracker, sans avoir à fournir de raison. Les jours flottants ne se reportent pas à l'année suivante et n'ont aucune valeur en argent. Les nouveaux employés les reçoivent au prorata, arrondis à la demi-journée supérieure. Voir HR-POL-010 Statutory Holidays Policy.

## 4. Congés (vacances, maladie, parental)

### Combien de jours de vacances ai-je?

Votre droit dépend des années de service terminées au 1er janvier : 15 jours (moins de 3 ans), 20 jours (3 ans à moins de 10 ans), 25 jours (10 ans à moins de 20 ans) et 30 jours (20 ans ou plus). Les vacances s'accumulent chaque mois. Les nouveaux employés accumulent à partir de leur date d'entrée en fonction, au prorata et arrondi à la demi-journée supérieure; ils peuvent demander des vacances dès le premier jour et les prendre après 3 mois de service. Voir HR-POL-006 Vacation and Paid Time Off Policy.

### Puis-je reporter des vacances à l'année suivante?

Vous pouvez reporter jusqu'à 5 jours inutilisés, à prendre au plus tard le 31 mars. Les autres jours sont perdus, sauf si vous étiez en congé approuvé qui vous a empêché de les prendre ou si la loi exige qu'ils soient payés. Cette limite de 5 jours s'applique depuis le 1er janvier 2026 (elle était de 3 jours auparavant). Voir HR-POL-006 Vacation and Paid Time Off Policy.

### Comment demander mes vacances?

Faites la demande dans MyHR au moins 4 semaines à l'avance pour 5 jours ou plus, et au moins 5 jours ouvrables à l'avance pour moins de 5 jours. Votre gestionnaire répond dans les 5 jours ouvrables. Chaque employé doit aussi prendre au moins 10 jours ouvrables consécutifs de vacances une fois par année civile, à planifier dans MyHR au plus tard le 30 juin. Voir HR-POL-006 Vacation and Paid Time Off Policy.

### Combien de jours de maladie ai-je, et dois-je fournir une preuve?

Vous avez 10 jours de maladie payés par année civile, crédités le 1er janvier, dont jusqu'à 5 peuvent servir aux soins d'un proche; vous avez aussi 3 jours personnels, sans certificat. Au Québec, la Banque ne demande une preuve de l'absence qu'après 3 jours consécutifs (4e jour de travail consécutif dans les autres provinces). Le certificat indique les limitations fonctionnelles et la durée prévue, jamais le diagnostic, et il va à l'équipe des congés par MyHR, pas à votre gestionnaire. Signalez l'absence à votre gestionnaire avant le début de votre quart ou au plus tard 30 minutes après. Voir HR-POL-007 Sick Leave and Personal Leave Policy et HR-SUP-001 Supplément pour le Québec.

### Que se passe-t-il si je suis malade longtemps?

L'assurance invalidité de courte durée, payée par la Banque, commence après 5 jours ouvrables consécutifs d'absence : 100 % du salaire de base pendant les semaines 1 à 13, puis 75 % pendant les semaines 14 à 26. L'assurance invalidité de longue durée prend le relais à la semaine 27 et verse 66 2/3 % du salaire de base, jusqu'à un maximum de 15 000 $ par mois. Présentez votre demande à Maplewood Benefits par MyHR dans les 5 jours ouvrables suivant le début de l'absence; la décision revient à Maplewood Benefits. Voir HR-POL-007 Sick Leave and Personal Leave Policy.

### Comment fonctionne le congé de maternité, de paternité ou parental?

Au Québec, la prestation gouvernementale est versée par le Régime québécois d'assurance parentale (RQAP), et la Banque la coordonne de sorte que votre rémunération totale égale 100 % de votre salaire de base. Après 6 mois de service continu, le parent biologique reçoit ce complément pendant 17 semaines; le parent non biologique, adoptif ou d'intention en cas de gestation pour autrui, pendant 8 semaines. La Banque ne peut pas garantir la prestation du RQAP et vous remettez l'avis de prestation à l'équipe des congés dans les 5 jours ouvrables suivant sa réception. Donnez un préavis de 4 semaines au moyen de FORM-HR-012 lorsque c'est possible; le congé parental doit commencer dans les 78 semaines suivant la naissance ou le placement. Voir HR-POL-008 Parental and Family Leave Policy et HR-SUP-001 Supplément pour le Québec.

### Ai-je droit à un congé pour prendre soin d'un proche gravement malade?

Oui, ces congés sont non payés et protégés. Le congé de compassion est d'au plus 28 semaines; le congé pour maladie grave est d'au plus 37 semaines pour un enfant et de 17 semaines pour un adulte. Faites la demande au moyen de FORM-HR-013. Vous pouvez aussi utiliser jusqu'à 5 jours de maladie pour les soins d'un proche. Voir HR-POL-008 Parental and Family Leave Policy.

### Combien de jours ai-je lors d'un décès dans ma famille?

Vous avez 5 jours payés pour le décès d'un conjoint, d'un enfant, d'un parent ou d'un frère ou d'une sœur; 3 jours pour un grand-parent, un petit-enfant, un beau-parent ou un beau-frère ou une belle-sœur; et 1 jour pour une tante, un oncle, une nièce, un neveu ou un ami proche. Jusqu'à 3 jours non payés s'ajoutent pour le déplacement, soit 5 si le trajet dépasse 800 km aller simple. Voir HR-POL-026 Bereavement, Jury Duty and Other Leaves Policy.

## 5. Paie et incitatifs

### Quand suis-je payé?

Vous êtes payé toutes les deux semaines, à terme échu, le jeudi, par dépôt direct (26 dates de paie par année). Votre talon de paie est dans MyHR 2 jours ouvrables avant la date de paie. Les prochaines dates de paie de 2026 sont les 29 octobre, 12 novembre, 26 novembre, 10 décembre et 24 décembre. Les changements aux coordonnées bancaires et aux formulaires fiscaux doivent être saisis avant 17 h (heure de l'Est) cinq jours ouvrables avant la date de paie, au moyen de FORM-HR-022. Voir HR-POL-009 Compensation and Payroll Policy.

### Ma paie est incorrecte. Que faire?

Appelez RH Connect ou déposez FORM-HR-021 dans le portail des cas RH de MyHR. Une paie manquante est urgente (P1) et reçoit une première réponse dans les 4 heures ouvrables. Une insuffisance nette de 250 $ ou plus est payée hors cycle dans les 3 jours ouvrables suivant la confirmation; en dessous de 250 $, elle est corrigée à la prochaine date de paie régulière. En cas de trop-payé, vous pouvez rembourser en une somme forfaitaire, par une retenue d'au plus 15 % de votre paie nette par période, ou selon un plan d'au plus 12 mois. Voir HR-POL-009 Compensation and Payroll Policy.

### Quand ai-je une augmentation de salaire?

Les salaires sont révisés une fois par année, avec effet le 1er mars, en fonction de la cote de fin d'année. Les augmentations liées à une promotion sont traitées séparément. Voir HR-POL-009 Compensation and Payroll Policy.

### Comment fonctionne ma prime annuelle?

Le Régime incitatif annuel verse un pourcentage cible du salaire de base selon la bande : 5 % pour les bandes 1 à 3, 8 % pour la bande 4, 10 % pour la bande 5, 15 % pour la bande 6, 20 % pour la bande 7, 30 % pour la bande 8 et 45 % pour la bande 9. Le montant dépend du facteur de financement de l'entreprise (de 0 à 1,5) et de votre cote (multiplicateur de 1,5 pour « Exceptionnel » jusqu'à 0 pour « Insatisfaisant »). Il faut avoir été embauché au plus tard le 31 juillet de l'exercice et être sur la paie le 31 octobre et à la date de versement, soit la première date de paie de février. Un employé qui démissionne avant cette date perd la prime. Voir HR-POL-009 Compensation and Payroll Policy et HR-POL-015 Resignation and Offboarding Policy.

### Quelles retenues figurent sur ma paie, et quand reçois-je mon Relevé 1?

Les retenues légales comprennent l'impôt fédéral et provincial, le Régime de rentes du Québec et le Régime québécois d'assurance parentale; viennent ensuite les primes d'assurance, les cotisations d'épargne et les dons facultatifs. Le Relevé 1 (et le feuillet T4) est disponible dans MyHR au plus tard le 28 février. Mettez à jour votre nom, votre adresse ou votre retenue d'impôt dans MyHR au moyen de FORM-HR-022. Voir HR-POL-009 Compensation and Payroll Policy.

### Puis-je obtenir une avance sur salaire?

Les documents de la Banque ne couvrent pas les avances sur salaire. Ils prévoient seulement une avance de vacances d'au plus 5 jours avant l'accumulation, avec l'approbation du gestionnaire; elle est récupérée sur la paie finale si vous quittez la Banque. Pour toute autre situation, communiquez avec RH Connect au 1-800-555-0142 (français ou anglais). Voir HR-POL-006 Vacation and Paid Time Off Policy.

### Y a-t-il une prime de bilinguisme?

Les documents de la Banque ne couvrent pas une prime de bilinguisme ou de langue. Les seules primes qu'ils décrivent sont la prime de quart (2,00 $ CAD l'heure entre 18 h et 6 h) et l'allocation de disponibilité (200 $ CAD par semaine), prévues dans HR-POL-003 Working Hours and Overtime Policy. La rémunération est décrite dans HR-POL-009 Compensation and Payroll Policy. Pour une réponse sur ce sujet, communiquez avec RH Connect au 1-800-555-0142 (français ou anglais).

## 6. Avantages sociaux et retraite

### Quand puis-je m'inscrire à l'assurance collective, et combien coûte-t-elle?

Vous avez 31 jours après votre embauche ou un événement de vie admissible; sinon, l'inscription annuelle a lieu du 2 au 16 novembre 2026 pour une protection à compter du 1er janvier 2027. Faute de choix, vous recevez l'option Standard. Les primes mensuelles pour une personne seule sont de 0 $ (Essentiel), 22 $ (Standard) et 48 $ (Amélioré); pour la famille, elles sont de 65 $, 138 $ et 205 $. Voir HR-GDE-001 Employee Benefits Guide.

### Comment fonctionne l'assurance médicaments au Québec?

Les employés du Québec adhèrent au régime public d'assurance médicaments ou au régime de la Banque, selon ce que la loi exige. Dans le régime de la Banque, les médicaments sont remboursés à 70 % (Essentiel), 80 % (Standard) ou 90 % (Amélioré), et la substitution par un médicament générique est obligatoire (vous payez la différence si vous choisissez la marque). Maplewood Benefits administre les régimes. Voir HR-GDE-001 Employee Benefits Guide et HR-SUP-001 Supplément pour le Québec.

### Comment fonctionne le régime de retraite de la Banque?

Au Régime d'épargne et de retraite de la Banque, vous cotisez de 2 % à 10 % de votre salaire de base; sans choix de votre part, vous êtes inscrit automatiquement à 4 % à la première date de paie suivant 30 jours d'emploi, et vous pouvez vous retirer dans les 90 jours pour être remboursé. La Banque verse une cotisation de base de 2 % quoi que vous fassiez, plus une contribution égale à 100 % de vos cotisations sur les premiers 4 % (maximum de 6 % pour la Banque). Les droits sont acquis immédiatement, et les fonds sont immobilisés jusqu'à 55 ans. Pour obtenir de l'aide, appelez Evergreen Retirement Services au 1-800-555-0188. Voir HR-GDE-002 Retirement and Savings Plan Guide.

### Quel est le maximum que je peux cotiser à ma retraite ou à mon REER?

Les documents de la Banque ne précisent pas ces plafonds. Les plafonds légaux de cotisation sont fixés chaque année par les autorités fiscales, et HR-GDE-002 Retirement and Savings Plan Guide ne les indique pas. Appelez Evergreen Retirement Services au 1-800-555-0188 ou RH Connect au 1-800-555-0142 (français ou anglais).

### Où puis-je obtenir du soutien en santé mentale?

Le Programme de soutien Wellspring est gratuit et confidentiel, 24 heures sur 24, 7 jours sur 7, au 1-800-555-0166; il offre jusqu'à 8 séances de counseling par problème et par année civile pour vous et les membres de votre ménage. Le régime d'assurance couvre aussi les praticiens en santé mentale jusqu'à 1 500 $ (Essentiel), 2 500 $ (Standard) ou 4 000 $ (Amélioré) par année. Un compte de dépenses de bien-être de 500 $ CAD par année civile est aussi offert, avec des réclamations jusqu'au 31 mars de l'année suivante. Voir HR-GDE-001 Employee Benefits Guide.

## 7. Rendement et formation

### Quand ai-je ma cote de rendement, et quelles sont les dates clés?

L'année de rendement va du 1er novembre au 31 octobre, et votre cote vous est communiquée au plus tard le 15 janvier. L'échelle va de 1 (Exceptionnel) à 5 (Insatisfaisant), 3 correspondant à « Répond aux attentes ». Les objectifs sont fixés au plus tard le 15 décembre (dans les 30 jours pour les nouveaux employés), le bilan de mi-année a lieu du 1er mai au 15 juin, l'autoévaluation est due le 15 novembre et l'évaluation du gestionnaire le 10 décembre. Voir HR-POL-011 Performance Management Policy.

### Je ne suis pas d'accord avec ma cote. Que puis-je faire?

Écrivez à votre partenaire d'affaires RH dans les 10 jours ouvrables suivant l'annonce de votre cote. Le supérieur de votre gestionnaire et le partenaire d'affaires RH examinent la demande dans les 15 jours ouvrables, et leur décision est finale. Voir HR-POL-011 Performance Management Policy.

### Qu'est-ce qu'un plan d'amélioration du rendement?

C'est un plan écrit, sur FORM-HR-070, d'une durée standard de 60 jours (de 30 à 90 jours), avec un suivi chaque semaine. Il peut être déclenché par la cote « Doit s'améliorer » ou « Insatisfaisant », ou par un sous-rendement documenté après au moins une conversation de coaching. Vous pouvez être accompagné d'une personne de soutien qui n'est pas un conseiller juridique, et le plan peut être prolongé une fois d'au plus 30 jours. Voir HR-POL-013 Performance Improvement Policy.

### Que paie la Banque pour mes cours?

Vous disposez d'un budget de perfectionnement professionnel de 2 000 $ CAD par exercice. Le remboursement des frais de scolarité atteint 5 000 $ CAD par exercice après 6 mois de service, avec une dernière cote « Répond aux attentes » ou mieux. Faites approuver votre cours au moyen de FORM-HR-060 au moins 15 jours ouvrables à l'avance, et présentez votre réclamation dans les 60 jours suivant la fin du cours. Le remboursement est de 100 % pour 70 % ou plus (ou une réussite) et de 50 % pour 60 à 69 %; il faut rembourser la totalité si vous démissionnez dans les 12 mois suivant le dernier remboursement. Voir HR-POL-012 Learning and Development Policy.

## 8. Départ et fin d'emploi

### Quel préavis dois-je donner si je démissionne?

Le préavis est de 2 semaines pour les bandes 1 à 4, de 4 semaines pour les bandes 5 et 6 et de 8 semaines pour la bande 7 et plus. Remettez-le par écrit sur FORM-HR-080 à votre gestionnaire et aux Opérations RH, qui accusent réception dans les 2 jours ouvrables. Vous retournez votre équipement dans les 5 jours ouvrables suivant votre dernier jour, et votre accès prend fin à 17 h ce jour-là. Voir HR-POL-015 Resignation and Offboarding Policy.

### Quand reçois-je ma paie finale?

Au Québec, la paie finale est versée à la prochaine date de paie régulière, que vous démissionniez ou que la Banque mette fin à votre emploi. Elle comprend les vacances acquises et non prises. Les sommes que vous devez à la Banque, comme une avance de vacances ou un trop-payé, sont récupérées sur la paie finale dans la mesure où la loi le permet. Voir HR-POL-015 Resignation and Offboarding Policy et HR-SUP-001 Supplément pour le Québec.

### Que se passe-t-il avec mon relevé d'emploi, mon Relevé 1 et mes assurances?

Le relevé d'emploi est émis par voie électronique dans les 5 jours civils suivant la fin de la période de paie au cours de laquelle votre emploi prend fin, et le Relevé 1 est produit au plus tard le 28 février. Vos assurances prennent fin à la fin du mois, et vous avez 31 jours pour transformer l'assurance vie. Le Programme de soutien Wellspring reste accessible 30 jours après votre dernier jour, et votre accès à MyHR pour les talons de paie et les feuillets fiscaux se poursuit pendant 24 mois; tenez votre adresse à jour. Voir HR-POL-015 Resignation and Offboarding Policy.

### Que reçois-je si la Banque met fin à mon emploi sans motif?

Vous recevez le plus élevé entre le minimum prévu par la loi et la formule de la Banque : 2 semaines de salaire de base par année de service terminée, avec un minimum de 8 semaines et un maximum de 52 semaines. Vos assurances se poursuivent pendant la période de préavis. Une indemnité bonifiée exige la signature d'une quittance, avec 14 jours pour y réfléchir. Un soutien de réorientation de carrière est offert pendant 12 semaines (bandes 1 à 6) ou 26 semaines (bande 7 et plus). Voir HR-POL-025 Involuntary Termination and Severance Policy.

## 9. Vie privée, sécurité et accommodement

### Comment voir les renseignements que la Banque détient sur moi?

Déposez FORM-HR-090 ou écrivez à privacy@bank.example. Le Bureau de la protection de la vie privée vérifie votre identité et répond dans les 30 jours; ce délai peut être prolongé d'au plus 30 jours avec un avis écrit et les motifs. Il n'y a aucuns frais pour une demande courante. Voir HR-POL-016 Employee Data Privacy Policy.

### La Banque peut-elle transférer mes renseignements hors du Québec?

Seulement après une évaluation des facteurs relatifs à la vie privée (EFVP, ou PIA, FORM-HR-091), que le Bureau de la protection de la vie privée réalise avec le responsable du système et examine dans les 15 jours ouvrables. Cette exigence découle des règles du Québec, dont la Loi 25. Les dossiers des employés canadiens sont principalement conservés au Canada. Voir HR-POL-016 Employee Data Privacy Policy et HR-SUP-001 Supplément pour le Québec.

### La Banque vérifie-t-elle mon casier judiciaire?

Au Québec, la Banque ne tient compte d'un casier judiciaire que s'il est lié à l'emploi. Votre consentement est obtenu d'abord, avant toute vérification. Voir HR-POL-020 Pre-Employment Screening Policy et HR-SUP-001 Supplément pour le Québec.

### Puis-je recevoir mes documents et communications en français?

Oui. Les employés du Québec reçoivent les documents et les communications des Ressources humaines en français, par défaut ou sur demande, et une version anglaise est disponible. L'avis de collecte de renseignements personnels est remis en français et en anglais à l'embauche, et les communications sur la vie privée sont en français par défaut ou sur demande. RH Connect vous répond en français ou en anglais, avec interprète sur demande. Voir HR-SUP-001 Supplément pour le Québec et HR-POL-016 Employee Data Privacy Policy.

### Comment demander une mesure d'adaptation, et qui voit mes renseignements médicaux?

Parlez-en à votre gestionnaire, à RH Connect ou écrivez à accommodations@bank.example; il n'est pas nécessaire d'utiliser le mot « accommodement ». Les RH accusent réception dans les 2 jours ouvrables et décident dans les 10 jours ouvrables suivant la réception de l'information complète (3 jours ouvrables si c'est urgent). Vos renseignements médicaux sont conservés séparément de votre dossier du personnel, et votre gestionnaire ne reçoit que les limitations fonctionnelles et la durée prévue, jamais un diagnostic. Voir HR-POL-018 Workplace Accommodation and Accessibility Policy.

### J'ai cliqué sur un lien suspect ou perdu mon appareil. Que faire?

Utilisez immédiatement le bouton Signaler l'hameçonnage. Signalez tout incident soupçonné ou appareil perdu au Centre des opérations de sécurité (1-800-555-0155), tout de suite et au plus tard dans l'heure. Si des renseignements personnels sont en cause, avisez aussi le Bureau de la protection de la vie privée (privacy@bank.example) immédiatement et au plus tard 24 heures après la découverte. Voir HR-POL-017 IT Acceptable Use and Information Security Policy et HR-POL-016 Employee Data Privacy Policy.

## 10. Obtenir de l'aide

### Comment joindre les RH?

RH Connect répond au 1-800-555-0142 ou à hrconnect@bank.example, du lundi au vendredi, de 8 h à 20 h (heure de l'Est), et par clavardage dans MyHR aux mêmes heures. Le service est offert en français et en anglais, avec interprète sur demande, et le centre est fermé les jours fériés de la Banque. Voir HR-GDE-004 HR Service and Support Guide.

### En combien de temps les RH me répondent-elles, et que faire si le délai n'est pas respecté?

La première réponse est donnée dans les 4 heures ouvrables pour une demande urgente (P1), 1 jour ouvrable pour une demande prioritaire (P2), 2 jours ouvrables pour une demande standard (P3) et 3 jours ouvrables pour une demande d'information (P4). Si un délai n'est pas respecté, passez au gestionnaire des Opérations RH après un premier délai manqué, puis au vice-président des Opérations RH, puis au Bureau du chef des ressources humaines. Le Bureau de l'ombudsman (ombuds@bank.example) est toujours accessible. Voir HR-GDE-004 HR Service and Support Guide.

### Comment signaler du harcèlement ou de la violence?

Parlez à votre gestionnaire, à votre partenaire d'affaires RH ou aux Relations avec les employés, ou appelez la ligne Speak-Up au 1-800-555-0177, offerte 24 heures sur 24, 7 jours sur 7, avec option anonyme. En cas de violence, composez le 911, puis la Sécurité de l'entreprise au 1-800-555-0119. Les RH accusent réception dans les 2 jours ouvrables, et les représailles sont interdites. Voir HR-POL-005 Workplace Harassment and Violence Prevention Policy et HR-POL-022 Whistleblower and Speak-Up Policy.

## 11. Documents connexes et personnes-ressources

Les règles propres au Québec sont dans HR-SUP-001 Supplément pour le Québec; les tableaux par province sont dans HR-REF-003 Canada Jurisdiction Quick Reference; les questions communes à tout le Canada et aux États-Unis sont dans HR-FAQ-001 Employee HR FAQ. Pour toute question non couverte, communiquez avec RH Connect au 1-800-555-0142 ou à hrconnect@bank.example, du lundi au vendredi, de 8 h à 20 h (heure de l'Est), en français ou en anglais. Pour le soutien confidentiel, appelez le Programme de soutien Wellspring au 1-800-555-0166, 24 heures sur 24, 7 jours sur 7.

## 12. Historique des modifications

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2026.1 | 2026-10-26 | Première édition de la foire aux questions pour les employés du Québec |
