# Written Warning and Attendance Plan Template

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-071 |
| Title | Written Warning and Attendance Plan Template |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | VP Employee Relations |
| Audience | Managers |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-021, HR-POL-004, HR-POL-018, FORM-HR-070 |

## 1. Purpose and when to use this form

Managers use this form for three documents: a written warning, a final written warning, and a Stage 2 written attendance plan. A coaching conversation and a verbal warning do not use it.

## 2. Who completes it and who approves

| Document | Required consultation or approval |
| --- | --- |
| Written warning | HRBP consulted before delivery |
| Final written warning | HRBP and Employee Relations; Director approval |
| Attendance plan | HRBP; check for protected absences and accommodation first |

Protected absences never count toward an attendance trigger. A pattern linked to a disability goes to the Accommodation Specialist (HR-POL-018).

## 3. Where and when to submit

Hold a private meeting, preferably Tuesday to Thursday. Place a copy in the confidential file within 2 business days. For attendance, hold the Stage 1 conversation within 5 business days of a trigger: 3 late arrivals in 30 days, 4 absence occurrences or 8 absence days in a rolling 12 months.

## 4. Form fields

| Field | Required | Notes |
| --- | --- | --- |
| Employee, manager, date | Yes | |
| Document type | Yes | Written warning, final written warning, attendance plan |
| Facts of the concern | Yes | Dates and examples |
| Policy or standard breached | Yes | |
| Expected behaviour or improvement | Yes | Targets for an attendance plan |
| Support offered | Yes | |
| Active period | Yes | 12 months (written warning); 24 months (final written warning) |
| Review period | Attendance plan | 90 days |
| Unpaid suspension | Final warning only | Up to 3 days, where law allows |
| Consequences of further concerns | Yes | |

## 5. Declarations and signatures

- Manager: the facts are accurate and the step is consistent with HR-POL-021 Employee Relations and Progressive Discipline Policy.
- Employee: I received this document; my signature does not mean agreement. If the employee declines to sign, the manager notes that on the form.
- The employee may respond in writing within 5 business days and bring a support person who is not legal counsel.

## 6. What happens next

A response does not stop the process, but it is considered before the decision is final. If attendance does not improve during the plan, Stage 3 is a final written warning; termination is considered only after HR and Employee Relations review (HR-POL-004 Attendance and Absenteeism Policy). A warning stops counting as a step when its active period ends without a related further warning. Manager Hotline: 1-800-555-0143. Where applicable law gives a greater right, the law applies.

## 7. Related documents

- HR-POL-021 Employee Relations and Progressive Discipline Policy
- HR-POL-004 Attendance and Absenteeism Policy
- FORM-HR-070 Performance Improvement Plan

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-09-01 | Aligned active periods with HR-POL-021 version 4.0 and added the attendance plan section. |
