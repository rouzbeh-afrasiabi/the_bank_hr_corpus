# Family Caregiver Leave Request

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-013 |
| Title | Family Caregiver Leave Request |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-11-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-008, HR-POL-007, HR-POL-006, FORM-HR-012 |

## 1. Purpose and when to use this form

Use this form to request unpaid, job-protected leave to care for a family member who is seriously or critically ill. For a short absence, consider up to 5 sick days a year for family care (HR-POL-007) or vacation.

## 2. Who completes it and who approves

You complete it. The Leaves team confirms eligibility and the leave type. Your manager plans coverage.

## 3. Where and when to submit

Submit in MyHR as early as you can. The Leaves team gives a first response within 2 business days. In the US, an FMLA eligibility notice follows within 5 business days of the Bank learning that the leave may qualify.

## 4. Form fields

| Field | Required | Notes |
| --- | --- | --- |
| Type of leave | Yes | See the table below |
| Relationship of the family member | Yes | |
| Start date and expected end date | Yes | |
| Medical certificate supporting the need for care | Where the law allows | Describes care needed and period; no diagnosis detail beyond what the law requires |
| Government benefit applied for | Canada, optional | You apply yourself; the Bank does not top it up |
| Intermittent or reduced schedule | No | Describe the pattern |

| Leave | Canada | US |
| --- | --- | --- |
| Compassionate care | Up to 28 weeks | FMLA caregiver, up to 12 weeks |
| Critical illness of a child | Up to 37 weeks | FMLA, up to 12 weeks |
| Critical illness of an adult | Up to 17 weeks | FMLA, up to 12 weeks |
| Military caregiver | Not applicable | Up to 26 weeks |

## 5. Declarations and signatures

- The information is accurate.
- I understand the leave is unpaid and job-protected.
- I understand I may use vacation during the leave.
- I will tell the Leaves team if the family member's situation or my dates change.

## 6. What happens next

The Leaves team confirms the leave in writing and informs Payroll Services and Benefits Administration. Benefit arrangements are described in HR-GDE-001 Employee Benefits Guide. You return to the same or a comparable role. Retaliation for taking leave is prohibited. Where applicable law gives a greater right, the law applies. Questions: HR Connect, 1-800-555-0142.

## 7. Related documents

- HR-POL-008 Parental and Family Leave Policy
- HR-POL-007 Sick Leave and Personal Leave Policy
- HR-GDE-001 Employee Benefits Guide

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-11-01 | Added the Canada and US entitlement table and the first-response time. |
