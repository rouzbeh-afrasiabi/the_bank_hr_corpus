# Director, Retail Distribution

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1011 |
| Title | Director, Retail Distribution |
| Document type | Job description |
| Version | 1.2 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-09-22 |
| Next review | 2027-09-22 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-POL-031, HR-PLN-003, HR-POL-002, HR-POL-018 |

## 1. Role summary

The Director, Retail Distribution leads the Bank's branch network across several regions, setting the distribution strategy, branch footprint priorities and operating model for in-person retail banking. The role oversees the Regional Managers, owns the network's financial, service and risk outcomes, and partners with digital, marketing, operations and risk leaders to keep the branch channel relevant and efficient. The Director is accountable to the Vice President, Retail Banking for network performance and talent. This is a Band 7 (Director) role in the Retail Banking family; see HR-GDE-006 Job Architecture and Pay Bands Guide.

## 2. Key responsibilities

- Lead the Regional Managers, Retail and set the distribution strategy and annual plan for the branch network.
- Own network revenue, expense, customer experience, and risk and conduct results and report them to executive leadership.
- Decide branch format, staffing model and hours changes with Real Estate, Operations and the HR Business Partner.
- Manage the distribution budget and approve major spending within delegated authority.
- Oversee sales-practice standards, branch controls, audit remediation and regulatory commitments across the network.
- Build the leadership bench through talent reviews, succession planning and development of Regional Managers.
- Partner with digital and contact centre leaders to design a coherent customer journey across channels.
- Represent Retail Banking with regulators, unions or employee groups where applicable, and with community and industry partners.
- Approve exceptions and escalated people matters in line with Director authority in Bank policy.
- Champion an inclusive, safe and ethical branch culture and act on engagement survey results.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in business or a related field, or equivalent experience.
- Twelve to sixteen years of progressive banking experience, including significant experience leading managers of managers.
- Proven success running a multi-site network with accountability for financial and risk results.
- Strategic thinking, financial acumen and executive communication skills.
- Satisfactory results in pre-employment screening and periodic re-screening for senior roles.

### 3.2 Preferred

- MBA or an executive leadership qualification.
- Experience across both branch and digital channels.
- Fluency in English and French.

### 3.3 Licences and certifications

No licence is required. The Director must understand the obligations in HR-POL-029 Licensing, Registration and Qualification Policy because licensed advisors and specialists work in the network.

## 4. Competencies

Competencies are defined in HR-FWK-001 Competency and Leadership Model; this role works at the Enterprise Leader level.

- **Drive for Results**: delivers network targets while investing in the future.
- **Judgement and Decision Quality**: makes high-impact network decisions with data and judgement.
- **Risk and Conduct Awareness**: sets the tone for conduct and control across the network.
- **Developing Others**: builds the next generation of retail leaders.
- **Inclusive Leadership**: leads a diverse network and removes barriers to inclusion.
- **Adaptability**: leads change as customer behaviour shifts to digital.
- **Collaboration**: works across business units and enterprise functions.

## 5. Compensation and classification

| Item | Detail |
| --- | --- |
| Band | 7 (Director) |
| Canada salary range | $140,000 to $210,000 CAD per year |
| US salary range | $138,000 to $206,000 USD per year |
| Incentive target | Annual Incentive Plan (AIP): 20% of base salary; deferral and clawback apply under HR-POL-031; eligible for the Long-Term Incentive Plan (HR-PLN-003) |
| Overtime eligibility (Canada) | No |
| FLSA classification (US) | Exempt |
| Work arrangement | Hybrid: at least 3 days a week in the office, with network visits scheduled around them |

## 6. Working conditions and accessibility

This is a hybrid office role with regular travel to regions and branches. Hybrid arrangements follow HR-POL-002 Remote and Hybrid Work Policy, with at least 3 days a week in the office and anchor days on Tuesday and Thursday. The Bank provides accommodation to the point of undue hardship (Canada) or reasonable accommodation (US); see HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to the Vice President, Retail Banking.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.2 | 2026-03-01 | Pay ranges updated to the 2026 pay bands |
| 1.1 | 2026-01-01 | Added deferral, clawback and long-term incentive references |
| 1.0 | 2024-09-02 | First issue |
