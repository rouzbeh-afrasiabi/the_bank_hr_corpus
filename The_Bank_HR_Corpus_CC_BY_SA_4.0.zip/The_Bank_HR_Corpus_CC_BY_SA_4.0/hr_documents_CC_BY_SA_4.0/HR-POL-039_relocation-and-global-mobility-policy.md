# Relocation and Global Mobility Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-039 |
| Title | Relocation and Global Mobility Policy |
| Document type | Policy |
| Version | 3.2 |
| Status | Current |
| Effective date | 2025-06-01 |
| Last reviewed | 2026-06-09 |
| Next review | 2027-06-09 |
| Policy owner | VP HR Operations |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-002, HR-POL-009, HR-POL-015, HR-POL-025, HR-POL-038, FORM-HR-122 |

## 1. Purpose

This policy explains when and how the Bank supports an employee who is asked to move home to a new work location, and how international assignments are approved. It sets out who is eligible, what the Bank pays, how a request is made and approved, what is taxable, and what must be repaid if the employee leaves soon after the move. It exists so that Bank-initiated moves are treated consistently and fairly across business units.

## 2. Scope

The policy applies to regular full-time and regular part-time employees in Canada and the US whose move is initiated by the Bank and approved in advance under section 6. It does not cover employee-initiated moves, including a move chosen by a hybrid or remote employee (see section 5). Casual employees, fixed-term employees, students, co-op students, interns, contractors and agency workers are not eligible (see HR-POL-014 Employment Status and Classification Policy). Promotions and transfers are handled separately; a change of role does not by itself make a move eligible under this policy. Where applicable law gives a greater right, the law applies.

## 3. Definitions

- **Bank-initiated move:** a move that the business unit asks the employee to make because the role must be performed at a different work location, and that is approved in writing before the move on FORM-HR-122.
- **Old home and new home:** the employee's principal residence before and after the move.
- **Qualifying distance:** the new home is at least **80 km closer** than the old home to the new work location, measured by the shortest driving route.
- **Relocation lump sum:** a single taxable payment toward moving and settling costs, set by band in section 7.
- **Tax assistance payment:** an additional payment that offsets some of the tax on approved relocation benefits (section 10).
- **Global Mobility:** the HR Operations team that administers relocations and international assignments.
- **International assignment:** work for the Bank in a country other than the employee's home country that is longer than the temporary work from elsewhere limits in HR-POL-002 Remote and Hybrid Work Policy.

## 4. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Employee | Applies on FORM-HR-122 before any commitment (lease, sale, moving contract); keeps receipts; repays amounts due under section 9 |
| Manager | Confirms the business need and recommends the move |
| HRBP | Checks eligibility, band and approval level; advises on exceptions |
| Global Mobility | Acknowledges requests, confirms qualifying distance, arranges temporary housing, tracks repayment obligations |
| Payroll Services | Pays the lump sum, calculates the tax assistance payment, reports taxable amounts, recovers repayments |
| Approvers | As set out in section 6 |
| VP HR Operations | Owns this policy and approves exceptions under section 12 |

## 5. Moves that are not covered

The following are not eligible, whatever the distance:

1. A move the employee chooses for personal reasons.
2. A move by a remote employee to another province or state. That employee needs approval at least 30 days before the move under HR-POL-002 Remote and Hybrid Work Policy, and the Bank may decline if the new location is not on the approved employment-jurisdiction list. No relocation benefits are paid.
3. A move made before FORM-HR-122 is approved.
4. A move of less than the qualifying distance.
5. A move that follows a resignation notice or a notice of termination.

## 6. Approval

### 6.1 Approval levels

| Band | Required approvals |
| --- | --- |
| Bands 1 to 4 | Business unit SVP (required for any relocation lump sum at these bands), HRBP and Global Mobility |
| Bands 5 and 6 | Vice President, HRBP and Global Mobility |
| Band 7 and above | SVP, HRBP and Global Mobility; the CHRO is informed |

### 6.2 Timeline

1. The manager and employee agree the business need and the employee submits FORM-HR-122 in MyHR **at least 30 days before** the planned move date.
2. Global Mobility acknowledges the request within **2 business days**.
3. Global Mobility and the HRBP confirm eligibility and qualifying distance within **5 business days** of acknowledgement.
4. The approvers decide within **10 business days** of the complete request.
5. The approved move must be completed within **6 months** of the approval date; after that the employee reapplies.

## 7. What the Bank provides

### 7.1 Relocation lump sum

| Band | Lump sum (Canada) | Lump sum (US) |
| --- | --- | --- |
| Bands 1 to 4 | $5,000 CAD (SVP approval required) | $4,000 USD |
| Bands 5 and 6 | $12,000 CAD | $9,500 USD |
| Band 7 and above | $20,000 CAD | $16,000 USD |

The lump sum is paid once per approved move through payroll, on the next pay date after the employee confirms the move on FORM-HR-122 and submits proof of the new address, subject to the payroll cut-off in HR-POL-009 Compensation and Payroll Policy. It is not itemized and no receipts are needed for how it is spent. Proof of the move must be submitted within **90 days** of the move date.

### 7.2 Temporary housing

The Bank arranges and pays for temporary housing for up to **60 days** when the employee has started in the new work location but cannot yet occupy the new home. Global Mobility books it; the employee does not claim reimbursement for housing the Bank has not arranged unless Global Mobility approved it first.

### 7.3 House-hunting trip

One house-hunting trip of up to **3 days** is available before the move. The days are paid working time and are not charged to vacation. Travel, hotel and meals follow HR-POL-038 Business Travel and Expense Policy, and the expenses are claimed within 30 days as set out there.

## 8. International assignments

An international assignment, or any request to work in another country beyond the limits for temporary work from elsewhere, needs approval by the **SVP, Global Mobility and Legal at least 30 days ahead**. Global Mobility confirms work authorization, tax and payroll treatment, social security coverage, benefits continuity and the employee's return arrangements in a written assignment letter before the employee travels. Without that letter, no employee may start work in another country. The Canada-US limits for temporary work are in HR-POL-002 and are not international assignments. Terms of an assignment letter may differ from this policy; the letter prevails where it gives the employee more.

## 9. Repayment

Before any payment is made, the employee signs the repayment acknowledgement on FORM-HR-122. If the employee resigns:

| Resignation date, counted from the date the lump sum is paid | Repayment |
| --- | --- |
| Within 12 months | 100% of the lump sum and any other relocation amounts paid |
| After 12 months and within 24 months | 50% of those amounts |
| After 24 months | None |

Repayment is requested in writing within 10 business days of the resignation date being known. Payroll Services recovers it from final pay as far as the law allows; the remainder is repaid by lump sum or under a plan agreed with Payroll Services, using the repayment rules in HR-POL-009 (at most 15% of net pay per period where a deduction is used, and a plan of up to 12 months). Notice and final pay are handled under HR-POL-015 Resignation and Offboarding Policy.

Repayment is waived if the Bank ends the employment without cause (see HR-POL-025 Involuntary Termination and Severance Policy), on the employee's death, or on the employee's long-term disability.

## 10. Taxes

Relocation benefits are taxable income to the employee. For an approved Bank-initiated move, Payroll Services adds a tax assistance payment to offset some of the tax on the benefits, and reports both amounts on the employee's pay statement and tax slip. The Bank does not give tax advice; employees should consult a tax adviser about any deduction available to them. Tax rules differ between countries, provinces and states, and Payroll Services applies the rules that apply to the employee.

## 11. Worked examples

**Example 1: eligible move.** A Band 6 employee in Alberta is asked to move to a role 300 km away. Her new home is 280 km closer to the new work location. She submits FORM-HR-122 45 days before the move; the Vice President, HRBP and Global Mobility approve in 8 business days. She receives $12,000 CAD, a tax assistance payment, and 60 days of temporary housing. She resigns 14 months after the lump sum is paid, so she repays 50%, or $6,000 CAD (plus the same share of any other relocation amount paid).

**Example 2: distance too short.** A Band 3 employee in the US is asked to work at a site 70 km from home and moves to a flat that is 60 km closer. The move is under the 80 km threshold and is not eligible.

**Example 3: remote employee.** A remote Band 4 employee wants to move to another province. She submits the notice required by HR-POL-002 30 days ahead and is approved. The move is employee-initiated, so no relocation benefits are paid.

## 12. Exceptions

The VP HR Operations may approve an exception to the qualifying distance, the lump sum timing or the 6-month completion window, in writing and with the business unit head's agreement. Lump sum amounts and repayment rules change only with the HR Policy Committee's approval.

## 13. Consequences

Claiming relocation benefits for a move that did not take place, or submitting false proof, breaches HR-POL-001 Code of Conduct and Ethics, may lead to discipline under HR-POL-021 Employee Relations and Progressive Discipline Policy, and the amounts are recovered.

## 14. Related documents and contacts

Related: HR-POL-002 Remote and Hybrid Work Policy; HR-POL-009 Compensation and Payroll Policy; HR-POL-015 Resignation and Offboarding Policy; HR-POL-025 Involuntary Termination and Severance Policy; HR-POL-038 Business Travel and Expense Policy; FORM-HR-122. Contact HR Connect at 1-800-555-0142 or hrconnect@bank.example.

## 15. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 3.0 | 2023-06-01 | Introduced bands-based lump sums and the 80 km qualifying distance |
| 3.1 | 2024-06-01 | Added the tax assistance payment and the 90-day proof-of-move deadline |
| 3.2 | 2025-06-01 | Added the 50% repayment tier for resignation between 12 and 24 months, and the 30-day advance approval for international assignments |
