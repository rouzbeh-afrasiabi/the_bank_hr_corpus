# Employment Agreement Standard Terms (Canada)

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-TPL-003 |
| Title | Employment Agreement Standard Terms (Canada) |
| Document type | Template |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-06-30 |
| Next review | 2027-06-30 |
| Policy owner | VP HR Operations |
| Audience | HR only |
| Jurisdiction | Canada |
| Language | English |
| Related documents | HR-TPL-001, HR-POL-025, HR-POL-015, HR-POL-014 |

## 1. Purpose and when to use this template

These standard terms are attached to HR-TPL-001 Offer Letter (Canada) and form part of the employment agreement once the offer is accepted. They set out the terms that are the same for every Canadian employee. They are not used in the US.

## 2. How to use this template

1. Attach the terms to every Canadian offer without changing the clause numbers.
2. Complete the placeholders in clauses 1, 2 and 7.
3. Where the employee works in Quebec, issue the French version in addition to the English one.
4. Send any change to a clause to Legal before the offer goes out.

## 3. Standard terms

**1. Position and reporting.** The employee is employed as **[Job title]**, Band **[Band]**, in **[Business unit]**, reporting to **[Manager name]**, working from **[Work location, province]**. The Bank may change duties and reporting lines within the scope of the band. Promotions and transfers are handled separately.

**2. Probation.** The first 3 months are a probation period. The Bank may extend it once, to a total of 6 months, by written notice before the end of month 3 (see HR-POL-014 Employment Status and Classification Policy). The employee is entitled to the minimum rights required by law during probation.

**3. Hours.** The standard work week is 37.5 hours (7.5 hours a day, 5 days) with a 60-minute unpaid meal period. Overtime-eligible employees are paid as set out in HR-POL-003 Working Hours and Overtime Policy.

**4. Compensation and incentive.** Base salary is **[Base salary] CAD** a year, paid biweekly on Thursdays. Participation in the Annual Incentive Plan is governed by the plan document and is not guaranteed.

**5. Vacation, sick days and benefits.** Vacation, paid sick days, personal days, benefits and pension participation are as stated in the offer letter and in the policies in force. The Bank may amend benefit plans and policies on notice, within the limits of the law.

**6. Resignation.** The employee gives written notice of **[2 / 4 / 8] weeks** according to band (Bands 1 to 4 two weeks; Bands 5 and 6 four weeks; Band 7 and above eight weeks). The Bank may waive part of the notice and pay through the notice period, or place a Band 7 or above employee on paid garden leave.

**7. Termination by the Bank.** If the Bank ends employment without cause, the employee receives notice or pay in lieu equal to the greater of the minimum required by law and the formula in HR-POL-025 Involuntary Termination and Severance Policy (2 weeks of base pay per completed year of service, minimum 8 weeks, maximum 52 weeks). Benefits continue through the notice period. Enhanced severance above the legal minimum requires a signed release, and the employee has 14 days to consider it. If the Bank ends employment for cause, only statutory entitlements apply.

**8. Confidentiality.** The employee keeps Bank, client and employee information confidential during and after employment and returns all Bank property within 5 business days of the last day.

**9. Non-solicitation and non-competition.** For **[Non-solicitation period]** after employment ends, the employee will not solicit Bank clients or employees. A non-competition covenant applies only to Band 8 and above, and only where the law permits.

**10. Intellectual property.** Work product created in the course of employment belongs to the Bank.

**11. Privacy.** The employee acknowledges the collection and use of personal information described in HR-POL-016 Employee Data Privacy Policy.

**12. Language and law.** For Quebec employees the parties confirm a French version was provided. The agreement is governed by the laws of **[Province]** and of Canada. Where the law gives a greater right, the law applies.

**13. Entire agreement.** The offer letter and these terms are the entire agreement. Changes must be in writing and signed by HR Operations.

## 4. Required clauses checklist

| Clause | Required |
| --- | --- |
| Probation | 3 months, extension to 6 |
| Termination | Greater of legal minimum and Bank formula; reference to HR-POL-025 |
| Release | 14 days to consider |
| Resignation notice | By band |
| Confidentiality | Yes |
| Non-solicitation | Yes; non-compete only Band 8 and above where law permits |

## 5. Drafting notes for HR

- Some provinces do not permit a non-competition covenant for most employees. Delete clause 9 wording that does not apply and confirm with Legal.
- Do not describe severance as a fixed number of weeks; the formula is applied at termination.
- Keep the placeholders in square brackets until completed; never send an offer with a visible placeholder.

## 6. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.0 | 2023-04-03 | First standard terms |
| 2.0 | 2025-09-01 | Aligned the termination clause with HR-POL-025 and added the non-competition limit for Band 8 and above |
