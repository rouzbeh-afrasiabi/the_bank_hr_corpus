# Manager's HR Procedures Guide

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-GDE-005 |
| Title | Manager's HR Procedures Guide |
| Document type | Guide |
| Version | 3.2 |
| Status | Current |
| Effective date | 2026-02-02 |
| Last reviewed | 2026-10-06 |
| Next review | 2027-10-06 |
| Policy owner | SVP Talent and Learning |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Applies to | All people managers in Canada and the US (see Scope) |
| Audience | Managers |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-006, HR-POL-011, HR-POL-013, HR-POL-005, HR-POL-018, HR-POL-021, HR-POL-025, HR-GDE-004 |

## 1. Purpose and scope

This guide tells people managers what to do, who approves what, and by when. It covers the people-management steps from hiring to offboarding. It applies to every employee in Canada or the US who has direct reports. The owning policy always governs the rule itself; this guide governs the manager's procedure. Where applicable law gives a greater right, the law applies. Promotions and transfers are handled separately and are not covered here.

## 2. Manager role and delegated authority

You are the first point of contact for your team on HR matters. You may approve the items marked "Manager" in the approvals matrix (section 3). You may not approve exceptions to policy, promise outcomes to employees about pay, leave or accommodation, or investigate complaints. If you are unsure, call the Manager Hotline before you decide. Authority is delegated to you by your Director and by the policy owners; it ends when you stop managing the team, and an acting manager needs written delegation recorded in MyHR.

## 3. Approvals matrix

| Request | Approver | Turnaround |
| --- | --- | --- |
| Vacation | Manager | Respond within 5 business days (HR-POL-006) |
| Hybrid office-attendance exception, up to 12 days per employee per calendar year | Manager | 3 business days |
| Hybrid exception beyond 12 days | HRBP | 5 business days |
| Overtime (all pre-approvals) | Manager, in Time Tracker; FORM-HR-020 if planned or recurring | Before the hours are worked |
| More than 8 overtime hours in a week | Director, with HR notified | Before the hours are worked |
| Scheduling beyond 12 hours a day or 48 hours a week | VP, with written employee consent | Before scheduling |
| Time in lieu (Canada only) | Manager | 3 business days |
| Personal days | Manager | 2 business days |
| Personal leave of absence (FORM-HR-010) | Director and HRBP | 10 business days |
| Tuition reimbursement, up to $5,000 CAD / $5,250 USD per fiscal year (FORM-HR-060) | Manager approves; HRBP confirms eligibility | 5 business days |
| Off-cycle salary adjustment | Manager recommends; HRBP and Total Rewards approve | 10 business days |
| Requisition, Bands 1 to 4 | Director | 5 business days |
| Requisition, Bands 5 and 6 | VP | 5 business days |
| Requisition, Band 7 and above | SVP and CHRO | 10 business days |
| Termination without cause | HRBP and Employee Relations | Before any meeting |
| Termination for cause | VP Employee Relations and Legal | Before any meeting |
| Exception to any HR policy | The policy owner, through your HRBP | 10 business days |

Time entries for non-exempt employees must be approved by Monday 12:00 local time. Approvals are recorded in MyHR or Time Tracker, never only by email.

## 4. Managing leave requests

### What you do

Acknowledge a leave request promptly and route it to the Leaves team through the HR Case Portal. Do not approve or deny statutory, medical, parental or caregiver leave yourself. Parental leave notice (FORM-HR-012) is due 4 weeks before leave starts where possible. For vacation, follow HR-POL-006 Vacation and Paid Time Off Policy, including the block-leave requirement of 10 consecutive business days per year.

### What you must never do

Never ask for a diagnosis, symptoms, test results or treatment details. A medical certificate is requested only from the 4th consecutive working day (3 days in Quebec) and goes to HR, not to you. Never discourage an employee from taking a protected leave.

### What you share with HR

Share the dates, the type of leave, and any operational impact. Short-term disability starts after 5 consecutive working days, and the employee applies through MyHR within 5 business days of going off work; remind them, but do not complete the claim. See HR-POL-007 Sick Leave and Personal Leave Policy and HR-POL-008 Parental and Family Leave Policy.

## 5. Attendance conversations

Employees report an absence before their scheduled start, or within 30 minutes after it if unable. A pattern review is triggered by 3 late arrivals in 30 days, or 4 absence occurrences or 8 absence days in a rolling 12 months, excluding protected absences such as leaves, accommodated absences and jury duty. Hold a Stage 1 informal conversation, documented in a note, which is not discipline. Stage 2 is a written attendance plan on FORM-HR-071, with HRBP consultation. Hold a return-to-work conversation within 2 business days after 5 or more absence days. Focus on reliability, not on the reason for the illness. Talking point: "I have noticed some absences and late starts. I am not questioning the reasons; I want to understand whether there is anything I can change so you can be here when the team needs you." If the employee mentions a medical or family reason, stop, do not ask for details, and refer them to HR Connect for leave or accommodation options. Three consecutive scheduled days without contact is presumed job abandonment only after HR makes at least 3 documented contact attempts; do not decide this yourself. See HR-POL-004 Attendance and Absenteeism Policy.

## 6. Performance cycle checklist

The performance year runs 1 November to 31 October.

| Date | Manager action |
| --- | --- |
| Within 30 days of start | Set goals for new hires |
| Quarterly | Informal check-in with each team member |
| 1 May to 15 June | Mid-year check-in |
| 31 October | Year closes; employees hired on or before 31 July are eligible for a rating |
| 15 November | Employee self-assessment due |
| 10 December | Your written assessment due |
| 15 December | Goals for the new year set |
| 11 December to 10 January | Calibration |
| 15 January | Ratings communicated |
| First pay date in February | Incentive paid |
| 1 March | Salary increases effective |

Rating disputes: the employee writes to the HRBP within 10 business days of being told; review takes up to 15 business days and is final. See HR-POL-011 Performance Management Policy.

## 7. Goal-setting, check-ins and year-end conversations

### Goal-setting

Agree 3 to 5 goals (the "what") and discuss the Bank values (the "how"): Integrity, Customer Focus, Accountability, Collaboration and Inclusion. Talking point: "Which three results would make this year a success, and how will we both know?"

### Check-ins

Keep them short and regular. Talking points: "What is going well? Where are you blocked? What support do you need from me?" Write a one-line note of any agreement. At the mid-year check-in, review progress against each goal, adjust goals that have changed, and say plainly whether the employee is on track for Meets Expectations or higher, so that nothing in the rating comes as a surprise. Talking point: "If the year ended today, here is where I think you would land, and here is what would change that."

### Year-end

Read the self-assessment first. Give evidence for each rating-related point, and separate results from behaviours. Talking point: "Your rating reflects what you delivered and how you delivered it; here are three examples." Do not share the rating before calibration is complete. Remind the employee of the dispute window. If the employee is disappointed, listen, restate the evidence and explain the next steps; do not renegotiate the rating in the meeting.

## 8. Calibration

Calibration runs 11 December to 10 January and is facilitated by your HRBP. Bring evidence, not impressions. Guidance, not a forced distribution, is Outstanding 5 to 10%, Exceeds Expectations 20 to 30%, and Meets Expectations 50 to 60%, with the rest Needs Improvement or Unsatisfactory. Challenge your own bias, compare like roles fairly, and record any rating change and its reason. Do not discuss other employees' ratings with the team. Calibrated ratings are communicated by 15 January.

Before the session, prepare for each team member a short summary of the goals, results, and values behaviours, with at least one concrete example. During the session, expect questions about consistency across teams. After the session, confirm the outcome with your HRBP and plan each rating conversation so that the employee hears the result from you first.

## 9. Coaching, warnings and PIPs

### Coaching

Begin with coaching, which is not discipline. Document the conversation, the expectation and the follow-up date. Talking point: "I want to talk about a gap between what I expect and what I am seeing. Here is the specific example. What is getting in the way, and what will you do differently by the follow-up date?" Always ask whether anything at work or an accommodation need is contributing, without asking about health details.

### Written warnings

Consult your HRBP before any written warning, using FORM-HR-071. The employee may respond in writing within 5 business days and may bring a support person. A written warning is active for 12 months; a final written warning for 24 months and may include unpaid suspension of up to 3 days. Serious misconduct may skip steps. Employee Relations must approve any termination. Involve Employee Relations when misconduct, discrimination or retaliation may be present. See HR-POL-021 Employee Relations and Progressive Discipline Policy.

### Performance improvement plans

A PIP follows a rating of Needs Improvement or Unsatisfactory, or documented sustained underperformance after at least one documented coaching conversation. You need HRBP approval before the meeting. The standard length is 60 days (range 30 to 90), with weekly check-ins and the plan on FORM-HR-070. The employee may bring a support person who is not legal counsel. Consider accommodation needs first. One extension of up to 30 days is possible. During an active PIP the employee is not eligible for a merit increase. See HR-POL-013 Performance Improvement Policy.

## 10. Handling complaints of harassment or violence

If an employee tells you about harassment, discrimination or violence, on the same business day you must:

1. Make sure the employee is safe; in any danger, call 911, then Corporate Security at 1-800-555-0119.
2. Refer it to the Employee Relations designated recipient through the HR Case Portal (a P1 case) or HR Connect; your HRBP can help. FORM-HR-050 is the intake form.
3. Write down only what was said, when, and by whom.
4. Tell the employee what happens next, without promising an outcome.

Never investigate yourself, confront the other person, or ask others to "check the facts". Share only on a need-to-know basis. Retaliation is prohibited. Under the policy, the complaint is acknowledged within 2 business days, interim measures are in place within 5 business days, and a trained impartial investigator finishes within 60 calendar days. See HR-POL-005 Workplace Harassment and Violence Prevention Policy.

## 11. Accommodation requests

A request does not need the word "accommodation", a form or a diagnosis. Tell the employee you will help, then send the request to the Accommodation Specialist at accommodations@bank.example the same business day. HR acknowledges within 2 business days and decides within 10 business days of complete information (3 for urgent cases). You receive only functional limitations and expected duration. Put interim measures in place while the request is pending. The cost is met by the central Accommodation Fund, not your budget. See HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 12. Hiring steps

1. Obtain requisition approval for the band (section 3).
2. Post with the pay range, open at least 5 business days.
3. Use structured interviews with a panel of at least 3 and at least 2 stages; use diverse interview slates for Band 5 and above.
4. Never hire, or be the manager of, a relative.
5. Complete 2 reference checks, and use AI screening tools only as an aid, never as the sole basis for rejection.
6. Approve the offer within the band; the offer is valid for 5 business days.
7. Obtain consent (FORM-HR-111) and complete pre-employment screening; employment is conditional on satisfactory results.

The time-to-fill target is 45 days. Employee referral bonuses ($1,000 CAD / $750 USD for Bands 1 to 5; $1,500 CAD / $1,100 USD for Band 6 and above and hard-to-fill roles) are paid after the referred hire completes 6 months; do not promise them to candidates. Candidate data is kept for 12 months, so never keep your own interview notes beyond what HR requires. See HR-POL-019 Recruitment and Selection Policy and HR-POL-020 Pre-Employment Screening Policy.

## 13. Onboarding responsibilities

Before day 1, confirm the equipment order and assign an onboarding buddy; remote laptops are delivered 3 business days before the start date. Welcome the employee at 9:00 local time on day 1. Within 30 days make sure goals are set and mandatory training is complete, and hold check-ins at 30, 60 and 90 days. Probation is 3 months; to extend it once to 6 months, get your HRBP's agreement, then give written notice before the end of month 3. Remind the employee to enrol in benefits within 31 days. See HR-GDE-003 New Employee Onboarding Guide.

## 14. Offboarding and terminations protocol

### Resignations

The employee submits FORM-HR-080 to you and HR. Notice is 2 weeks for Bands 1 to 4, 4 weeks for Bands 5 and 6, and 8 weeks for Band 7 and above; HR acknowledges within 2 business days. Complete FORM-HR-081, collect equipment within 5 business days, and let access end at 17:00 on the last day. The exit interview is run by HR Operations, not you. See HR-POL-015 Resignation and Offboarding Policy.

### Terminations

Get the approvals in section 3 before telling anyone. Hold the meeting with the HRBP present, and Corporate Security on standby where needed, ideally Tuesday to Thursday. Access is removed at once for involuntary exits. Do not describe severance terms yourself; HR presents them. See HR-POL-025 Involuntary Termination and Severance Policy.

## 15. Privacy and security duties of managers

Access employee information only when you need it for a management purpose. Keep medical and accommodation details out of team records and conversations. Report any suspected privacy breach to the Privacy Office immediately and within 24 hours. Any new HR system, vendor or tool that collects employee information needs a Privacy Impact Assessment (FORM-HR-091) first, and monitoring or AI-assisted decisions about employees need a Data Protection Impact Assessment (FORM-HR-092); a human always makes the final employment decision. Never place employee personal data in public AI tools. Report a phishing or lost device to the Security Operations Centre at 1-800-555-0155 immediately and within 1 hour at most. Review your team's system access quarterly. See HR-POL-016 Employee Data Privacy Policy and HR-POL-017 IT Acceptable Use and Information Security Policy.

## 16. Escalation paths and the Manager Hotline

The Manager Hotline, 1-800-555-0143, is for managers only. It operates Monday to Friday 8:00 to 20:00 Eastern Time and responds within 4 business hours. Use this path:

| Situation | Go to |
| --- | --- |
| General question | Manager Hotline |
| Pay, leave, accommodation or discipline | HRBP |
| Misconduct, harassment or termination | Employee Relations |
| Ethics concern or concern about a leader | Speak-Up Line, 1-800-555-0177 |
| Safety emergency | 911, then Corporate Security, 1-800-555-0119 |
| Missed HR service level | HR Operations manager, then VP HR Operations, then the Office of the CHRO |

The Ombuds Office is always available. See HR-GDE-004 HR Service and Support Guide.

## 17. Quick-reference deadlines

| Item | Deadline |
| --- | --- |
| Vacation response | 5 business days |
| Time entry approval | Monday 12:00 local time |
| Harassment or violence report referred to Employee Relations | Same business day |
| Privacy breach to Privacy Office | Immediately, within 24 hours |
| Security incident to the SOC | Immediately, within 1 hour |
| Accommodation request forwarded | Same business day |
| Return-to-work conversation | 2 business days after 5 or more absence days |
| New hire goals | 30 days |
| Mid-year check-in | 1 May to 15 June |
| Manager assessment | 10 December |
| Ratings communicated | 15 January |
| PIP length | 60 days standard |
| Equipment returned after exit | 5 business days |

## 18. Related documents and contacts

HR-POL-004 Attendance and Absenteeism Policy, HR-POL-007 Sick Leave and Personal Leave Policy, HR-POL-011 Performance Management Policy, HR-GDE-006 Job Architecture and Pay Bands Guide. Contact the Manager Hotline at 1-800-555-0143.

## 19. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 3.0 | 2024-09-01 | Restructured the guide around the manager approvals matrix |
| 3.1 | 2025-06-01 | Aligned PIP standard length with 60 days |
| 3.2 | 2026-02-02 | Added the same-business-day harassment referral steps, 3-day hybrid rule and 5-day vacation carryover |
