# Employee HR FAQ

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-FAQ-001 |
| Title | Employee HR FAQ |
| Document type | FAQ |
| Version | 2026.3 |
| Status | Current |
| Effective date | 2026-10-26 |
| Last reviewed | 2026-10-26 |
| Next review | 2027-10-26 |
| Policy owner | VP HR Operations |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Applies to | All Canadian and US employees (see Scope) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-002, HR-POL-003, HR-POL-006, HR-POL-007, HR-POL-008, HR-POL-009, HR-POL-010, HR-GDE-001, HR-GDE-004 |

## 1. Purpose and scope

This FAQ gives plain-language answers to common employee questions in Canada and the US. Each answer names the owning document; if this FAQ and that document differ, the owning document applies. Where applicable law gives a greater right, the law applies. If a question is not covered, contact HR Connect at 1-800-555-0142 or hrconnect@bank.example.

## 2. Working arrangements

### How many days a week must I be in the office?

Hybrid employees attend at least 3 days a week. Tuesday and Thursday are anchor days and your team picks the third day. This rule has applied since 5 January 2026 (it was 2 days before). See HR-POL-002 Remote and Hybrid Work Policy.

### Can I work from home full time?

Only if your role is designated remote-eligible and you are approved on FORM-HR-030. You must have passed probation, hold a Meets Expectations rating or higher, have no active performance improvement plan, and live in an approved jurisdiction. See HR-POL-002 Remote and Hybrid Work Policy.

### Can I work from my cottage for a month?

It depends. Temporary work from elsewhere is limited to 20 working days per calendar year within your home country, requested on FORM-HR-031 at least 5 business days ahead. A full month usually exceeds that, so the extra days would need to be vacation or office days; the policy does not offer longer stays, so contact HR Connect. See HR-POL-002 Remote and Hybrid Work Policy.

### Can I work across the Canada-US border or from another country?

Across the border, up to 10 working days per calendar year, requested at least 10 business days ahead. Any other country needs Global Mobility and Legal approval at least 30 days ahead. See HR-POL-002 Remote and Hybrid Work Policy.

### I'm moving from Ontario to Quebec. What changes?

Update your address in MyHR (FORM-HR-022); remote employees need approval at least 30 days before moving. You lose Family Day and the Civic Holiday, gain the Fête nationale du Québec, and Victoria Day becomes National Patriots' Day. Medical certificates are requested after 3 consecutive days instead of 4, overtime stays at 1.5x after 40 hours, and you may receive HR documents in French by default. See HR-POL-010 Statutory Holidays Policy and HR-POL-007 Sick Leave and Personal Leave Policy.

### What do I get for a home office?

A Bank laptop, headset, and one external monitor on request, plus a setup allowance once every 3 years: Remote $600 CAD / $450 USD, Hybrid $300 CAD / $225 USD. There is no ongoing internet reimbursement, and Canadian employees can request a form T2200 from HR Operations. See HR-POL-002 Remote and Hybrid Work Policy.

### Can I skip an office day now and then?

Your manager can approve up to 12 exception days per calendar year. More than 12 needs your HRBP. See HR-POL-002 Remote and Hybrid Work Policy.

### What happens in a snowstorm?

Closures are announced by 6:30 local time through a MyHR alert, text message and the intranet banner. Hybrid and remote staff work from home, and employees whose branch is closed are paid for the day. See HR-POL-004 Attendance and Absenteeism Policy.

## 3. Hours, overtime and holidays

### How long is my standard work week?

Canada 37.5 hours (7.5 per day) and the US 40 hours (8 per day), each with a 60-minute unpaid meal period. Core hours for office staff are 10:00 to 15:00 local time. See HR-POL-003 Working Hours and Overtime Policy.

### Do I get overtime in Ontario?

If you are in Canada Bands 1 to 4 in a non-managerial role, hours over 40 a week are paid at 1.5x. Hours from 37.5 to 40 are paid at straight time or banked 1:1. Overtime must be pre-approved in Time Tracker. See HR-POL-003 Working Hours and Overtime Policy.

### What are the overtime rules in British Columbia, Alberta and California?

British Columbia and California pay 1.5x after 8 hours a day and 40 a week, and 2x after 12 hours a day. Alberta pays 1.5x after 8 hours a day or 40 a week, whichever is greater. See HR-POL-003 Working Hours and Overtime Policy.

### Can I take time off instead of overtime pay?

In Canada, with manager approval, at 1.5 hours off per overtime hour (FORM-HR-020). The bank cap is 40 hours and it must be taken within 3 months, or it is paid out. US non-exempt employees are paid cash only. See HR-POL-003 Working Hours and Overtime Policy.

### When must I enter my time?

Non-exempt employees enter hours in Time Tracker by Friday 17:00 local time; managers approve by Monday 12:00. See HR-POL-003 Working Hours and Overtime Policy.

### Do I get paid for Boxing Day if I work in Calgary?

Yes, it is a paid holiday in every province. In 2026 it falls on Saturday 26 December, so it is observed on Monday 28 December. If you must work that day you get regular holiday pay plus 1.5x, or 1.5x time in lieu taken within 60 days. See HR-POL-010 Statutory Holidays Policy.

### Which holidays do US employees get in 2026?

Eleven: New Year's Day, Martin Luther King Jr. Day, Presidents' Day, Memorial Day, Juneteenth, Independence Day (observed Friday 3 July), Labor Day, Veterans Day, Thanksgiving, the day after Thanksgiving, and Christmas Day. See HR-POL-010 Statutory Holidays Policy.

### Do I lose holiday pay if I'm absent the day before?

An unexcused absence on your scheduled day before and after the holiday forfeits holiday pay. Approved leave or certified illness does not. See HR-POL-010 Statutory Holidays Policy.

### What are floating days?

Two Cultural and Religious Observance Days per calendar year in both countries, with 24 hours' notice and no carryover. See HR-POL-010 Statutory Holidays Policy.

### Is there extra pay for nights or being on call?

In Technology and Operations and extended-hours branches, $2.00 per hour (in your country's currency) for hours between 18:00 and 06:00. On-call pays $200 CAD / $150 USD per week, with a 3-hour call-out minimum. See HR-POL-003 Working Hours and Overtime Policy.

## 4. Time off and leaves

### How much vacation, or PTO, do I get?

Vacation depends on completed years of service at 1 January: 15 days (under 3 years), 20 (3 to under 10), 25 (10 to under 20) and 30 (20 or more), in both countries. Sick days, personal days and holidays are separate. See HR-POL-006 Vacation and Paid Time Off Policy.

### What happens to my vacation if I start in July?

It accrues monthly from your start date, pro-rated and rounded up to the nearest half day. At 1.25 days a month, July to December gives about 7.5 days. You can request vacation from day 1 and take it after 3 months of service. See HR-POL-006 Vacation and Paid Time Off Policy.

### Can I carry vacation into next year?

Up to 5 days, used by 31 March; the rest is forfeited unless you were on approved leave or the law requires payment. See HR-POL-006 Vacation and Paid Time Off Policy.

### How early must I request vacation?

At least 4 weeks ahead for 5 or more days, and 5 business days ahead for fewer. Your manager responds within 5 business days. See HR-POL-006 Vacation and Paid Time Off Policy.

### How many sick days do I get, and do I need a doctor's note?

Canada gets 10 paid sick days per calendar year and the US gets 8, pro-rated for new hires. A certificate is needed from the 4th consecutive working day, or after 3 days in Quebec. See HR-POL-007 Sick Leave and Personal Leave Policy.

### Can I use sick days to care for my child?

Yes, up to 5 of them for family care. See HR-POL-007 Sick Leave and Personal Leave Policy.

### What if I'm off sick for a long time?

Short-term disability starts after 5 consecutive working days: 100% of base salary for weeks 1 to 13 and 75% for weeks 14 to 26. Long-term disability starts at week 27 at 66 2/3% of base salary, to $15,000 per month. Apply in MyHR within 5 business days of going off work. See HR-POL-007 Sick Leave and Personal Leave Policy.

### What are personal days?

Three per calendar year for any reason, with 24 hours' notice where possible, no certificate, and no carryover. See HR-POL-007 Sick Leave and Personal Leave Policy.

### How long is mat leave?

In Canada, pregnancy leave is up to 17 weeks, with a Bank top-up to 100% of base salary for those 17 weeks after 6 months of service. In the US, any new parent gets 12 weeks of paid parental leave at 100% of base salary. See HR-POL-008 Parental and Family Leave Policy.

### What about the other parent, or adoption?

In Canada, non-birth, adoptive and surrogacy-intended parents get a top-up to 100% for 8 weeks. In the US the 12 weeks also covers adoption and foster care. Give 4 weeks' notice on FORM-HR-012 where possible. See HR-POL-008 Parental and Family Leave Policy.

### How much bereavement leave do I get?

Five paid days for a spouse, partner, child, parent or sibling; 3 for a grandparent, grandchild or in-law; 1 for an aunt, uncle, niece, nephew or close friend. Up to 3 unpaid travel days are added (5 if over 800 km one way). See HR-POL-026 Bereavement, Jury Duty and Other Leaves Policy.

### Can I take an unpaid leave of absence?

Up to 6 months after 2 years of service, approved by your Director and HRBP (FORM-HR-010). Benefits continue only if you pay both shares. See HR-POL-007 Sick Leave and Personal Leave Policy.

### Can I take a sabbatical?

The HR policies do not describe a sabbatical programme. Unpaid personal leave or vacation are the closest options, so contact HR Connect to ask about anything else. See HR-POL-007 Sick Leave and Personal Leave Policy.

### Can I take time off for a seriously ill relative?

In Canada, compassionate care leave is up to 28 weeks, and critical illness leave is up to 37 weeks for a child or 17 for an adult. In the US, FMLA caregiver leave is up to 12 weeks. All are unpaid. See HR-POL-008 Parental and Family Leave Policy.

### Do I get time off to vote or volunteer?

Up to 3 consecutive paid hours to vote if poll hours do not already allow it, and 1 paid volunteer day per calendar year, requested 10 business days ahead. See HR-POL-026 Bereavement, Jury Duty and Other Leaves Policy.

## 5. Pay and incentives

### Who do I call if my pay is short?

Call HR Connect at 1-800-555-0142 or file FORM-HR-021 in the HR Case Portal. A missed pay is P1, answered within 4 business hours. A $250 or greater net shortfall is paid off-cycle within 3 business days of confirmation; smaller ones are fixed on the next regular pay date. See HR-POL-009 Compensation and Payroll Policy.

### When do I get paid?

Biweekly in arrears: Thursdays in Canada and Fridays in the US. Your statement is in MyHR 2 business days before. See HR-POL-009 Compensation and Payroll Policy.

### When do I get my raise?

Salary reviews are annual, effective 1 March, based on your year-end rating. Promotion increases are handled separately. See HR-POL-009 Compensation and Payroll Policy.

### How does my bonus work?

The Annual Incentive Plan pays a target percentage of base salary by band, from 5% in Bands 1 to 3 to 45% in Band 9, adjusted by business funding and your rating. You must be hired by 31 July and on payroll on 31 October and the payment date, which is the first pay date in February. See HR-POL-009 Compensation and Payroll Policy.

### What if I resign before the bonus is paid?

A voluntary leaver not on payroll on the payment date forfeits it. See HR-POL-015 Resignation and Offboarding Policy.

### I was overpaid. Must I repay it all at once?

No. You can repay by lump sum, payroll deduction of at most 15% of net pay per period, or a plan of up to 12 months. See HR-POL-009 Compensation and Payroll Policy.

### Can I get a salary advance?

The policies describe only a vacation advance of up to 5 days, not salary advances. Contact HR Connect. See HR-POL-006 Vacation and Paid Time Off Policy.

## 6. Benefits and retirement

### When can I enrol in benefits?

Within 31 days of hire or a qualifying life event; otherwise at annual enrolment, 2 to 16 November 2026 for coverage from 1 January 2027. The default is Standard (Canada) or Choice PPO employee-only (US). See HR-GDE-001 Employee Benefits Guide.

### What goes into my US health savings account?

On the Saver HDHP, the Bank deposits $750 (individual) or $1,500 (family) in January, pro-rated for new hires. See HR-GDE-001 Employee Benefits Guide.

### What is the retirement match?

Canada: auto-enrolment at 4% after 30 days, a 2% Bank base contribution and 100% match on your first 4%, vested immediately. US 401(k): 5% auto-enrolment rising 1% a year to 8%, the same 2% plus match, vesting after 2 years. See HR-GDE-002 Retirement and Savings Plan Guide.

### What is the most I can contribute?

Statutory limits are set by the tax authorities each year and the guide does not state them. Call Evergreen Retirement Services at 1-800-555-0188 or HR Connect. See HR-GDE-002 Retirement and Savings Plan Guide.

### How much notice do I give to retire?

Three months. Early retirement is available from age 55 with 5 years in the plan. See HR-GDE-002 Retirement and Savings Plan Guide.

### Where can I get mental health support?

The Wellspring Support Program, free and confidential 24/7 at 1-800-555-0166, with up to 8 counselling sessions per issue per calendar year for you and your household. See HR-GDE-001 Employee Benefits Guide.

### When does coverage end if I leave?

At the end of the month. Canadians have 31 days to convert life insurance; US employees get a COBRA notice within 14 days and 60 days to elect. See HR-GDE-001 Employee Benefits Guide.

## 7. Performance and development

### When do I get my rating?

By 15 January for the year ending 31 October. The scale runs 1 Outstanding to 5 Unsatisfactory, with 3 Meets Expectations. See HR-POL-011 Performance Management Policy.

### What are the key performance dates?

Goals by 15 December (30 days for new hires), mid-year check-in 1 May to 15 June, self-assessment 15 November, manager assessment 10 December. See HR-POL-011 Performance Management Policy.

### I disagree with my rating. What can I do?

Write to your HRBP within 10 business days of being told. Your manager's manager and the HRBP review it within 15 business days, and that decision is final. See HR-POL-011 Performance Management Policy.

### What is a PIP?

A performance improvement plan: 60 days as standard (30 to 90), weekly check-ins, a written plan on FORM-HR-070, and a support person who is not legal counsel if you wish. See HR-POL-013 Performance Improvement Policy.

### How much does the Bank pay for courses?

A $2,000 professional development budget per fiscal year, plus tuition reimbursement up to $5,000 CAD / $5,250 USD after 6 months of service with a Meets Expectations rating. Pre-approve on FORM-HR-060 at least 15 business days ahead. See HR-POL-012 Learning and Development Policy.

### Can I get a promotion or transfer?

Promotions and transfers are handled separately and are not covered here. Ask your manager, HRBP or HR Connect. See HR-POL-011 Performance Management Policy.

## 8. Joining, changing and leaving

### How long is probation?

Three months, extendable once to 6 with written notice before month 3 ends. See HR-POL-014 Employment Status and Classification Policy.

### What paperwork do I need on day one?

Canada: Social Insurance Number within 3 business days, tax credit return forms, direct deposit and proof of right to work. US: Form I-9 within 3 business days, Form W-4 and direct deposit. See HR-GDE-003 New Employee Onboarding Guide.

### How much notice do I give if I quit?

Two weeks for Bands 1 to 4, 4 weeks for Bands 5 and 6, and 8 weeks for Band 7 and above, on FORM-HR-080. Return equipment within 5 business days. See HR-POL-015 Resignation and Offboarding Policy.

### When do I get my final pay?

On the next regular pay date but not later than the legal deadline; in Ontario the later of 7 days after employment ends or the next pay date, and in California immediately on termination. Unused earned vacation is included. See HR-POL-015 Resignation and Offboarding Policy.

### If I get a pink slip, what do I receive?

The greater of the statutory minimum and the Bank formula. Canada: 2 weeks of base pay per year of service, minimum 8, maximum 52 weeks. US: 1 week per year, minimum 4, maximum 26. See HR-POL-025 Involuntary Termination and Severance Policy.

## 9. Privacy, security and accommodation

### How do I see what the Bank holds about me?

File FORM-HR-090. The Bank responds within 30 days, with a possible further 30 days if you are notified. See HR-POL-016 Employee Data Privacy Policy.

### I clicked a suspicious link. What now?

Use the Report Phishing button immediately, and report any suspected incident or lost device to the Security Operations Centre at 1-800-555-0155 within 1 hour at most. See HR-POL-017 IT Acceptable Use and Information Security Policy.

### Who sees my medical information?

It is stored apart from your personnel file, and your manager gets only functional limitations and expected duration, never a diagnosis. See HR-POL-018 Workplace Accommodation and Accessibility Policy.

### How do I ask for an accommodation?

Tell your manager, HR Connect or accommodations@bank.example; the word "accommodation" is not required. HR acknowledges within 2 business days and decides within 10 business days of complete information (3 if urgent). See HR-POL-018 Workplace Accommodation and Accessibility Policy.

### What if I'm hurt at work?

Tell your manager and Corporate Security immediately and record it in MyHR within 24 hours. See HR-POL-023 Workplace Health, Safety and Wellness Policy.

## 10. Conduct and speaking up

### How do I report harassment?

Tell your manager, HRBP, Employee Relations, the Speak-Up Line (1-800-555-0177) or, for violence, Corporate Security (911 first in an emergency). Reports are acknowledged within 2 business days and retaliation is prohibited. See HR-POL-005 Workplace Harassment and Violence Prevention Policy.

### Can I report something anonymously?

Yes, through the Speak-Up Line, run by Clearline, 24 hours a day, 7 days a week. See HR-POL-022 Whistleblower and Speak-Up Policy.

### Can I accept a gift from a client?

Up to $100 per occasion and $250 cumulative per source per calendar year; above that needs FORM-HR-101. Never cash or gift cards. See HR-POL-001 Code of Conduct and Ethics.

### Can I post about my job on social media?

It depends on what you post. Never share confidential information or speak for the Bank without authorization; ask the Ethics Office if unsure. See HR-POL-027 Social Media and External Communications Policy.

### What happens if I'm late or miss work?

Tell your manager before your start time, or within 30 minutes after it if you cannot. A pattern review begins after 3 late arrivals in 30 days, or 4 absence occurrences or 8 absence days in 12 months, excluding protected absences. See HR-POL-004 Attendance and Absenteeism Policy.

## 11. Getting HR help

### How do I reach HR?

HR Connect: 1-800-555-0142, hrconnect@bank.example, or live chat in MyHR, Monday to Friday 8:00 to 20:00 Eastern Time, closed on Bank holidays, in English and French. See HR-GDE-004 HR Service and Support Guide.

### How fast will HR answer?

First response within 4 business hours for P1, 1 business day for P2, 2 for P3 and 3 for P4. See HR-GDE-004 HR Service and Support Guide.

### What if HR misses its deadline?

Escalate to the HR Operations manager after one missed deadline, then the VP HR Operations, then the Office of the CHRO. See HR-GDE-004 HR Service and Support Guide.

### I'm a manager. Who do I call?

The Manager Hotline, 1-800-555-0143, which responds within 4 business hours. See HR-GDE-005 Manager's HR Procedures Guide.

## 12. Related documents and contacts

For anything not answered here, contact HR Connect. Terms are defined in HR-REF-001 HR Glossary.

## 13. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2026.1 | 2026-01-05 | Annual refresh: 3-day hybrid rule, 10 and 8 sick days, 5-day vacation carryover |
| 2026.2 | 2026-04-01 | Updated payroll correction threshold to $250 |
| 2026.3 | 2026-10-26 | Added questions on cross-border work, moving provinces, time in lieu and unanswerable topics |
