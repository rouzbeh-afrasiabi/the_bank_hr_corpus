# Leave of Absence Request

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-010 |
| Title | Leave of Absence Request |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-007, HR-POL-006, HR-POL-008, FORM-HR-012, FORM-HR-013 |

## 1. Purpose and when to use this form

Use this form to request an unpaid personal leave of absence of up to 6 months. Do not use it for parental leave (FORM-HR-012), family caregiver leave (FORM-HR-013), vacation, sick days or disability claims.

## 2. Who completes it and who approves

You complete it. The Director and your HR Business Partner (HRBP) both approve. You need at least 2 years of service.

## 3. Where and when to submit

Submit in MyHR (HR Case Portal) at least 30 days before the leave starts where possible. The Leaves team gives a first response within 2 business days and records the decision in MyHR.

## 4. Form fields

| Field | Required | Notes |
| --- | --- | --- |
| Employee name and ID | Yes | Pre-filled from MyHR |
| Manager, Director, HRBP | Yes | Pre-filled |
| Service date | Yes | Must show 2 or more years |
| First day of leave | Yes | |
| Planned return date | Yes | Maximum 6 months after the first day |
| General reason | Yes | A short description is enough; no medical detail |
| Benefits choice | Yes | Continue by paying both the employee and Bank shares, or suspend |
| Work handover plan | Yes | Agreed with your manager |
| Vacation balance to use before leave | No | |

## 5. Declarations and signatures

- I understand the leave is unpaid.
- I understand vacation stops accruing after 30 days of leave.
- I understand my benefits continue only if I pay both shares of the premiums.
- I understand I will return to the same or a comparable role.
- The information is accurate.

Sign electronically in MyHR; the manager, Director and HRBP sign when they approve.

## 6. What happens next

The Leaves team confirms the dates in writing and notifies Payroll Services and Benefits Administration. Service stays continuous. If your plans change, tell the Leaves team before the planned return date. Where applicable law gives a greater right, the law applies. Questions: HR Connect, 1-800-555-0142, hrconnect@bank.example.

## 7. Related documents

- HR-POL-007 Sick Leave and Personal Leave Policy
- HR-POL-006 Vacation and Paid Time Off Policy
- HR-POL-008 Parental and Family Leave Policy

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-01-01 | Aligned with HR-POL-007 version 3.0 and the MyHR form layout. |
