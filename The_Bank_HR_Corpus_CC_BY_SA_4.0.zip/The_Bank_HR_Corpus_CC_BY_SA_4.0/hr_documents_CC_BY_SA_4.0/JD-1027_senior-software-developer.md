# Senior Software Developer

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1027 |
| Title | Senior Software Developer |
| Document type | Job description |
| Version | 2.1 |
| Status | Current |
| Effective date | 2026-02-02 |
| Last reviewed | 2026-09-15 |
| Next review | 2027-09-15 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-POL-002, HR-POL-012, HR-POL-017 |

## 1. Role summary

The Senior Software Developer leads the technical design and delivery of complex applications and services. The role sets coding and architecture standards inside the team, makes sound trade-offs between speed, resilience and security, and mentors other developers. A Band 4 developer is recognized for depth in a technical field and handles work that crosses systems or teams.

## 2. Key responsibilities

- Lead the design of services and components, document decisions and gain agreement from architects and peers.
- Write and review high-quality, secure and well-tested code on the most complex parts of the system.
- Break epics into deliverable stories and estimate them with the Technology Team Lead and product owner.
- Raise the team's engineering standards through code review, pairing and shared tooling.
- Mentor Professional-level developers and help them plan their growth.
- Design for resilience, observability and performance, and drive fixes for production incidents to root cause.
- Work with Information Security and Site Reliability Engineering on threat modelling and operational readiness.
- Evaluate new libraries, frameworks and platforms and recommend adoption with risks stated.
- Partner with Business Analysts and product owners to refine requirements and challenge unclear scope.
- Support production releases and take part in the on-call rotation.
- Use only Bank-approved tools, including AI tools, as required by HR-POL-017 IT Acceptable Use and Information Security Policy.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in computer science, software engineering or a related field, or equivalent experience.
- Typically 5 to 8 years of professional development experience, including ownership of production services.
- Expert-level skill in at least one modern programming language and strong knowledge of distributed-system design.
- Experience with automated testing, continuous delivery and secure development practices.

### 3.2 Preferred

- Experience designing event-driven services and public-cloud solutions.
- Experience in regulated financial services.
- Cloud architecture or secure-development certification; see HR-POL-012 Learning and Development Policy for reimbursement of designations.

### 3.3 Licences and certifications

None required.

## 4. Competencies

Measured against HR-FWK-001 Competency and Leadership Model at the Practitioner level:

- Judgement and Decision Quality
- Developing Others
- Collaboration
- Drive for Results
- Adaptability
- Risk and Conduct Awareness

## 5. Compensation and classification

| Item | Value |
| --- | --- |
| Band | 4 (Senior Professional) |
| Canada range | $72,000 to $108,000 CAD |
| US range | $70,000 to $106,000 USD |
| Incentive target | 8% of base salary (Annual Incentive Plan) |
| Overtime eligibility, Canada | Yes (non-managerial Band 4) |
| FLSA classification, US | Exempt |
| Work arrangement | Hybrid (at least 3 days a week in the office) |

Band definitions are in HR-GDE-006 Job Architecture and Pay Bands Guide.

## 6. Working conditions and accessibility

This is an office role with a hybrid arrangement under HR-POL-002 Remote and Hybrid Work Policy: at least 3 days a week in the office, including the Tuesday and Thursday anchor days. The on-call allowance and call-out minimum in HR-POL-003 Working Hours and Overtime Policy apply when on call. The Bank provides accommodation to the point of undue hardship; see HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to: Technology Team Lead. Direct reports: none (technical guidance to Software Developers).

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.1 | 2026-02-02 | Updated hybrid and tooling wording |
| 2.0 | 2024-07-01 | Added mentoring and design leadership duties |
| 1.0 | 2023-07-01 | First issue |
