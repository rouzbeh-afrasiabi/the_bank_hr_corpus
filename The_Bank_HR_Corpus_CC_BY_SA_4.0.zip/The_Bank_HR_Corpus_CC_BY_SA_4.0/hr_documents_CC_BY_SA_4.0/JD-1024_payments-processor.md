# Payments Processor

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1024 |
| Title | Payments Processor |
| Document type | Job description |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-04-01 |
| Last reviewed | 2026-06-30 |
| Next review | 2027-06-30 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-POL-003, HR-POL-018, HR-POL-044 |

## 1. Role summary

The Payments Processor handles the release, repair and reconciliation of customer and commercial payments: domestic transfers, wires, cheques and electronic funds transfers. The role exercises judgement on exceptions, applies screening and fraud controls and meets strict cut-off times. Payments Processors work under general guidance and are the Bank's first line of defence against payment errors and fraud.

## 2. Key responsibilities

- Process incoming and outgoing payments accurately before each payment-system cut-off time.
- Repair rejected or incomplete payment messages by checking details with customers or branches.
- Review payments held by sanctions and fraud screening and escalate suspicious items according to procedure.
- Apply dual control to wires and high-value items, and never release a payment you initiated yourself.
- Reconcile payment accounts daily and investigate and clear differences.
- Handle recall, amendment and investigation requests from customers and other institutions.
- Document actions in the case system so that any colleague can pick up an item.
- Meet daily productivity and accuracy targets, and give feedback on process improvements.
- Take part in business-continuity tests and follow outage procedures for payment systems (see HR-POL-044 Business Continuity and Severe Weather Policy).
- Record time and overtime in Time Tracker each week.

## 3. Qualifications

### 3.1 Required

- High school diploma or equivalent.
- 1 to 3 years of experience in payments, banking operations or a similar transaction-processing role.
- Knowledge of payment types, cut-off windows and exception handling.
- Careful, well-organized and comfortable working to deadlines.

### 3.2 Preferred

- Diploma or degree in business, finance or accounting.
- Experience with sanctions screening tools in general terms.
- Bilingual English and French.

### 3.3 Licences and certifications

None required. A recognized payments-industry certificate is an asset.

## 4. Competencies

Measured against HR-FWK-001 Competency and Leadership Model at the Foundation level:

- Risk and Conduct Awareness
- Judgement and Decision Quality
- Drive for Results
- Customer Obsession
- Collaboration

## 5. Compensation and classification

| Item | Value |
| --- | --- |
| Band | 2 (Associate) |
| Canada range | $44,000 to $64,000 CAD |
| US range | $43,000 to $62,000 USD |
| Incentive target | 5% of base salary (Annual Incentive Plan) |
| Overtime eligibility, Canada | Yes (non-managerial Band 2) |
| FLSA classification, US | Non-exempt |
| Work arrangement | On-site (payments operations centre) |

Overtime, the $2.00 per hour shift premium for hours between 18:00 and 06:00, and the on-call allowance and call-out minimum are set in HR-POL-003 Working Hours and Overtime Policy. Band definitions are in HR-GDE-006 Job Architecture and Pay Bands Guide.

## 6. Working conditions and accessibility

This is an on-site role in a payments operations centre, with posted schedules that may include early, late or weekend coverage around payment-system windows. Peak days (month-end, pay days) may need planned overtime, which must be pre-approved. Hybrid work does not generally apply because of secure-system and dual-control requirements. The Bank provides accommodation to the point of undue hardship; see HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to: Team Lead, Operations. Direct reports: none.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-04-01 | Reworked responsibilities for sanctions and fraud review |
| 1.0 | 2023-04-01 | First issue |
