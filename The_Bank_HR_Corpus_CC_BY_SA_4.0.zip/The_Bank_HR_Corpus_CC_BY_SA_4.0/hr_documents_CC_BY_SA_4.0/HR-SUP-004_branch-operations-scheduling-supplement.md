# Branch Operations Scheduling Supplement

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-SUP-004 |
| Title | Branch Operations Scheduling Supplement |
| Document type | Supplement |
| Version | 3.0 |
| Status | Current |
| Effective date | 2025-04-01 |
| Last reviewed | 2026-06-15 |
| Next review | 2027-06-15 |
| Policy owner | VP HR Operations |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-003, HR-POL-006, HR-POL-010, HR-POL-023, HR-POL-004, HR-SUP-002, FORM-HR-020 |

## 1. Purpose

This supplement explains how schedules, shifts, breaks and cash-handling routines work in Bank branches and in on-site operations teams that follow posted schedules. It applies the rules in HR-POL-003 Working Hours and Overtime Policy to branch life and adds practical routines. Where applicable law gives a greater right, the law applies.

## 2. Scope

The supplement applies to branch employees and on-site operations employees in Canada and the US whose hours follow a posted schedule, including regular full-time, regular part-time, fixed-term and casual employees. Office-based employees on core hours of 10:00 to 15:00 are not covered. California employees also follow HR-SUP-002 California Supplement.

## 3. Schedules

### 3.1 Posting and changes

| Rule | Requirement |
| --- | --- |
| Posting | Schedules are posted at least 14 days ahead |
| Change with less than 96 hours' notice | Needs the employee's consent |
| Shift added with less than 24 hours' notice | The employee may decline, without any penalty |
| Daily and weekly limits | No scheduling beyond 12 hours a day or 48 hours a week without VP approval and the employee's written consent |
| Rest between shifts | At least 8 hours |
| Weekly rest | At least 24 consecutive hours off per week |

**Example.** The schedule for the week starting Monday 2026-11-23 must be posted by Monday 2026-11-09. If on Monday 2026-11-16 at 09:00 a manager wants to move a Thursday 08:00 shift, that is 71 hours' notice, so the employee must consent. If a shift is added on Tuesday at 14:00 for Wednesday 09:00 (19 hours' notice), the employee may decline.

### 3.2 Swaps

Employees may swap shifts with a colleague who is qualified for the same duties. Both employees record the swap in Time Tracker and the manager approves it within 1 business day. A swap must still respect the 8-hour rest rule, the weekly limits and the overtime rules.

### 3.3 Saturday rota

Where a branch opens on Saturday, the manager publishes the Saturday rota with the schedule. Saturday work is shared fairly across the team. No employee is rostered on more than 2 consecutive Saturdays unless they agree, and volunteers are asked first. Saturday hours are paid under HR-POL-003, with overtime if the weekly or daily thresholds are exceeded.

## 4. Meal periods and rest breaks

| Item | Canada | US except California | California |
| --- | --- | --- | --- |
| Meal period | 30 minutes unpaid, after at most 5 consecutive hours | Same as Canada | 30 minutes, taken before the end of the 5th hour |
| Rest breaks | Two paid 15-minute breaks per full shift | Two paid 15-minute breaks per full shift | A paid 10-minute break per 4 hours worked |

The standard 60-minute meal period may be shortened to 30 minutes with the manager's agreement. The branch manager staggers breaks so that the counter, the phones and the cash area stay covered. An employee is relieved of duties during a meal period and is never asked to stay at the counter. Breaks are not skipped to leave early.

## 5. Dual control and cash handling

- Opening and closing are done by two people. Employees do not work alone in a branch after hours unless a lone-working check-in plan is in place (see HR-POL-023 Workplace Health, Safety and Wellness Policy).
- Cash, vault access and alarm codes are controlled by the branch manager. Vault and safe access needs two authorized employees.
- Cash counts and balancing are completed by one employee and verified by a second. The same person does not count and verify the same drawer.
- An employee never processes, approves or reviews a transaction on their own accounts or accounts of relatives, friends or colleagues (see HR-POL-001 Code of Conduct and Ethics).
- Any difference is reported to the branch manager the same day.

## 6. Robbery protocol

During a robbery, every employee:

1. complies calmly and does not resist;
2. activates the alarm only when it is safe;
3. notes descriptions and does not touch anything the robber touched;
4. calls 911 after the robber has left, then Corporate Security on 1-800-555-0119;
5. keeps the branch closed until the police release it.

After any robbery or threat, the Wellspring Support Program (1-800-555-0166) is offered immediately and a debrief is held within 24 hours. The full protocol is in HR-POL-023.

## 7. Absences and weather

An absence is reported to the branch manager and to the employee's manager before the scheduled start, or within 30 minutes after it (see HR-POL-004 Attendance and Absenteeism Policy). Closure decisions are announced by 6:30 local time through a MyHR alert, a text message and the intranet banner. Employees at a closed branch are paid for the day.

## 8. Vacation and December blackout

For some branch roles the last 2 weeks of December are a vacation blackout. The business unit head publishes the blackout in MyHR by 1 November for the following year, and it applies only to the roles named. A branch employee is never refused all of their vacation in a year because of blackouts (see HR-POL-006 Vacation and Paid Time Off Policy). Employees still take the 10-consecutive-business-day block leave.

## 9. Holiday coverage

Branches that open on a Bank holiday plan coverage fairly (see HR-POL-010 Statutory Holidays Policy). An employee who works a Bank holiday receives regular holiday pay plus 1.5x for the hours worked. In Canada, the employee may choose 1.5x time in lieu taken within 60 days instead of the premium. US non-exempt employees are paid in cash. The manager records the choice on FORM-HR-020 before the holiday. Part-time employees' holiday pay is the average daily earnings over the previous 20 working days. HR Operations publishes the holiday calendar each year by 1 October.

## 10. Premiums, overtime and time entry

- Branches with extended hours pay a shift premium of $2.00 per hour (CAD in Canada, USD in the US) for hours worked between 18:00 and 06:00.
- Overtime must be pre-approved in Time Tracker. More than 8 overtime hours in a week needs Director approval and HR notification.
- Non-exempt employees enter start, end and meal times by Friday 17:00 local time; the manager approves by Monday 12:00 local time.
- Employees have no obligation to answer messages outside their scheduled hours, except when on call.

## 11. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Employee | Works the posted schedule, records time, reports differences and incidents |
| Branch manager | Posts schedules on time, obtains consent for short-notice changes, protects breaks and rest, runs dual control |
| Regional manager | Approves schedules beyond limits with the VP, monitors fairness of the Saturday rota |
| HRBP | Advises on scheduling disputes and coverage |
| VP HR Operations | Owns this supplement |

## 12. Contacts

HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time, hrconnect@bank.example. Manager Hotline: 1-800-555-0143. Corporate Security: 1-800-555-0119 (24/7).

## 13. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2023-07-01 | Added the Saturday rota and shift swap rules |
| 3.0 | 2025-04-01 | Aligned schedule notice rules with HR-POL-003, added the dual control summary and the holiday coverage section |
