# Termination Letter, For Cause

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-TPL-005 |
| Title | Termination Letter, For Cause |
| Document type | Template |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-06-30 |
| Next review | 2027-06-30 |
| Policy owner | VP Employee Relations |
| Audience | HR only |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-021, HR-POL-025, HR-PRC-004, HR-TPL-004 |

## 1. Purpose and when to use this template

This template confirms a termination for cause after an investigation and the approvals required by HR-POL-021 Employee Relations and Progressive Discipline Policy. It is used only when the VP Employee Relations and Legal have approved the termination for cause. For a termination without cause use HR-TPL-004 Termination Letter, Without Cause.

## 2. How to use this template

1. Attach written evidence of the approvals by the VP Employee Relations and Legal to the case file.
2. Confirm that the employee had the chance to respond (HR-POL-021 gives the employee 5 business days to respond in writing to a warning) and that the investigation outcome is documented.
3. Complete the placeholders. Describe the conduct in neutral, factual terms.
4. Hold the meeting as described in HR-PRC-004 Termination Checklist and Protocol, with Corporate Security on standby where needed.

## 3. Letter text

**[Date]**   **Personal and confidential**

**[Employee full name]**, [Employee ID]

**Subject: Termination of employment for cause**

Dear [Employee first name],

This letter confirms that the Bank has terminated your employment as **[Job title]**, Band **[Band]**, for cause, effective **[Termination date]**. Your access to Bank systems and premises ended on **[Date and time access ended]**.

**Reasons.** The termination follows an investigation (reference **[Case reference]**) which found that **[Neutral summary of the substantiated conduct]**. This conduct breaches **[Policy ID and title]** and the Code of Conduct and Ethics. **[Where relevant: You were given the opportunity to respond on [date].]**

**Pay and entitlements.** Because the termination is for cause, you are not entitled to the Bank's enhanced severance, only to the entitlements required by law. You will be paid all earned wages and your unused earned vacation by the legal deadline for **[Work province or state]**. You are not eligible for Annual Incentive Plan pay because you will not be on payroll on the payment date.

**Benefits.** Your benefits end on **[Last day of month]**, the last day of the month in which your employment ends. **[Canada]** You may convert your life insurance within 31 days. **[US]** You will receive a COBRA election notice within 14 days and have 60 days to elect.

**Records and tax slips.** **[Canada]** Your Record of Employment will be issued electronically within 5 calendar days after the end of the pay period in which employment ends; your T4 and, in Quebec, Relevé 1 will be issued by 28 February. **[US]** Your Form W-2 will be issued by 31 January.

**Bank property and confidentiality.** Please return all Bank property within 5 business days. Your confidentiality obligations, and any non-solicitation obligation in your agreement, continue after your employment ends.

**Questions and support.** HR Connect is available at 1-800-555-0142. The Wellspring Support Program, 1-800-555-0166, is available 24 hours a day, confidential and free. The Ombuds Office (ombuds@bank.example) offers confidential, informal advice.

Sincerely,
**[Manager name]**, [Manager title]
**[HRBP name]**, HR Business Partner

## 4. Required clauses checklist

| Clause | Required content |
| --- | --- |
| Effective date | Termination date and access end |
| Reasons | Neutral, factual, cleared by Legal |
| Entitlements | No enhanced severance; statutory entitlements only |
| Final pay | Earned wages and unused vacation by the legal deadline |
| Benefits | End of month; conversion or COBRA information |
| Records | ROE, T4, Relevé 1 or W-2 |
| Support | HR Connect, Wellspring Support Program, Ombuds Office |

## 5. Drafting notes for HR

- A termination for cause needs the approval of the VP Employee Relations and Legal. Do not issue the letter before both approvals are on file.
- Serious misconduct (for example theft, fraud, violence, harassment, breach of confidentiality, falsifying records) may skip progressive steps; suspension with pay pending investigation is up to 10 business days, extendable by the VP Employee Relations.
- Do not add opinions, speculation or the names of complainants or witnesses.
- Statutory entitlements vary by jurisdiction; Legal confirms them before the meeting. Where applicable law gives a greater right, the law applies.
- Retention of the investigation file is set by HR-REF-002 Employee Records Retention Schedule.

## 6. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.0 | 2023-04-03 | First for-cause termination letter template |
| 2.0 | 2025-09-01 | Added approval requirements, neutral-reasons wording and records and benefits clauses |
