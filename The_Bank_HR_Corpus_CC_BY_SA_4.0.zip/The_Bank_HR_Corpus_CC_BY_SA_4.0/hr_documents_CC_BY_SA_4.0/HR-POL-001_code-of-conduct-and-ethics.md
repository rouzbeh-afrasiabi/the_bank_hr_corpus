# Code of Conduct and Ethics

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-001 |
| Title | Code of Conduct and Ethics |
| Document type | Policy |
| Version | 6.0 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-09-10 |
| Next review | 2027-09-10 |
| Policy owner | Head of Ethics Office |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Applies to | All Canadian and US employees (see Scope) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-005, HR-POL-016, HR-POL-017, HR-POL-021, HR-POL-022, HR-POL-027, FORM-HR-100, FORM-HR-101, FORM-HR-102 |

## 1. Purpose

This Code of Conduct and Ethics (the "Code") sets out the standards of honesty, fairness and professionalism that the Bank expects of everyone who works for it. Customers, regulators, shareholders and colleagues trust the Bank with their money, their information and their careers. The Code explains how to protect that trust in everyday decisions and where to get help when the right course of action is not clear.

## 2. Scope

The Code applies to all employees of the Bank in Canada and in the US, including regular, part-time, casual, fixed-term, student, co-op and intern employees, and to members of the Executive Committee. Contractors and agency workers are not employees, but they must follow this Code, HR-POL-017 IT Acceptable Use and Information Security Policy and the mandatory training assigned to them. Where applicable law gives a greater right or sets a stricter standard, the law applies.

## 3. Definitions

- **Conflict of interest:** a situation in which a personal, family, financial or outside interest could influence, or appear to influence, your judgment on behalf of the Bank.
- **Relative:** a spouse or partner, child, parent, sibling, grandparent, grandchild, in-law, or anyone living in your household.
- **Gift:** anything of value given or received without full payment, including meals, tickets, travel, discounts and services. **Entertainment** is a gift that you attend together with the giver.
- **Inside information:** non-public information about the Bank, a client or any issuer that a reasonable investor would consider important in deciding to buy or sell a security.
- **Source:** a single person or organization, together with its affiliates, that offers gifts or entertainment.

## 4. Our values

Every decision under this Code is guided by the Bank values: **Integrity, Customer Focus, Accountability, Collaboration and Inclusion**. These values are also used in performance ratings (see HR-POL-011 Performance Management Policy). When a situation is not covered by a rule, ask four questions: Is it legal? Is it consistent with our values? Would I be comfortable if it were reported in the news? Would a customer be treated fairly?

## 5. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Employees | Know and follow the Code, complete mandatory training, make timely disclosures, raise concerns promptly. |
| Managers | Lead by example, answer questions, escalate concerns to the Ethics Office or HRBP, never discourage a report. |
| Head of Ethics Office | Owns the Code, administers disclosures and attestation, advises on grey areas, reports to the Audit Committee. |
| Chief Compliance Officer | Approves for-profit directorships, administers personal trading rules and the restricted list. |
| HRBP and Employee Relations | Support managers and apply HR-POL-021 Employee Relations and Progressive Discipline Policy. |

## 6. Conflicts of interest

You must avoid, or openly manage, any situation where your personal interests conflict with your duties to the Bank. Typical examples are hiring or supervising a relative, approving a transaction for a business you own, or taking a personal benefit from a supplier.

1. Disclose an actual, potential or perceived conflict using FORM-HR-100 Conflict of Interest Disclosure **within 10 business days** of becoming aware of it.
2. Do not take part in the related decision until the Ethics Office tells you in writing how the conflict will be managed.
3. Managers may not hire, or directly supervise, a relative (see HR-POL-019 Recruitment and Selection Policy).

## 7. Gifts and entertainment

### 7.1 Receiving gifts and entertainment

You may accept a gift or entertainment of reasonable value if all of the following are true:

| Test | Limit |
| --- | --- |
| Value per occasion | Up to $100 |
| Cumulative value from one source | Up to $250 per calendar year |
| Form of the gift | Never cash or cash equivalents, including gift cards |
| Source | Never from a regulator or public official |
| Business context | Not offered while the Bank is selecting a supplier or deciding on a transaction involving the source |

Anything above these limits requires pre-approval on FORM-HR-101 Gift and Entertainment Disclosure. The amounts are in the currency of the country in which you work (CAD or USD). If a gift above the limit arrives unannounced, politely return it or hand it to the Ethics Office within 5 business days.

### 7.2 Giving gifts and entertainment

Business gifts you give on the Bank's behalf must be modest, transparent, recorded accurately in expense reports and never intended to influence a decision. **No gifts or entertainment may be given to public officials**, and none may be given to anyone to obtain an improper advantage.

## 8. Outside activities

Outside business activities, paid or unpaid, and external board seats require **prior approval** using FORM-HR-102 Outside Business Activity Request. For-profit directorships additionally need the approval of the Chief Compliance Officer. Approval will not be given for activities that compete with the Bank, use Bank time, assets or information, create a conflict that cannot be managed, or interfere with your performance or availability. Volunteering for charitable and community organizations does not need approval unless you will handle money or hold a director or officer role. Approvals are reviewed each year at attestation.

## 9. Confidentiality

You must protect confidential information about the Bank, its customers, its employees and its suppliers, both during and after your employment. Use it only for your job, share it only with people who need it, and store and transmit it as required by HR-POL-017 IT Acceptable Use and Information Security Policy. Confidentiality obligations continue after you leave.

### 9.1 Generative AI and public tools

Effective with version 6.0, you must not enter Bank confidential information, client information, employee personal information or inside information into any public or unapproved generative AI tool, chatbot or online translation or summarizing service. Use only Bank-approved AI tools, and remember that you remain responsible for checking the accuracy and fairness of anything an AI tool produces. Suspected disclosures must be reported to the Security Operations Centre immediately and no later than 1 hour after discovery.

## 10. Insider information and personal trading

You may not trade, or tip others to trade, securities while in possession of inside information. You must not disclose inside information except to colleagues with a need to know. Employees in Capital Markets, Wealth Management and Treasury must obtain **pre-clearance** from Compliance before any personal trade in individual securities and must hold each security for a **minimum of 30 days**. Employees in other areas must still observe the restricted list and any blackout notice sent to them. Pre-clearance approvals are valid for the day they are given and the next business day (see HR-POL-032 Personal Trading and Restricted Lists Policy).

## 11. Anti-bribery and corruption

You must never offer, promise, give, request or accept a bribe or kickback, directly or through an agent, supplier or other third party. Facilitation payments, charitable donations and sponsorships made to influence a decision are also prohibited. Dealings with public officials require extra care: do not offer anything of value without written approval from the Chief Compliance Officer. Accurate books and records are required, and falsifying any record is serious misconduct.

## 12. Anti-money laundering and sanctions

You must complete Anti-Money Laundering and Sanctions training each year, know your customer, and report unusual or suspicious activity to Compliance **on the same business day** that you notice it. Never tell a customer or any other person that a report has been or may be made ("tipping off"). You may not process or facilitate transactions with sanctioned persons, entities or jurisdictions, and you must escalate any sanctions match to Compliance before proceeding.

## 13. Client data and records

You may access client records, and your own or relatives' accounts, only where you have a genuine business need. You may not look up, process or approve transactions on your own accounts or accounts of relatives, friends or colleagues out of curiosity or personal interest. All access is logged and audited. See HR-POL-016 Employee Data Privacy Policy for the privacy principles that apply and the 24-hour breach reporting rule.

## 14. Political activity

Your personal political views and activity are your own. When you participate, you must do so on your own time, make clear that you are not speaking for the Bank, and not use Bank resources, premises, email or funds. The Bank does not make political contributions through employees. You must seek approval through FORM-HR-102 before running for or accepting elected or appointed public office. See also HR-POL-027 Social Media and External Communications Policy.

## 15. Speaking up and non-retaliation

If you see or suspect conduct that breaches this Code, the law or Bank policy, speak up. Options include your manager, your HRBP, the Ethics Office at ethics@bank.example, the Ombuds Office at ombuds@bank.example for informal and confidential advice, and the Speak-Up Line (1-800-555-0177, 24 hours, 7 days, anonymous option, operated by Clearline). Concerns about harassment follow HR-POL-005 Workplace Harassment and Violence Prevention Policy. Reports about fraud, accounting or other wrongdoing are handled under HR-POL-022 Whistleblower and Speak-Up Policy.

**The Bank does not tolerate retaliation** against anyone who raises a concern in good faith or who takes part in an investigation. Retaliation is itself a breach of the Code and may result in termination.

## 16. Attestation and training

- Complete the Code of Conduct and Ethics course in the Learning Hub each year within the annual window of 1 August to 31 October.
- Attest to the Code **by 31 October** each year, confirming that you have read it, complied with it, and disclosed all conflicts, outside activities and gifts.
- New hires complete the course and attest **within 30 days** of their start date.
- Late completion follows the mandatory training escalation in HR-POL-012 Learning and Development Policy.

## 17. Consequences of breaching the Code

A breach may lead to corrective action under HR-POL-021 Employee Relations and Progressive Discipline Policy, up to and including termination for cause. Serious breaches, such as bribery, fraud, insider trading and falsifying records, may also be reported to regulators or law enforcement and may result in personal civil or criminal liability. Making a knowingly false report in bad faith is also misconduct.

## 18. Exceptions

Exceptions to the Code are rare and must be approved in writing in advance by the Head of Ethics Office. No exception may permit a breach of law. Waivers for Executive Committee members are reported to the Audit Committee.

## 19. Related documents and contacts

- HR-POL-005 Workplace Harassment and Violence Prevention Policy
- HR-POL-016 Employee Data Privacy Policy
- HR-POL-017 IT Acceptable Use and Information Security Policy
- HR-POL-021 Employee Relations and Progressive Discipline Policy
- HR-POL-022 Whistleblower and Speak-Up Policy
- HR-POL-027 Social Media and External Communications Policy
- Ethics Office: ethics@bank.example; Speak-Up Line 1-800-555-0177; HR Connect 1-800-555-0142.

## 20. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 6.0 | 2026-01-01 | Introduced a cumulative gift and entertainment cap of $250 per source per calendar year and added the generative AI confidentiality clause (section 9.1). |
| 5.0 | 2024-01-01 | Previous version. Gift and entertainment limit was $150 per occasion with no cumulative cap. |
