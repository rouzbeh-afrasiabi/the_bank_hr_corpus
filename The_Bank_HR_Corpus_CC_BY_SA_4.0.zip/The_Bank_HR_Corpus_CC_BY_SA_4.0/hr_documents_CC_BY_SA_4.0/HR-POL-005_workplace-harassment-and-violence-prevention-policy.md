# Workplace Harassment and Violence Prevention Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-005 |
| Title | Workplace Harassment and Violence Prevention Policy |
| Document type | Policy |
| Version | 5.0 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-07-08 |
| Next review | 2027-07-08 |
| Policy owner | VP Employee Relations |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Applies to | All Canadian and US employees (see Scope) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-001, HR-POL-018, HR-POL-021, HR-POL-022, HR-POL-023, FORM-HR-050 |

## 1. Purpose

The Bank is committed to a workplace that is safe, respectful and free from harassment, discrimination and violence. This policy defines unacceptable behaviour, explains how to report it, and sets out how the Bank responds, investigates and prevents it. Every person is entitled to be treated with dignity, whether at a desk, in a branch, at home on a video call or at a client event.

## 2. Scope

This policy applies to all employees of the Bank in Canada and in the US, including managers and executives. It covers conduct at any Bank workplace, in remote and hybrid work settings, at Bank-sponsored events and social gatherings, on business travel, and in any online or digital communication (including after-hours messages and social media) that affects the working relationship. It also covers conduct by or towards customers, suppliers, contractors, agency workers and visitors. Where applicable law gives a greater right or a stricter standard, the law applies.

## 3. Definitions

### 3.1 Harassment

Harassment is any single or repeated comment, conduct, gesture or display that is known, or ought reasonably to be known, to be unwelcome, and that offends, humiliates, intimidates or degrades a person. Examples include insults, slurs, threats, offensive jokes, spreading rumours, deliberate exclusion, abuse of authority, persistent unwanted contact, and sharing demeaning images or messages.

### 3.2 Sexual harassment

Sexual harassment is harassment of a sexual nature, including unwelcome advances, requests for sexual favours, sexual comments or jokes, unwelcome touching, display of sexually explicit material, and any conduct where submission or rejection is linked, directly or implicitly, to a job decision. It can occur between people of any gender and regardless of seniority.

### 3.3 Discrimination

Discrimination is treating a person differently, or adversely, because of a characteristic protected by human rights or employment law, such as race, colour, ancestry, national or ethnic origin, religion or creed, sex, pregnancy, gender identity or expression, sexual orientation, age, marital or family status, disability, or veteran status. Discrimination may be a form of harassment, but it can also occur through a single decision, rule or practice. Concerns about unequal treatment in hiring, pay, scheduling or accommodation are reviewed under this policy as well as HR-POL-018 Workplace Accommodation and Accessibility Policy.

### 3.4 What is not harassment

Reasonable management actions carried out fairly, such as performance feedback, setting goals, assigning work, scheduling, and corrective action under HR-POL-021 Employee Relations and Progressive Discipline Policy, are not harassment. Disagreements and workplace conflict, without disrespect or abuse, are also not harassment, although the Ombuds Office can help resolve them.

### 3.5 Violence

Workplace violence is the use or threat of physical force against a person that could cause injury, including attempts, threatening statements or behaviour, stalking, and property damage intended to intimidate. It includes robbery and aggressive behaviour by customers.

### 3.6 Domestic violence at work

Domestic or family violence that follows a person into the workplace, such as an abuser calling, visiting or monitoring an employee at work, is treated as a workplace safety matter. An employee affected may request workplace safety planning with Corporate Security, a referral to the Wellspring Support Program, and paid domestic and family violence leave under HR-POL-026 Bereavement, Jury Duty and Other Leaves Policy. The employee's disclosure is kept confidential and is shared only as needed to protect people.

### 3.7 Third-party and customer harassment

The Bank does not expect employees to tolerate harassment or violence from customers, suppliers or visitors. An employee who experiences it should leave the interaction safely, tell their manager, and report it through any channel in section 5. The Bank will take reasonable steps, which may include warning or restricting a customer, ending a relationship, or involving law enforcement.

## 4. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| All employees | Treat others respectfully, complete training, report what they see or experience, co-operate with reviews. |
| Managers | Model respectful behaviour, act promptly when they see or hear of an issue even without a formal complaint, and refer every report to Employee Relations on the same business day. |
| Designated recipient (Employee Relations) | Receives complaints, acknowledges them, arranges interim measures and assigns investigators. |
| HRBP | Supports employees and managers and helps arrange interim measures. |
| Corporate Security | Responds to threats and violence, safety planning and emergencies. |
| VP Employee Relations | Owns this policy, approves outcomes in serious cases and reports annually to the HR Policy Committee. |
| Head of Workplace Safety | Leads the annual workplace assessment with the Workplace Health and Safety Committees (see HR-POL-023 Workplace Health, Safety and Wellness Policy). |

## 5. How to report

You may report to any of the following. You do not need to tell the person involved first, and you can choose the channel you trust most:

- your manager or a more senior manager;
- your HRBP;
- the **designated recipient** in Employee Relations, through the HR Case Portal in MyHR;
- the **Speak-Up Line**, 1-800-555-0177, 24 hours a day, 7 days a week, with an anonymous option (operated by Clearline), or the Speak-Up page in MyHR;
- **Corporate Security** at 1-800-555-0119 (24 hours) for violence or threats.

**FORM-HR-050 Harassment and Violence Complaint Intake** is the standard intake form. A verbal or written report is also accepted, and the designated recipient will complete the form with you. Complaints are encouraged within 12 months of the last incident, but there is **no hard deadline**. An employee may also file a complaint with a human rights commission, the EEOC or another government agency, and nothing in this policy limits that right.

The Ombuds Office (ombuds@bank.example) provides informal, confidential, independent guidance and is not a place to file a formal complaint.

## 6. Process and timelines

| Step | Timeline |
| --- | --- |
| Acknowledgment of the report to the complainant | Within **2 business days** |
| Interim measures put in place where needed | Within **5 business days** |
| Investigation by a trained, impartial investigator | Completed within **60 calendar days** |
| Written outcome to the complainant and respondent | Within **10 business days after the report** |
| Request for review of the outcome | Within **10 business days of the outcome** |

HR treats harassment and safety matters as P1 urgent requests, with a first response within 4 business hours (see HR-GDE-004 HR Service and Support Guide). The investigation may need more than 60 calendar days where there are many witnesses or leave absences; any extension is communicated in writing to both parties with the reason and a new date.

### 6.1 Interim measures

Where needed, the Bank may separate the people involved, change reporting lines or work locations, adjust schedules or remote work, restrict system access, or place a respondent on paid leave. Measures protect people and the integrity of the process and are not a finding or a form of discipline. An interim measure must not disadvantage the complainant. Referrals to the Wellspring Support Program (1-800-555-0166; up to 8 counselling sessions per issue per calendar year) are offered to everyone involved.

### 6.2 Investigation

Employee Relations assigns a trained, impartial investigator with no stake in the outcome, who may be internal or external. The investigator reviews the complaint, interviews the complainant, the respondent and witnesses, and collects documents. Both parties may be accompanied by a support person who is not legal counsel. The respondent receives the allegations in writing and has a fair chance to respond. The investigator prepares a written report with findings on each allegation on the balance of probabilities.

### 6.3 Outcomes

Where harassment, discrimination or violence is substantiated, the outcome may include coaching, training, a written warning, a final written warning, suspension, reassignment, or termination, applied consistently under HR-POL-021. Substantiated serious cases may skip steps. Where an allegation is not substantiated, the complainant is not penalized if the complaint was made in good faith. Outcomes also include steps to restore a healthy working relationship, such as mediation, if both parties agree. A knowingly false complaint made in bad faith is misconduct.

### 6.4 Review of the outcome

A party who believes the process was not followed or the outcome was unreasonable may request a review in writing to the VP Employee Relations within 10 business days of the outcome. A reviewer who was not involved in the case confirms or changes the outcome, and the decision is final within the Bank's internal process.

## 7. Confidentiality

The Bank protects the privacy of everyone involved. Information is shared only with those who need it to manage the complaint, to carry out the investigation, to take corrective action, or as the law requires. Parties and witnesses must keep the matter confidential, but this does not prevent employees from speaking to a lawyer, a union or employee representative where applicable, a regulator or a counsellor. Investigation files are retained for 10 years after closing (see HR-REF-002 Employee Records Retention Schedule) and are held separately from the general personnel file.

## 8. No retaliation

Retaliation against anyone who reports in good faith, supports a colleague, or takes part in an investigation is strictly prohibited and is itself serious misconduct. Retaliation includes threats, exclusion, adverse changes to work or pay, and negative references. Report suspected retaliation through any channel in section 5; it will be treated as a new complaint. See also HR-POL-022 Whistleblower and Speak-Up Policy.

## 9. Prevention, training and assessment

- All employees complete Workplace Harassment and Violence Prevention training in the Learning Hub every year, within the annual window of 1 August to 31 October; new hires complete it within 30 days of starting.
- Managers complete additional training on recognizing, receiving and escalating complaints, and on supporting a team through an investigation.
- A **workplace assessment** is carried out every year for each business unit and branch, covering risk factors, incident data and survey results; results and corrective actions are reported to the HR Policy Committee.
- Staff who work with the public in branches receive de-escalation and robbery-response training.

## 10. Branch violence and emergencies

If anyone is in immediate danger, **call 911 first, then Corporate Security at 1-800-555-0119**. In a branch robbery, comply with demands, do not resist or pursue, activate the alarm only when it is safe to do so, and call 911 once the robber has left. Corporate Security will coordinate support, a post-incident debrief and a referral to the Wellspring Support Program for affected staff. Report every incident to your manager and Corporate Security immediately and in MyHR within 24 hours, following HR-POL-023 Workplace Health, Safety and Wellness Policy. Employees may leave a situation they reasonably believe is unsafe without penalty.

## 11. Consequences

Breaching this policy may result in corrective action up to and including termination for cause, under HR-POL-021 Employee Relations and Progressive Discipline Policy and consistent with HR-POL-001 Code of Conduct and Ethics. Conduct that may be a crime may also be referred to the police.

## 12. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 5.0 | 2025-09-01 | Current version. Reviewed annually; clarified third-party and customer harassment, domestic violence at work, and the timelines in section 6. |
