# Remote and Hybrid Work Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-002 |
| Title | Remote and Hybrid Work Policy |
| Document type | Policy |
| Version | 3.0 |
| Status | Current |
| Effective date | 2026-01-05 |
| Last reviewed | 2026-08-20 |
| Next review | 2027-08-20 |
| Policy owner | VP HR Operations |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Applies to | All Canadian and US employees (see Scope) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-003, HR-POL-004, HR-POL-017, HR-POL-023, HR-POL-018, FORM-HR-030, FORM-HR-031 |

## 1. Purpose

This policy explains where and how Bank employees work. It sets the rules for on-site, hybrid and remote arrangements, for working temporarily from another location, and for the equipment, security and safety conditions that apply when an employee works away from a Bank office. Its aims are to support collaboration in person, to give employees predictable flexibility, and to apply the rules consistently and fairly across business units.

## 2. Scope

This policy applies to all regular full-time, regular part-time and fixed-term employees in Canada and the US. Casual employees, students, co-op students and interns follow the arrangement stated in their engagement letter. Contractors and agency workers are not covered (see HR-POL-014 Employment Status and Classification Policy). Where applicable law gives a greater right, the law applies.

## 3. Definitions

- **Office:** a Bank branch, operations centre or office building designated as the employee's home location.
- **In-office day:** a working day on which the employee works from the office for the full day, or for at least the core hours of 10:00 to 15:00 local time.
- **Anchor days:** Tuesday and Thursday, the two days on which all hybrid employees are expected in the office.
- **Home jurisdiction:** the province, territory or US state in which the employee lives and is paid.
- **Approved employment-jurisdiction list:** the list of provinces, territories and states in which the Bank may employ remote workers, held by Payroll Services and Legal.
- **Business unit head:** the VP or more senior leader accountable for a business unit.

## 4. Arrangement types

| Arrangement | Who it is for | Where the employee works | Approval |
| --- | --- | --- | --- |
| On-site | Customer-facing branch roles and operations roles that must be performed on Bank premises | At the office, on a posted schedule | None; set by the role |
| Hybrid | Default for eligible office roles | At least 3 days per week in the office, the rest from home | Recorded on FORM-HR-030 |
| Remote | Roles designated remote by the business unit | From home, with up to 4 planned in-person events per year | Approved on FORM-HR-030 |

The arrangement is attached to the role and recorded in MyHR. Promotions and transfers are handled separately and may change the arrangement.

## 5. Hybrid schedule and anchor days

### 5.1 Requirement

From 5 January 2026 (version 3.0), hybrid employees work in the office **at least 3 days per week**. Tuesday and Thursday are anchor days. The third day is chosen by the team, agreed by the manager, and recorded on FORM-HR-030 in MyHR. A team may change its third day with 10 business days' notice to its members.

### 5.2 Part-time employees

Part-time hybrid employees attend on anchor days they are scheduled to work. Their total in-office days equal 60% of their scheduled days per week, rounded up to the next whole day.

### 5.3 Holidays and absences

An anchor day that falls on a Bank holiday or on an approved absence is not a missed day and is not an exception day. The manager may agree to move that week's third day.

### 5.4 Core availability

All hybrid and remote employees are available online between 10:00 and 15:00 local time, as set out in HR-POL-003 Working Hours and Overtime Policy.

### 5.5 Severe weather

When a closure is announced under HR-POL-004 Attendance and Absenteeism Policy, hybrid and remote employees work from home that day.

## 6. Exceptions to office attendance

A manager may approve up to **12 office-attendance exception days per calendar year** per employee. Examples are a medical appointment, a client commitment near home, or a transit disruption. Any request beyond 12 days in a calendar year needs the approval of the HRBP. The manager records each exception day in MyHR. Absences covered by vacation, sick leave, personal days or other leave are not exception days. Accommodation needs that affect office attendance are handled under HR-POL-018 Workplace Accommodation and Accessibility Policy and do not count against the 12 days.

## 7. Remote eligibility

An employee may be approved for a Remote arrangement only if all of the following apply:

1. The business unit head has designated the role as remote-eligible.
2. The employee has completed probation.
3. The employee's last rating was Meets Expectations or higher.
4. The employee has no active performance improvement plan.
5. The employee's home address is in a jurisdiction on the approved employment-jurisdiction list.

The employee submits FORM-HR-030; the manager responds within 5 business days and the HRBP confirms eligibility. An employee who intends to move to a different province or state must obtain approval at least **30 days before the move**. Remote employees attend up to **4 planned team or client events** in person each year, with the Bank paying approved travel costs.

## 8. Temporary work from elsewhere

Employees may work temporarily from a location other than their normal workplace by submitting FORM-HR-031 (Temporary Work-from-Elsewhere Request).

| Location | Limit per calendar year | Request lead time | Approval |
| --- | --- | --- | --- |
| Elsewhere within the employee's home country | Up to 20 working days | At least 5 business days ahead | Manager |
| Across the Canada-US border | Up to 10 working days | At least 10 business days ahead | Manager, with Payroll Services and Legal review |
| Any other country | Not permitted by default | At least 30 days ahead | Global Mobility and Legal |

The domestic and cross-border limits are separate. Time away does not extend vacation or create any entitlement to a different pay or tax treatment. Employees remain responsible for their own right to work, and the Bank may refuse a request for tax, immigration, regulatory or security reasons. Travelling with a Bank device to a restricted country needs Corporate Security notice under HR-POL-017 IT Acceptable Use and Information Security Policy.

## 9. Equipment and allowances

The Bank provides a laptop, a headset, and one external monitor on request. A one-time home office setup allowance is available once every 3 years:

| Arrangement | Setup allowance (Canada) | Setup allowance (US) |
| --- | --- | --- |
| Hybrid | $300 CAD | $225 USD |
| Remote | $600 CAD | $450 USD |

The employee claims the allowance with receipts in MyHR within 60 days of purchase. The Bank does not reimburse ongoing internet, phone, utility or rent costs. Bank equipment remains Bank property and is returned under HR-POL-015 Resignation and Offboarding Policy. Equipment needed because of a disability is provided through the accommodation process, not this allowance.

### 9.1 Form T2200 (Canada)

A Canadian employee may ask HR Operations, through the HR Case Portal, for a signed form T2200 (declaration of conditions of employment). HR Operations signs it where the employee's conditions of employment support it, usually within 10 business days of the request. Whether any tax deduction is available is for the employee and a tax adviser to decide; the Bank gives no tax advice.

## 10. Information security and privacy

Employees working away from an office follow HR-POL-017: the VPN is always on, no public Wi-Fi is used without the VPN, Confidential and Restricted data is accessed only on a Bank-issued device, the workspace is private so that screens and conversations cannot be seen or heard, and the screen is locked whenever the employee steps away. Lost or stolen devices and suspected incidents are reported to the Security Operations Centre immediately and no later than 1 hour (1-800-555-0155).

## 11. Health, safety and workers' compensation

The Bank's health and safety duties extend to an employee's approved remote workplace while the employee is working. Employees keep a safe, ergonomic workspace and may request an ergonomic assessment, which is completed within 30 days of the request (see HR-POL-023 Workplace Health, Safety and Wellness Policy). An injury or incident that arises out of and in the course of work is reported to the manager and Corporate Security immediately and in MyHR within 24 hours. The Leaves team files any workers' compensation claim within 3 business days of learning of the injury.

## 12. Performance and fairness

Employees are assessed on results and behaviours, not on location. Managers apply the same goals, development opportunities and consequences to on-site, hybrid and remote employees, and avoid favouring those who are physically nearby. An arrangement does not affect pay band, benefits or eligibility for the Annual Incentive Plan. Employees who believe an arrangement decision was unfair may raise it with the HRBP, the Ombuds Office, or through the Speak-Up Line.

## 13. Ending or changing an arrangement

- **By the employee:** the employee gives 4 weeks' notice through FORM-HR-030.
- **By the Bank for business reasons:** the manager and HRBP give at least 30 calendar days' written notice with the reason.
- **Immediately:** the Bank may end an arrangement without notice for a security breach, a conduct issue under HR-POL-021, or when the employee no longer meets a remote eligibility condition (for example an active performance improvement plan). The employee returns to the arrangement shown for the role.
- **Moves and role changes:** an employee who leaves the approved employment-jurisdiction list or changes role must resubmit FORM-HR-030.

## 14. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Employee | Follows the schedule, records exceptions, submits forms on time, protects Bank information |
| Manager | Approves exceptions and temporary requests, agrees the team's third day, monitors fairness |
| Business unit head | Designates remote-eligible roles |
| HRBP | Approves exceptions above 12 days, resolves disputes |
| HR Operations | Maintains arrangement records and signs form T2200 |
| Payroll Services and Legal | Maintain the approved employment-jurisdiction list and review cross-border requests |
| VP HR Operations | Owns this policy |

## 15. Consequences

Repeated failure to meet the in-office requirement without an approved exception is addressed by the manager through a documented conversation and, if it continues, under HR-POL-021 Employee Relations and Progressive Discipline Policy.

## 16. Related documents and contacts

Related: HR-POL-003, HR-POL-004, HR-POL-014, HR-POL-017, HR-POL-018, HR-POL-023. Contact HR Connect at 1-800-555-0142 (Monday to Friday 8:00 to 20:00 Eastern Time) or hrconnect@bank.example; managers may use the Manager Hotline at 1-800-555-0143.

## 17. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2022-03-01 | Introduced hybrid work as the default for eligible office roles |
| 2.1 | 2023-09-01 | Hybrid requirement of 2 office days per week, with no anchor days (in force until 2026-01-04) |
| 3.0 | 2026-01-05 | Hybrid requirement raised to 3 office days per week; Tuesday and Thursday anchor days introduced; 12-day exception allowance and FORM-HR-031 limits added |
