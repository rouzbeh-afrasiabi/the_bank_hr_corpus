# Retirement and Savings Plan Guide

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-GDE-002 |
| Title | Retirement and Savings Plan Guide |
| Document type | Guide |
| Version | 3.0 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-09-17 |
| Next review | 2027-09-17 |
| Policy owner | SVP Total Rewards |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Applies to | All Canadian and US employees (see Scope) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-001, HR-POL-009, HR-POL-014, HR-POL-015, HR-POL-008, HR-GDE-004 |

## 1. Purpose

This guide describes the Bank's retirement and savings plans: the Bank Savings and Pension Plan in Canada and the Bank US 401(k) Savings Plan in the US. It explains who can join, how much you and the Bank contribute, how vesting works, how your money is invested, when you can borrow or withdraw it, and what happens when you leave or retire.

The legal plan documents govern if they differ from this guide. Statutory contribution limits are set by the tax authorities each year and are not stated in this guide; Evergreen Retirement Services publishes the current limits. Where applicable law gives a greater right, the law applies.

## 2. Scope and eligibility

| Employment category | Canada: Bank Savings and Pension Plan | US: Bank US 401(k) Savings Plan |
| --- | --- | --- |
| Regular full-time and part-time | Eligible from day 1 | Eligible from day 1 |
| Fixed-term, 6 months or more | Eligible from day 1 | Eligible from day 1 |
| Fixed-term, under 6 months | Not eligible | Not eligible |
| Casual | Not eligible | Eligible after 1,000 hours worked |
| Student, co-op, intern | Not eligible | Not eligible |

The full status definitions are in HR-POL-014 Employment Status and Classification Policy. Evergreen Retirement Services is the recordkeeper for both plans. Benefits such as health, dental and insurance are covered separately in HR-GDE-001 Employee Benefits Guide.

## 3. Definitions

- **Base salary**: your annual rate of pay before deductions, excluding incentive pay (the Annual Incentive Plan), overtime, premiums and allowances.
- **Base contribution**: the Bank contribution made regardless of whether you contribute.
- **Match**: the Bank contribution that matches your own contributions.
- **Vesting**: your ownership of the Bank contributions in your account.
- **Locked in**: money that cannot be withdrawn before a set age under pension law.

## 4. Canada: Bank Savings and Pension Plan

The plan is a defined contribution pension plan. Your pension depends on the contributions made and the investment returns earned, not on a formula based on salary or service.

### 4.1 Your contributions

You may contribute 2% to 10% of base salary through payroll deduction. If you do not make an election, you are auto-enrolled at 4% on the first pay date after 30 days of employment. You may opt out within 90 days of enrolment and your contributions will be refunded. After that, your contributions stay in the plan.

### 4.2 Bank contributions

| Bank contribution | Amount |
| --- | --- |
| Base contribution | 2% of base salary, regardless of your contribution |
| Match | 100% of your contributions up to the first 4% of base salary |
| Maximum Bank total | 6% of base salary |

The Bank's contributions are vested immediately. Incentive pay is not matched. Contributions on Bank-paid parental leave continue on top-up pay (see HR-POL-008 Parental and Family Leave Policy).

### 4.3 Locking in

Pension assets are locked in until age 55. Before then you cannot withdraw them, except in limited situations allowed by pension law, such as a transfer to another locked-in account.

### 4.4 Optional savings: Group RRSP and payroll TFSA

You may also save through the Group RRSP and the payroll TFSA by payroll deduction. These accounts have no Bank match. Withdrawals follow the account's tax rules and are not locked in, but tax consequences apply and you should consider them before withdrawing.

## 5. US: Bank US 401(k) Savings Plan

### 5.1 Your contributions

You are auto-enrolled at 5% of base salary after 30 days of employment. Your rate increases by 1% each year until it reaches 8%, so the path is 5%, 6%, 7%, 8%. You may opt out, or change your rate or the escalation, at any time. You may contribute on a pre-tax basis, a Roth (after-tax) basis, or a combination of the two.

### 5.2 Bank contributions

| Bank contribution | Amount |
| --- | --- |
| Base contribution | 2% of base salary |
| Match | 100% on the first 4% of base salary you contribute |
| Maximum Bank total | 6% of base salary |

### 5.3 Vesting

Your own contributions are always 100% yours. The Bank base contribution and the match vest after 2 years of service (cliff vesting): you own none of the Bank contributions before the second anniversary of your service date and all of them from that date. If you leave before 2 years, the unvested Bank contributions are forfeited. If you are rehired within the time allowed under the plan document, previously forfeited amounts may be restored.

### 5.4 Loans and withdrawals

| Feature | Rule |
| --- | --- |
| Loans | One loan at a time; up to 50% of your vested balance, to a maximum of $50,000; repaid by payroll deduction |
| Hardship withdrawal | Available for qualifying needs under the plan document; documentation is required |
| Withdrawals after leaving | Allowed according to the plan rules and tax law; tax and early-withdrawal penalties may apply |

An unpaid loan balance at termination may be treated as a taxable distribution unless repaid within the period allowed by the plan. Loans are not available in the Canadian pension plan.

## 6. Matching worked examples for a $90,000 salary

The examples assume a base salary of $90,000 and a full year of contributions. Percentages are applied to base salary.

### 6.1 Canada

| Employee rate | Employee contribution | Bank base (2%) | Bank match | Total Bank | Total into plan |
| --- | --- | --- | --- | --- | --- |
| 2% | $1,800 | $1,800 | $1,800 | $3,600 | $5,400 |
| 3% | $2,700 | $1,800 | $2,700 | $4,500 | $7,200 |
| 4% (default) | $3,600 | $1,800 | $3,600 | $5,400 | $9,000 |
| 6% | $5,400 | $1,800 | $3,600 | $5,400 | $10,800 |
| 10% | $9,000 | $1,800 | $3,600 | $5,400 | $14,400 |

Contributing more than 4% increases your savings but not the match. An employee who contributes 4% receives the full $5,400 Bank total, which equals 6% of salary. An employee who contributes only 2% gives up $1,800 of match each year.

### 6.2 US

Using the default rate of 5% in the first year: employee $4,500; Bank base $1,800; Bank match on the first 4% = $3,600; Bank total $5,400; total into plan $9,900. In year 2 at 6%: employee $5,400; Bank total $5,400; total $10,800.

### 6.3 Effect of vesting (US)

An employee who contributes 5% in the first year and 6% in the second year, and leaves 6 months into that second year (18 months of service), has contributed $4,500 + $2,700 = $7,200 of their own money, which they keep together with its earnings. Bank contributions of $5,400 + $2,700 = $8,100 are forfeited because the 2-year cliff has not been reached. An employee who stays until the second anniversary of their service date keeps all of the Bank contributions.

## 7. Investments

Your contributions and the Bank's go into a default target-date fund chosen by your age (assumed retirement at 65) unless you choose otherwise. You may choose from the investment menu in the plan at any time and may move balances between funds without charge except where the fund rules state otherwise. Quarterly statements are available in MyHR and from Evergreen Retirement Services. Every employee receives a free one-to-one financial advice session each year; book it with Evergreen Retirement Services at 1-800-555-0188.

## 8. Changing your contributions

Contribution changes are made in MyHR and take effect at the next payroll cut-off. The cut-off is 17:00 Eastern Time five business days before the pay date (see HR-POL-009 Compensation and Payroll Policy). A change made after the cut-off applies from the following pay date. Changes made by phone through Evergreen Retirement Services are reflected only after Payroll Services receives them.

### 8.1 Beneficiaries

Name your beneficiaries for each plan in MyHR or through Evergreen Retirement Services. Review them after marriage, divorce, birth or adoption of a child, or the death of a beneficiary. If no valid beneficiary is on file, the plan document and applicable law decide who receives your account, and a spouse may have a legal entitlement in some circumstances.

### 8.2 Part-time and leaves

Part-time employees contribute and receive Bank contributions on their actual base salary. During unpaid leaves no contributions are made, because there is no salary on which to base them. During Bank-paid leaves, contributions continue on the pay received, including parental leave top-up pay.

### 8.3 Statements and keeping your information current

Statements are issued quarterly. Check your name, address and contribution rate on each one and report errors to Benefits Administration within 30 days of receiving the statement. If you move between Canada and the US, contact HR Connect before the move because your plan membership changes.

## 9. Retirement ages

| Item | Rule |
| --- | --- |
| Normal retirement age | 65 |
| Early retirement | From age 55 with at least 5 years in the plan |
| Retirement notice | 3 months before your intended last day |

Give notice by submitting the resignation form (FORM-HR-080 Resignation Notice) and tell HR Operations that you intend to retire; see HR-POL-015 Resignation and Offboarding Policy for notice periods by band. Evergreen Retirement Services will send you the options for your account, including leaving the money in the plan, transferring it, or taking income. Retiree health access is explained in HR-GDE-001 Employee Benefits Guide.

## 10. Leaving the Bank

| Situation | Canada | US |
| --- | --- | --- |
| Left with less than 2 years of service | All Bank contributions vested; locked-in rules apply | Unvested Bank contributions forfeited |
| Left with 2 or more years | All contributions vested | All contributions vested |
| Options | Leave in plan, transfer to a locked-in account, or other options under pension law | Leave in plan, roll over to an IRA or another employer plan, or take a distribution (tax and penalties may apply) |

Evergreen Retirement Services sends the options package within 30 days after your employment ends.

## 11. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Employee | Choose your contribution rate and beneficiaries; check statements |
| Payroll Services | Deduct and remit contributions |
| Benefits Administration | Confirm eligibility and answer plan questions |
| Evergreen Retirement Services | Keep records, issue statements, process transactions |
| SVP Total Rewards | Owns this guide and the plan design |

## 12. Contacts

| Need | Contact |
| --- | --- |
| Account balances, investments, advice sessions | Evergreen Retirement Services, 1-800-555-0188 |
| Eligibility, payroll deductions, policy | HR Connect, 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time, hrconnect@bank.example |

For service levels see HR-GDE-004 HR Service and Support Guide.

## 13. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 3.0 | 2026-01-01 | Combined Canada and US descriptions; added worked matching examples and vesting example |
| 2.0 | 2024-01-01 | Added Roth option and financial advice session |
