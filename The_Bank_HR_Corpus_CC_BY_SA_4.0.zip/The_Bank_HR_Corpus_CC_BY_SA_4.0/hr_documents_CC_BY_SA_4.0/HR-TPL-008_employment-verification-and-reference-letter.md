# Employment Verification and Reference Letter

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-TPL-008 |
| Title | Employment Verification and Reference Letter |
| Document type | Template |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-06-30 |
| Next review | 2027-06-30 |
| Policy owner | VP HR Operations |
| Audience | HR only |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-016, HR-GDE-004, HR-REF-002 |

## 1. Purpose and when to use this template

This template is used by HR Operations to confirm employment to a landlord, lender, government body or future employer. By default the letter confirms only job title, dates of employment and employment status. Anything more, such as salary or a reference on performance, needs the written consent of the current or former employee. Personal information rules are in HR-POL-016 Employee Data Privacy Policy.

## 2. How to use this template

1. Receive the request through the HR Case Portal or HR Connect (see HR-GDE-004 HR Service and Support Guide for service levels). Managers do not issue verification letters themselves.
2. Confirm the identity of the employee and the identity of the requester.
3. Check whether the employee has given written consent for additional content. If not, use Option A only.
4. Issue the letter from HR Operations on Bank letterhead and record the disclosure in the case.

## 3. Letter text

**[Date]**

**[Recipient name or "To whom it may concern"]**
[Recipient organization]

**Subject: Employment verification for [Employee full name]**

This letter confirms the following information about **[Employee full name]**.

**Option A: standard verification (no consent needed)**

- **Job title:** [Job title]
- **Dates of employment:** from [Start date] to [End date / "present"]
- **Employment status:** [Regular full-time / Regular part-time / Fixed-term / Casual; current or former employee]

**Option B: verification with income or other details (written consent on file)**

The employee gave written consent on **[Consent date]** for the Bank to disclose: **[Selected items, for example base salary of [Base salary] per year, or hours of work]**.

**Option C: reference (written consent on file)**

The employee gave written consent on **[Consent date]** for the Bank to provide a reference. **[Factual, job-related statements approved by the manager and HR Operations.]**

The Bank provides no other information. This letter is provided at the request of the employee and is accurate as of the date above. It is not a guarantee of future employment.

Sincerely,
**[HR Operations representative name]**, HR Operations

## 4. Required clauses checklist

| Clause | Required content |
| --- | --- |
| Default content | Title, dates of employment and status only |
| Consent | Written consent date for any additional item |
| Accuracy | "Accurate as of the date above" |
| Limit | Statement that no other information is provided |

## 5. Drafting notes for HR

- Do not confirm salary, performance, reasons for leaving, leave history, medical information or disciplinary history without written consent. Even with consent, give only facts supported by records.
- Where a third party asks for income verification, ask the employee to use the consent form in MyHR rather than answering by phone.
- For a former employee, confirm the identity from the personnel file; personnel files are kept for 7 years after employment ends (HR-REF-002 Employee Records Retention Schedule).
- Keep a copy of each letter and consent in the case. Quebec employees may ask for the letter in French.
- Reference requests concerning an employee dismissed for cause go to Employee Relations before any reply.

## 6. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.0 | 2023-04-03 | First verification letter template |
| 2.0 | 2025-09-01 | Added the consent-based options and the default of title, dates and status only |
