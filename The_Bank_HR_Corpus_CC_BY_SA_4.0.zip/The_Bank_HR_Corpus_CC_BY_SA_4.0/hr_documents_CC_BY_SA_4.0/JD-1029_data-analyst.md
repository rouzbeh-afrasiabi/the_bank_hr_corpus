# Data Analyst

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1029 |
| Title | Data Analyst |
| Document type | Job description |
| Version | 1.1 |
| Status | Current |
| Effective date | 2025-03-17 |
| Last reviewed | 2026-07-07 |
| Next review | 2027-07-07 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-POL-002, HR-POL-016, HR-POL-017 |

## 1. Role summary

The Data Analyst turns Bank data into clear, accurate information that helps business and technology teams make decisions. The analyst builds reports and dashboards, investigates questions with queries and statistics, checks data quality and explains findings to non-technical audiences. A Band 3 analyst works independently on assigned analyses and applies professional judgement to interpret results.

## 2. Key responsibilities

- Translate business questions into analysis plans, queries and measurable definitions.
- Extract, join and clean data from warehouses and operational systems, and document the logic.
- Build and maintain dashboards and scheduled reports that business teams rely on.
- Run descriptive and basic statistical analyses, and present results with their limits and caveats.
- Reconcile reports with source systems and finance figures, and explain differences.
- Monitor data quality, raise issues with data owners and track fixes.
- Handle customer and employee data according to classification rules and privacy principles (see HR-POL-016 Employee Data Privacy Policy and HR-POL-017 IT Acceptable Use and Information Security Policy).
- Use only Bank-approved analytics and AI tools; never upload client or employee personal data to public tools.
- Support ad hoc requests from leaders and the Senior Data Scientists with data preparation.
- Share reusable queries and definitions so that colleagues can rely on consistent numbers.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in statistics, mathematics, economics, computer science, business analytics or a related field.
- Typically 2 to 5 years of experience in data analysis or reporting.
- Strong skills in a structured query language and in a data-visualization or reporting tool.
- Ability to explain numbers clearly to non-specialists.

### 3.2 Preferred

- Scripting skills in a data-analysis language.
- Experience with banking, risk or customer-analytics data.
- Understanding of data governance and lineage concepts.

### 3.3 Licences and certifications

None required.

## 4. Competencies

Measured against HR-FWK-001 Competency and Leadership Model at the Practitioner level:

- Judgement and Decision Quality
- Customer Obsession
- Collaboration
- Drive for Results
- Risk and Conduct Awareness

## 5. Compensation and classification

| Item | Value |
| --- | --- |
| Band | 3 (Professional) |
| Canada range | $56,000 to $84,000 CAD |
| US range | $55,000 to $82,000 USD |
| Incentive target | 5% of base salary (Annual Incentive Plan) |
| Overtime eligibility, Canada | Yes (non-managerial Band 3) |
| FLSA classification, US | Exempt |
| Work arrangement | Hybrid (at least 3 days a week in the office) |

Band definitions are in HR-GDE-006 Job Architecture and Pay Bands Guide.

## 6. Working conditions and accessibility

This is an office role with a hybrid arrangement under HR-POL-002 Remote and Hybrid Work Policy: at least 3 days a week in the office, including the Tuesday and Thursday anchor days. Work with Confidential and Restricted data is done on Bank-issued devices only. The Bank provides accommodation to the point of undue hardship; see HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to: Technology Team Lead. Direct reports: none.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.1 | 2025-03-17 | Added data-handling and approved-tools wording |
| 1.0 | 2023-10-01 | First issue |
