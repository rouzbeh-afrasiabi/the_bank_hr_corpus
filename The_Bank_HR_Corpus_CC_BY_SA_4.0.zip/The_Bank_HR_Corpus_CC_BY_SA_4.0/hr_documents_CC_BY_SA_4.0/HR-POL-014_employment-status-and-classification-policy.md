# Employment Status and Classification Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-014 |
| Title | Employment Status and Classification Policy |
| Document type | Policy |
| Version | 2.3 |
| Status | Current |
| Effective date | 2025-03-01 |
| Last reviewed | 2026-07-30 |
| Next review | 2027-07-30 |
| Policy owner | VP HR Operations |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Applies to | All Canadian and US employees (see Scope) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-003, HR-POL-006, HR-POL-009, HR-POL-010, HR-GDE-001, HR-GDE-006 |

## 1. Purpose

This policy defines the categories of employment at the Bank, the benefits and entitlements attached to each, and the rules on probation, fixed-term contracts, contractors, overtime classification, service dates and changes of status. Correct classification protects employees' rights, keeps pay and benefits accurate and keeps the Bank compliant with employment, tax and labour laws. Where applicable law gives a greater right, the law applies.

## 2. Scope

The policy covers all workers engaged by the Bank in Canada and the US. It also sets out which workers are not employees and which Bank policies they follow. Promotions and transfers are handled separately.

## 3. Definitions

- **Employee:** a person engaged under a contract of employment and paid through payroll.
- **Category:** the employment status recorded in MyHR for each employee.
- **Scheduled hours:** the weekly hours stated in the offer letter or the schedule agreed with the manager.
- **Service date:** the date from which continuous service is measured.
- **Contractor:** an independent worker or agency worker engaged through a commercial contract.

## 4. Employment categories

| Category | Hours | Benefits and pension | Vacation, sick, personal | Holidays | AIP | Tuition |
| --- | --- | --- | --- | --- | --- | --- |
| Regular full-time | 35+ per week | Yes, day 1 | Full | Yes | Eligible | Yes after 6 months |
| Regular part-time | 20 to under 35 | Yes, day 1 | Pro-rated by hours | Yes, pro-rated pay | Pro-rated | Yes after 6 months |
| Casual (on call) | Under 20 average | No (EAP only; 401(k) after 1,000 hours in the US) | 6% vacation pay; statutory sick | Per law | No | No |
| Fixed-term, 6 months or more | Per contract | Yes, day 1 | Full / pro-rated | Yes | Pro-rated | No |
| Fixed-term, under 6 months | Per contract | EAP only | Pro-rated | Yes | No | No |
| Student, co-op, intern | Up to 40 | EAP only | Statutory | Per law | No | No |

"EAP" means the Wellspring Support Program. The numbers of vacation, sick and personal days are in HR-POL-006 Vacation and Paid Time Off Policy and HR-POL-007 Sick Leave and Personal Leave Policy; benefit plan details are in HR-GDE-001 Employee Benefits Guide; holiday pay is in HR-POL-010 Statutory Holidays Policy; the Annual Incentive Plan (AIP) rules are in HR-POL-009 Compensation and Payroll Policy. Tuition reimbursement is subject to the conditions in HR-POL-012 Learning and Development Policy.

### 4.1 Regular full-time and part-time

Regular employees hold an ongoing role with no end date. Full-time employees work 35 or more hours a week; part-time employees work 20 to under 35. Both are eligible for benefits and pension from the first day and for holidays from day one. A part-time employee's vacation, sick and personal days and holiday pay are pro-rated by scheduled hours.

### 4.2 Casual employees

Casual employees are called in as needed and average under 20 hours a week. They receive 6% vacation pay in lieu on every paycheque, the statutory sick protection, and holiday entitlements as the law requires. They are not eligible for benefits, pension or the AIP; in the US they become eligible for the 401(k) plan after 1,000 hours. A casual employee whose hours average 20 or more over 12 consecutive weeks may ask the manager and HRBP to review a change to regular part-time.

### 4.3 Fixed-term employees

A fixed-term contract has a defined end date, **up to 24 months**. Before the end date the manager and HRBP either convert the employee to a regular role, extend within the 24-month limit, or let the contract end. The manager gives the employee written notice of the decision at least 30 days before the end date. A fixed-term employee on a contract of 6 months or more has benefits and pension from day 1; a contract under 6 months carries EAP only.

### 4.4 Students, co-op students and interns

Students, co-op students and interns work up to 40 hours a week for a defined term and are paid. They receive statutory entitlements and EAP only. They may apply for regular roles through recruitment and are not guaranteed conversion.

## 5. Probation

All new hires serve a probation period of **3 months** from the start date. Probation may be extended **once, to 6 months**, if the manager gives the employee written notice before the end of month 3, stating the reasons and the expectations. During probation:

- Benefits, pension and leave entitlements apply as in the category table, from day 1.
- The manager meets the employee at 30, 60 and 90 days (see HR-GDE-003 New Employee Onboarding Guide).
- Statutory rights and notice requirements still apply.

Employees complete probation on the date the manager confirms it in MyHR. Completion is a condition for remote work eligibility under HR-POL-002 Remote and Hybrid Work Policy. Probation does not apply to fixed-term conversions or internal moves.

## 6. Contractors and agency workers

Contractors and agency workers are **not employees**. They are not covered by HR policies, except for the Code of Conduct and Ethics, IT acceptable use and mandatory training. They are engaged through Procurement and Legal, under a written agreement that states the deliverables, fees, duration and the contractor's responsibility for taxes and insurance. They do not receive benefits, Bank equipment beyond what the contract provides, vacation, holiday pay or the AIP, and are not managed through the performance process. Managers must not direct a contractor's hours or integrate them into a team in the way an employee would be.

## 7. Overtime-eligible and non-exempt classification

Whether a role is eligible for overtime (Canada) or non-exempt under the Fair Labor Standards Act (US) is set out in HR-POL-003 Working Hours and Overtime Policy. In summary, Canadian Bands 1 to 4 non-managerial roles are overtime-eligible; Bands 5 and above are not. In the US, roles classified non-exempt (generally Bands 1 to 3 and some Band 4) are paid overtime. HR Operations and Legal classify each role on duties, not title, when the job is created or its duties change. Band definitions are in HR-GDE-006 Job Architecture and Pay Bands Guide.

## 8. Service date

- **Service date:** continuous service starts on the first day of work in a regular role and drives vacation entitlement, retirement rules and service awards.
- **Rehire within 12 months:** prior service is restored.
- **Rehire after more than 12 months:** service restarts on the new start date.
- **Fixed-term converted to regular within 6 months:** service is credited from the original fixed-term start date.
- **Approved leaves:** service continues, except as stated in the relevant leave policy.

HR Operations records the service date in MyHR; employees may ask HR Connect to correct an error.

## 9. Status changes

An employee who wants to move between categories (for example part-time to full-time) asks the manager, who submits the request with the HRBP, giving **4 weeks' notice**. The change takes effect at the start of a pay period. HR Operations updates MyHR, and Payroll Services and Benefits Administration adjust pay, benefits and pro-rated entitlements. Fixed-term, casual and regular status changes initiated by the Bank follow the same notice, unless the law or contract requires longer.

## 10. Misclassification

Misclassification means that a worker is placed in the wrong category: for example an employee treated as a contractor, a non-exempt employee treated as exempt, or a regular employee treated as casual.

1. Employees, managers or contractors who suspect it raise a case in the HR Case Portal or contact HR Connect.
2. HR Operations and Legal review the facts, the duties and the contract and decide within **15 business days**.
3. If a worker was misclassified, the category is corrected from the earliest date supported by the facts, and Payroll Services corrects pay, with retroactive corrections going back up to 24 months (see HR-POL-009).
4. The VP HR Operations reports confirmed misclassification to the Chief Compliance Officer.

The Bank will not retaliate against anyone who raises a misclassification concern.

## 11. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Manager | Requests the correct category, gives probation and contract-end notices |
| HRBP | Reviews status changes and extensions |
| HR Operations | Maintains the category and service date records, classifies roles |
| Legal and Procurement | Engage and assess contractors |
| Payroll Services and Benefits Administration | Apply category effects to pay and benefits |
| VP HR Operations | Owns this policy |

## 12. Contacts

HR Connect: 1-800-555-0142, hrconnect@bank.example. Manager Hotline: 1-800-555-0143.

## 13. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2023-09-01 | Introduced the 24-month limit on fixed-term contracts and the single probation extension |
| 2.2 | 2024-06-01 | Added the student, co-op and intern category |
| 2.3 | 2025-03-01 | Clarified the service-date rules for rehire and conversion, and added the misclassification review process |
