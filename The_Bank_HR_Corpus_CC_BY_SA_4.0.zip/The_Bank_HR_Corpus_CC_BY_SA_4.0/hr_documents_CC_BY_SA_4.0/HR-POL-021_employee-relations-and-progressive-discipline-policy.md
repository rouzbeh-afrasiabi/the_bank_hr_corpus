# Employee Relations and Progressive Discipline Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-021 |
| Title | Employee Relations and Progressive Discipline Policy |
| Document type | Policy |
| Version | 4.0 |
| Status | Current |
| Effective date | 2025-04-01 |
| Last reviewed | 2026-07-14 |
| Next review | 2027-07-14 |
| Policy owner | VP Employee Relations |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Applies to | All Canadian and US employees (see Scope) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-001, HR-POL-004, HR-POL-005, HR-POL-013, HR-POL-025, FORM-HR-071 |

## 1. Purpose

This policy explains how the Bank addresses conduct and performance concerns fairly, consistently and with respect. Employee Relations helps managers and employees resolve workplace issues early and constructively. Where a concern cannot be resolved informally, progressive discipline gives the employee clear notice of the problem, a fair chance to respond, and a reasonable opportunity to improve.

## 2. Scope

This policy applies to all employees in Canada and in the US. It does not apply to employees in a probation period in the same way: during the first 3 months of employment (or up to 6 months if probation was extended under HR-POL-014 Employment Status and Classification Policy), the Bank may end employment or take other steps without following every step below, though the Bank will still act fairly and lawfully. Where an employee is covered by a collective agreement or by employment law that provides additional rights, that agreement or law applies. Where applicable law gives a greater right, the law applies. Terminations without cause are governed by HR-POL-025 Involuntary Termination and Severance Policy.

## 3. Principles

- **Fairness:** the employee is told what the concern is and may respond before a decision is made.
- **Proportionality:** the response matches the seriousness, frequency and impact of the behaviour or performance gap.
- **Consistency:** similar cases are treated similarly, taking into account role, history and circumstances.
- **Documentation:** facts, meetings and decisions are recorded promptly and accurately.
- **Confidentiality:** information is shared only with people who need it.
- **Support:** employees are reminded of the Wellspring Support Program (1-800-555-0166) and, where relevant, of accommodation rights under HR-POL-018 Workplace Accommodation and Accessibility Policy. Medical or protected reasons for a concern are considered before any step.

## 4. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Manager | Identifies concerns early, holds coaching conversations, consults HR before any written warning, delivers and documents steps. |
| HRBP | Consulted before any written warning; reviews facts and consistency; supports the manager and employee. |
| Employee Relations (ER) consultant | Advises on process, reviews consistency across the Bank, approves any termination and leads investigations of serious matters. |
| Director | Approves final written warnings and suspensions (other than suspension with pay pending investigation). |
| VP Employee Relations | Can extend a suspension with pay and, with Legal, approves a termination for cause. |
| Employee | Co-operates, responds to concerns, and takes action to improve. |

## 5. Progressive discipline steps

Steps are normally taken in order. The table summarizes each step, its record and how long it stays active.

| Step | What it is | Documented? | Active period |
| --- | --- | --- | --- |
| 1. Coaching conversation | A manager conversation setting out expectations and support. Not discipline. | Short note on file, not a disciplinary record | Not applicable |
| 2. Verbal warning | A formal discussion that the behaviour is a concern and that further issues may lead to more serious action. | Yes, confirmed in writing to the employee | 6 months |
| 3. Written warning | A formal letter describing the concern, the expected change and the consequences of repeating it. | Yes, on FORM-HR-071 | **12 months** |
| 4. Final written warning | A formal letter stating that further misconduct or failure to improve may lead to termination. May include an unpaid suspension of **up to 3 days**. | Yes, on FORM-HR-071 | **24 months** |
| 5. Termination | End of employment for cause. | Yes | Not applicable |

### 5.1 Active periods

A warning is "active" for the period shown from the date it is delivered. While a warning is active it may be relied on if a similar or related concern arises. When the period ends without a further warning on the same or a related matter, the warning no longer counts as a step. A new, unrelated concern is assessed as a new matter. Expired warnings are not used to decide a new step, though they remain in the confidential file until the retention period in HR-REF-002 Employee Records Retention Schedule has ended.

### 5.2 Skipping steps

The Bank is not required to follow every step. The manager, with the HRBP and Employee Relations, may begin at a later step depending on the seriousness of the matter and the employee's history.

## 6. Serious misconduct

Serious misconduct may result in a final written warning or immediate termination without prior steps. Examples include:

- theft, fraud or dishonesty;
- violence, threats or intimidation (see HR-POL-005 Workplace Harassment and Violence Prevention Policy);
- harassment or discrimination;
- serious breach of confidentiality or client privacy;
- falsifying records, including time records or expense claims;
- serious breaches of HR-POL-001 Code of Conduct and Ethics, such as bribery or insider trading;
- working under the influence of alcohol or drugs, or the deliberate misuse of Bank systems.

### 6.1 Suspension with pay pending investigation

When an allegation is serious, or presence at work could put people, customers or the investigation at risk, the manager may, with HRBP and ER approval, place the employee on **suspension with pay for up to 10 business days** while the matter is investigated. The VP Employee Relations may extend that period in writing, with the reason and a new end date. Suspension with pay is neutral: it is not discipline, and it does not imply guilt. The employee will be told in writing why they are suspended, that they remain on payroll and benefits, and whom to contact. Access to Bank systems and premises may be restricted, and the employee must be available to take part in the investigation.

### 6.2 Unpaid suspension

An unpaid suspension may be applied only as part of a final written warning, for **up to 3 days**, with Director approval, and where law allows. Employees in the US who are exempt under the FLSA are suspended in full-day increments only, so that salary treatment complies with the law.

## 7. Right to respond and support person

Before any written warning, final written warning or termination, the employee receives the facts in writing or in a meeting and may respond. The employee may:

1. respond in writing within **5 business days** after receiving the written warning or the notice of the allegations;
2. bring a **support person** (a colleague or representative who is not legal counsel) to any disciplinary or investigation meeting; and
3. ask Employee Relations to review whether the steps and facts were applied consistently.

A response does not stop the process, but the manager, HRBP and Employee Relations will consider it, and any new information, before the decision is final.

## 8. Approvals and documentation

| Action | Required approval or consultation |
| --- | --- |
| Coaching conversation | None; manager may call the Manager Hotline (1-800-555-0143) for advice |
| Verbal warning | Manager; HRBP informed |
| Written warning | **HRBP consulted before delivery** |
| Final written warning, or unpaid suspension | HRBP and Employee Relations; Director approval |
| Suspension with pay pending investigation | Manager, HRBP and Employee Relations; extension beyond 10 business days by VP Employee Relations |
| Termination for cause | **Employee Relations approval**; VP Employee Relations and Legal approval (see HR-POL-025 Involuntary Termination and Severance Policy) |

Every written warning uses **FORM-HR-071 Written Warning and Attendance Plan Template**. It states the date, the facts, the policy or standard breached, the expected behaviour or improvement, the support offered, the active period and the consequences of further concerns. The employee is asked to sign to acknowledge receipt, which does not mean agreement; if the employee declines, the manager notes that on the form. Disciplinary meetings are held privately, preferably on a Tuesday to Thursday, and a copy is placed in the confidential file within 2 business days.

## 9. Consistency review

Employee Relations reviews each proposed written warning, final written warning and termination for consistency with comparable past cases. It compares the conduct, the role, the length of service, the employee's history, any mitigating factors, and whether any bias may have affected the proposed step. It also ensures that no step relates to a protected ground, a request for accommodation, a leave, a good-faith complaint, or a report made under HR-POL-022 Whistleblower and Speak-Up Policy. Employee Relations reports anonymized discipline trends to the HR Policy Committee each year.

## 10. Link to performance and attendance

### 10.1 Performance improvement

Where the concern is performance rather than conduct, a Performance Improvement Plan under HR-POL-013 Performance Improvement Policy is the first formal step. It normally runs for 60 days with weekly check-ins. An unsuccessful PIP leads to progressive discipline under this policy, up to termination, and the steps taken during the PIP are considered when choosing the step.

### 10.2 Attendance

Attendance concerns follow the stages in HR-POL-004 Attendance and Absenteeism Policy: an informal conversation (Stage 1), a written attendance plan on FORM-HR-071 (Stage 2) and a final written warning (Stage 3). Termination for attendance occurs only after review by HR and Employee Relations. Protected absences never count towards attendance discipline.

## 11. Employee relations support

Beyond discipline, Employee Relations offers conflict coaching, facilitated conversations and mediation, workplace investigations, and advice to managers on difficult conversations. Employees can contact their HRBP, HR Connect (1-800-555-0142), or the Ombuds Office (ombuds@bank.example) for confidential, informal and independent guidance. Managers can call the Manager Hotline, which responds within 4 business hours.

## 12. Records and retention

Disciplinary records are kept in the confidential employee file. Investigation files are kept for 10 years after closing, as set out in HR-REF-002 Employee Records Retention Schedule. Employees may request access to their own file under HR-POL-016 Employee Data Privacy Policy.

## 13. Exceptions

An exception to the steps or timelines in this policy requires the written approval of the VP Employee Relations and must be recorded in the file with the reason.

## 14. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 4.0 | 2025-04-01 | Current version. Aligned active periods (written warning 12 months, final written warning 24 months), set the 10 business day limit for suspension with pay, and added the link to HR-POL-013 and HR-POL-004. |
