# Performance Improvement Plan

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-070 |
| Title | Performance Improvement Plan |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | VP Employee Relations |
| Audience | Managers |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-013, HR-POL-021, HR-POL-018, HR-POL-011 |

## 1. Purpose and when to use this form

Managers use this form to set out a written, time-limited plan for an employee whose performance is below expectations. Start a plan after a year-end rating of Needs Improvement or Unsatisfactory, or after documented sustained underperformance and at least one documented coaching conversation.

## 2. Who completes it and who approves

The manager completes it with the HRBP. **The HRBP must approve it before the meeting.** Consider accommodation needs first; if a need is known or suspected, the HRBP involves the Accommodation Specialist (HR-POL-018). A 90-day plan also needs Employee Relations approval.

## 3. Where and when to submit

Send the draft and evidence to the HRBP at least 3 business days before the kickoff meeting, which is held within 10 business days of the trigger. The final review and written outcome follow within 5 business days of the end date.

## 4. Form fields

| Field | Required | Notes |
| --- | --- | --- |
| Employee, manager, HRBP | Yes | |
| Specific performance gaps with examples | Yes | |
| Expected standard | Yes | Measurable and realistic for the band and role |
| Improvement targets and dates | Yes | |
| Support the Bank provides | Yes | Training, coaching, tools, workload, mentor |
| Start and end dates | Yes | 30 days; 60 days is standard; up to 90 days |
| Weekly check-in day and time | Yes | 30 minutes every week |
| Mid-point review date | Yes | |
| How progress is measured | Yes | |
| Consequences if unsuccessful | Yes | |
| Employee comments | No | Within 5 business days |

## 5. Declarations and signatures

- Manager and HRBP: the plan is based on documented facts, is not retaliation, and accommodation has been considered.
- Employee: I have received the plan. My signature does not mean agreement. If the employee refuses to sign, the manager records this.
- The employee may bring a support person who is not legal counsel.

## 6. What happens next

| Outcome | Result |
| --- | --- |
| Success | The plan closes; regular check-ins continue |
| Extension | One extension of up to 30 days, approved by the HRBP |
| Unsuccessful | Progressive discipline under HR-POL-021; Employee Relations approval before termination |

A protected absence or approved leave of more than 5 consecutive business days pauses the plan. During the plan the employee is not eligible for a merit increase or an internal transfer. Records leave the active file 12 months after successful completion. Where applicable law gives a greater right, the law applies. Manager Hotline: 1-800-555-0143.

## 7. Related documents

- HR-POL-013 Performance Improvement Policy
- HR-POL-021 Employee Relations and Progressive Discipline Policy
- HR-POL-018 Workplace Accommodation and Accessibility Policy

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-09-01 | Standard plan length 60 days (was 90) from 1 June 2025; added accommodation review before the plan starts. |
