# How to add or remove a dependant

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-013 |
| Title | How to add or remove a dependant |
| Document type | How-to article |
| Version | 1.1 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-10-20 |
| Next review | 2027-10-20 |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-001, HR-PLN-004, HOW-011 |

## 1. The short answer

Report the change in MyHR under Benefits, Life Event Change, within 31 days of the event, with supporting documents.

## 2. Who this applies to

Employees enrolled in Bank benefits in Canada, Quebec and the US. Eligible dependants are:

| Dependant | Canada | US |
| --- | --- | --- |
| Spouse, common-law partner or domestic partner | Eligible | Eligible |
| Children | To age 21 (to 26 if a full-time student) | To age 26 |

## 3. Steps to add a dependant

1. Select **MyHR > Benefits > Life Event Change** and choose the event: marriage, common-law or domestic partnership; birth or adoption of a child; or loss of other coverage for a dependant.
2. Enter the event date and the dependant's details.
3. Upload supporting documents, for example a marriage certificate or a birth record. Benefits Administration may ask for proof of eligibility.
4. Choose your new coverage level (for example employee only to family) and review the premium change. Canada, Standard: $22 per month employee only and $138 per month family. US, Choice PPO: $58 per pay period employee only and $236 family.
5. Submit within 31 days of the event.

## 4. Steps to remove a dependant

1. Select **MyHR > Benefits > Life Event Change** and choose divorce, separation, death of a covered person, or change in dependant status (for example a child no longer eligible by age).
2. Enter the date and submit within 31 days, with documents where requested.
3. Review the new coverage tier, which may lower your premium.

## 5. What happens next

If you apply within 31 days, coverage for a new dependant starts on the date of the event. Benefits Administration confirms the change and adjusts premiums on your pay statement. If you miss the window, you can change only at annual enrolment (2 to 16 November 2026 for coverage from 1 January 2027). Review your life insurance beneficiaries under **MyHR > Benefits > Beneficiaries** at the same time; optional spouse life ($25,000) and dependent child life ($10,000) are separate elections.

## 6. Common mistakes

- Waiting for the next annual enrolment instead of reporting the event within 31 days.
- Not removing a dependant who stops being eligible, for example a Canadian child who turns 21 and is not a full-time student. Providing false dependant information is a breach of the Code of Conduct and Ethics.
- Adding a person who is not an eligible dependant.
- Forgetting documents.

## 7. Who to call

HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, or live chat in MyHR; English and French. Maplewood Benefits: 1-800-555-0190.

## 8. Related documents

- HR-GDE-001 Employee Benefits Guide
- HR-PLN-004 Group Benefits Booklet (Canada)
- HOW-011 How to enrol in benefits or change your election after a life event

## 9. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.1 | 2026-01-01 | Premium examples updated for plan year 2026. |
| 1.0 | 2025-01-06 | First edition. |
