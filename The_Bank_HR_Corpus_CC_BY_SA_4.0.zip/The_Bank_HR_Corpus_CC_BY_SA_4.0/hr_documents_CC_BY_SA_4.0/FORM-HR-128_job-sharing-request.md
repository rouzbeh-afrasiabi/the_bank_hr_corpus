# Job Sharing Request

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-128 |
| Title | Job Sharing Request |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-042, HR-POL-014, HR-GDE-001, FORM-HR-121 |

## 1. Purpose and when to use this form

Use this form when two employees want to share one full-time role (HR-POL-042 Secondment and Job Sharing Policy). The hours are split 50/50 or 60/40. Each partner is treated as a regular part-time employee, so benefits are pro-rated by hours (HR-POL-014 Employment Status and Classification Policy).

## 2. Who completes it and who approves

Both partners complete it together. Each partner's manager and the HRBP approve; HR Operations records the arrangement. Both partners must have at least 12 months of service, a last rating of Meets Expectations or higher, and no active performance improvement plan. Promotions and transfers are handled separately.

## 3. Where and when to submit (deadline, channel, processing time)

Submit one joint request in MyHR (Work Arrangements > Job Sharing) at least 30 days before the proposed start. The HRBP confirms eligibility within 3 business days and decides with the manager within 10 business days of the complete request, then confirms the outcome in writing. If approved, the arrangement starts with a 6-month trial.

## 4. Form fields

| Field | Required | Notes |
| --- | --- | --- |
| Partner 1 and Partner 2: name, employee ID, band, start date | Yes | Each must have 12 months of service |
| Role and team to be shared | Yes | One full-time role |
| Hours split | Yes | 50/50 or 60/40; say who takes which share |
| Proposed weekly schedule and overlap time | Yes | |
| Proposed start date | Yes | |
| Written handover protocol | Yes | Covers client files, open work, communication and decisions |
| Who is the point of contact for stakeholders | Yes | |
| Impact on pay, benefits and vacation | Yes | Pro-rated by scheduled hours (see HR-GDE-001 Employee Benefits Guide) |
| Continuity plan if one partner is absent | Yes | |
| Reason for the request | No | |

## 5. Declarations and signatures

We confirm that we meet the eligibility rules, that we understand that pay and benefits are pro-rated by hours, and that we will follow the written handover protocol. If either partner leaves the arrangement, a 60-day review is triggered. Partner 1 signature and date: ____________. Partner 2 signature and date: ____________. Managers and HRBP: ____________.

## 6. What happens next

After approval, HR Operations updates each partner's work schedule and status in the HR system. A review at the end of the 6-month trial decides whether the arrangement continues. If either partner leaves, the HRBP starts the 60-day review, which decides whether the remaining partner continues, a new partner is found, or the role returns to a single full-time holder.

## 7. Related documents

- HR-POL-042 Secondment and Job Sharing Policy
- FORM-HR-121 Secondment Request
- HR-POL-014 Employment Status and Classification Policy

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-09-01 | Added the 6-month trial, handover protocol and 60-day review. |
| 1.0 | 2024-09-01 | Initial form. |
