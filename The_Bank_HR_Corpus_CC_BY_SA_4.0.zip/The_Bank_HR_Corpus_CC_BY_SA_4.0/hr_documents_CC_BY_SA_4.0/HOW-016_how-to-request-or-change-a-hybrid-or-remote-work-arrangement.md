# How to request or change a hybrid or remote work arrangement

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-016 |
| Title | How to request or change a hybrid or remote work arrangement |
| Document type | How-to article |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-01-05 |
| Last reviewed | 2026-08-20 |
| Next review | 2027-08-20 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-002, FORM-HR-030, HR-POL-018 |

## 1. The short answer

Submit FORM-HR-030 (Work Arrangement Request) in MyHR > Personal Information > Work Arrangement; your manager responds within 5 business days.

## 2. Who this applies to

Regular full-time, regular part-time and fixed-term employees in Canada (including Quebec) and the US. On-site roles, such as customer-facing branch and operations roles, do not need the form. Casual, student, co-op and intern employees follow their engagement letter.

## 3. Steps

1. **Pick the arrangement.** Hybrid means at least 3 days a week in the office, with Tuesday and Thursday as anchor days; your team chooses the third day. Part-time hybrid employees attend 60% of scheduled days, rounded up.
2. **For Remote, check eligibility.** The business unit head must have designated your role remote-eligible, you have completed probation, your last rating is Meets Expectations or higher, you have no active performance improvement plan, and your home address is in a jurisdiction on the approved employment-jurisdiction list.
3. Open MyHR > Personal Information > Work Arrangement and complete FORM-HR-030.
4. Submit. Your manager responds within 5 business days; for Remote the HRBP confirms eligibility.

## 4. Deadlines and what happens next

| Situation | What to do |
| --- | --- |
| Moving to another province or state | Submit at least 30 days before the move |
| Ending your arrangement | Give 4 weeks' notice |
| The Bank ends it for business reasons | You receive at least 30 calendar days' written notice |
| Team changes its third day | 10 business days' notice to team members |

HR Operations records the approved arrangement in MyHR. Remote employees attend up to 4 planned team or client events in person each year. A manager may approve up to 12 office-attendance exception days per calendar year; more needs the HRBP. Accommodation needs follow HR-POL-018 Workplace Accommodation and Accessibility Policy and do not count against the 12 days.

## 5. Common mistakes

- Treating the form as optional. The arrangement is only valid once recorded.
- Moving before approval. Moving province or state needs approval first because of payroll, tax and employment-law rules.
- Confusing this with a short trip. For a stay elsewhere of up to 20 working days, use HOW-017 (FORM-HR-031).
- Counting a holiday or approved absence on an anchor day as a missed day. It is not.
- Forgetting core hours of 10:00 to 15:00 local time and the VPN rules.

## 6. Who to call

- Your manager first; HR Operations and your HRBP handle exceptions.
- HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, in English or French.

## 7. Related documents

- HR-POL-002 Remote and Hybrid Work Policy (the owning document)
- FORM-HR-030 Work Arrangement Request (Hybrid or Remote)
- HR-POL-017 IT Acceptable Use and Information Security Policy

Where applicable law gives a greater right, the law applies.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-01-05 | Updated for the 3-day hybrid minimum and Tuesday and Thursday anchor days. |
| 1.0 | 2025-01-01 | First version (2 office days a week, no anchor days). |
