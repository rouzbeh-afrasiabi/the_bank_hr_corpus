# Privacy Request and Incident Handling Procedure

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-PRC-008 |
| Title | Privacy Request and Incident Handling Procedure |
| Document type | Procedure |
| Version | 3.0 |
| Status | Current |
| Effective date | 2026-02-01 |
| Last reviewed | 2026-09-01 |
| Next review | 2027-09-01 |
| Policy owner | Chief Privacy Officer |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | HR only |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-016, HR-POL-017, HR-POL-018, HR-REF-002, HR-PRC-001, HR-PRC-007, FORM-HR-090, FORM-HR-091, FORM-HR-092 |

## 1. Purpose

This procedure tells HR, Payroll Services, Benefits Administration and the Privacy Office how to handle personal information access requests, privacy breaches and impact assessment intake. It implements HR-POL-016 Employee Data Privacy Policy and keeps its numbers: 30 days for access requests, 24 hours for breach reporting, 15 business days for PIA review and 30 days for DPIA decisions. It adds steps, system actions and checklists only.

## 2. Scope

The procedure applies to personal information of employees, former employees, applicants, dependants and beneficiaries handled by the Bank in Canada and the US, in any format. Laws in scope include PIPEDA, provincial private-sector privacy laws (including Quebec's Law 25 and the BC and Alberta PIPA) and US state laws such as CCPA and CPRA. Where applicable law gives a greater right, the law applies.

## 3. Roles

| Role | Responsibility |
| --- | --- |
| Chief Privacy Officer | Accountable for the program; chairs the Privacy Governance Committee. |
| Privacy Office (privacy@bank.example) | Verifies identity, decides on access, assesses breaches, reviews PIAs and DPIAs. |
| HR Operations, Payroll Services, Benefits Administration | Search and supply records; apply this procedure. |
| HR Connect agent | Recognizes a privacy request or incident and routes it to the Privacy Office the same business day. |
| Security Operations Centre (SOC), 1-800-555-0155 | Handles cyber incidents and lost devices. |
| CISO | Reviews DPIAs; owns technical safeguards. |
| Legal | Advises on withholding, regulator contact and legal holds. |
| Privacy Governance Committee | Decides DPIAs. |

## 4. Access and correction requests

### 4.1 Timeline

| Step | Rule |
| --- | --- |
| Request received (FORM-HR-090 Personal Information Access Request, or privacy@bank.example) | Log in the HR Case Portal the same business day |
| Acknowledge and check completeness | Within 2 business days |
| Identity verified | Before any release |
| Response due | Within 30 days of a complete request |
| Extension | Up to a further 30 days, with written notice to the requester that gives the reasons |
| Fee | None for standard requests |

The 30 days start when the request is complete. If the request is unclear, ask the requester to clarify in the acknowledgement; the clock starts when the answer arrives.

### 4.2 Procedure

1. **Log.** Open a Privacy case in the HR Case Portal. Record the requester, the type (access, correction, both), the date received and the due date.
2. **Verify identity.** Confirm identity through MyHR sign-in with multi-factor authentication for current employees. For former employees and applicants, check two identifiers on file and, if needed, government photo ID. Do not release anything until identity is confirmed. If a representative applies, ask for written consent.
3. **Search.** Send a search request to HR Operations, Payroll Services, Benefits Administration, Employee Relations, the Leaves team and the Accommodation Specialist. Systems owners return the records within 10 business days. Employees can see much of their own information in MyHR, so point to it where it answers the request.
4. **Review and redact.** The Privacy Office reviews each record. Remove information about other people, privileged legal advice, investigation information protected by law, and information where access could harm someone. Record each redaction and the reason.
5. **Decide.** Release in full, release with redactions, or refuse in part with an explanation. Decisions to withhold are reviewed by Legal.
6. **Release.** Send the package through a secure MyHR message, not by email attachment. Include an explanation of redactions and the right to complain to the Privacy Office or a regulator.
7. **Corrections.** Accept a correction when the information is shown to be inaccurate; otherwise add a note of the disagreement to the record. Tell anyone who received the wrong information where practical.
8. **Close.** Log the date of release, close the case and keep the file under the retention schedule (HR-REF-002 Employee Records Retention Schedule).

### 4.3 Internal schedule

To protect the 30-day limit, use these internal targets: search request sent by day 3; records back by day 13; redaction complete by day 20; Legal review by day 24; release by day 28. If any target slips, tell the Privacy Office lead so that the extension notice can be sent before day 30.

## 5. Breach and incident handling

### 5.1 Who reports and when

Anyone who discovers or suspects a breach reports it to the Privacy Office (privacy@bank.example) immediately and no later than 24 hours after discovery. Cyber incidents and lost devices are also reported to the SOC immediately and within 1 hour. A manager or HR employee who is told of a breach forwards it at once. Failure to report is a breach of HR-POL-016.

### 5.2 Triage steps

| Step | Action | Target |
| --- | --- | --- |
| 1 | Log in the breach register with the time of discovery and who found it | Same business day |
| 2 | Contain: recall the message, remove access, retrieve the device or file, ask unintended recipients to delete | Immediately |
| 3 | Classify: type of data, number of people, sensitivity, who received it | Within 24 hours of the report |
| 4 | Assess real risk of significant harm with the CISO and Legal | As soon as the facts are known |
| 5 | Decide on notification | Without delay |
| 6 | Notify the regulator and affected individuals where required, as soon as feasible | As soon as feasible |
| 7 | Review root cause and corrective actions | After containment |
| 8 | Close and record | When actions are complete |

Examples HR often sees: an email with employee data sent to the wrong person, a lost device, access to a file by a person without a need to know, a payroll or benefits file sent to a vendor in error, or a manager sharing medical information.

### 5.3 Decision point: notification

| Factor | Question |
| --- | --- |
| Sensitivity | Health, disability, financial account, government identifier or diversity data? |
| Probability of misuse | Was the information exposed to someone who may misuse it? |
| Containment | Was it fully recovered or deleted and confirmed? |
| Volume and vulnerability | How many people? Any vulnerable people? |
| Law | Does a Canadian provincial or federal law or a US state law require notice? |

Where there is a real risk of significant harm, notify the regulator and the affected individuals as soon as feasible. The notice states what happened, what information is affected, what the Bank has done, what the person can do and where to get help (Wellspring Support Program, 1-800-555-0166, 24/7, where appropriate). Legal reviews every regulator notice. Record every breach, including those that do not need notification, in the breach register.

### 5.4 Special cases

- **Medical or accommodation information.** Treat any disclosure as high sensitivity and tell the Accommodation Specialist (HR-PRC-007 Accommodation Case Management Procedure). Review the access log for the file.
- **Case files.** If material from an employee relations case is mis-sent, tell the ER consultant (HR-PRC-001 Employee Relations Case Handling Playbook).
- **Vendors.** For a breach at Maplewood Benefits, Evergreen Retirement Services, Wellspring Support Program or Clearline, the contract requires prompt notice; log it and treat it as a Bank breach.
- **Legal hold.** Legal holds override destruction until Legal releases them.

## 6. PIA and DPIA intake

### 6.1 Which assessment?

| Situation | Assessment |
| --- | --- |
| New or materially changed HR system, process, vendor or tool that handles employee personal information | PIA (FORM-HR-091) |
| Employee monitoring, biometrics, automated or AI-assisted decisions about employees, large-scale sensitive data, cross-border transfers | PIA and DPIA (FORM-HR-092) |
| Transfer of information outside Quebec | PIA before the transfer |

### 6.2 Intake steps

1. The system owner submits FORM-HR-091 (and FORM-HR-092 where high-risk) in the HR Case Portal. Log the intake date.
2. The Privacy Office checks completeness within 2 business days and returns incomplete forms.
3. PIA: the Privacy Office reviews within 15 business days and decides; it also checks vendor and contract terms. Reassess every 3 years or on material change.
4. DPIA: the system owner works with the Privacy Office; the Privacy Office, CISO and Legal review it; the Privacy Governance Committee decides within 30 days. A human must make the final decision on any employment outcome, with documented safeguards for fairness and explainability. Reassess annually.
5. A system may not go live without a decision. Project plans must include the 15 business day and 30 day periods.
6. For Quebec, the Privacy Office completes the PIA step before a transfer outside Quebec with the system owner.
7. Only Bank-approved AI tools may be used, and employee personal data may not be put into public AI tools. An AI tool in an HR process needs the assessment first (HR-POL-017 IT Acceptable Use and Information Security Policy).

## 7. Logs and reporting

The Privacy Office keeps the breach register, the request log and the assessment log. HR access logs to medical and accommodation files are reviewed quarterly. Results are reported to the Chief Privacy Officer and, each year, to the Privacy Governance Committee.

## 8. Checklist

- [ ] Request or incident logged the same business day.
- [ ] Identity verified before release.
- [ ] Response sent within 30 days, or extension notice sent with reasons.
- [ ] Redactions recorded.
- [ ] Breach reported within 24 hours of discovery; SOC told within 1 hour where cyber.
- [ ] Notification decision recorded.
- [ ] PIA review within 15 business days; DPIA decision within 30 days.
- [ ] Case closed and retention set.

## 9. Escalation and contacts

Escalate to the Chief Privacy Officer when a deadline is at risk, when a regulator makes contact, or when the breach affects many people. Employees may complain to the Privacy Office, the Speak-Up Line (1-800-555-0177) or a privacy regulator at any time. Reports made in good faith are protected from retaliation.

## 10. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 3.0 | 2026-02-01 | Aligned with HR-POL-016 version 4.0: added the PIA and DPIA intake steps, the AI in HR rule and the Quebec transfer step. |
| 2.0 | 2024-02-01 | Set the 24-hour breach reporting step. |
