# Capital Markets Addendum

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-SUP-003 |
| Title | Capital Markets Addendum |
| Document type | Supplement |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-08-01 |
| Last reviewed | 2026-07-27 |
| Next review | 2027-07-27 |
| Policy owner | Chief Compliance Officer |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-006, HR-POL-001, HR-POL-029, HR-POL-031, HR-POL-032, HR-POL-033, HR-POL-003 |

## 1. Purpose

This addendum brings together the rules that apply to Capital Markets employees in addition to, or in a stricter form than, the Bank's standard employment policies. It lists each rule briefly and points to the policy that owns it. Where applicable law gives a greater right or sets a stricter standard, the law applies.

## 2. Scope

The addendum applies to all employees in the Capital Markets business unit in Canada and the US, including trading, sales, research, structuring and desk support roles. Several sections also apply to employees in other units that Compliance designates. The Chief Compliance Officer owns the addendum.

## 3. Block leave and the audit

Every employee takes at least 10 consecutive business days of vacation once per calendar year (see HR-POL-006 Vacation and Paid Time Off Policy). Capital Markets roles are audited by the Chief Compliance Officer's office.

- Schedule the block in MyHR by 30 June and complete it by 31 December.
- During the block, access to trading, ledger and client systems is suspended, and the employee does not work.
- A statutory holiday inside the block does not break the 10 consecutive business days.
- An approved leave of 10 or more consecutive business days satisfies the requirement for that year.
- A manager who cannot release an employee must obtain written approval from their VP and the Chief Compliance Officer for an alternative control, such as a documented rotation of duties.

## 4. Fiscal year-end blackout

The Capital Markets fiscal year ends on 31 October, the same as the Bank's fiscal year. Vacation is not available during the fiscal year-end week. The business unit head publishes the blackout in MyHR, and it applies only to the roles named in the notice. A blackout never prevents an employee from taking all of their vacation in a year, and it does not remove the block leave requirement.

## 5. Personal trading and the restricted list

Employees in Capital Markets, Wealth Management and Treasury are covered persons for personal trading (see HR-POL-032 Personal Trading and Restricted Lists Policy and HR-POL-001 Code of Conduct and Ethics). The key rules are:

| Rule | Summary |
| --- | --- |
| Pre-clearance | Required before every trade in individual securities, requested on FORM-HR-124; Compliance answers within 1 business day |
| Holding period | Minimum 30 days for each security; no short-term trading |
| Restricted and watch lists | No trading in a restricted or watch-list name |
| Inside information | No trading, and no tipping, while holding material non-public information |
| Accounts | Disclose all brokerage accounts within 30 days of hire or designation; Bank-approved brokerage only; duplicate statements go to Compliance |
| Annual disclosure | Personal holdings on FORM-HR-125 by 31 January each year |

HR-POL-032 owns the details, including how long a pre-clearance approval is valid and the products that do not need pre-clearance. Breaches are conduct matters under HR-POL-021 Employee Relations and Progressive Discipline Policy.

## 6. Communications recording and monitoring

Telephone lines in trading are recorded, and electronic communications on Bank systems are scanned. These measures exist for security, compliance, fraud prevention and safety, and are disclosed to employees. Call recordings for Capital Markets and Wealth Management are kept for 7 years; other monitoring logs are kept for 13 months. Employees use only Bank-approved channels for business communications, and never personal messaging or personal devices for trading instructions. Compliance and Security access recordings only with a documented reason, and HR requests need Privacy Office approval (see HR-POL-033 Electronic Monitoring and Right to Disconnect Policy). Employees acknowledge the policy on FORM-HR-129.

## 7. Incentive deferral and clawback

Deferral and clawback are owned by HR-POL-031 Incentive Deferral and Clawback Policy. In summary:

| Item | Rule |
| --- | --- |
| Who is covered | Band 7 and above, and Designated Material Risk Takers named by the Chief Risk Officer (any band) |
| When deferral applies | The Annual Incentive Plan payout is above $100,000 (CAD in Canada, USD in the US) |
| Share deferred | 40% for Bands 7 and 8; 50% for Band 9 and Material Risk Takers |
| Vesting | Equally over 3 years, one third each year on the anniversary of the payment date |
| Clawback window | Up to 3 years after payment (5 years for Material Risk Takers) for misconduct, a material misstatement or a material risk-management failure |

The Board HR Committee decides clawback on the CHRO's recommendation, with written notice and 15 business days to respond.

## 8. Licensing and registration

Capital Markets roles and Portfolio Managers hold the securities registrations their role needs: in Canada, the securities registrations required for the role, and in the US, the Series examinations the role needs (see HR-POL-029 Licensing, Registration and Qualification Policy). The rules are:

- No licensed duties until the licence or registration is active.
- The Bank pays exam fees (two attempts), licence and registration fees and required continuing education, and grants 5 paid study days per designation exam.
- Tell Compliance within 2 business days of any change in registration status, regulatory inquiry, complaint, sanction, bankruptcy, criminal charge or conviction.
- A lapse removes the employee from licensed duties immediately, with up to 60 days to restore the licence, followed by a review by the HRBP and Compliance.
- The annual licence review is held each 1 September.

## 9. Shift premium and on-call

Hours and overtime follow HR-POL-003 Working Hours and Overtime Policy. Where an employee works in a unit that policy names for the shift premium, the premium is $2.00 per hour (CAD in Canada, USD in the US) for hours between 18:00 and 06:00. The on-call allowance is $200 CAD or $150 USD per week, with a call-out minimum of 3 hours' pay at the applicable rate. Employees in Bands 5 and above are not overtime-eligible. A right to disconnect applies except when on call.

## 10. Conduct escalation

Capital Markets employees escalate concerns promptly:

1. Raise the concern with the manager or the Compliance desk the same business day if it involves a suspected breach, a conflict of interest or suspicious activity.
2. Use the Ethics Office (ethics@bank.example) or the Speak-Up Line (1-800-555-0177, 24 hours, 7 days, anonymous option) if the manager is involved or the employee prefers.
3. Report a regulatory inquiry, complaint or sanction to Compliance within 2 business days.

The Code attestation, completed each year by 31 October, includes the fit-and-proper attestation. Gifts and entertainment limits of $100 per occasion and $250 per source per calendar year apply. Retaliation against anyone who raises a concern in good faith is prohibited.

## 11. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Employee | Takes the block, pre-clears trades, keeps licences current, escalates concerns |
| Manager | Releases employees for block leave, reviews desk activity, escalates breaches |
| Chief Compliance Officer | Owns this addendum, audits block leave, administers pre-clearance and the restricted list |
| HRBP | Supports licence reviews, redeployment and conduct cases |
| Payroll Services | Calculates premiums, allowances and deferral amounts |

## 12. Contacts

Compliance desk: through the Capital Markets compliance officer assigned to the desk. HR Connect: 1-800-555-0142, hrconnect@bank.example. Manager Hotline: 1-800-555-0143.

## 13. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.0 | 2023-08-01 | First edition of the addendum |
| 2.0 | 2025-08-01 | Added deferral and clawback, licensing and the communications recording summary, and aligned personal trading with HR-POL-032 |
