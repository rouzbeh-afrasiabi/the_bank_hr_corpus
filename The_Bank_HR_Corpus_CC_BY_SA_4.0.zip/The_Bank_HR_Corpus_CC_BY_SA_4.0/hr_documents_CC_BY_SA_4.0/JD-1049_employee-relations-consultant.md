# Employee Relations Consultant

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1049 |
| Title | Employee Relations Consultant |
| Document type | Job description |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-07-14 |
| Next review | 2027-07-14 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-021, HR-POL-005, HR-PRC-001, HR-PRC-002, HR-GDE-006, HR-FWK-001 |

## 1. Role summary

The Employee Relations (ER) Consultant is a Tier 3 specialist who manages conduct, attendance, discipline, harassment and workplace investigation matters. The consultant advises managers, protects fair process for all parties and makes sure the Bank meets its legal and policy obligations. The role is Band 5 (Team Lead / Manager I): it is a senior specialist accountable for the quality of case outcomes. See HR-GDE-006 Job Architecture and Pay Bands Guide.

## 2. Key responsibilities

- Take intake of ER cases in the HR Case Portal and triage them; start P1 cases (harassment, violence, safety) with first response within 4 business hours.
- Act as the designated recipient for complaints under HR-POL-005 Workplace Harassment and Violence Prevention Policy: acknowledge within 2 business days, set interim measures within 5 business days and track the 60 calendar day investigation target.
- Advise managers on progressive discipline under HR-POL-021 Employee Relations and Progressive Discipline Policy: coaching conversation, verbal warning, written warning (active 12 months), final written warning (active 24 months) and termination, with ER approval before any termination.
- Run or assign trained, impartial investigators following HR-PRC-002 Workplace Investigation Procedure and write clear, evidence-based findings.
- Manage case files under HR-PRC-001 Employee Relations Case Handling Playbook, including conflict checks and closure codes.
- Review attendance matters, including pattern triggers of 3 late arrivals in 30 days and 4 absence occurrences or 8 absence days in a rolling 12 months, taking protected absences into account.
- Prepare written warnings, attendance plans (FORM-HR-071) and termination documents with the HRBP, and attend termination meetings.
- Monitor for retaliation for 12 months after a harassment matter closes.
- Escalate threatened litigation, regulatory exposure and whistleblower overlap to the VP Employee Relations and Legal.
- Deliver training for managers on respectful workplace conduct and fair process.
- Analyse case trends and recommend preventive action.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in human resources, industrial relations, law or a related field.
- Seven to ten years of employee relations, HR or investigation experience.
- Demonstrated ability in neutral fact-finding, interviewing and written reporting.
- Strong knowledge of human rights, employment standards and workplace violence and harassment law in Canada and the US.

### 3.2 Preferred

- Formal investigator training and a recognized HR or legal designation.
- Experience in a unionized or highly regulated workplace.
- Bilingual English and French.

## 4. Competencies

Competency names follow HR-FWK-001 Competency and Leadership Model (Leader level, Bands 5 to 6).

- Judgement and Decision Quality
- Risk and Conduct Awareness
- Inclusive Leadership
- Collaboration
- Developing Others
- Adaptability

## 5. Compensation and classification

| Item | Detail |
| --- | --- |
| Band | 5 (Team Lead / Manager I) |
| Canada range | $90,000 to $134,000 CAD per year |
| US range | $88,000 to $132,000 USD per year |
| Incentive target | 10% of base salary (Annual Incentive Plan) |
| Overtime eligibility, Canada | No |
| FLSA classification, US | Exempt |
| Work arrangement | Hybrid |

## 6. Working conditions and accessibility

Office-based and hybrid by default, with at least 3 days a week in the office; Tuesday and Thursday are anchor days (HR-POL-002 Remote and Hybrid Work Policy; FORM-HR-030). The role involves emotionally demanding cases and strict confidentiality; the Wellspring Support Program is available to all employees. The Bank provides accommodation to the point of undue hardship (HR-POL-018 Workplace Accommodation and Accessibility Policy).

## 7. Reporting line

Reports to the Director, Employee Relations. The role has no direct reports.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-03-01 | Pay band aligned with the 2026 pay bands; added retaliation monitoring duty |
| 1.0 | 2025-01-01 | First issue |
