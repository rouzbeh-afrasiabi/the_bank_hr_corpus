# Whistleblower and Speak-Up Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-022 |
| Title | Whistleblower and Speak-Up Policy |
| Document type | Policy |
| Version | 3.1 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-08-11 |
| Next review | 2027-08-11 |
| Policy owner | Head of Ethics Office |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Applies to | All Canadian and US employees (see Scope) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-001, HR-POL-005, HR-POL-016, HR-POL-021, HR-REF-002 |

## 1. Purpose

The Bank relies on its people to raise concerns early, so that problems can be fixed before they harm customers, colleagues or the Bank. This policy explains what to report, how to report it, what happens next, and how the Bank protects people who speak up in good faith. It supports the duty to speak up in HR-POL-001 Code of Conduct and Ethics.

## 2. Scope

This policy applies to all employees in Canada and in the US, and to contractors, agency workers, suppliers and other third parties who wish to report a concern about the Bank. Concerns may be raised about the conduct of any employee, manager, executive, director or third party acting for the Bank. Where applicable law gives a greater right, the law applies. Nothing in this policy limits anyone's right to report to a regulator or law enforcement authority.

## 3. What to report

Report any suspected or actual wrongdoing, whether it has happened, is happening or is likely to happen. Examples include:

- fraud, theft, embezzlement or misappropriation of funds;
- bribery, corruption, kickbacks or improper gifts (see HR-POL-001 Code of Conduct and Ethics);
- money laundering, sanctions breaches, or failure to report suspicious activity;
- accounting, auditing, internal control or financial reporting irregularities, including pressure to misstate results;
- breaches of laws or regulations, including requirements set by banking regulators such as OSFI;
- market abuse, insider trading or manipulation of rates, prices or benchmarks;
- serious breaches of customer or employee privacy or information security (see HR-POL-016 Employee Data Privacy Policy);
- danger to health or safety, or damage to the environment;
- concealment of any of the above, or retaliation against someone who has reported.

Harassment, discrimination and violence complaints may also be made through the Speak-Up Line and are managed under HR-POL-005 Workplace Harassment and Violence Prevention Policy. Personal grievances about pay, performance ratings or workload should usually go to your manager, HRBP or the Ombuds Office, but the Ethics Office will redirect a concern if it was submitted in the wrong place.

You do not need proof. You need a reasonable, good-faith belief that something is wrong. Do not investigate on your own, confront the person involved, or collect confidential records that you are not entitled to access.

## 4. Reporting channels

| Channel | Details |
| --- | --- |
| Manager, senior manager or HRBP | In person, by phone or in writing; they must forward the concern to the Ethics Office within **1 business day** |
| Ethics Office | ethics@bank.example |
| **Speak-Up Line** | 1-800-555-0177, 24 hours a day, 7 days a week; operated independently by **Clearline**; anonymous option; interpreter available |
| Speak-Up web form | The Speak-Up page in MyHR (confidential; anonymous option) |
| Ombuds Office | ombuds@bank.example; independent, confidential and informal; helps you understand your options but does not conduct investigations |
| Audit Committee | A concern about the Ethics Office, a senior executive or a director may be sent directly to the Chair of the Audit Committee through Clearline |

### 4.1 Anonymity

You may report anonymously through the Speak-Up Line or the web form. Clearline gives you a report number and a password so that you can check progress and answer follow-up questions without revealing your identity. Anonymous reports are taken as seriously as named reports, although it may be harder to investigate when the Bank cannot ask follow-up questions. If you choose to identify yourself, the Bank keeps your identity confidential and tells only those who must know in order to investigate or comply with law. Do not try to identify an anonymous reporter.

## 5. What happens after a report

| Step | Who | Timeline |
| --- | --- | --- |
| Acknowledgement to the reporter (where contact is possible) | Ethics Office or Clearline | Within **3 business days** |
| Triage: assessing the report, deciding the route and risk, and assigning an investigator | Ethics Office | Within **5 business days** |
| Status updates to the reporter (where contact is possible) | Ethics Office | At least every **30 days** |
| Investigation and closure | Assigned investigator | Target **90 days** |
| Reporting to the Audit Committee | Head of Ethics Office | **Quarterly** |

### 5.1 Triage

The Ethics Office classifies each report by seriousness, subject and conflict risk. Reports are routed as follows: employment and conduct matters to Employee Relations; fraud and financial crime to Corporate Security or Compliance; privacy and information security matters to the Privacy Office or the Security Operations Centre; and allegations about senior executives, the Ethics Office or Employee Relations to the Audit Committee Chair, who will appoint an independent investigator. A person who is named in a report, or who has a close relationship with the person named, is never involved in triage or investigation. Where a report involves immediate danger, the matter is referred at once to Corporate Security (1-800-555-0119).

### 5.2 Investigation

Investigations are conducted by trained, impartial investigators, and external specialists may be engaged for complex matters. The investigator will gather documents and system records, interview witnesses and give the person named a fair chance to respond. Employees must co-operate fully and truthfully and must keep the matter confidential. The investigator writes a report with findings and recommendations. The target for closure is **90 days** from the report; where a case needs more time, the Ethics Office tells the reporter (where contact is possible) and the Audit Committee the reason for the delay.

### 5.3 Outcomes

Substantiated concerns lead to corrective action, which may include discipline up to termination for cause under HR-POL-021 Employee Relations and Progressive Discipline Policy, control improvements, repayment, or referral to regulators or law enforcement. The reporter is told whether the concern was addressed, but details about any individual's discipline are confidential. Even if a concern is not substantiated, the reporter is protected if it was raised in good faith.

## 6. Protection from retaliation

The Bank prohibits retaliation against anyone who reports a concern in good faith, helps with an investigation, or refuses to take part in wrongdoing. Retaliation includes dismissal, demotion, suspension, harassment, threats, reduced hours, negative performance ratings, loss of incentive pay, exclusion or any other adverse treatment connected to a report. Retaliation is itself serious misconduct and may lead to termination.

- Report suspected retaliation to the Ethics Office, the Speak-Up Line or Employee Relations. It is investigated as a new matter.
- The Ethics Office will check on the reporter's situation at least once during the investigation and again 6 months after closure.
- Managers must not try to identify an anonymous reporter, and must consult Employee Relations before any employment decision that affects a person known to have reported.
- A person who takes part in the wrongdoing is not excused simply by reporting it, although self-reporting and co-operation are taken into account.

## 7. Good faith and bad-faith reports

A report made in good faith is protected even if it turns out to be mistaken. **A report made knowingly falsely, maliciously or in bad faith is misconduct** and may lead to discipline.

## 8. Regulators and external reporting

Employees may contact a government regulator, an enforcement agency or law enforcement authority at any time, and do not need to tell or ask the Bank first. This applies, for example, to financial regulators, privacy commissioners, labour and employment standards authorities, and in the US to the relevant federal and state agencies. The Bank will not discipline anyone for doing so. The confidentiality obligations in HR-POL-001 do not prohibit reporting to a regulator or disclosing information as protected by law. Employees are still asked to protect client confidentiality and privileged legal information when making disclosures to others.

## 9. Governance and reporting

The Head of Ethics Office reports to the Audit Committee **every quarter** on the volume, categories, ageing, outcomes and trends of reports, including retaliation concerns and cases that are open longer than 90 days, without disclosing identities. The report also covers the effectiveness of the Speak-Up Line. The policy is reviewed once a year, and the Audit Committee receives a summary of any changes.

## 10. Records and confidentiality

Speak-Up case files are kept by the Ethics Office in a restricted system and retained for **7 years after closing**, as shown in HR-REF-002 Employee Records Retention Schedule. Access to files is limited to the Ethics Office, the investigator and others who need them to carry out the investigation or comply with law. Information is handled in accordance with HR-POL-016 Employee Data Privacy Policy.

## 11. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Employees | Speak up promptly, co-operate, keep the matter confidential. |
| Managers | Listen, never discourage a report, forward concerns within 1 business day, protect against retaliation. |
| Head of Ethics Office | Owns this policy, triages reports, tracks timelines, reports quarterly to the Audit Committee. |
| Clearline | Runs the Speak-Up Line independently, preserves anonymity, relays communications. |
| Audit Committee | Oversees the programme and receives concerns about senior leaders. |
| VP Employee Relations | Investigates employment-related reports and applies discipline consistently. |

## 12. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 3.1 | 2025-09-01 | Current version. Confirmed the timelines in section 5 (acknowledgement 3 business days, triage 5 business days, updates every 30 days, closure target 90 days), clarified the Audit Committee route and regulator access. |
