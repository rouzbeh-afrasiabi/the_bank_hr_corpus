# Performance Improvement Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-013 |
| Title | Performance Improvement Policy |
| Document type | Policy |
| Version | 2.1 |
| Status | Current |
| Effective date | 2025-06-01 |
| Last reviewed | 2026-04-10 |
| Next review | 2027-04-10 |
| Policy owner | VP Employee Relations |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Applies to | All Canadian and US employees (see Scope) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-011, HR-POL-021, HR-POL-018, HR-POL-025, FORM-HR-070 |

## 1. Purpose

This policy sets out a fair, structured and supportive process for helping an employee whose performance is below expectations to improve. A performance improvement plan (PIP) gives clear expectations, support and time to improve, and a transparent outcome.

## 2. Scope

The policy applies to all regular full-time and regular part-time employees, and to fixed-term employees of 6 months or more, in Canada and the US. It applies after probation; performance concerns during the 3-month probation (see HR-POL-014 Employment Status and Classification Policy) are managed through the probation review. A PIP is about performance (results and capability). Conduct issues, such as dishonesty or harassment, are managed under HR-POL-021 Employee Relations and Progressive Discipline Policy and do not require a PIP. Where applicable law gives a greater right, the law applies.

## 3. Definitions

| Term | Meaning |
| --- | --- |
| PIP | A written, time-limited plan in FORM-HR-070 Performance Improvement Plan that sets out expected improvement and support. |
| Coaching conversation | A documented discussion where the manager explains the performance gap and the expected standard. Coaching is not discipline. |
| Support person | A colleague, union representative where applicable, or other person chosen by the employee, who is not legal counsel. |

## 4. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Manager | Identifies and documents performance gaps, holds coaching conversations, writes the plan with the HRBP, holds weekly check-ins, records progress and makes a recommendation at the end. |
| HR Business Partner | Reviews the evidence, approves the PIP before the meeting, advises the manager, and attends meetings where needed. |
| Employee Relations consultant | Advises on risk and process, and reviews unsuccessful outcomes before progressive discipline. |
| Employee | Participates in meetings, works on the plan, asks for help and tells the manager early if something prevents progress. |
| VP Employee Relations | Owns the policy and approves exceptions. |

## 5. Triggers

A PIP may start when either of these applies:

1. The employee received a year-end rating of Needs Improvement or Unsatisfactory (see HR-POL-011 Performance Management Policy).
2. The manager has documented sustained underperformance during the year, after at least one documented coaching conversation, and the employee has not improved to the expected standard within a reasonable time.

A PIP is not mandatory after a rating of 4 or 5 but the manager and HRBP must record why a PIP was not started. A PIP must not be used to retaliate against an employee who raised a complaint, requested an accommodation, took protected leave or contacted the Speak-Up Line.

## 6. Steps

| Step | Action | Timing |
| --- | --- | --- |
| 1 | Coaching conversation held and documented. | Before any PIP, except where a rating triggers the PIP. |
| 2 | Manager drafts the plan in FORM-HR-070 and sends it with the evidence to the HRBP. | At least 3 business days before the meeting. |
| 3 | HRBP approves the plan. The HRBP checks for accommodation needs (section 11). | Before the meeting. |
| 4 | PIP kickoff meeting with the employee. | Within 10 business days of the trigger. |
| 5 | Weekly check-ins. | Every week during the PIP. |
| 6 | Mid-point review. | At half-way through the plan. |
| 7 | Final review meeting and written outcome. | Within 5 business days of the end date. |

## 7. Content of the plan

FORM-HR-070 must include: the specific performance gaps with examples; the standard expected, stated in measurable terms; the improvement targets and the date for each; the support the Bank will provide (training, coaching, tools, workload adjustments, a mentor); the start and end dates; the day and time of weekly check-ins; how progress is measured; and the consequences if the plan is not successful. Goals and standards must be realistic and consistent with the employee's band and role.

### 7.1 Length of the plan

| Length | When used |
| --- | --- |
| 30 days | Narrow, clearly defined gaps that can be corrected quickly. |
| 60 days (standard) | Most cases. |
| 90 days | Complex roles or goals that need a longer cycle; needs HRBP and Employee Relations approval. |

The standard length is 60 days. The permitted range is 30 to 90 days.

## 8. Meetings

### 8.1 Kickoff meeting

The manager and the HRBP meet the employee in private (in person or by video). The manager explains the gaps, the plan, the support and the weekly schedule. The employee may bring a support person who is not legal counsel and may add written comments to the plan within 5 business days. The employee is asked to sign the plan to acknowledge that it has been received; the signature does not mean agreement. If the employee refuses to sign, the manager records this.

### 8.2 Weekly check-ins

The manager meets the employee weekly, for 30 minutes, to review progress against each target, give feedback, remove obstacles and update the notes in the plan. Missed check-ins are rescheduled within 2 business days.

### 8.3 Final review

The manager and HRBP meet the employee to share the outcome and the next steps. A written outcome is issued in the plan form.

## 9. Support

The Bank provides the resources listed in the plan. Support may include training from the Learning Hub (see HR-POL-012 Learning and Development Policy), coaching by a more experienced colleague, clearer prioritization and a review of workload. The employee may use the Wellspring Support Program (1-800-555-0166, 24/7, confidential) at any time, and the Ombuds Office for confidential informal advice.

## 10. Outcomes

| Outcome | What happens |
| --- | --- |
| Successful completion | The employee meets the targets; the PIP closes and the manager continues regular check-ins. |
| Extension | Where progress is clear but not complete, one extension of up to 30 days may be approved by the HRBP. No second extension is allowed. |
| Unsuccessful | The case moves to progressive discipline under HR-POL-021 Employee Relations and Progressive Discipline Policy, up to termination. Employee Relations approval is required before termination. Severance and notice are governed by HR-POL-025 Involuntary Termination and Severance Policy. |

A plan may be paused if the employee takes a protected absence or approved leave of more than 5 consecutive business days and resumes on return; the end date is extended by the length of the absence. This does not count as the extension.

## 11. Accommodation considerations

Before a PIP starts and throughout, the manager and HRBP must consider whether a medical condition, disability, family status, pregnancy, religion or another protected ground may be affecting performance, and must assess whether accommodation is needed. If an accommodation need is known or suspected, the HRBP involves the Accommodation Specialist and applies HR-POL-018 Workplace Accommodation and Accessibility Policy first. A PIP does not stop an employee from requesting accommodation. Medical information is shared only on a need-to-know basis; managers receive functional limitations and expected duration only.

## 12. Restrictions during a PIP

During an active PIP the employee is not eligible for a merit increase or an internal transfer. Remote work eligibility requires no active PIP (see HR-POL-002 Remote and Hybrid Work Policy). The employee remains eligible for benefits, vacation, sick leave and statutory leaves, and the Bank must not reduce pay or change the job during the plan except as part of a disciplinary outcome. Promotions and transfers are handled separately. A successful PIP lifts the restrictions from the date of the final review.

## 13. Records

The PIP, check-in notes, evidence and outcomes are kept in the confidential employee file. After successful completion, they are removed from the active file 12 months later. Other retention rules in HR-REF-002 Employee Records Retention Schedule apply. Employees may request access to their records under HR-POL-016 Employee Data Privacy Policy.

## 14. Exceptions and consequences

Exceptions to this policy need written approval of the VP Employee Relations. A manager who starts or ends a PIP without HRBP approval is in breach of this policy. Retaliation against an employee is misconduct.

## 15. Related documents and contacts

HR-POL-011 Performance Management Policy; HR-POL-018 Workplace Accommodation and Accessibility Policy; HR-POL-021 Employee Relations and Progressive Discipline Policy; HR-POL-025 Involuntary Termination and Severance Policy. Managers may call the Manager Hotline, 1-800-555-0143 (response within 4 business hours). Employees may call HR Connect, 1-800-555-0142.

## 16. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.1 | 2025-06-01 | Reduced the standard PIP length from 90 days to 60 days (range 30 to 90 days); added accommodation review before the plan starts. |
| 2.0 | 2023-06-01 | Introduced FORM-HR-070, weekly check-ins, a standard length of 90 days and the single 30-day extension. |
