# How to set goals and complete your year-end self-assessment

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-023 |
| Title | How to set goals and complete your year-end self-assessment |
| Document type | How-to article |
| Version | 1.2 |
| Status | Current |
| Effective date | 2025-11-01 |
| Last reviewed | 2026-10-01 |
| Next review | 2027-10-01 |
| Policy owner | SVP Talent and Learning |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-011, HR-MEMO-2025-007, HR-POL-012 |

## 1. The short answer

Agree 3 to 5 goals with your manager in MyHR > Career and Learning > Performance by 15 December (new hires within 30 days of starting), and submit your year-end self-assessment there by 15 November.

## 2. Who this applies to

Regular full-time, regular part-time and fixed-term (6 months or more) employees in Canada (including Quebec) and the US. Casual, student, co-op and intern employees receive feedback but are not rated. The performance year is 1 November to 31 October. You are eligible for a rating if you started on or before 31 July; later starters set goals within 30 days but are rated the following year.

## 3. Steps

**Goals**

1. Open MyHR > Career and Learning > Performance > Goals and draft 3 to 5 goals. Make each specific, measurable, achievable, relevant and time-bound, written as outcomes rather than activities, and linked to your team plan.
2. Include at least one development goal (see HR-POL-012 Learning and Development Policy).
3. Agree them with your manager and confirm in MyHR by 15 December.
4. If priorities change, record the change in MyHR within 10 business days of agreeing it. Do not rewrite goals after 31 October.

**Self-assessment**

5. From 1 November, open MyHR > Career and Learning > Performance > Self-Assessment.
6. For each goal, describe the results you delivered and the evidence (the "what").
7. Describe how you worked against the Bank values: Integrity, Customer Focus, Accountability, Collaboration and Inclusion (the "how").
8. Submit by **15 November**.

## 4. Deadlines and what happens next

| Milestone | Date |
| --- | --- |
| Mid-year check-in | 1 May to 15 June |
| Self-assessment due | 15 November |
| Manager assessment due | 10 December |
| Calibration | 11 December to 10 January |
| Ratings communicated | By 15 January |
| Incentive paid | First pay date in February |
| Salary increases effective | 1 March |

A date that falls on a weekend or Bank holiday moves to the next business day. A human always makes the final decision on your rating (see HR-POL-011 Performance Management Policy). If you disagree with it, write to your HRBP within 10 business days of being told; the manager's manager and the HRBP review it within 15 business days and the decision is final.

## 5. Common mistakes

- Setting more than 5 or fewer than 3 goals.
- Writing tasks, not outcomes.
- Skipping the quarterly check-ins and the mid-year check-in, so the self-assessment has no evidence.
- Writing only about results and forgetting the "how".
- Submitting after 15 November, so your manager has less time before 10 December.
- Waiting past 10 business days to dispute a rating.

## 6. Who to call

- Your manager first, then your HRBP.
- HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, for MyHR access issues.

## 7. Related documents

- HR-POL-011 Performance Management Policy (the owning document)
- HR-MEMO-2025-007 Fiscal 2026 Performance Cycle Timetable
- HR-POL-012 Learning and Development Policy

Where applicable law gives a greater right, the law applies.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.2 | 2025-11-01 | Aligned with HR-POL-011 version 4.1. |
| 1.0 | 2025-01-01 | First version. |
