# Senior Trader

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1021 |
| Title | Senior Trader |
| Document type | Job description |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-09-08 |
| Next review | 2027-09-08 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-POL-029, HR-POL-031, HR-POL-032, HR-SUP-003 |

## 1. Role summary

The Senior Trader runs a trading book within the limits set by Risk and approved by the Managing Director, Capital Markets. The role makes prices to clients, manages positions and risk through the trading day and leads a small desk of analysts. The Senior Trader is accountable for the book's results, for the desk's adherence to limits and conduct standards, and for the development of the people on the desk.

## 2. Key responsibilities

- Make competitive, fair prices to institutional clients and manage the resulting positions within approved limits.
- Set the desk's daily trading and hedging plan and adjust it as markets move.
- Manage book risk (rate, spread, volatility or foreign exchange exposure) and report breaches to Risk and the Managing Director at once.
- Partner with sales coverage to understand client needs and agree how the Bank can serve them.
- Lead and coach the Trading Analysts on the desk, including trade capture quality and control habits.
- Review daily profit and loss and explain unexpected results to Finance and Risk.
- Take part in new-product approvals and ensure desk processes are ready before a product trades.
- Ensure all trading is conducted on recorded lines and that communications comply with surveillance rules.
- Contribute to desk planning, capital usage and annual targets with the Managing Director.
- Maintain business-continuity readiness for the desk, including remote trading procedures.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in finance, economics, mathematics or a related field.
- Typically 9 to 13 years of experience in trading, with a record of managing a book through volatile markets.
- Deep knowledge of the desk's product area and of the regulatory and conduct obligations of trading.
- Demonstrated leadership of junior traders or analysts.

### 3.2 Preferred

- CFA designation or a master's degree in finance or a quantitative discipline.
- Experience on both sell-side and risk-management sides of a trading business.
- Bilingual English and French.

### 3.3 Licences and certifications

Required under HR-POL-029 Licensing, Registration and Qualification Policy: securities registration in Canada for a trading and supervisory role, and in the US the Series 7 and Series 63 examinations, plus Series 65 or 66 if the desk requires it. Licensed duties start only when registration is active. The Bank pays exam, licence and registration fees and required continuing education. A lapse removes the employee from licensed duties immediately.

## 4. Competencies

Measured against HR-FWK-001 Competency and Leadership Model at the Leader level:

- Judgement and Decision Quality
- Risk and Conduct Awareness
- Drive for Results
- Developing Others
- Collaboration
- Adaptability

## 5. Compensation and classification

| Item | Value |
| --- | --- |
| Band | 6 (Manager II / Senior Manager) |
| Canada range | $112,000 to $168,000 CAD |
| US range | $110,000 to $166,000 USD |
| Incentive target | 15% of base salary (Annual Incentive Plan) |
| Overtime eligibility, Canada | No |
| FLSA classification, US | Exempt |
| Work arrangement | On-site (trading floor) |

If the Chief Risk Officer designates the Senior Trader a Material Risk Taker, deferral and clawback under HR-POL-031 Incentive Deferral and Clawback Policy also apply. Band definitions are in HR-GDE-006 Job Architecture and Pay Bands Guide.

## 6. Working conditions and accessibility

This is an on-site role on the Capital Markets trading floor. Trading hours follow the markets the desk covers, and recorded lines are used at all times. The role is a covered position under HR-POL-032 Personal Trading and Restricted Lists Policy and is subject to the 10-consecutive-business-day block leave audit and the fiscal year-end week vacation blackout described in HR-SUP-003 Capital Markets Addendum. The Bank provides accommodation to the point of undue hardship under HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to: Managing Director, Capital Markets. Direct reports: Trading Analysts and other desk staff.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-09-01 | Added supervisory registration wording and clawback reference |
| 1.0 | 2023-09-01 | First issue |
