# How to disclose a conflict of interest or an outside business activity

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-032 |
| Title | How to disclose a conflict of interest or an outside business activity |
| Document type | How-to article |
| Version | 1.1 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-09-10 |
| Next review | 2027-09-10 |
| Policy owner | Head of Ethics Office |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-001, FORM-HR-100, FORM-HR-102, FORM-HR-101, HR-POL-019 |

## 1. Short answer

Disclose a conflict of interest on FORM-HR-100 within 10 business days of becoming aware of it, and get written approval on FORM-HR-102 before you start any outside business activity or external board seat.

## 2. Who this applies to

Employees in Canada and the US, including part-time, casual, fixed-term, student, co-op and intern employees. The rules are the same in every province and state. Where applicable law gives a greater right or a stricter standard, the law applies.

## 3. Steps

### 3.1 A conflict of interest (FORM-HR-100)

A conflict is a personal, family, financial or outside interest that could influence, or appear to influence, your judgment for the Bank, such as supervising a relative or approving a transaction for a business you own.

1. Note the date you became aware; it starts the 10-business-day period.
2. Open MyHR > Ethics > Conflict of Interest, or email ethics@bank.example.
3. Describe the facts, the people involved and the decisions affected.
4. **Do not take part in the related decision** until the Ethics Office tells you in writing how it will be managed.

### 3.2 An outside business activity (FORM-HR-102)

1. Before you start, open MyHR > Ethics > Outside Activities, or email ethics@bank.example.
2. Describe the organization, your role, hours and pay. The activity must be outside Bank working time and use no Bank time, assets or information.
3. Your manager comments; the Ethics Office decides. A for-profit directorship also needs the Chief Compliance Officer's approval.
4. Do not begin until you have written approval.

Volunteering for a charity or community group needs no approval unless you will handle money or hold a director or officer role. Running for public office needs FORM-HR-102.

## 4. Deadlines

| Item | Deadline |
| --- | --- |
| Conflict of interest (FORM-HR-100) | Within 10 business days of becoming aware |
| Outside activity or board seat (FORM-HR-102) | Before you start |
| Gift or entertainment above $100 per occasion or $250 per source per year (FORM-HR-101) | Before you accept |
| Annual Code attestation | By 31 October |

## 5. What happens next

The Ethics Office replies in writing: no action, step back from certain decisions, change a reporting line, or end the interest. For FORM-HR-102 the answer is approved, approved with conditions or declined. Disclosures are confidential and protected from retaliation. Submit a new request if an activity changes materially.

## 6. Common mistakes

- Waiting beyond 10 business days.
- Taking part in the decision while you wait.
- Starting the activity before approval.
- Assuming an unpaid role needs no approval; both paid and unpaid activities are covered.

## 7. Who to call

Ethics Office, ethics@bank.example. Ombuds Office (informal, confidential), ombuds@bank.example. HR Connect, 1-800-555-0142.

## 8. Related documents

- HR-POL-001 Code of Conduct and Ethics
- FORM-HR-100 Conflict of Interest Disclosure
- FORM-HR-102 Outside Business Activity Request

## 9. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.1 | 2026-01-01 | Added the cumulative gift limit of $250 per source from HR-POL-001 version 6.0. |
| 1.0 | 2025-01-01 | First issue. |
