# Payroll Processing Calendar and Runbook

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-PRC-003 |
| Title | Payroll Processing Calendar and Runbook |
| Document type | Procedure |
| Version | 2026.2 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-09-28 |
| Next review | 2027-09-28 |
| Policy owner | SVP Total Rewards |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | HR only |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-009, HR-POL-003, HR-POL-015, HR-POL-025, HR-GDE-004, FORM-HR-021, FORM-HR-022 |

## 1. Purpose

This runbook tells Payroll Services and HR Operations what to do, and by when, in each biweekly payroll run, for off-cycle payments, overpayments and year-end tax slips. It implements HR-POL-009 Compensation and Payroll Policy and adds operational detail only. Employee-facing numbers (cut-off, correction threshold, deduction limits) are owned by that policy and are repeated here so that staff can work from one page.

## 2. Scope

The runbook covers regular payroll for employees in Canada (paid Thursdays) and the US (paid Fridays), off-cycle payments, final pay, corrections, overpayment recovery and year-end reporting. Overtime rules are in HR-POL-003 Working Hours and Overtime Policy. Where applicable law gives a greater right, the law applies.

## 3. Roles

| Role | Responsibility |
| --- | --- |
| Payroll Services analyst | Enters changes, produces the registers, runs audits, releases files. |
| Payroll Services manager | Approves the audited register and the bank file release. |
| HR Operations | Keeps employee master data, hires and terminations current in the HR system before the cut-off. |
| Benefits Administration | Supplies deduction and coverage changes. |
| Treasury (funding) | Confirms funding of the net pay amount. |
| Managers | Approve time in Time Tracker by Monday 12:00 local time. |
| HR Connect | Opens pay cases in the HR Case Portal and applies the priority rules. |

## 4. Key rules

| Item | Rule |
| --- | --- |
| Pay frequency | Biweekly in arrears, 26 pay dates a year |
| Pay day | Canada Thursday; US Friday |
| Pay period | Ends the Saturday immediately before the pay date |
| Cut-off for changes | 17:00 Eastern Time, five business days before the pay date |
| Pay statements in MyHR | 2 business days before the pay date |
| Time entry | Weekly by Friday 17:00 local time; manager approval by Monday 12:00 local time |
| Off-cycle correction | Net underpayment of $250 or more, within 3 business days of confirmation |
| Small corrections | Net underpayment under $250 corrected on the next regular pay date |
| Retroactive corrections | Up to 24 months |
| Overpayment recovery | Lump sum, deduction of at most 15% of net pay per period, or a plan of up to 12 months |

Business days exclude weekends and Bank holidays. A change received after the cut-off is processed on the next pay date. The cut-off applies to changes to bank details, federal and provincial personal tax credit return forms and US withholding forms, new hires and bonuses. Hours, overtime and absences follow the time-entry deadlines above, not the cut-off.

## 5. Task calendar for each pay date

T is the pay date. Count back by business days.

| Day | Task | Owner | System action |
| --- | --- | --- | --- |
| T-5, 17:00 ET | Changes locked | Payroll Services | Close the change window in the payroll system; export the late-change list to HR Operations |
| T-4 | Preliminary payroll register produced | Payroll Services analyst | Run the preliminary register; compare to the prior period |
| T-3 | Audit | Payroll Services analyst | Review variances, new hires, terminations, rate changes, deductions, garnishments |
| T-2 | Statements published | Payroll Services | Release pay statements in MyHR |
| T-1 | Funding | Treasury and Payroll Services manager | Approve final register; confirm funding |
| T, by 6:00 ET | Bank file release | Payroll Services manager | Release the direct deposit file; confirm acknowledgement |

### 5.1 T-5: lock changes

1. At 17:00 Eastern Time, close the change window. Anything entered later goes to the next pay date.
2. Confirm with HR Operations that all hires, terminations and status changes dated on or before the pay period end are in the system.
3. Send HR Operations the late-change list so that managers and employees can be told the change moves to the next run.

### 5.2 T-4: preliminary register

Produce the register by country. Check headcount against the prior period; flag any employee whose gross pay differs from the prior period by more than 10%, a new payee, or a net pay of zero or negative.

### 5.3 T-3: audit

| Check | Action if it fails |
| --- | --- |
| Time approvals complete (Monday 12:00 local time passed) | Contact the manager; unapproved hours go to the next run unless urgent |
| Overtime and premiums reconciled to Time Tracker | Correct before T-2 |
| New hire paperwork complete by the cut-off | Pay on the next pay date if it was not |
| Deductions for benefits, pension and 401(k) | Reconcile to Benefits Administration files |
| Garnishments and support orders | Confirm the order, amount and employee notification |
| Direct deposit changes (FORM-HR-022) | Prenote or verify before release; hold funds for any failed verification |
| Leave pay (HR-PRC-006) | Confirm the top-up and disability coding |

The Payroll Services manager signs off the audit in the payroll system.

### 5.4 T-2 and T-1: statements and funding

Publish the statements at T-2 so employees can check pay in MyHR. At T-1 the manager approves the final register; Treasury confirms funding of the net pay and remittances for taxes and deductions.

### 5.5 T: release

Release the bank file by 6:00 Eastern Time. Confirm the bank acknowledgement. Keep the reconciliation pack: register, audit sign-offs and file totals. Record any failed deposit in the HR Case Portal as a P1 pay issue (first response within 4 business hours) and arrange a replacement payment.

### 5.6 Worked example

Canada pay date Thursday 2026-03-05 (pay period ended Saturday 2026-02-28): T-5 cut-off is 17:00 Eastern Time on Thursday 2026-02-26; T-4 preliminary register Friday 2026-02-27; T-3 audit Monday 2026-03-02 (after the Monday 12:00 time approval); T-2 statements Tuesday 2026-03-03; T-1 funding Wednesday 2026-03-04; bank file release by 6:00 on Thursday 2026-03-05.

## 6. Remaining 2026 pay dates and cut-offs

Holiday-adjusted pay dates are counted back from the date money is actually paid. Remembrance Day (2026-11-11) is a Bank holiday in both countries.

| Pay period ends | Canada pay date | Canada cut-off | US pay date | US cut-off |
| --- | --- | --- | --- | --- |
| 2026-10-24 | 2026-10-29 | 2026-10-22 | 2026-10-30 | 2026-10-23 |
| 2026-11-07 | 2026-11-12 | 2026-11-04 | 2026-11-13 | 2026-11-05 |
| 2026-11-21 | 2026-11-26 | 2026-11-19 | 2026-11-25 (holiday adjustment) | 2026-11-18 |
| 2026-12-05 | 2026-12-10 | 2026-12-03 | 2026-12-11 | 2026-12-04 |
| 2026-12-19 | 2026-12-24 | 2026-12-17 | 2026-12-24 (holiday adjustment) | 2026-12-17 |

The full 2026 pay date table is in HR-POL-009.

## 7. Off-cycle payments

### 7.1 Criteria

| Situation | Rule |
| --- | --- |
| Net underpayment of $250 or more | Off-cycle payment within 3 business days of confirmation |
| Net underpayment under $250 | Next regular pay date |
| Missed pay or failed deposit | P1: respond within 4 business hours and replace as quickly as the bank allows |
| Final pay where the legal deadline is earlier than the next pay date | Off-cycle payment on or before the legal deadline (see HR-POL-015 Resignation and Offboarding Policy and section 9) |

### 7.2 Steps

1. The employee or manager submits FORM-HR-021 Payroll Correction Request in the HR Case Portal. HR Connect sets the priority and routes it to Payroll Services (Tier 2).
2. A Payroll Services analyst confirms the error, the pay periods affected, the gross and net amount and the currency of pay (CAD in Canada, USD in the US). Record the confirmation date; the 3 business days run from it.
3. If the net underpayment is $250 or more, the analyst prepares the off-cycle run, a second person checks the calculation, and the Payroll Services manager releases it. If under $250, tag the correction for the next regular register.
4. Add a case note with the amount, the pay date and the cause, and close the case after the employee confirms or the statement posts in MyHR.

Retroactive corrections go back up to 24 months. Corrections that change tax slips are flagged for year-end.

## 8. Overpayments

1. Notify the employee in writing with the amount, the dates and the cause.
2. Offer the three methods: lump sum; payroll deduction of at most 15% of net pay per period; or a plan of up to 12 months agreed with Payroll Services.
3. Where law requires written consent before deductions (for example California), obtain it first and record it in the case before any deduction.
4. Set the recovery schedule in the payroll system and confirm it to the employee. Recovery from final pay follows the same limits and applicable law.
5. If the employee disputes the overpayment, hold deductions and treat the case as P3.

## 9. Final pay

Payroll Services applies the deadline of the province or state of work and issues an off-cycle payment when the deadline falls before the next regular payroll.

| Jurisdiction | Resignation | Termination by the Bank |
| --- | --- | --- |
| Ontario | Later of 7 days after employment ends or the next pay date | Same |
| Quebec | Next regular pay date | Next regular pay date |
| British Columbia | 6 days after resignation | 48 hours after termination |
| Alberta | 10 days after resignation | 3 days after termination |
| California | Within 72 hours of resignation without notice; on the last day if notice was given | Immediately on termination |
| New York, New Jersey, Florida | Next regular pay date | Next regular pay date |

Final pay includes earned salary, earned unused vacation and any amounts owing; Annual Incentive Plan payment follows the payment-date rules in HR-POL-009. The Termination Checklist (HR-PRC-004 Termination Checklist and Protocol) sets the notice to Payroll Services. In Canada the Record of Employment is issued within 5 calendar days after the end of the pay period in which employment ends.

## 10. Reconciliation

Reconcile gross pay, deductions, remittances and net pay to the general ledger and the bank file total after each run, and investigate any difference above $1.00 per country before the next register. Keep payroll records for 7 years (HR-REF-002 Employee Records Retention Schedule).

## 11. Year-end slips and Annual Incentive Plan

| Item | Deadline | Steps |
| --- | --- | --- |
| US W-2 | 31 January | Reconcile year-to-date to quarterly filings in early January, correct, publish to MyHR |
| T4 and Relevé 1 (Canada) | 28 February | Reconcile year-to-date, correct, file and publish to MyHR |
| Annual Incentive Plan | First pay date in February | Load the payout file after Total Rewards approval; apply eligibility and rating rules in HR-POL-009 |
| Salary review changes | Effective 1 March | Load approved increases before the cut-off for the first March pay date (see HR-PRC-005 Calibration and Salary Planning Guidelines) |

Former employees receive slips at the address on file; remind leavers to keep it current.

## 12. Escalation

Escalate a pay issue that threatens a deadline to the Payroll Services manager at once. If a service level is missed, follow the HR Operations manager, VP HR Operations and Office of the CHRO path in HR-GDE-004 HR Service and Support Guide. Questions from employees go to HR Connect, 1-800-555-0142.

## 13. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2026.2 | 2026-03-01 | Raised the off-cycle correction threshold from $200 to $250 to match HR-POL-009 version 7.2; refreshed the 2026 cut-off tables. |
| 2026.1 | 2026-01-05 | Annual refresh of the task calendar and year-end steps. |
