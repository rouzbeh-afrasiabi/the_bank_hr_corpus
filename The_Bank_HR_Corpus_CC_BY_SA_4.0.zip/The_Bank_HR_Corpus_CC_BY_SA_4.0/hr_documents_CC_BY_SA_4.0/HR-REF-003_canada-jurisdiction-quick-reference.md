# Canada Jurisdiction Quick Reference

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-REF-003 |
| Title | Canada Jurisdiction Quick Reference |
| Document type | Reference |
| Version | 1.1 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-10-05 |
| Next review | 2027-10-05 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada |
| Language | English |
| Related documents | HR-POL-003, HR-POL-010, HR-POL-015, HR-POL-007, HR-POL-008, HR-SUP-001 |

## 1. Purpose and how to use this reference

This quick reference puts the Canadian rules that differ by province or territory into one place. It is a summary, not a policy. It restates key values and always points to the document that owns them: HR-POL-003 Working Hours and Overtime Policy, HR-POL-010 Statutory Holidays Policy, HR-POL-015 Resignation and Offboarding Policy and HR-POL-007 Sick Leave and Personal Leave Policy. If this page differs from an owning policy, the owning policy applies. Where applicable law gives a greater right, the law applies. For anything this page does not cover, or where it says "confirm with HR Connect", call 1-800-555-0142 or write to hrconnect@bank.example.

Your jurisdiction is the province or territory where you work, as recorded in MyHR. For US rules, see HR-REF-004 US Jurisdiction Quick Reference.

## 2. Canada at a glance

| Topic | Rule for all of Canada | Owner |
| --- | --- | --- |
| Standard work week | 37.5 hours (7.5 hours a day, 5 days), with a 60-minute unpaid meal period | HR-POL-003 |
| Extra hours | Hours between 37.5 and 40 a week are paid at straight time, or banked 1:1 | HR-POL-003 |
| Time in lieu | 1.5 hours off per overtime hour, bank cap 40 hours, taken within 3 months | HR-POL-003 |
| Meal and rest | 30-minute unpaid meal period after at most 5 consecutive hours; two paid 15-minute breaks per full shift | HR-POL-003 |
| Paid sick days | 10 per calendar year | HR-POL-007 |
| Personal days | 3 per calendar year | HR-POL-007 |
| Pay dates | Biweekly, Thursdays | HR-POL-009 |
| Tax slips | T4 (and Relevé 1 in Quebec) by 28 February | HR-POL-009 |
| Record of Employment | Issued electronically within 5 calendar days after the end of the pay period in which employment ends | HR-POL-015 |

## 3. Statutory holidays by province and territory

The Bank observes nine holidays everywhere in Canada: New Year's Day, Good Friday, Canada Day, Labour Day, the National Day for Truth and Reconciliation, Thanksgiving, Remembrance Day, Christmas Day and Boxing Day. The table shows the additional holidays and the total (see HR-POL-010).

| Jurisdiction | Victoria Day (Patriots' Day in Quebec) | Family Day or equivalent | Civic Holiday / Provincial Day | Fête nationale | Total Bank holidays |
| --- | --- | --- | --- | --- | --- |
| Ontario | Yes | Yes | Yes | No | 12 |
| Quebec | Yes (Patriots' Day) | No | No | Yes | 11 |
| British Columbia | Yes | Yes | Yes (BC Day) | No | 12 |
| Alberta | Yes | Yes | Yes | No | 12 |
| Manitoba | Yes | Yes (Louis Riel Day) | Yes | No | 12 |
| Saskatchewan | Yes | Yes | Yes | No | 12 |
| Nova Scotia | Yes | Yes (Heritage Day) | Yes | No | 12 |
| New Brunswick | Yes | Yes | Yes | No | 12 |
| Prince Edward Island | Yes | Yes (Islander Day) | Yes | No | 12 |
| Newfoundland and Labrador | Yes | No | Yes | No | 11 |
| Yukon | Yes | No | No | No | 10 |
| Northwest Territories | Yes | No | No | No | 10 |
| Nunavut | Yes | No | No | No | 10 |

### 3.1 2026 dates

| Holiday | Date | Where observed |
| --- | --- | --- |
| New Year's Day | 2026-01-01 (Thursday) | All |
| Family Day and equivalents | 2026-02-16 (Monday) | Ontario, Alberta, British Columbia, Saskatchewan, New Brunswick, Manitoba, Nova Scotia, Prince Edward Island |
| Good Friday | 2026-04-03 | All, including Quebec |
| Victoria Day / National Patriots' Day | 2026-05-18 (Monday) | All; Quebec observes National Patriots' Day |
| Fête nationale du Québec | 2026-06-24 (Wednesday) | Quebec only |
| Canada Day | 2026-07-01 (Wednesday) | All |
| Civic Holiday / Provincial Day | 2026-08-03 (Monday) | Ontario, British Columbia, Alberta, Manitoba, Saskatchewan, Nova Scotia, New Brunswick, Prince Edward Island, Newfoundland and Labrador |
| Labour Day | 2026-09-07 | All |
| National Day for Truth and Reconciliation | 2026-09-30 | All |
| Thanksgiving | 2026-10-12 | All |
| Remembrance Day | 2026-11-11 | All |
| Christmas Day | 2026-12-25 | All |
| Boxing Day | Saturday 2026-12-26, observed Monday 2026-12-28 | All |

Quebec observes Good Friday as the Bank's choice between Good Friday and Easter Monday. A holiday that falls on a Saturday is observed on the following Monday in Canada, and a holiday that falls during vacation is not charged against the vacation balance. Employees who must work a holiday receive regular holiday pay plus 1.5x for the hours worked, or 1.5x time in lieu taken within 60 days. The 2 floating Cultural and Religious Observance Days per calendar year apply in every province and territory.

## 4. Overtime rules by province and territory

Overtime in Canada is paid at 1.5x unless a row says 2x. The Bank pays earlier than the law in several provinces (see HR-POL-003). Overtime applies to Band 1 to 4 non-managerial roles that are overtime-eligible.

| Jurisdiction | Daily rule | Weekly rule | Note |
| --- | --- | --- | --- |
| Ontario | None | 1.5x after 40 hours | The provincial threshold is 44; the Bank pays from 40 |
| Quebec | None | 1.5x after 40 hours | |
| British Columbia | 1.5x after 8 hours; 2x after 12 hours | 1.5x after 40 hours | Hours already paid as daily overtime are not counted again |
| Alberta | 1.5x after 8 hours | 1.5x after 40 hours | The greater of the daily or weekly overtime hours is paid, not both |
| Manitoba, Saskatchewan, Nova Scotia, New Brunswick, Newfoundland and Labrador, Prince Edward Island | None | 1.5x after 40 hours | |
| Yukon, Northwest Territories, Nunavut | None | 1.5x after 40 hours | |

Overtime must be pre-approved by the manager in Time Tracker. More than 8 overtime hours in a week needs Director approval and HR notification.

## 5. Final pay deadlines

Final pay is paid on the next regular pay date but never later than the legal deadline. It includes earned, unused vacation. Payroll Services applies the deadline of the province or territory of work (see HR-POL-015).

| Jurisdiction | Resignation | Termination by the Bank |
| --- | --- | --- |
| Ontario | Later of 7 days after employment ends or the next pay date | Same |
| Quebec | Next regular pay date | Next regular pay date |
| British Columbia | 6 days after resignation | 48 hours after termination |
| Alberta | 10 days after resignation | 3 days after termination |
| Manitoba, Saskatchewan, Nova Scotia, New Brunswick, Newfoundland and Labrador, Prince Edward Island, Yukon, Northwest Territories, Nunavut | Next regular pay date, or an earlier legal deadline confirmed by Payroll Services; confirm with HR Connect | Same |

## 6. Sick-leave evidence and language

| Jurisdiction | Medical certificate or evidence | Language of HR documents and communications |
| --- | --- | --- |
| Quebec | The Bank asks for evidence only after 3 consecutive days of absence | French by default or on request; English versions available (see HR-SUP-001 Supplément pour le Québec) |
| All other provinces and territories | Required from the 4th consecutive working day, using FORM-HR-011 | English or French on request; HR Connect serves employees in both languages, with an interpreter on request |

Certificates show functional limitations and expected duration, never a diagnosis, and go to the Leaves team through MyHR, not to the manager. Personal days never need a certificate.

## 7. Parental leave pointer

The Bank top-up requires 6 months of continuous service. A birth parent receives a top-up to 100% of base salary for 17 weeks, and a non-birth, adoptive or surrogacy-intended parent for 8 weeks. The government benefit is paid under Employment Insurance, or under the Quebec Parental Insurance Plan in Quebec. The Bank cannot guarantee a government benefit. Total job-protected leave can reach 18 months for a birth parent, and parental leave must begin within 78 weeks of the birth or placement. Compassionate care leave is up to 28 weeks; critical illness leave is up to 37 weeks for a child and up to 17 weeks for an adult. Notice is given 4 weeks ahead on FORM-HR-012. See HR-POL-008 Parental and Family Leave Policy.

## 8. What this reference does not say

Some provincial rules are not set out in the Bank's policies, such as other statutory leaves or provincial notice periods. Where a value is not shown here, see the owning policy or confirm with HR Connect. Promotions and transfers are handled separately.

## 9. Contacts

HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time, closed on Bank holidays; hrconnect@bank.example; live chat in MyHR. English and French. Manager Hotline: 1-800-555-0143. Privacy Office: privacy@bank.example. Ombuds Office: ombuds@bank.example.

## 10. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.0 | 2025-01-01 | First edition of the Canada quick reference |
| 1.1 | 2026-01-01 | Updated for the 2026 calendar, 10 paid sick days and the 8-hour weekly overtime approval threshold |
