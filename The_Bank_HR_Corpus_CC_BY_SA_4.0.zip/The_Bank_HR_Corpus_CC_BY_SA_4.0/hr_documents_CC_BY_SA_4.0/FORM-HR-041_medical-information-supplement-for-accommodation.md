# Medical Information Supplement for Accommodation

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-041 |
| Title | Medical Information Supplement for Accommodation |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | Head of Accessibility and Inclusion |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-018, HR-POL-016, HR-REF-002, FORM-HR-040 |

## 1. Purpose and when to use this form

The Accommodation Specialist may ask for this form when the Bank needs to understand your **functional limitations**, restrictions and expected duration. It is completed by your health care provider. **It collects only what you can and cannot do. It never asks for, and must not contain, a diagnosis, treatment, test results or medical history.**

## 2. Who completes it and who approves

Your health care provider completes Part B; you complete Part A. The Accommodation Specialist reviews it. There is no approval step for the form itself; the accommodation decision follows HR-POL-018.

## 3. Where and when to submit

Upload to the Accommodation Specialist in MyHR, or email accommodations@bank.example, as soon as reasonably possible. Extra time is available on request. The decision is due within 10 business days of complete information (3 business days if urgent).

## 4. Form fields

| Field | Required | Notes |
| --- | --- | --- |
| Part A: employee name, ID and request reference | Yes | |
| Part A: consent to share this form with the Accommodation Specialist | Yes | |
| Part B: provider name, profession, licence or registration number | Yes | |
| Part B: functional limitations | Yes | For example "cannot lift more than 5 kg" or "needs a break every 45 minutes" |
| Part B: tasks or conditions to avoid | Yes | Described as functions, not conditions |
| Part B: expected duration or review date | Yes | |
| Part B: helpful supports or adjustments | No | Practical suggestions only |
| Part B: provider signature and date | Yes | |
| Diagnosis, treatment, test results | Do not provide | Leave these out |

## 5. Declarations and signatures

- Provider: the information reflects my professional opinion of functional limitations only.
- Employee: I consent to the use of this information to arrange my accommodation.

## 6. What happens next

The form is held by the Accommodation Specialist, separately from your general personnel file. Your manager receives only the functional limitations and the expected duration. Access is logged and reviewed quarterly, and records are kept for 7 years after employment ends (HR-REF-002 Employee Records Retention Schedule). The Bank reimburses up to $150 CAD or $120 USD for the cost of completing the form; submit the receipt with your request. Where applicable law gives a greater right, the law applies.

## 7. Related documents

- HR-POL-018 Workplace Accommodation and Accessibility Policy
- HR-POL-016 Employee Data Privacy Policy
- FORM-HR-040 Accommodation Request

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-09-01 | Restated that only functional limitations and duration are collected; added reimbursement wording. |
