# Outside Business Activity Request

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-102 |
| Title | Outside Business Activity Request |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | Head of Ethics Office |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-001, HR-POL-027, FORM-HR-100, HOW-032 |

## 1. Purpose and when to use this form

Use this form to request prior approval for any outside business activity, paid or unpaid, and for any external board seat (HR-POL-001 Code of Conduct and Ethics). It also applies before you run for, or accept, elected or appointed public office. Volunteering for a charitable or community organization needs no approval unless you will handle money or hold a director or officer role.

## 2. Who completes it and who approves

You complete it. Your manager gives an opinion on availability and conflicts. The Ethics Office decides. A for-profit directorship also needs the approval of the Chief Compliance Officer.

## 3. Where and when to submit (deadline, channel, processing time)

Submit before you start the activity, in MyHR (Ethics > Outside Activities) or by email to ethics@bank.example. Do not begin until you have written approval. Approvals are reviewed each year at your Code attestation, due by 31 October; submit a new request if the activity changes materially.

## 4. Form fields

| Field | Required | Notes |
| --- | --- | --- |
| Name, employee ID, band, manager | Yes | Pre-filled |
| Type of activity | Yes | Employment, self-employment, business ownership, board seat (for-profit or non-profit), public office, other |
| Organization name and its business | Yes | |
| Your role and start date | Yes | |
| Paid or unpaid; expected compensation | Yes | |
| Time commitment and when it occurs | Yes | Must be outside Bank working time |
| Does the organization compete with, supply, or bank with the Bank? | Yes | Explain any relationship |
| Will you use Bank time, assets, premises or information? | Yes | The answer must be No |
| Will you handle money or hold an officer role? | Yes | |
| Could it affect your performance or availability? | Yes | |
| Public statements you may make | If public office or board | Say you are not speaking for the Bank (HR-POL-027 Social Media and External Communications Policy) |

## 5. Declarations and signatures

I confirm that the activity does not compete with the Bank, will not use Bank time, assets or information, and will not interfere with my duties. I will submit FORM-HR-100 Conflict of Interest Disclosure if a conflict arises. Signature and date: ____________. Manager comments and date: ____________.

## 6. What happens next

The Ethics Office replies in writing: approved, approved with conditions, or declined. Approval is not given for activities that compete with the Bank, use Bank time, assets or information, create a conflict that cannot be managed, or interfere with your performance or availability. Stopping the activity should be reported through the same channel.

## 7. Related documents

- HR-POL-001 Code of Conduct and Ethics
- FORM-HR-100 Conflict of Interest Disclosure
- HR-POL-027 Social Media and External Communications Policy

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-01-01 | Added public office, annual review at attestation and Chief Compliance Officer step for directorships. |
| 1.0 | 2022-01-01 | Initial form. |
