# Termination Checklist and Protocol

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-PRC-004 |
| Title | Termination Checklist and Protocol |
| Document type | Procedure |
| Version | 2.3 |
| Status | Current |
| Effective date | 2025-02-01 |
| Last reviewed | 2026-07-21 |
| Next review | 2027-07-21 |
| Policy owner | VP Employee Relations |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | HR only |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-025, HR-POL-021, HR-POL-015, HR-POL-013, HR-PRC-001, HR-PRC-003, FORM-HR-081 |

## 1. Purpose

This procedure gives HR a checklist and meeting protocol for involuntary terminations, so that every termination is approved, lawful, consistent and delivered with respect. It implements HR-POL-025 Involuntary Termination and Severance Policy and uses the progressive discipline rules in HR-POL-021 Employee Relations and Progressive Discipline Policy. It adds operational detail only; the policy owns the entitlements and approvals. Voluntary exits follow HR-POL-015 Resignation and Offboarding Policy.

## 2. Scope

The procedure applies to terminations of regular full-time and regular part-time employees, and fixed-term employees ended before the end of the term, in Canada and the US. Casual employees, students, co-op students and interns receive statutory entitlements. Where applicable law or a collective agreement gives a greater right, it applies.

## 3. Roles

| Role | Responsibility |
| --- | --- |
| Manager | Proposes the action with the HRBP; conducts the meeting; never decides alone. |
| HRBP | Prepares the case file, calculates the package with Payroll Services, attends the meeting, follows up within 1 business day. |
| ER consultant | Reviews that discipline steps are complete; approves every termination as set out in HR-POL-021. |
| VP Employee Relations | With Legal, approves every termination for cause; owns this procedure. |
| Legal | Reviews cause cases, releases, group terminations and protected circumstances. |
| Payroll Services | Calculates final pay, vacation payout and deductions; meets legal deadlines. |
| Benefits Administration | Ends coverage; sends COBRA (US) and conversion (Canada) notices. |
| Corporate Security | On standby; removes access. |
| HR Operations | Updates the HR system, rehire code and records. |

## 4. Decision point: which path?

| Situation | Path | Approvals |
| --- | --- | --- |
| Restructuring, role elimination or position closure | Without cause | HRBP, ER consultant; Legal for any group |
| Unresolved performance failure after the PIP | Without cause or for cause per case file | ER consultant; VP Employee Relations and Legal if for cause |
| Serious misconduct (theft, fraud, violence, harassment, breach of confidentiality, falsifying records) | For cause | Completed investigation; ER approval; VP Employee Relations and Legal |
| Employee on a protected leave or with a pending accommodation | Hold | Legal review before any step |
| 5 or more employees affected | Group | VP Employee Relations and Legal before any communication |
| Probation (first 3 months, or up to 6 if extended) | Probation exit | HRBP and ER; act fairly and lawfully |

No manager may tell an employee that they are dismissed for cause without both approvals. No termination may rest on a protected ground, a protected leave, an accommodation request, a good-faith report under HR-POL-022 Whistleblower and Speak-Up Policy or a harassment complaint.

## 5. Phase 1: pre-meeting checklist

Open a termination case in the HR Case Portal (code ER-TRM, see HR-PRC-001 Employee Relations Case Handling Playbook) and complete every item before the meeting date is set.

| # | Item | Owner | Done when |
| --- | --- | --- | --- |
| 1 | Reason and evidence summarized in the case file | HRBP | Uploaded |
| 2 | Discipline steps or PIP outcome confirmed; consistency review against comparable cases | ER consultant | Recorded |
| 3 | Protected-circumstances check (leave, accommodation, complaint, Speak-Up report, rating dispute) | HRBP and ER consultant | Cleared or sent to Legal |
| 4 | For cause: investigation complete; employee had 5 business days to respond; VP Employee Relations and Legal approval in writing | ER consultant | Approvals attached |
| 5 | Package calculated: statutory minimum compared with the Bank formula (Canada 2 weeks per completed year, minimum 8, maximum 52; US 1 week per completed year, minimum 4, maximum 26) | HRBP and Payroll Services | Greater amount confirmed |
| 6 | Benefits, retirement plan and Annual Incentive Plan position confirmed | Benefits Administration, Payroll Services | Noted |
| 7 | Release prepared where enhanced severance applies | Legal | Reviewed |
| 8 | Letter prepared (HR-TPL-004 or HR-TPL-005) | HRBP | Approved |
| 9 | Final pay deadline identified for the province or state of work (section 9) | Payroll Services | Dated |
| 10 | Outplacement set up (without cause only) | HR Operations | Vendor booked |
| 11 | Corporate Security on standby if a risk exists; access removal timed for the meeting | Corporate Security | Confirmed |
| 12 | Meeting booked; room or video link ready; HR Connect briefed | HRBP | Confirmed |

### 5.1 Choosing the date and time

Hold the meeting from Tuesday to Thursday where possible. Do not hold it on the employee's birthday, the day before a statutory holiday or during a protected leave, unless Legal agrees. For remote employees use a private video meeting and arrange shipping of equipment. Payroll Services confirms the package from current annual base salary divided by 52 and the formula in HR-POL-025.

## 6. Phase 2: the meeting

The meeting is planned for 15 to 20 minutes, with a scripted opening of about 15 minutes. Attendees are the manager and the HRBP; Corporate Security stays nearby where needed. The employee is not accompanied by counsel but may bring a support person.

| Minute | Step | Who |
| --- | --- | --- |
| 0 to 2 | Greet; state the purpose in the first sentence | Manager |
| 2 to 5 | State the decision plainly and the effective date; do not debate or re-argue the reasons | Manager |
| 5 to 10 | Summarize the package: notice or pay in lieu, benefits, final pay timing, release if any, outplacement | HRBP |
| 10 to 13 | Explain next steps: access ending, equipment, personal items, tax slips, who to call | HRBP |
| 13 to 15 | Offer support: Wellspring Support Program (1-800-555-0166), HR Connect (1-800-555-0142) | HRBP |
| 15 to 20 | Questions; give the letter; confirm contact details | HRBP |

Script points: "We have decided to end your employment, effective [date]." "This decision is final." "Here is what you will receive." Do not comment on other employees; for a for-cause termination, state the reason in the terms approved by Legal. If there is any threat or safety concern, end the meeting, call 911 if anyone is in danger, and then call Corporate Security at 1-800-555-0119.

## 7. Phase 3: post-meeting checklist

| Within | Action | Owner |
| --- | --- | --- |
| Immediately | Access removed for involuntary exits; badge and systems disabled; equipment arrangements confirmed | Corporate Security, IT |
| Same day | HR system updated; Payroll Services, Benefits Administration and HR Operations notified | HRBP, HR Operations |
| Same day | Meeting notes recorded in the confidential file | HRBP |
| Same day | Team message agreed with the HRBP: brief, factual and respectful | Manager |
| 1 business day | HRBP follow-up with the employee | HRBP |
| 5 business days | Equipment returned (prepaid shipping kit for remote employees) | Employee |
| Release period | 14 days to consider in Canada; 21 days in the US (45 days in a group termination) and 7 days to revoke for employees aged 40 or over | Legal, HRBP |
| 10 business days | Lump sum paid after the release becomes effective (statutory part earlier if the law requires) | Payroll Services |
| 10 business days from the meeting | Window for the employee to ask for a review in writing to the VP Employee Relations (logged in the HR Case Portal) | Employee |
| 15 business days | Review decision by a reviewer who did not take part | VP Employee Relations, Legal |

Enhanced severance above the statutory minimum requires a signed release. Statutory entitlements and earned wages are paid even if the employee declines to sign. Legal may extend the consideration period in writing. The Bank reimburses independent legal advice up to $1,000 CAD in Canada and $750 USD in the US. A review request does not stop the release period unless Legal grants a written extension.

## 8. Benefits, outplacement and support

In Canada benefits and retirement plan participation continue through the notice period at the same employee cost. In the US benefits end at the end of the month; if the employee elects COBRA, the Bank pays 3 months of the Bank's premium share. Outplacement runs 12 weeks for Bands 1 to 6 and 26 weeks for Band 7 and above; it is not offered for terminations for cause. The Wellspring Support Program stays available for 30 days after the last day.

## 9. Final pay by jurisdiction

| Jurisdiction | Termination by the Bank |
| --- | --- |
| Ontario | Later of 7 days after employment ends or the next pay date |
| Quebec | Next regular pay date |
| British Columbia | 48 hours after termination |
| Alberta | 3 days after termination |
| California | Immediately on termination |
| New York, New Jersey, Florida | Next regular pay date |
| Other provinces, territories and states | Next regular pay date, or the earlier legal deadline confirmed by Payroll Services |

Where the deadline falls before the cut-off, Payroll Services issues an off-cycle payment (HR-PRC-003 Payroll Processing Calendar and Runbook). Final pay includes earned salary, earned unused vacation and statutory amounts. In Canada the Record of Employment is issued electronically within 5 calendar days after the end of the pay period in which employment ends; the T4 and Relevé 1 follow by 28 February. In the US the W-2 follows by 31 January.

## 10. Group terminations

Any proposal affecting 5 or more employees goes to the VP Employee Relations and Legal before any communication. Group terminations of 50 or more employees in Canada, and mass layoffs in the US, follow statutory notice rules, including the 60-day notice under the US WARN Act. Selection uses objective, documented criteria reviewed for adverse impact. Legal prepares the group release and the 45-day disclosure information for the US. Use a project plan and a single communications schedule.

## 11. Records and closure

Complete FORM-HR-081 Offboarding Checklist items that apply to involuntary exits. Set the rehire code (a "Not Eligible" code needs approval of the VP Employee Relations). Keep the personnel file, payroll records and benefits records for 7 years and any investigation file for 10 years after closing (HR-REF-002 Employee Records Retention Schedule). Close the case in the HR Case Portal with closure code CL-TRM once the release, final pay, tax slips and outplacement are complete.

## 12. Escalation and contacts

Any doubt about approvals, protected circumstances or the package: stop and contact the ER consultant or Legal. Managers may call the Manager Hotline, 1-800-555-0143. A complaint raised by the employee is handled under HR-PRC-001 or HR-PRC-002 Workplace Investigation Procedure.

## 13. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.3 | 2025-02-01 | Aligned with HR-POL-025 version 2.4: added the meeting timeline, outplacement durations and the release timelines table. |
| 2.0 | 2023-01-15 | Introduced the pre-meeting checklist and the for-cause approvals. |
