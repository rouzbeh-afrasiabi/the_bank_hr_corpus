# Business Travel and Expense Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-038 |
| Title | Business Travel and Expense Policy |
| Document type | Policy |
| Version | 5.0 |
| Status | Current |
| Effective date | 2025-12-01 |
| Last reviewed | 2026-09-21 |
| Next review | 2027-09-21 |
| Policy owner | SVP Total Rewards |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-009, HR-POL-001, HR-POL-017, HR-POL-003, HR-POL-012, FORM-HR-127 |

## 1. Purpose

This policy explains how employees book business travel, what the Bank pays for, the limits that apply, and how to claim reimbursement. Its aim is to let employees travel safely and sensibly, to spend the Bank's money responsibly, and to make claims quick to approve. Where applicable law gives a greater right, the law applies.

## 2. Scope

The policy applies to all employees in Canada and the US who travel on Bank business or incur approved business expenses. It covers air and rail travel, hotels, meals, ground transport, mileage and client expenses. Contractors and agency workers follow the terms of their engagement. Relocation is covered by HR-POL-039 Relocation and Global Mobility Policy, and conference or course fees by HR-POL-012 Learning and Development Policy. Commuting between home and the usual work location is not business travel.

## 3. Definitions

| Term | Meaning |
| --- | --- |
| Business travel | Travel away from the usual work location, approved in advance by the manager, for a Bank purpose. |
| Travel Desk | The Bank Travel Desk, through which all air, rail, hotel and car bookings are made. |
| Corporate card | A Bank-sponsored card used for travel and client expenses. |
| Designated high-cost city | A city on the list in section 6.2: in Canada, Toronto and Vancouver; in the US, New York City, San Francisco and Boston. |
| Expense report | FORM-HR-127 Business Expense Report, or the expense report in MyHR. |
| Approver | The manager, or the Director where section 8 requires it. |
| Total | The sum of all reimbursable items on one expense report, including items booked through the Travel Desk. |

## 4. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| SVP Total Rewards | Owns this policy and the limits; approves exceptions above Director level. |
| Employee | Travel within the limits, keep receipts, submit on time and repay anything claimed in error. |
| Manager | Approve travel in advance and review reports; check that claims fit the limits. |
| Director | Approve reports with a total over $2,500 and exceptions to hotel and meal limits. |
| Travel Desk | Book within the policy and advise on fares and hotels. |
| Payroll Services | Reimburse approved reports by direct deposit and recover amounts owed. |
| Corporate Security | Provides travel safety guidance (1-800-555-0119, 24/7). |

## 5. Booking

1. Approve the trip with your manager before booking. International trips also need Director approval.
2. Book through the Travel Desk, where possible at least 14 days ahead. Bookings outside the Travel Desk are reimbursed only up to the fare the Travel Desk would have offered.
3. Use the corporate card for travel and client expenses. Personal use of the corporate card is not permitted.
4. If you travel with a Bank device to a restricted country, notify Corporate Security 10 business days ahead (see HR-POL-017 IT Acceptable Use and Information Security Policy).
5. Whether travel time counts as hours worked for an overtime-eligible or non-exempt employee follows HR-POL-003 Working Hours and Overtime Policy; ask HR Connect before booking.

## 6. Limits

### 6.1 Air travel

| Flight length | Class |
| --- | --- |
| Under 6 hours | Economy |
| 6 to 8 hours | Premium economy |
| Over 8 hours | Business class only for Band 8 and above, or with SVP approval; otherwise premium economy |

### 6.2 Hotels

| Location | Maximum per night |
| --- | --- |
| Standard locations | $250 CAD / $200 USD |
| Designated high-cost cities | $350 CAD / $300 USD |

The limit applies to the room rate before taxes and fees. The employee pays the difference where the room costs more, unless a Director approved the higher rate in advance.

### 6.3 Meals

Meal limits apply on days when the employee travels overnight or is away from the usual work location for more than 10 hours. Meals provided at a conference, by a client or by the hotel cannot also be claimed.

| Meal | Canada (CAD) | US (USD) |
| --- | --- | --- |
| Breakfast | $15 | $12 |
| Lunch | $20 | $16 |
| Dinner | $40 | $32 |
| Total per day | $75 | $60 |

Each meal is reimbursed at actual cost up to its limit. Alcohol is not reimbursed, except at a client event that a Director pre-approved.

### 6.4 Mileage

Use of a personal vehicle for approved Bank business is reimbursed at $0.70 CAD per km in Canada and $0.67 USD per mile in the US. The rate covers fuel, wear and insurance. Tolls and parking are claimed separately with receipts. Commuting distance is not reimbursed.

### 6.5 Receipts

A receipt is required for every expense over $25. Mileage needs the date, the start and end points and the distance instead of a receipt. A lost receipt may be replaced by a signed statement approved by the manager.

## 7. Client expenses and gifts

Client meals and events are charged to the corporate card, with the names of attendees and the business purpose on the report. Gifts and entertainment follow HR-POL-001 Code of Conduct and Ethics: never cash or gift cards, and never to a public official. Alcohol rules are in section 6.3.

## 8. Submitting and approving expenses

| Step | Who | Deadline or rule |
| --- | --- | --- |
| Submit FORM-HR-127 or the MyHR expense report with receipts | Employee | Within 30 days of the expense |
| Manager review and approval | Manager | Within 5 business days of submission |
| Director approval | Director | Where the total is over $2,500; within 5 business days of the manager's approval |
| Reimbursement by direct deposit | Payroll Services | Within 7 business days of final approval |

No one approves their own report. A Director's report is approved by their own manager. A foreign-currency expense is converted at the rate on the day of the expense and reimbursed in the currency of the pay. Mileage claims use the rate in section 6.4.

## 9. Exceptions

- A limit may be exceeded in advance with Director approval for hotels and meals, and SVP approval for flights.
- In an emergency (a cancelled flight or a safety risk) the employee takes reasonable steps and reports to the manager the same business day; Corporate Security can assist.
- A report submitted more than 30 days after an expense needs Director approval. A claim more than 90 days after an expense is reimbursed only with SVP Total Rewards approval.
- An expense that is within the limit but unusual may be refused if the business purpose is not clear.

## 10. Worked examples

### 10.1 Canada: Branch Manager, Calgary to Vancouver

A Branch Manager (Band 5) travels from Calgary to Vancouver from Tuesday 22 September to Thursday 24 September 2026. The flight is under 6 hours, so economy is correct: return fare $415.00 CAD, booked through the Travel Desk. Vancouver is a designated high-cost city, so the hotel limit is $350 per night.

| Item | Claimed (CAD) | Reimbursed (CAD) | Why |
| --- | --- | --- | --- |
| Hotel, 2 nights at $372 | 744.00 | 700.00 | Limit $350 per night; employee bears $44 |
| Dinner, day 1 | 41.20 | 40.00 | Dinner limit $40 |
| Breakfast, day 2 | 14.50 | 14.50 | Within $15 |
| Lunch, day 2 | 18.75 | 18.75 | Within $20 |
| Dinner, day 2 | 36.00 | 36.00 | Within $40 |
| Breakfast, day 3 | 16.00 | 15.00 | Breakfast limit $15 |
| Lunch, day 3 | 12.40 | 12.40 | Within $20; no receipt needed (under $25) |
| Airport taxis | 62.00 | 62.00 | Receipt attached |
| Total on the report | 944.85 | 898.65 | |

Meals reimbursed are $136.65. Adding the $415.00 fare, the trip total is $1,313.65, which is under $2,500, so the manager alone approves. The employee submits on Thursday 1 October (within 30 days of the first expense on 22 September) and the manager approves on Friday 2 October. Reimbursement is due within 7 business days, by Wednesday 14 October (Thanksgiving, Monday 12 October, is not counted).

### 10.2 US: a larger trip needing Director approval

A Senior Financial Analyst (Band 4) in Boston attends a client workshop in San Francisco from Sunday 13 September to Friday 18 September 2026 (5 nights). The flight is about 6 hours 20 minutes, so premium economy applies: $1,240.00 USD return, booked through the Travel Desk. San Francisco is a designated high-cost city, so the hotel limit is $300 per night. The employee drives 38 miles to the airport and back.

| Item | Amount (USD) |
| --- | --- |
| Airfare, premium economy | 1,240.00 |
| Hotel, 5 nights at $289 (within $300) | 1,445.00 |
| Meals, 6 days, each within its limit | 318.00 |
| Ground transport, rideshare with receipts | 96.00 |
| Mileage, 38 miles at $0.67 | 25.46 |
| Total | 3,124.46 |

The total is over $2,500, so the Director must approve after the manager. The earliest expense is 13 September, so the report is due by Tuesday 13 October. The employee submits on Friday 2 October, the manager approves on Monday 5 October and the Director on Tuesday 6 October. Payroll Services reimburses within 7 business days of that approval, by Thursday 15 October.

## 11. Consequences

False or inflated claims, claiming personal expenses, splitting an expense to avoid a limit or approval, or claiming an item twice is serious misconduct under HR-POL-021 Employee Relations and Progressive Discipline Policy and may lead to termination. Amounts claimed in error are repaid within 30 days of notice; if not, Payroll Services may deduct at most 15% of net pay per period, as set out in HR-POL-009 Compensation and Payroll Policy and subject to local law.

## 12. Related documents

- HR-POL-009 Compensation and Payroll Policy
- HR-POL-001 Code of Conduct and Ethics
- HR-POL-017 IT Acceptable Use and Information Security Policy
- HR-POL-003 Working Hours and Overtime Policy
- HR-POL-012 Learning and Development Policy
- HR-POL-039 Relocation and Global Mobility Policy
- FORM-HR-127 Business Expense Report

## 13. Contacts

| Need | Contact |
| --- | --- |
| Questions about this policy | HR Connect, 1-800-555-0142, hrconnect@bank.example (Monday to Friday 8:00 to 20:00 Eastern Time) |
| Reimbursement not received | HR Case Portal in MyHR (Payroll Services) |
| Travel emergency or safety | Corporate Security, 1-800-555-0119 (24/7); call 911 first in an emergency |
| Managers | Manager Hotline, 1-800-555-0143 |

## 14. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 5.0 | 2025-12-01 | Reset the hotel and meal limits, added designated high-cost cities, the mileage rates and the $2,500 Director approval threshold. |
| 4.0 | 2023-12-01 | Required booking through the Bank Travel Desk and the 30-day submission rule. |
