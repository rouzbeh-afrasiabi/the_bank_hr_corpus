# How to approve time and leave in MyHR

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-046 |
| Title | How to approve time and leave in MyHR |
| Document type | How-to article |
| Version | 1.2 |
| Status | Current |
| Effective date | 2026-02-02 |
| Last reviewed | 2026-10-06 |
| Next review | 2027-10-06 |
| Policy owner | SVP Total Rewards |
| Audience | Managers |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-005, HR-POL-003, HR-POL-006, HR-POL-007, FORM-HR-020 |

## 1. Short answer

Approve or return each request in MyHR > Time and Absence > Team approvals: time entries for non-exempt employees by Monday 12:00 local time, and vacation requests within 5 business days. Approvals are recorded in MyHR or Time Tracker, never only by email.

## 2. Who this applies to

All people managers in Canada and the US for their direct reports. An acting manager needs written delegation recorded in MyHR. You do not approve statutory, medical, parental or caregiver leave; the Leaves team does.

## 3. Steps

1. Sign in to MyHR and open Time and Absence > Team approvals. Requests are grouped by type.
2. **Time entries.** Open each non-exempt employee's week (employees enter start, end and meal times by Friday 17:00 local time). Check hours against the schedule, then approve or return with a comment. Exempt employees record absences only.
3. **Overtime.** Check that it was pre-approved in Time Tracker. Planned or recurring overtime needs FORM-HR-020. More than 8 overtime hours in a week needs Director approval and HR notified before the hours are worked. Emergency overtime is approved by the next business day. Unapproved overtime is still paid.
4. **Vacation.** Decide on coverage, not preference. If two requests conflict, the earlier submission goes first. Respond within 5 business days; silence is never approval and MyHR escalates the request to your manager. Check blackout periods and that the employee plans the 10-day block leave.
5. **Other approvals.** Personal days: 2 business days. Time in lieu (Canada only, FORM-HR-020): 3 business days. Hybrid office-attendance exception up to 12 days per employee per calendar year: 3 business days; beyond 12 the HRBP approves.
6. **Leaves you route, not approve.** For a medical certificate, a disability claim, or parental or caregiver leave, open a case in MyHR > HR Case Portal for the Leaves team. A personal leave of absence (FORM-HR-010) is approved by the Director and HRBP within 10 business days.

## 4. Deadlines

| Item | Deadline |
| --- | --- |
| Employee time entry | Friday 17:00 local time |
| Your time approval | Monday 12:00 local time |
| Vacation response | 5 business days |
| Personal day | 2 business days |

## 5. What happens next

Approved time flows to Payroll Services for the next pay date; a late approval can delay pay. Corrections after the payroll cut-off (17:00 Eastern Time, five business days before the pay date) follow HR-POL-009 Compensation and Payroll Policy. Approved vacation returns to the balance if the employee cancels at least 2 business days before it starts.

## 6. Common mistakes

- Approving by email only, or letting a vacation request sit past 5 business days.
- Asking for a diagnosis. A medical certificate goes to the Leaves team, not to you; it is requested from the 4th consecutive working day (after 3 days in Quebec).
- Approving above your authority, such as more than 8 weekly overtime hours without the Director.

## 7. Who to call

Manager Hotline, 1-800-555-0143, Monday to Friday 8:00 to 20:00 Eastern Time (response within 4 business hours). Your HR Business Partner for exceptions. Employees call HR Connect, 1-800-555-0142.

## 8. Related documents

- HR-GDE-005 Manager's HR Procedures Guide
- HR-POL-003 Working Hours and Overtime Policy
- HR-POL-006 Vacation and Paid Time Off Policy

## 9. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.2 | 2026-02-02 | Added the 3-day hybrid exception and 5-day vacation escalation wording from HR-GDE-005 version 3.2. |
| 1.1 | 2025-07-01 | Lowered the weekly overtime threshold for Director approval from 10 to 8 hours. |
| 1.0 | 2025-02-03 | First edition. |
