# Calibration and Salary Planning Guidelines

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-PRC-005 |
| Title | Calibration and Salary Planning Guidelines |
| Document type | Procedure |
| Version | 2026.1 |
| Status | Current |
| Effective date | 2026-10-01 |
| Last reviewed | 2026-10-14 |
| Next review | 2027-10-14 |
| Policy owner | SVP Total Rewards |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | HR only |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-011, HR-POL-009, HR-POL-013, HR-GDE-006, HR-PRC-003 |

## 1. Purpose

These guidelines tell HR Business Partners (HRBPs), Total Rewards and Payroll Services how to run the year-end calibration sessions and the annual salary review in a consistent way. They implement HR-POL-011 Performance Management Policy and HR-POL-009 Compensation and Payroll Policy. They add operating detail and merit guidance for HR; the employee-facing rules (calendar, rating scale, multipliers, eligibility) stay in those policies.

## 2. Scope

The guidelines apply to every business unit in Canada and the US for the performance year that runs from 1 November to 31 October. They cover calibration, merit increases, the interaction with the Annual Incentive Plan (AIP) and lump sums. Promotion increases are handled separately and are not part of the annual review; this document only states the adjustment range HR uses when processing one. Where applicable law gives a greater right, the law applies.

## 3. Roles

| Role | Responsibility |
| --- | --- |
| HRBP | Facilitates calibration, checks ratings for consistency and bias, records changes and reasons. |
| Business unit head | Leads the sessions and owns the final proposed ratings for the unit. |
| Managers | Present proposed ratings with evidence; prepare merit recommendations after calibration closes. |
| Total Rewards | Sets budget allocation, publishes merit guidance, checks pay-equity and band positions. |
| SVP Talent and Learning | Publishes the calibration guidance and receives distribution variances (HR-POL-011). |
| SVP Total Rewards | Owns these guidelines and approves exceptions to the merit guide. |
| Payroll Services | Loads approved increases and lump sums (see HR-PRC-003 Payroll Processing Calendar and Runbook). |

## 4. Annual calendar

Dates that fall on a weekend or Bank holiday move to the next business day.

| Date or window | Milestone |
| --- | --- |
| 31 October | Performance year ends |
| 15 November | Year-end self-assessments due |
| 10 December | Manager assessments due in MyHR |
| 11 December to 10 January | Calibration sessions |
| By 15 January | Ratings communicated to employees |
| After year-end results | Board HR Committee sets the AIP business funding factor (0 to 1.5) |
| First pay date in February | AIP paid |
| 1 March | Salary increases effective |

Total Rewards publishes the merit guidance to HRBPs and managers before the review opens. Manager merit recommendations are entered in the salary planning worksheet only after calibration closes, and no increase is communicated before ratings are communicated.

## 5. Calibration procedure

### 5.1 Before the session

1. HRBP confirms that every eligible employee has a manager assessment in MyHR by 10 December. Employees are eligible for a rating if they were employed for at least 3 months in the performance year, meaning they started on or before 31 July. Employees on approved leave are rated on the period worked.
2. HRBP prepares the unit view: proposed ratings, distribution against guidance, part-time, remote and leave status, new hires and any active performance improvement plan under HR-POL-013 Performance Improvement Policy.
3. Managers prepare a short evidence note per employee: goals met (the "what"), behaviours against the Bank values (the "how") and examples.

### 5.2 Running the session

1. The business unit head opens the session and restates the rating definitions from HR-POL-011.
2. Each manager presents the proposed rating and evidence. The group tests it against the definition, compares it to similar roles and checks for bias.
3. Check for: recency effect, similarity bias, tenure, part-time or remote status, leave history, accommodation or a protected ground, and pressure to match a distribution.
4. A rating may change only with a recorded reason. The HRBP records the reason in the HR Case Portal calibration note or the MyHR calibration record.
5. No rating is final until calibration closes on 10 January. Ratings are not shared with other employees.

### 5.3 Distribution guidance

The ranges are guidance and are not forced quotas. No manager is required to give a rating to meet a range.

| Rating | Guidance for the business unit |
| --- | --- |
| 1 Outstanding | 5% to 10% |
| 2 Exceeds Expectations | 20% to 30% |
| 3 Meets Expectations | 50% to 60% |
| 4 Needs Improvement and 5 Unsatisfactory | The remainder |

A business unit whose distribution falls outside a range explains the material difference to the SVP Talent and Learning. HRBPs flag any unit where all employees in a group, such as part-time or remote staff, are rated lower than peers.

### 5.4 After calibration

Managers communicate ratings in a one-to-one conversation by 15 January. A rating of Needs Improvement or Unsatisfactory is reviewed by the HRBP for a possible PIP; if a PIP is not started, the manager and HRBP record why (HR-POL-013). An employee may dispute a rating by writing to the HRBP within 10 business days of being told; the manager's manager and the HRBP decide within 15 business days and the decision is final. A dispute does not delay the AIP or salary increase; any correction is paid on the next regular pay date.

### 5.5 Use of automated tools

AI-assisted tools may help to prepare summaries, but a human makes the final decision on every rating. A tool may be used only after the assessments in HR-POL-016 Employee Data Privacy Policy are complete.

## 6. Salary planning

### 6.1 Merit budget

| Review | Effective | Merit budget (% of base payroll) | Status |
| --- | --- | --- | --- |
| 2026 | 1 March 2026 | 3.5% | Board-approved; confirmed by the HR Policy Committee on 5 February 2026 |
| 2027 | 1 March 2027 | 3.0% | Board-approved planning figure; Total Rewards confirms before the review opens |

The budget is a pool for the business unit, not a per-employee entitlement. Total Rewards allocates the pool; HRBPs keep the unit's average merit within it.

### 6.2 Merit increase guide by rating

| Year-end rating | Merit increase range (% of base salary) |
| --- | --- |
| 1 Outstanding | 5.0% to 6.0% |
| 2 Exceeds Expectations | 4.0% to 5.0% |
| 3 Meets Expectations | 2.0% to 3.5% |
| 4 Needs Improvement | 0% to 1.0% |
| 5 Unsatisfactory | 0% |

Within the range, position in the pay band decides the point: an employee lower in the band is usually placed higher in the range. Pay bands (minimum, midpoint, maximum) are in HR-GDE-006 Job Architecture and Pay Bands Guide and `pay_bands.csv`, which is the source of truth.

### 6.3 Rules and checks

- An employee on an active performance improvement plan is not eligible for a merit increase (HR-POL-013 and HR-POL-011). The restriction lifts from the date of the final review of a successful PIP and does not create a retroactive increase.
- No merit increase may take base pay above the band maximum. Where it would, raise base to the band maximum and pay the balance as a one-time lump sum that is not added to base.
- Increases are placed inside the band for the role and the jurisdiction (Canada in CAD; US in USD).
- Promotion adjustments are processed outside the annual review. HR uses 8% to 12% of base, not above the band maximum, and records approval in the HR Case Portal. Promotions and transfers themselves are handled separately.
- Total Rewards runs the annual pay-equity review across gender and other protected groups; unexplained gaps are addressed at the following salary review.
- The AIP uses base salary earned in the fiscal year, so a 1 March increase does not change the AIP for the year that has already ended.

### 6.4 Worked examples

1. A Band 4 employee in Canada earns $90,000 and is rated Meets Expectations. A 3.0% increase is $2,700, giving $92,700. The band maximum is $108,000, so the increase is applied in full.
2. A Band 3 employee in Canada earns $82,000 and is rated Exceeds Expectations. A 4.5% increase would be $3,690 and give $85,690, above the band maximum of $84,000. Raise base to $84,000 (an increase of $2,000) and pay the remaining $1,690 as a lump sum.
3. A unit has base payroll of $40,000,000 and a 3.5% merit budget, so the pool is $1,400,000.

## 7. Salary planning steps

1. Total Rewards publishes the guidance and opens the planning worksheet after calibration closes.
2. Managers enter recommendations within the guide; the HRBP reviews them for consistency, band position and the PIP rule.
3. Total Rewards checks totals against the pool, band maximums and pay equity; exceptions need written approval of the SVP Total Rewards.
4. The business unit head approves the final plan.
5. Total Rewards sends approved increases and lump sums to Payroll Services, who load them in time for the payroll cut-off (17:00 Eastern Time, five business days before the pay date).
6. Managers communicate increases in a letter or MyHR statement; the increase is effective 1 March.

## 8. Checklist

- [ ] Manager assessments complete by 10 December.
- [ ] Calibration notes and reasons for every rating change recorded.
- [ ] Distribution explained where outside guidance.
- [ ] Ratings communicated by 15 January.
- [ ] PIP review done for ratings 4 and 5.
- [ ] Merit within the guide, the band maximum respected and lump sums coded.
- [ ] Pay-equity check complete.
- [ ] Payroll load confirmed before the cut-off.

## 9. Exceptions and contacts

Exceptions to the merit guide require written approval of the SVP Total Rewards. Questions go to HR Connect at 1-800-555-0142 or the manager's HRBP; managers may call the Manager Hotline at 1-800-555-0143.

## 10. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2026.1 | 2026-10-01 | Updated the merit guide, recorded the 3.5% merit budget for 2026 and the 3.0% planning figure for 2027, and clarified lump-sum treatment above the band maximum. |
| 2025.1 | 2025-10-01 | Annual refresh of the calibration calendar. |
