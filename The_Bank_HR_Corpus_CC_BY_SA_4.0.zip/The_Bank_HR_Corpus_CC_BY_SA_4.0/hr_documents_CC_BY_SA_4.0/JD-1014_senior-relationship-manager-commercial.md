# Senior Relationship Manager, Commercial

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1014 |
| Title | Senior Relationship Manager, Commercial |
| Document type | Job description |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-08-25 |
| Next review | 2027-08-25 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-POL-011, HR-POL-002, HR-POL-018 |

## 1. Role summary

The Senior Relationship Manager, Commercial leads the Bank's relationships with mid-market commercial clients, structuring multi-product credit and treasury solutions and acting as the senior point of contact for each client. The role also leads a small team of Commercial Banking Analysts, assigning work, reviewing credit submissions and developing their skills. The Senior Relationship Manager is accountable for the quality, growth and risk profile of a defined commercial portfolio. This is a Band 5 (Team Lead / Manager I) role in the Commercial Banking family; see HR-GDE-006 Job Architecture and Pay Bands Guide.

## 2. Key responsibilities

- Own the relationship strategy for a portfolio of mid-market commercial clients.
- Structure complex credit facilities, including term debt, revolving credit, real estate and cross-border financing, with documented risk analysis.
- Negotiate pricing, terms and covenants within delegated authority and recommend larger transactions for senior credit approval.
- Lead and coach the Commercial Banking Analysts, including goal-setting and year-end assessments under HR-POL-011 Performance Management Policy.
- Review analyst credit memoranda and annual reviews for accuracy, rating and completeness.
- Monitor portfolio quality, watch-list accounts and covenant compliance, and lead remediation conversations with clients.
- Bring cash management, trade, foreign exchange, wealth and capital markets specialists to client discussions.
- Ensure compliance with anti-money-laundering, sanctions, conduct and privacy obligations for commercial relationships.
- Develop new client opportunities through networks, industry events and referral partners.
- Contribute to regional commercial plans and market intelligence.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in business, finance, economics or a related field, or equivalent experience.
- Seven to ten years of commercial banking experience, including independent credit structuring and client management.
- Demonstrated leadership or mentoring of junior analysts.
- Strong negotiation, analytical and written communication skills.
- Satisfactory results in pre-employment screening and periodic re-screening for roles with financial authority.

### 3.2 Preferred

- MBA, CFA or a credit risk designation.
- Experience with a specialized industry such as real estate, agriculture or manufacturing.
- Fluency in English and French.

### 3.3 Licences and certifications

No licence is required. Referrals for investment or mortgage needs follow HR-POL-029 Licensing, Registration and Qualification Policy.

## 4. Competencies

Competencies are defined in HR-FWK-001 Competency and Leadership Model; this role works at the Leader level.

- **Customer Obsession**: becomes the senior adviser to client executives.
- **Judgement and Decision Quality**: structures credit solutions that balance growth and risk.
- **Risk and Conduct Awareness**: upholds credit discipline and conduct standards.
- **Developing Others**: builds analyst capability.
- **Drive for Results**: grows a high-quality portfolio.
- **Collaboration**: orchestrates internal specialists around the client.
- **Inclusive Leadership**: leads a diverse analyst team fairly.

## 5. Compensation and classification

| Item | Detail |
| --- | --- |
| Band | 5 (Team Lead / Manager I) |
| Canada salary range | $90,000 to $134,000 CAD per year |
| US salary range | $88,000 to $132,000 USD per year |
| Incentive target | Annual Incentive Plan (AIP): 10% of base salary |
| Overtime eligibility (Canada) | No |
| FLSA classification (US) | Exempt |
| Work arrangement | Hybrid: at least 3 days a week in the office, with client visits scheduled around them |

## 6. Working conditions and accessibility

This is a hybrid role with frequent client visits and some travel. Hybrid arrangements follow HR-POL-002 Remote and Hybrid Work Policy, with at least 3 days a week in the office and anchor days on Tuesday and Thursday. The Bank provides accommodation to the point of undue hardship (Canada) or reasonable accommodation (US); see HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to the Regional Manager, Commercial.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-03-01 | Pay ranges updated to the 2026 pay bands; added analyst leadership duties |
| 1.0 | 2024-05-06 | First issue |
