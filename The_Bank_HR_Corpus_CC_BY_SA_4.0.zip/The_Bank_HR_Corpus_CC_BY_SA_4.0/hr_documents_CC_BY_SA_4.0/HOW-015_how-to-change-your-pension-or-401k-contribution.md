# How to change your pension or 401(k) contribution

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-015 |
| Title | How to change your pension or 401(k) contribution |
| Document type | How-to article |
| Version | 1.2 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-09-17 |
| Next review | 2027-09-17 |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-002, HR-PLN-005, HR-PLN-006, HR-POL-009 |

## 1. The short answer

Change your rate in MyHR > Benefits > Retirement and Savings before 17:00 Eastern Time, five business days before the pay date, and it takes effect on that pay date; later changes start on the following pay date.

## 2. Who this applies to

- **Canada (including Quebec):** Bank Savings and Pension Plan. You contribute 2% to 10% of base salary. If you made no election you were auto-enrolled at 4% after 30 days.
- **US:** Bank US 401(k) Savings Plan. You were auto-enrolled at 5% after 30 days, rising 1% a year to 8%. You can change your rate, your pre-tax and Roth split, or the yearly increase at any time.

Casual employees are not eligible in Canada; in the US they are eligible after 1,000 hours worked.

## 3. Steps

1. Sign in to MyHR and open Benefits > Retirement and Savings.
2. Select your plan and choose **Change contribution**.
3. Enter the new percentage of base salary (US: also the pre-tax and Roth split or the yearly increase).
4. Review the estimate of the Bank match, then submit.
5. Check your next pay statement (MyHR > Pay) to confirm the new deduction.

## 4. Deadlines and what happens next

The cut-off is 17:00 Eastern Time, five business days before the pay date (see HR-POL-009 Compensation and Payroll Policy). A change made before it applies to that pay date; after it, to the following one. Payroll Services deducts and sends the contributions to Evergreen Retirement Services. Quarterly statements appear in MyHR; report errors to Benefits Administration within 30 days of receiving one.

In Canada, if you opt out within 90 days of enrolment, your contributions are refunded.

## 5. Common mistakes

- **Canada: contributing less than 4%.** The Bank pays 2% of base regardless, plus a 100% match on your first 4% (maximum Bank total 6%). At 2% on a $90,000 salary you give up $1,800 of match a year. Above 4% your savings grow but the match does not.
- **US: forgetting the 2-year cliff.** The Bank base contribution and match vest after 2 years of service.
- Expecting incentive pay to be matched. It is not.
- Changing by phone and assuming it is instant. Phone changes count only once Payroll Services receives them.
- Moving between Canada and the US without calling HR Connect first. Plan membership changes.

## 6. Who to call

- Evergreen Retirement Services: 1-800-555-0188, for balances, investments and your free annual financial advice session.
- HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, for eligibility and payroll deductions.

## 7. Related documents

- HR-GDE-002 Retirement and Savings Plan Guide (the owning document)
- HR-PLN-005 Bank Savings and Pension Plan Text Summary (Canada)
- HR-PLN-006 US 401(k) Savings Plan Summary Plan Description

Statutory contribution limits are set by the tax authorities each year; Evergreen Retirement Services publishes them. Where applicable law gives a greater right, the law applies.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.2 | 2026-01-01 | Aligned with HR-GDE-002 version 3.0 (combined Canada and US descriptions). |
| 1.0 | 2025-01-01 | First version. |
