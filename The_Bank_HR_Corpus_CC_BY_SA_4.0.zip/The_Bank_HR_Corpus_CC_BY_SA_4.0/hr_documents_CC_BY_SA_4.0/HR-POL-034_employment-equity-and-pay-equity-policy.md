# Employment Equity and Pay Equity Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-034 |
| Title | Employment Equity and Pay Equity Policy |
| Document type | Policy |
| Version | 3.0 |
| Status | Current |
| Effective date | 2025-04-01 |
| Last reviewed | 2026-05-26 |
| Next review | 2027-05-26 |
| Policy owner | Head of Inclusion and Belonging |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | Employees |
| Jurisdiction | Canada |
| Language | English |
| Related documents | HR-POL-024, HR-POL-009, HR-POL-016, HR-POL-018, HR-POL-019, HR-GDE-006 |

## 1. Purpose

This policy explains how the Bank meets its employment equity and pay equity obligations in Canada: how it counts and reports on the representation of designated groups, how it finds and removes barriers in its employment practices, and how it checks every year that people doing equal or comparable work are paid fairly. It complements the broader commitments in HR-POL-024 Diversity, Equity, Inclusion and Belonging Policy. Where applicable law gives a greater right, the law applies.

## 2. Scope

The policy applies to all employees in Canada, in every province and territory, and to applicants for Canadian roles. It covers recruitment, hiring, pay, development, assignments, leave, accommodation and exit. Promotions and transfers are handled separately. Employees in the US are covered by HR-POL-036 US Equal Employment Opportunity and Required Notices Policy. Quebec employees receive communications in French by default or on request.

## 3. Definitions

| Term | Meaning |
| --- | --- |
| Designated groups | Women, Indigenous peoples, persons with disabilities and members of visible minorities. |
| Self-identification | A voluntary, confidential choice to tell the Bank that you belong to one or more designated groups. |
| Workforce analysis | A count of employees by designated group, band, business unit and occupational group, compared with labour market availability. |
| Employment systems review | A review of the Bank's hiring, pay, development and exit practices to find barriers. |
| Pay equity review | A review of pay by gender and by designated group, after adjusting for role, band, location, experience and performance rating. |
| Unexplained difference | A pay gap that remains after those adjustments and has no documented, job-related reason. |
| Employment Equity Committee | The joint committee of employer and employee representatives described in section 6. |
| Equity adjustment | A base salary increase made to correct an unexplained difference. |

## 4. Principles

1. Decisions about people are based on skills, experience, performance and potential.
2. Employment equity goals are aspirations that guide outreach and the removal of barriers. The Bank does not use quotas or set aside positions, and goals never override the selection of the best qualified candidate (see HR-POL-024).
3. Self-identification is voluntary, private and used only in aggregate.
4. Equal or comparable work is paid fairly, and pay differences must be explained by job-related factors.

## 5. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Head of Inclusion and Belonging | Owns this policy; leads the workforce analysis; prepares the annual employment equity report; reports pay equity results to the HR Policy Committee. |
| Chair of the Employment Equity Committee | Convenes quarterly meetings and reports its recommendations to the CHRO. |
| SVP Total Rewards | Runs the annual pay equity review and the pay equity plan; funds adjustments centrally. |
| HRBPs | Review the fairness of pay and ratings in their business unit and act on findings. |
| Chief Privacy Officer | Protects self-identification data and reviews its use (see HR-POL-016 Employee Data Privacy Policy). |
| Managers | Apply fair, structured processes and refer barriers they see to their HRBP. |
| Employees | Decide freely whether to self-identify and keep their own information current in MyHR. |
| Ombuds Office | Provides confidential, informal advice on equity concerns. |

## 6. Employment equity

### 6.1 Self-identification

Employees may self-identify in MyHR at any time, and update or withdraw their answers at any time. Choosing not to respond has no effect on any employment decision. Answers are held in a restricted system, separately from the general personnel file. Individual answers are never shared with managers or hiring panels and are never used in decisions about hiring, pay, performance or discipline. Results are reported only in aggregate, with small groups suppressed so that no one can be identified. Use of this data is subject to a DPIA (FORM-HR-092).

### 6.2 Workforce analysis and employment systems review

The Bank carries out a workforce analysis every 3 years, and refreshes the representation figures each year for the annual report. The employment systems review covers recruitment (see HR-POL-019 Recruitment and Selection Policy), pay, development, assignments and accommodation (see HR-POL-018 Workplace Accommodation and Accessibility Policy). Barriers found are recorded in a plan with an owner and a date.

### 6.3 Annual report

The Bank files its annual employment equity report by 1 June each year. A summary is shared with all employees in MyHR within 30 days of filing, and a fuller aggregate view is part of the annual pay-equity and representation report in HR-POL-024.

### 6.4 Employment Equity Committee

The Employment Equity Committee has an equal number of employer and employee representatives. Employee representatives include members nominated by the employee resource groups. The committee meets quarterly, reviews the workforce analysis, the report and the barrier plan, and makes written recommendations. Minutes are kept and a summary is posted in MyHR within 15 business days of each meeting.

## 7. Pay equity

### 7.1 Annual review

Total Rewards reviews pay by gender and by designated group every year, as part of the compensation cycle in HR-POL-009 Compensation and Payroll Policy. The review compares base pay, incentive and rating outcomes after adjusting for role, band, location, experience and performance rating. Pay ranges for each band are set out in HR-GDE-006 Job Architecture and Pay Bands Guide.

### 7.2 Plan and adjustments

The Bank keeps a written pay equity plan and updates it every 3 years. Unexplained differences are corrected by equity adjustments, which are funded centrally and not from a team budget, and take effect with the annual salary review on 1 March. An adjustment that would take pay above the band maximum is paid as a lump sum under HR-GDE-006. Adjustments are not a reduction for anyone else: no employee's pay is lowered to close a gap.

### 7.3 Reporting

The Head of Inclusion and Belonging reports the findings and the actions to the HR Policy Committee each year. The summary for employees does not name individuals.

## 8. Procedures and deadlines

| Step | Who | Deadline |
| --- | --- | --- |
| File the employment equity report | Head of Inclusion and Belonging | 1 June each year |
| Share the summary with employees | Head of Inclusion and Belonging | Within 30 days of filing |
| Workforce analysis | Head of Inclusion and Belonging | Every 3 years |
| Committee meetings | Employment Equity Committee | Quarterly |
| Pay equity review | SVP Total Rewards | Annually, before salary planning |
| Update the pay equity plan | SVP Total Rewards | Every 3 years |
| Equity adjustments take effect | Payroll Services | 1 March, with the salary review |
| Acknowledge a complaint | Committee or Ombuds Office | Within 2 business days |
| Written outcome of a complaint | Committee | Within 30 calendar days of acknowledgement |

### 8.1 Making a complaint or raising a concern

An employee who believes they have been treated unfairly in pay or employment practices because of membership in a designated group may write to the Employment Equity Committee, or contact the Ombuds Office (ombuds@bank.example) for confidential informal advice. A complaint may also be made through HR Connect or the Speak-Up Line. The Committee may ask the HRBP and Total Rewards for the relevant data. The employee receives a written outcome and may ask the Head of Inclusion and Belonging for a review within 10 business days. Employees keep every external right of complaint.

## 9. Exceptions

- Where privacy law limits the analysis of a small group, results are combined with a neighbouring group or suppressed.
- If a filing deadline falls on a weekend or a Bank holiday, the report is filed on the previous business day.
- A pay adjustment may be made outside 1 March for a documented urgent case with the approval of the SVP Total Rewards.

## 10. Worked examples

**A pay equity finding.** The review of Band 3 analysts in Ontario compares pay after adjusting for band, location, experience and rating. It finds that women in the group earn on average 2.0% less than men with the same experience and rating, and no job-related reason is recorded. Total Rewards sets equity adjustments for the affected women. Each takes effect on 1 March and is funded centrally. No man's pay is changed. One employee is already near the band maximum, so her adjustment is paid partly as a lump sum.

**Declining to self-identify.** An employee chooses not to answer the self-identification questions. Nothing changes in their pay, rating or development. The employee can answer later, or update or withdraw an answer, in MyHR.

**A report deadline.** The employment equity report must be filed by 1 June. If 1 June falls on a Sunday, the Head of Inclusion and Belonging files by the previous Friday.

## 11. Consequences

Discrimination, retaliation against anyone who self-identifies or raises a concern, or misuse of self-identification data is a breach of this policy and of HR-POL-001 Code of Conduct and Ethics, and may lead to corrective action up to termination under HR-POL-021 Employee Relations and Progressive Discipline Policy.

## 12. Related documents

- HR-POL-024 Diversity, Equity, Inclusion and Belonging Policy
- HR-POL-009 Compensation and Payroll Policy
- HR-POL-016 Employee Data Privacy Policy
- HR-POL-018 Workplace Accommodation and Accessibility Policy
- HR-POL-019 Recruitment and Selection Policy
- HR-GDE-006 Job Architecture and Pay Bands Guide
- HR-POL-037 Pay Transparency Policy

## 13. Contacts

| Need | Contact |
| --- | --- |
| Questions about this policy | HR Connect, 1-800-555-0142, hrconnect@bank.example (Monday to Friday 8:00 to 20:00 Eastern Time) |
| Confidential informal advice | Ombuds Office, ombuds@bank.example |
| Privacy of self-identification data | privacy@bank.example |
| Anonymous reports | Speak-Up Line, 1-800-555-0177 (24 hours, 7 days) |

## 14. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 3.0 | 2025-04-01 | Set the 1 June filing date, the 3-year workforce analysis and pay equity plan cycles, and the quarterly Employment Equity Committee. |
| 2.0 | 2022-04-01 | Added the annual pay equity review and central funding of adjustments. |
| 1.0 | 2019-04-01 | First issue of the employment equity policy. |
