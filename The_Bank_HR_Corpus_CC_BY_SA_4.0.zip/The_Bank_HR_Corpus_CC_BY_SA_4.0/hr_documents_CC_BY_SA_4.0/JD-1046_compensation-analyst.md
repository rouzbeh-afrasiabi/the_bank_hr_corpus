# Compensation Analyst

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1046 |
| Title | Compensation Analyst |
| Document type | Job description |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-09-28 |
| Next review | 2027-09-28 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-POL-009, HR-PRC-005, HR-FWK-001, HR-POL-037, HR-POL-034 |

## 1. Role summary

The Compensation Analyst is a Tier 2 specialist in Total Rewards. The analyst levels jobs, runs market pricing, maintains the pay band data and supports the annual salary review, the Annual Incentive Plan and the pay-equity review. The role is Band 4 (Senior Professional): it handles complex work, advises HR Business Partners and is recognized for depth in compensation. See HR-GDE-006 Job Architecture and Pay Bands Guide.

## 2. Key responsibilities

- Level new and changed jobs against the four job-levelling factors (scope, complexity, accountability, independence) and recommend a band.
- Respond to job-review cases from the HR Case Portal within the 15 business days committed in HR-GDE-006.
- Match Bank jobs to peer-group survey jobs, require a match of at least 70% to use the data, and propose market-median (P50) midpoints.
- Maintain `pay_bands.csv` and the pay-range data used in job postings under HR-POL-037 Pay Transparency Policy.
- Model the annual salary review (effective 1 March) and prepare merit guides for calibration in line with HR-PRC-005 Calibration and Salary Planning Guidelines.
- Review offers above the midpoint with the HRBP and confirm they remain inside the band.
- Calculate compa-ratio and range position for individuals and teams, and flag cases below the minimum or above the maximum.
- Support the annual pay-equity analysis and the Canadian pay-equity requirements in HR-POL-034 Employment Equity and Pay Equity Policy.
- Support the Annual Incentive Plan: validate eligibility lists and test the payout formula using the funding factor and individual multipliers in HR-POL-009 Compensation and Payroll Policy.
- Prepare total rewards statements and answer compensation questions escalated by HR Connect.
- Keep job-architecture documentation accurate and flag inconsistent job descriptions.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in human resources, business, economics, finance or statistics.
- Five to eight years of experience in compensation, benefits analytics or HR analytics.
- Advanced spreadsheet and data-analysis skills; ability to build and audit models.
- Knowledge of job evaluation and survey methodology.

### 3.2 Preferred

- A recognized compensation designation.
- Experience with incentive plan design in financial services.
- Experience with a human capital analytics platform.

## 4. Competencies

Competency names follow HR-FWK-001 Competency and Leadership Model (Practitioner level, Bands 3 to 4).

- Judgement and Decision Quality
- Drive for Results
- Risk and Conduct Awareness
- Collaboration
- Inclusive Leadership

## 5. Compensation and classification

| Item | Detail |
| --- | --- |
| Band | 4 (Senior Professional) |
| Canada range | $72,000 to $108,000 CAD per year |
| US range | $70,000 to $106,000 USD per year |
| Incentive target | 8% of base salary (Annual Incentive Plan) |
| Overtime eligibility, Canada | Yes (non-managerial) |
| FLSA classification, US | Exempt |
| Work arrangement | Hybrid |

## 6. Working conditions and accessibility

Office-based and hybrid by default, with at least 3 days a week in the office; Tuesday and Thursday are anchor days (HR-POL-002 Remote and Hybrid Work Policy; FORM-HR-030). The role handles highly confidential pay data and may have peak workloads during calibration (11 December to 10 January). The Bank provides accommodation to the point of undue hardship (HR-POL-018 Workplace Accommodation and Accessibility Policy).

## 7. Reporting line

Reports to the Director, Total Rewards. The role has no direct reports.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-03-01 | Pay band, pay transparency and pay-equity duties aligned with the 2026 pay bands |
| 1.0 | 2025-01-01 | First issue |
