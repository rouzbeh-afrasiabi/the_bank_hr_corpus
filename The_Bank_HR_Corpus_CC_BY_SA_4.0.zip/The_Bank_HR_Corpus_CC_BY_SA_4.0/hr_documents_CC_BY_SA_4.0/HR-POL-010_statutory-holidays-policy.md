# Statutory Holidays Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-010 |
| Title | Statutory Holidays Policy |
| Document type | Policy |
| Version | 3.0 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-10-05 |
| Next review | 2027-10-05 |
| Policy owner | SVP Total Rewards |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Applies to | All Canadian and US employees (see Scope) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-006, HR-POL-003, HR-POL-009, HR-POL-014, HR-POL-004, FORM-HR-020 |

## 1. Purpose

This policy lists the paid holidays the Bank observes in Canada and the US, publishes the 2026 calendar, and sets the rules for eligibility, pay, holidays that fall on weekends or during vacation, work on a holiday, and the two floating Cultural and Religious Observance Days. Where applicable law gives a greater right, the law applies.

## 2. Scope

The policy applies to all regular full-time and regular part-time employees in Canada and the US, from their first day of employment. Fixed-term employees are eligible as set out in HR-POL-014 Employment Status and Classification Policy. Casual employees receive holiday entitlements as the law requires. Contractors are not covered.

## 3. Definitions

- **Bank holiday:** a day listed in section 4 or 5 as a paid holiday, or its observed date.
- **Observed date:** the day on which a holiday is taken when the calendar date falls on a weekend.
- **Holiday pay:** a normal day's pay for a day not worked.
- **Average daily earnings:** regular earnings, excluding overtime, over the previous 20 working days, divided by 20.
- **Day before and day after:** the employee's scheduled working days immediately before and after the holiday.

## 4. 2026 calendar: Canada

### 4.1 Holidays by date

| Date | Day | Holiday | Where observed |
| --- | --- | --- | --- |
| 2026-01-01 | Thursday | New Year's Day | All provinces and territories |
| 2026-02-16 | Monday | Family Day (Louis Riel Day in Manitoba, Heritage Day in Nova Scotia, Islander Day in Prince Edward Island) | Ontario, Alberta, British Columbia, Saskatchewan, New Brunswick, Manitoba, Nova Scotia, Prince Edward Island |
| 2026-04-03 | Friday | Good Friday | All, including Quebec |
| 2026-05-18 | Monday | Victoria Day (National Patriots' Day in Quebec) | All; Quebec observes it as National Patriots' Day |
| 2026-06-24 | Wednesday | Fête nationale du Québec | Quebec only |
| 2026-07-01 | Wednesday | Canada Day | All |
| 2026-08-03 | Monday | Civic Holiday / Provincial Day (British Columbia Day in BC) | Ontario, British Columbia, Alberta, Manitoba, Saskatchewan, Nova Scotia, New Brunswick, Prince Edward Island, Newfoundland and Labrador |
| 2026-09-07 | Monday | Labour Day | All |
| 2026-09-30 | Wednesday | National Day for Truth and Reconciliation | All |
| 2026-10-12 | Monday | Thanksgiving | All |
| 2026-11-11 | Wednesday | Remembrance Day | All |
| 2026-12-25 | Friday | Christmas Day | All |
| 2026-12-26 | Saturday | Boxing Day (observed Monday 2026-12-28) | All |

Quebec observes Good Friday as the Bank's choice between Good Friday and Easter Monday. Family Day is not observed in Quebec, Newfoundland and Labrador, Yukon, the Northwest Territories or Nunavut. The Civic Holiday is not observed in Quebec or the territories.

### 4.2 Holidays by jurisdiction

Nine holidays are observed everywhere: New Year's Day, Good Friday, Canada Day, Labour Day, the National Day for Truth and Reconciliation, Thanksgiving, Remembrance Day, Christmas Day and Boxing Day. The table shows the extra holidays by jurisdiction.

| Jurisdiction | Victoria Day / Patriots' Day | Family Day or equivalent | Civic Holiday / Provincial Day | Fête nationale | Total Bank holidays |
| --- | --- | --- | --- | --- | --- |
| Ontario | Yes | Yes | Yes | No | 12 |
| Quebec | Yes (Patriots' Day) | No | No | Yes | 11 |
| British Columbia | Yes | Yes | Yes (BC Day) | No | 12 |
| Alberta | Yes | Yes | Yes | No | 12 |
| Manitoba | Yes | Yes (Louis Riel Day) | Yes | No | 12 |
| Saskatchewan | Yes | Yes | Yes | No | 12 |
| Nova Scotia | Yes | Yes (Heritage Day) | Yes | No | 12 |
| New Brunswick | Yes | Yes | Yes | No | 12 |
| Prince Edward Island | Yes | Yes (Islander Day) | Yes | No | 12 |
| Newfoundland and Labrador | Yes | No | Yes | No | 11 |
| Yukon | Yes | No | No | No | 10 |
| Northwest Territories | Yes | No | No | No | 10 |
| Nunavut | Yes | No | No | No | 10 |

## 5. 2026 calendar: United States

The Bank observes 11 holidays in the US.

| Date | Day | Holiday | Observed date |
| --- | --- | --- | --- |
| 2026-01-01 | Thursday | New Year's Day | 2026-01-01 |
| 2026-01-19 | Monday | Martin Luther King Jr. Day | 2026-01-19 |
| 2026-02-16 | Monday | Presidents' Day | 2026-02-16 |
| 2026-05-25 | Monday | Memorial Day | 2026-05-25 |
| 2026-06-19 | Friday | Juneteenth | 2026-06-19 |
| 2026-07-04 | Saturday | Independence Day | Friday 2026-07-03 |
| 2026-09-07 | Monday | Labor Day | 2026-09-07 |
| 2026-11-11 | Wednesday | Veterans Day | 2026-11-11 |
| 2026-11-26 | Thursday | Thanksgiving | 2026-11-26 |
| 2026-11-27 | Friday | Day after Thanksgiving | 2026-11-27 |
| 2026-12-25 | Friday | Christmas Day | 2026-12-25 |

## 6. Eligibility and the day-before-and-after rule

All regular full-time and regular part-time employees are eligible for holiday pay from day one. An employee **forfeits holiday pay** if they have an unexcused absence on the scheduled day before **and** the scheduled day after the holiday. An absence is excused if it is a protected absence under HR-POL-004 Attendance and Absenteeism Policy, vacation, an approved personal day, or illness reported on time. Absence on only one of the two days does not forfeit holiday pay.

## 7. Pay for full-time and part-time employees

| Category | Holiday pay |
| --- | --- |
| Regular full-time | A normal day: 7.5 hours (Canada) or 8 hours (US) at the regular rate |
| Regular part-time | Average daily earnings over the previous 20 working days |

For example, a part-time employee who earned $2,400 CAD in the previous 20 working days (24 hours a week at $25 an hour) receives $2,400 / 20 = $120 for the holiday, whether or not the day was a scheduled day. Holiday pay is paid on the regular pay date (see HR-POL-009 Compensation and Payroll Policy).

## 8. Holidays on weekends

- A holiday on a **Saturday** is observed on the preceding Friday in the US and on the following Monday in Canada.
- A holiday on a **Sunday** is observed on the following Monday.
- In 2026, Independence Day (Saturday 2026-07-04) is observed on Friday 2026-07-03, and Boxing Day (Saturday 2026-12-26) is observed on Monday 2026-12-28.

## 9. Working on a holiday

An employee who must work on a Bank holiday (for example in a branch or operations unit that opens) receives **regular holiday pay plus 1.5x for the hours worked**, or, instead of the 1.5x payment, **1.5x time in lieu** taken within **60 days**. The manager records the choice before the holiday on FORM-HR-020 in Time Tracker. Overtime rules in HR-POL-003 Working Hours and Overtime Policy still apply to any hours over the weekly or daily thresholds.

**Example (Canada).** An employee paid $32 an hour works 7.5 hours on Monday 2026-09-07. Holiday pay is 7.5 x $32 = $240; the premium is 7.5 x 1.5 x $32 = $360; total $600. If time in lieu is chosen, the premium is replaced by 11.25 hours off (7.5 x 1.5) taken by 2026-11-06.

**Example (US).** An employee paid $30 an hour works 8 hours on Monday 2026-05-25. Holiday pay is $240; the premium is 8 x 1.5 x $30 = $360; total $600. US non-exempt employees receive cash only, so the time-in-lieu option applies to Canada.

## 10. Holiday during vacation

A Bank holiday that falls during an approved vacation is **not charged** against the vacation balance and extends the time away. For example, an Ontario employee on vacation from Monday 2026-05-11 to Friday 2026-05-22 uses 9 vacation days, because Victoria Day (Monday 2026-05-18) is a holiday. A US employee on vacation from Monday 2026-11-23 to Friday 2026-11-27 uses 3 days, because Thursday 2026-11-26 and Friday 2026-11-27 are holidays. See HR-POL-006 Vacation and Paid Time Off Policy. A holiday that falls during sick leave is also not charged against sick days.

## 11. Floating Cultural and Religious Observance Days

Every eligible employee in Canada and the US receives **2 floating days** per calendar year, to be used for a cultural or religious observance of their choice. The employee gives **24 hours' notice** in Time Tracker and no reason is required. Floating days do not carry over and have no cash value. New hires are credited pro rata, rounded up to the nearest half day. Part-time employees receive the same 2 days.

## 12. Bank closures and HR Connect

HR Connect is closed on Bank holidays. Urgent safety matters go to Corporate Security (1-800-555-0119).

## 13. Roles and responsibilities

- **Employees** check the calendar and request floating days in advance.
- **Managers** plan coverage fairly, record premium choices and confirm excused absences.
- **Payroll Services** pays holiday pay and premiums.
- **HR Operations** publishes the calendar each year by 1 October.
- **SVP Total Rewards** owns this policy.

## 14. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2023-01-01 | Aligned holiday pay rules for part-time employees across Canada and the US |
| 3.0 | 2026-01-01 | Added the 2026 calendar, the 20-working-day averaging rule for part-time pay, clarified weekend observance and holiday work compensation, and set 2 floating days |
