# Employee HR FAQ Updated to Version 2026.3

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-MEMO-2026-010 |
| Title | Employee HR FAQ Updated to Version 2026.3 |
| Document type | Memo |
| Version | 1.0 |
| Status | Current |
| Effective date | 2026-10-26 |
| Last reviewed | Not applicable |
| Next review | Not applicable |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-FAQ-001, HR-FAQ-002, HR-GDE-004, HR-ARC-007 |

**The Employee HR FAQ has been refreshed: version 2026.3 is live today.**

**From:** VP HR Operations

**To:** All employees in Canada and the US

**Date:** 26 October 2026

**Subject:** HR-FAQ-001 Employee HR FAQ, version 2026.3

## 1. What is changing

HR-FAQ-001 Employee HR FAQ is updated to version 2026.3 and replaces earlier 2026 editions. It reflects current policy values as of 26 October 2026. Where the FAQ and a policy differ, the policy governs.

## 2. Who is affected

All employees. Managers should point team members to the FAQ before calling HR Connect.

## 3. Effective date

26 October 2026.

## 4. What to do

1. Open the Employee HR FAQ in MyHR and search by topic.
2. Replace any saved copies or bookmarks. Do not rely on older material such as HR-ARC-007 (the archived 2024 edition), which quotes superseded values.
3. Quebec employees can use HR-FAQ-002, the French-language FAQ for Quebec employees.
4. If your answer is not there, ask HR Connect or use live chat in MyHR. HR service levels are in HR-GDE-004 HR Service and Support Guide.

## 5. Who to call

HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, or live chat in MyHR in the same hours. English and French; an interpreter is available on request. Managers: Manager Hotline 1-800-555-0143.

## 6. Related documents

- HR-FAQ-001 Employee HR FAQ
- HR-FAQ-002 Foire aux questions pour les employés du Québec
- HR-GDE-004 HR Service and Support Guide
