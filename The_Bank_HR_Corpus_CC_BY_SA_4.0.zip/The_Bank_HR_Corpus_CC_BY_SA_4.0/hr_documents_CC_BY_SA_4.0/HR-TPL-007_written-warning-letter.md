# Written Warning Letter

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-TPL-007 |
| Title | Written Warning Letter |
| Document type | Template |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-06-30 |
| Next review | 2027-06-30 |
| Policy owner | VP Employee Relations |
| Audience | HR only |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-021, HR-POL-004, HR-GDE-005, FORM-HR-071 |

## 1. Purpose and when to use this template

This template is the letter that records a written warning (or, with the changes in section 5, a final written warning) under HR-POL-021 Employee Relations and Progressive Discipline Policy. Attendance plans use FORM-HR-071 Written Warning and Attendance Plan Template with HR-POL-004 Attendance and Absenteeism Policy. The manager's step-by-step guidance is in HR-GDE-005 Manager's HR Procedures Guide.

## 2. How to use this template

1. Consult the HRBP before any written warning is issued.
2. Confirm that the earlier steps (coaching conversation and verbal warning) were held and documented, unless the misconduct is serious enough to skip steps.
3. Complete the placeholders with facts, dates and the policy or standard breached.
4. Meet the employee in private, give the letter, and explain that the employee may respond in writing within 5 business days and may bring a support person.
5. File the signed letter in the confidential employee file and set the expiry date 12 months from the issue date.

## 3. Letter text

**[Date]**   **Personal and confidential**

**[Employee full name]**, [Job title], Band [Band]

**Subject: Written warning**

Dear [Employee first name],

This letter is a written warning. It follows our meeting on **[Meeting date]**, at which **[Manager name]** and **[HRBP name / support person, if present]** attended.

**What happened.** **[Factual description of the conduct or issue, with dates and examples.]** This does not meet the standard required by **[Policy ID and title]**.

**Earlier steps.** **[Coaching conversation on [date]; verbal warning on [date].]**

**What is expected.** From today, you are expected to **[Specific, measurable expectations]**. We will review progress on **[Review date]**, and I will meet you **[Frequency]** to support you.

**Consequences.** If the conduct or performance does not improve, or if it happens again, further discipline may follow, up to and including termination of employment.

**How long this warning stays active.** This warning is active for **12 months** from the date of this letter, until **[Expiry date]**. After that it no longer counts as an active warning, although it stays in the file under the retention schedule.

**Your right to respond.** You may respond in writing within **5 business days**, and your response will be attached to this letter. You may bring a support person to any meeting about this warning; the person may not be legal counsel. Signing this letter shows that you received it; it does not mean that you agree with it. If you refuse to sign, I will record that.

**Support.** The Wellspring Support Program (1-800-555-0166, 24 hours a day, confidential) and the Ombuds Office (ombuds@bank.example) are available. If you believe a medical condition or another protected ground is affecting this matter, please tell me, HR Connect or accommodations@bank.example.

Sincerely,
**[Manager name]**, [Manager title]
**[HRBP name]**, HR Business Partner

Received by: ____________  Date: ____________

## 4. Required clauses checklist

| Clause | Required content |
| --- | --- |
| Facts | Dates and examples, no opinion |
| Expectations | Specific and measurable, with a review date |
| Active period | 12 months |
| Right to respond | Written response within 5 business days |
| Support person | Allowed, not legal counsel |
| Consequence | Further discipline up to termination |

## 5. Drafting notes for HR

- Progressive steps: coaching conversation (not discipline); verbal warning (documented); written warning (active 12 months); final written warning (active 24 months, may include an unpaid suspension of up to 3 days); termination. Employee Relations approval is required before termination.
- For a final written warning change the active period to 24 months, state any unpaid suspension (up to 3 days) and the date it is served, and add that termination may follow without further notice if the issue recurs.
- Protected absences must not be treated as misconduct (HR-POL-004). Check for accommodation needs before issuing a warning about attendance or performance.
- Never copy the warning to colleagues. Distribution is limited to the manager, HRBP and Employee Relations.

## 6. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.0 | 2023-04-03 | First written warning template |
| 2.0 | 2025-09-01 | Added the 12-month active period, right-to-respond wording and final written warning notes |
