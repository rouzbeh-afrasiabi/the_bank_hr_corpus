# Hybrid Work Minimum Rises to 3 Office Days a Week

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-MEMO-2025-002 |
| Title | Hybrid Work Minimum Rises to 3 Office Days a Week |
| Document type | Memo |
| Version | 1.0 |
| Status | Current |
| Effective date | 2025-09-24 |
| Last reviewed | Not applicable |
| Next review | Not applicable |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-002, FORM-HR-030, HR-POL-044 |

**From 5 January 2026, hybrid means at least 3 days a week in the office.**

**From:** VP HR Operations

**To:** All hybrid employees and their managers

**Date:** 24 September 2025

**Subject:** Hybrid work minimum and anchor days from 5 January 2026

## 1. What is changing

HR-POL-002 Remote and Hybrid Work Policy version 3.0 raises the hybrid minimum from 2 office days a week (no anchor days) to at least 3 office days a week. Tuesday and Thursday are anchor days for everyone; your team chooses the third day.

## 2. Who is affected

Employees on a Hybrid arrangement. On-site roles (branches and operations) and approved Remote roles are not affected.

## 3. Effective date

5 January 2026. Version 2.1 applies until 4 January 2026.

## 4. What to do

1. Agree your third office day with your team before the change.
2. Update your schedule through FORM-HR-030 (Work Arrangement Request) in MyHR before 5 January 2026.
3. If you need flexibility, your manager may approve up to 12 office-attendance exception days per calendar year per employee. More than 12 needs your HRBP.
4. Accommodation needs are handled separately; request them through accommodations@bank.example.

## 5. Who to call

HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, or live chat in MyHR. Managers: Manager Hotline 1-800-555-0143.

## 6. Related documents

- HR-POL-002 Remote and Hybrid Work Policy
- FORM-HR-030 Work Arrangement Request (Hybrid or Remote)
- HR-POL-044 Business Continuity and Severe Weather Policy
