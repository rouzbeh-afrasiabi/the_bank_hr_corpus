# HR Business Partner II

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1048 |
| Title | HR Business Partner II |
| Document type | Job description |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-08-12 |
| Next review | 2027-08-12 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-004, HR-GDE-006, HR-FWK-001, HR-FWK-003, HR-POL-024, HR-POL-031 |

## 1. Role summary

The HR Business Partner II (HRBP II) is the senior HR advisor to a major business unit, such as Capital Markets, Wealth Management or Technology and Operations. The HRBP II shapes the people strategy with the business unit head, owns the unit's talent and succession agenda and leads a small team of HR professionals. The role is Band 6 (Manager II / Senior Manager): it manages several teams or a significant function and sets operating plans. See HR-GDE-006 Job Architecture and Pay Bands Guide.

## 2. Key responsibilities

- Partner with the business unit head on strategy, organization design, workforce planning and cost-of-people decisions.
- Lead the annual talent review and succession process for Band 6 and above, using HR-FWK-003 Talent Review and Succession Process, and keep 9-box placement confidential.
- Advise on incentive design and deferral issues for senior roles and designated material risk takers, working with Total Rewards (HR-POL-031 Incentive Deferral and Clawback Policy).
- Lead Tier 3 resolution for complex cases in the HR Case Portal and escalate threatened litigation to Legal.
- Run calibration for the business unit between 11 December and 10 January and challenge rating distribution against the guidance (Outstanding 5 to 10%, Exceeds 20 to 30%, Meets 50 to 60%).
- Drive diversity goals, including diverse interview slates for Band 5 and above, and report on representation (HR-POL-024 Diversity, Equity, Inclusion and Belonging Policy).
- Advise on exceptions beyond the HRBP I approval limits, such as more than 12 office-attendance exception days a year under HR-POL-002.
- Lead people-impact assessments for restructuring and manage consultation and communications with Employee Relations and Legal.
- Coach senior leaders on managing performance, conduct and engagement; sponsor action plans after the engagement survey.
- Manage and develop HR Business Partners I and HR Generalists, including their goals and development plans.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in human resources, business or a related field; master's degree preferred.
- Nine to thirteen years of HR experience, including senior business-partner experience in a large, regulated organization.
- Experience leading people and managing a budget.
- Deep knowledge of Canadian and US employment law, executive compensation concepts and organizational change.
- Credibility with senior executives and strong influencing skills.

### 3.2 Preferred

- A recognized HR designation and experience in banking or capital markets.
- Experience supporting licensed or conduct-sensitive populations.

## 4. Competencies

Competency names follow HR-FWK-001 Competency and Leadership Model (Leader level, Bands 5 to 6).

- Inclusive Leadership
- Developing Others
- Judgement and Decision Quality
- Collaboration
- Drive for Results
- Risk and Conduct Awareness
- Adaptability

## 5. Compensation and classification

| Item | Detail |
| --- | --- |
| Band | 6 (Manager II / Senior Manager) |
| Canada range | $112,000 to $168,000 CAD per year |
| US range | $110,000 to $166,000 USD per year |
| Incentive target | 15% of base salary (Annual Incentive Plan) |
| Overtime eligibility, Canada | No |
| FLSA classification, US | Exempt |
| Work arrangement | Hybrid |

## 6. Working conditions and accessibility

Office-based and hybrid by default, with at least 3 days a week in the office; Tuesday and Thursday are anchor days (HR-POL-002 Remote and Hybrid Work Policy; FORM-HR-030). Regular travel to business-unit sites is expected. The role handles highly confidential matters and may need to respond to urgent situations. The Bank provides accommodation to the point of undue hardship (HR-POL-018 Workplace Accommodation and Accessibility Policy).

## 7. Reporting line

Reports to the Director, HR Business Partnering. Direct reports: HR Business Partners I and HR Generalists.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-03-01 | Pay band aligned with the 2026 pay bands; talent review and calibration dates updated |
| 1.0 | 2025-01-01 | First issue |
