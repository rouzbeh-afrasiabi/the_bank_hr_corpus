# Recognition and Awards Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-043 |
| Title | Recognition and Awards Policy |
| Document type | Policy |
| Version | 3.0 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-09-16 |
| Next review | 2027-09-16 |
| Policy owner | SVP Total Rewards |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-009, HR-POL-014, HR-POL-019, HR-POL-001, HR-POL-011, FORM-HR-126 |

## 1. Purpose

This policy describes how the Bank says thank you. It sets out the four recognition programs open to employees: spot awards, peer recognition points, the annual Excellence Awards and service awards. It explains who is eligible, how much each program is worth, how nominations are made and approved, how awards are paid and taxed, and the limits that keep recognition fair. Recognition is meant to reinforce the Bank values of Integrity, Customer Focus, Accountability, Collaboration and Inclusion.

## 2. Scope

Spot awards and peer recognition points are open to all employees in Canada and the US, including casual, student, co-op and intern employees. Excellence Awards and service awards are open to regular full-time, regular part-time and fixed-term employees (see HR-POL-014 Employment Status and Classification Policy). Contractors and agency workers are not eligible. Recognition does not replace pay, the Annual Incentive Plan or the incentive plans in HR-PLN-002 Advisor and Sales Incentive Plan Document, and is not part of the performance rating. Where applicable law gives a greater right, the law applies.

## 3. Definitions

- **Fiscal year:** 1 November to 31 October.
- **Spot award:** a one-off cash award for a specific contribution, made by a manager or Director.
- **Recognition points:** points given by one employee to another in MyHR; 1 point is worth $1 and is redeemed in a catalogue.
- **Excellence Awards:** the Bank's annual awards for exceptional contribution, with a nomination window.
- **Service award:** a gift marking a completed milestone of service.
- **Service date:** the continuous service date recorded in MyHR under HR-POL-014.
- **Recipient:** the employee who receives the award.

## 4. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Employee | Gives recognition fairly, nominates, redeems points and gifts, reports any misuse |
| Manager | Approves and gives spot awards within limits, keeps a record of awards given, supports nominations |
| Director | Approves spot awards above the manager limit |
| HRBP | Checks eligibility questions and fairness across a business unit |
| Total Rewards | Runs the programs and the Recognition Review Panel, administers the catalogue and Excellence Awards |
| Payroll Services | Pays cash awards through payroll and reports taxable amounts |
| Recognition Review Panel | Selects Excellence Award recipients (Total Rewards chair, plus one HRBP and three business unit representatives) |
| SVP Total Rewards | Owns this policy and approves exceptions |

## 5. Spot awards

### 5.1 Amounts and limits

| Approver | Maximum per award (Canada) | Maximum per award (US) |
| --- | --- | --- |
| Manager | $250 CAD | $200 USD |
| Director | $500 CAD | $400 USD |

An employee may receive no more than **3 spot awards per fiscal year**, whoever gives them. The limit counts awards, not dollars, and cannot be exceeded by combining or splitting awards. Managers may not give a spot award to themselves, to a relative, or in exchange for a favour.

### 5.2 Procedure

1. The manager records the award in MyHR with the reason, which must describe the specific action and the value it showed.
2. A manager gives awards only up to the manager limit. An award above that limit needs the approval of the Director of the employee's unit before it is told to the employee.
3. Payroll Services pays the award on the next regular pay date after the entry, provided it is entered by the payroll cut-off in HR-POL-009 Compensation and Payroll Policy (17:00 Eastern five business days before the pay date). A later entry is paid on the following pay date.
4. The manager tells the recipient promptly and, where possible, in public.

## 6. Peer recognition points

Any employee may give another employee recognition points in MyHR, with a short comment that links to a Bank value. One point is worth $1 and points are redeemed in the online catalogue for gift cards and merchandise from approved providers. The cap is **500 points per recipient per fiscal year**; points above the cap cannot be given. Points cannot be given to oneself, in a reciprocal exchange, or to a direct manager in a way that suggests a favour. Points are redeemed within 12 months of receipt; points not redeemed in that time expire. Points are a taxable benefit where tax law requires, and Payroll Services reports the redeemed value.

## 7. Annual Excellence Awards

### 7.1 Awards

The Bank grants up to **60 Excellence Awards** each year. Each recipient receives **$2,500 CAD** (Canada) or **$2,000 USD** (US), plus a certificate and recognition at a Bank event.

### 7.2 Nomination

1. Nominations are open from **1 September to 15 October** each year.
2. Anyone may nominate an eligible employee or team using FORM-HR-126 Recognition Award Nomination in MyHR. A manager may nominate a direct report with the support of the Director.
3. The nomination describes the achievement during the fiscal year, its result and the Bank value it shows. It must be supported by a Director or above.
4. A nomination cannot be made after 15 October.

### 7.3 Selection and announcement

The Recognition Review Panel meets in November, reviews the nominations against the criteria (impact, customer or colleague benefit, living the Bank values, conduct), checks conduct and risk records with the HRBP, and recommends recipients to the CHRO. Recipients are **announced in December**. A team award is divided equally among team members and counts as one of the 60 awards. The payment is made through payroll on the first regular pay date after the payroll cut-off that follows the announcement. An employee under an active disciplinary written warning or a final written warning (see HR-POL-021 Employee Relations and Progressive Discipline Policy) cannot receive an Excellence Award in that year.

## 8. Service awards

### 8.1 Milestones and gift values

Service awards recognize completed years of continuous service at milestone anniversaries. The gift value is shown in Canadian dollars; for employees in the US, the value is **80%** of the Canadian amount, stated in US dollars.

| Years of service | Gift value (Canada, CAD) | Gift value (US, USD at 80%) |
| --- | --- | --- |
| 5 years | $150 | $120 |
| 10 years | $300 | $240 |
| 15 years | $500 | $400 |
| 20 years | $750 | $600 |
| 25 years | $1,000 | $800 |
| 30 years | $1,250 | $1,000 |
| 35 years | $1,500 | $1,200 |
| 40 years | $2,000 | $1,600 |

### 8.2 Rules

- Service is measured from the service date recorded in MyHR (see HR-POL-014). A rehire within 12 months keeps prior service; a longer break restarts it.
- HR Operations notifies the employee **30 days before** the milestone anniversary and the employee chooses a gift from the catalogue within **90 days** after the anniversary; a gift not chosen in that time lapses, but HR Operations may reinstate it for a reason such as a long leave.
- Approved leaves do not interrupt service for the purposes of this table, except as the relevant leave policy says.
- Only the highest milestone reached in a year is awarded; milestones are not repeated or rolled together.
- A gift is delivered or issued as an e-gift, and employees may add their own money to buy a larger item.
- A service award is not payable to an employee who has resigned or received notice of termination before the anniversary date.

## 9. Taxes and payment

Cash awards, redeemed points and service gifts are taxable benefits where tax law requires; Payroll Services withholds the tax and shows each item on the pay statement and on the T4, Relevé 1 or W-2. The Bank does not provide tax advice. Employees may not trade a gift for cash. Referral bonuses are separate and are described in HR-POL-019 Recruitment and Selection Policy. Sales incentive payouts are separate and are described in HR-PLN-002.

## 10. Conduct and fairness

Recognition is given on the basis of contribution, never on gender, race, age or any other protected ground, and it must not be tied to a sales practice that the customer did not ask for. A person who receives a gift from a supplier or a customer follows the limits in HR-POL-001 Code of Conduct and Ethics; Bank recognition does not change them. HRBPs review the pattern of awards each year in each business unit and raise any concern with the VP responsible. A manager who gives awards unfairly or to a relative or for a favour may be disciplined. Employees who suspect abuse can contact the Ombuds Office (ombuds@bank.example) or the Speak-Up Line (1-800-555-0177).

## 11. Worked examples

**Example 1: spot awards.** A Canadian employee receives a $250 CAD award from her manager in February, a $500 CAD award from her Director in May and a $200 CAD award in August. These are her 3 awards for the fiscal year (1 November to 31 October). A fourth award in October is not allowed.

**Example 2: US Director limit.** A Director in the US wants to give a $450 USD spot award. The Director limit is $400 USD, so the award is capped at $400 USD unless the SVP Total Rewards approves an exception under section 12.

**Example 3: service award.** A US employee with a service date of 15 March 2006 reaches 20 years on 15 March 2026. The Canadian gift value is $750; at 80%, the US gift value is $600. HR Operations notifies the employee on 13 February 2026 and the employee has until 13 June 2026 to choose.

**Example 4: Excellence Awards.** A nomination is entered on FORM-HR-126 on 10 October with the support of a Director, so it is in time. The panel meets in November and the recipient is announced in December and paid $2,500 CAD (Canada) or $2,000 USD (US).

## 12. Exceptions

The SVP Total Rewards may approve an exception to a limit in this policy only in writing and with a clear business reason, and not for the service award table or the Excellence Award amounts.

## 13. Related documents and contacts

Related: HR-POL-009 Compensation and Payroll Policy; HR-POL-014 Employment Status and Classification Policy; HR-POL-019 Recruitment and Selection Policy; HR-POL-001 Code of Conduct and Ethics; FORM-HR-126 Recognition Award Nomination. Contact HR Connect at 1-800-555-0142 (Monday to Friday 8:00 to 20:00 Eastern Time) or hrconnect@bank.example. Managers may call the Manager Hotline at 1-800-555-0143.

## 14. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2022-01-01 | Introduced peer recognition points and the annual Excellence Awards |
| 2.5 | 2024-01-01 | Added the 3-awards-a-year limit on spot awards and the Director approval level |
| 3.0 | 2026-01-01 | Added the 40-year service milestone, the 80% US gift value, the nomination window of 1 September to 15 October and FORM-HR-126 |
