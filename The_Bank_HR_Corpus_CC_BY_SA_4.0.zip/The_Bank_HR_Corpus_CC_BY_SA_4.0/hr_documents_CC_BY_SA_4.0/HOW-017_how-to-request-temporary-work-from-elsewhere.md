# How to request temporary work from elsewhere

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-017 |
| Title | How to request temporary work from elsewhere |
| Document type | How-to article |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-01-05 |
| Last reviewed | 2026-08-20 |
| Next review | 2027-08-20 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-002, FORM-HR-031, HR-POL-017 |

## 1. The short answer

Submit FORM-HR-031 (Temporary Work-from-Elsewhere Request) in MyHR > Time and Absence > Work from Elsewhere at least 5 business days before you go (domestic) or 10 business days before (across the Canada-US border).

## 2. Who this applies to

Employees in Canada (including Quebec) and the US whose role allows working away from a Bank office. It does not change your arrangement; for that, use FORM-HR-030 (see HOW-016). Branch and operations roles that must be performed on Bank premises are not suited to it.

## 3. Steps

1. Choose the location and check the limit:

| Location | Limit per calendar year | Submit at least | Approval |
| --- | --- | --- | --- |
| Elsewhere in your home country | 20 working days | 5 business days ahead | Manager |
| Across the Canada-US border | 10 working days | 10 business days ahead | Manager, with Payroll Services and Legal review |
| Any other country | Not permitted by default | 30 days ahead | Global Mobility and Legal |

2. Open MyHR > Time and Absence > Work from Elsewhere and complete FORM-HR-031: destination, first and last working day, and the reason. MyHR pre-fills the working days you have used so far this year.
3. For cross-border or other countries, confirm your own right to work at the destination.
4. Confirm you have a private workspace and a secure connection.
5. Submit within the lead time.

## 4. Deadlines and what happens next

You are told the decision in MyHR before your travel dates. Approved days are added to your annual count. The domestic and cross-border limits are separate. The Bank may refuse a request for tax, immigration, regulatory or security reasons. Keep working your core hours, 10:00 to 15:00 local time.

## 5. Common mistakes

- Booking travel before approval.
- Submitting late. A request inside the lead time may be refused.
- Assuming time away extends your vacation or changes your pay or tax treatment. It does not.
- Taking a Bank device to a restricted country without telling Corporate Security 10 business days ahead.
- Using public Wi-Fi without the VPN. The VPN must always be on.
- Treating the limits as per trip. They are per calendar year.

## 6. Who to call

- Your manager for approval questions.
- HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example.
- Lost device or suspected incident: Security Operations Centre, 1-800-555-0155 (24 hours a day), immediately and no later than 1 hour.
- Corporate Security: 1-800-555-0119.

## 7. Related documents

- HR-POL-002 Remote and Hybrid Work Policy (the owning document)
- FORM-HR-031 Temporary Work-from-Elsewhere Request
- HR-POL-017 IT Acceptable Use and Information Security Policy

Where applicable law gives a greater right, the law applies.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-01-05 | Added domestic and cross-border limits and lead times from HR-POL-002 version 3.0. |
| 1.0 | 2025-01-01 | First version. |
