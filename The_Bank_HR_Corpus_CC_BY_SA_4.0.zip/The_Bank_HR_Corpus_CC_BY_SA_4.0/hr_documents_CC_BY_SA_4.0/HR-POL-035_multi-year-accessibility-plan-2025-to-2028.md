# Multi-Year Accessibility Plan 2025 to 2028

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-035 |
| Title | Multi-Year Accessibility Plan 2025 to 2028 |
| Document type | Policy |
| Version | 1.1 |
| Status | Current |
| Effective date | 2025-01-01 |
| Last reviewed | 2026-06-30 |
| Next review | 2027-06-30 |
| Policy owner | Head of Accessibility and Inclusion |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | Employees |
| Jurisdiction | Canada |
| Language | English |
| Related documents | HR-POL-018, HR-POL-024, HR-POL-019, HR-POL-012, HR-POL-016, HR-GDE-004 |

## 1. Purpose

This plan sets out how the Bank will identify, remove and prevent barriers for people with disabilities in Canada between 1 January 2025 and 31 December 2028. It lists the priority areas, the commitments the Bank has made with dates and owners, how progress is reported, and how employees and the public can give feedback. Individual accommodation requests are handled under HR-POL-018 Workplace Accommodation and Accessibility Policy; this plan deals with barriers that affect many people. Where applicable law gives a greater right, the law applies.

## 2. Scope

The plan covers the Bank's operations in Canada: employees, applicants, customers visiting branches or using Bank services, and the Bank's suppliers where they deliver services to employees or customers. Employees in the US are covered by the accommodation rules in HR-POL-018 and HR-POL-036 US Equal Employment Opportunity and Required Notices Policy.

## 3. Definitions

| Term | Meaning |
| --- | --- |
| Barrier | Anything that prevents a person with a disability from full participation, whether physical, architectural, informational, communication-related, technological, attitudinal or a matter of policy or practice. |
| Accessible format | A format such as large print, a screen-reader compatible document, captioning, sign language interpretation or plain language. |
| Plan period | 1 January 2025 to 31 December 2028. |
| Progress report | The annual public report on the status of each commitment. |
| Commitment | A dated action in section 7 with a named owner. |
| Abilities Network | The employee resource group for employees with disabilities and caregivers (see HR-POL-024 Diversity, Equity, Inclusion and Belonging Policy). |

## 4. Priority areas

The plan covers seven priority areas.

| Priority area | What the Bank is working on |
| --- | --- |
| Employment | Accessible recruitment, onboarding, training, performance and career development processes |
| Built environment | Entrances, counters, washrooms, wayfinding and workstations in branches and offices |
| Information and communication technologies | Accessible HR systems, MyHR, the Learning Hub and software the Bank buys |
| Communication | Accessible documents, plain language and alternate formats for HR and customer communication |
| Procurement | Accessibility criteria when buying goods, services and facilities |
| Design of programs and services | Accessible design of employee programs, customer services and events |
| Transportation | Accessible travel arrangements for business travel and Bank events, and accessible fleet vehicle options |

## 5. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Head of Accessibility and Inclusion | Owns the plan; chairs consultation; approves changes to dates; publishes the progress report. |
| Business unit heads | Deliver the commitments in their area and report quarterly to the Head of Accessibility and Inclusion. |
| Abilities Network and employees with disabilities | Advise on priorities and test the results. |
| Accommodation Specialist | Shares themes from accommodation requests (without personal details) to help find barriers. |
| Chief Information Security Officer and Technology and Operations | Make HR systems and tools accessible. |
| Procurement and Legal | Apply the accessibility criteria in contracts. |
| Chief Privacy Officer | Makes sure feedback and consultation data are handled under HR-POL-016 Employee Data Privacy Policy. |
| All employees | Use accessible formats when they create documents and raise barriers when they see them. |

## 6. Consultation, reporting and review

### 6.1 Consultation

The plan was developed after consultation with employees with disabilities, the Abilities Network and business leaders, and it is reviewed with the same groups. Consultation is voluntary, confidential and reasonable accommodations are provided for every session. Participation never affects employment.

### 6.2 Progress reports

A progress report is published on each 1 June in an accessible format, in MyHR and on the Bank's public website. It states the status of each commitment (Done, In progress, Planned, Ongoing or Revised) and any changes of date with reasons. The report of 1 June 2026 covered the period to 31 December 2025; the next is due on 1 June 2027.

### 6.3 Review of the plan

The plan is reviewed every 3 years with employees with disabilities. The first review under this plan is completed by 31 December 2027, so that a revised plan is ready for the period that starts on 1 January 2029.

### 6.4 Feedback

Anyone may give feedback on the plan or on a barrier by emailing accessibility@bank.example, calling HR Connect or using the Speak-Up page in MyHR. Feedback may be given anonymously. The Accessibility Office acknowledges feedback within 2 business days and gives a response within 10 business days, in the format the person requests. Feedback is summarized in the next progress report.

## 7. Commitments and status

Status as at 26 October 2026.

| # | Priority area | Commitment | Owner | Due date | Status |
| --- | --- | --- | --- | --- | --- |
| 1 | Employment | Launch an accessible job-application process | SVP Talent and Learning | 2026-06-30 | Done |
| 2 | Built environment | Self-assess all branches for physical accessibility | Business unit heads, Retail Banking | 2026-12-31 | In progress |
| 3 | Communication | Train all HR and employee communicators in accessible documents | Head of Accessibility and Inclusion | 2026-09-30 | Done |
| 4 | Communication | Provide any HR document or communication in an accessible format within 10 business days of request | Head of Accessibility and Inclusion | Continuous | Ongoing |
| 5 | Information and communication technologies | Complete an accessibility audit of MyHR and the Learning Hub | Technology and Operations | 2027-06-30 | Planned |
| 6 | Procurement | Add accessibility criteria to the standard supplier evaluation | Procurement and Legal | 2027-03-31 | Planned |
| 7 | Design of programs and services | Review employee programs and events for accessibility | Head of Inclusion and Belonging | 2027-12-31 | Planned |
| 8 | Transportation | Offer accessible options in every business travel booking | SVP Total Rewards (see HR-POL-038 Business Travel and Expense Policy) | 2027-09-30 | Planned |

Commitments 1, 3 and 4 relate to employees; commitments 2 and 6 relate to the Bank's premises and suppliers. Status definitions: Done means the action is complete; In progress means it has started and is on schedule; Planned means work has not started; Ongoing means it is a standing commitment that is measured every year; Revised means the date has been changed under section 9.

## 8. Procedures and deadlines

| Step | Who | Deadline |
| --- | --- | --- |
| Quarterly status update on each commitment | Business unit heads | Within 15 business days of each calendar quarter end |
| Publish the progress report | Head of Accessibility and Inclusion | 1 June each year |
| Acknowledge feedback | Accessibility Office | 2 business days |
| Respond to feedback | Accessibility Office | 10 business days |
| Provide accessible formats | Content owner with the Accessibility Office | 10 business days |
| Complete the branch self-assessments | Business unit heads, Retail Banking | 31 December 2026 |
| Review the plan | Head of Accessibility and Inclusion | By 31 December 2027 |

## 9. Exceptions

A commitment date may be moved only by the Head of Accessibility and Inclusion, in writing, with the reason and a new date. A moved commitment is shown as Revised in the next progress report. Where a barrier creates a safety risk, it is fixed or controlled at once, whatever the date in the plan. A request for an accessible format that cannot be met within 10 business days is escalated to the Head of Accessibility and Inclusion on day 5. None of these exceptions reduces the duty to accommodate an individual (see HR-POL-018).

## 10. Worked examples

**A feedback message.** An employee emails accessibility@bank.example on Monday 2 November 2026 to say that a Learning Hub course has no captions. The Accessibility Office acknowledges by Wednesday 4 November (2 business days). The response, with a fix date or an alternative such as a transcript, is due within 10 business days, by Tuesday 17 November (Remembrance Day, Wednesday 11 November, is not a business day).

**An accessible format request.** A manager asks on Tuesday 3 November 2026 for a policy to be provided as a screen-reader compatible document. The format is due within 10 business days, by Wednesday 18 November (again skipping 11 November), and sooner if a deadline, such as a leave request, depends on it. If the content owner has not delivered by the fifth business day, the request is escalated.

**A moved commitment.** If the branch self-assessments cannot be finished by 31 December 2026, the Head of Accessibility and Inclusion records a new date and the reason, and the next progress report shows the commitment as Revised.

## 11. Consequences

Failing to deliver a commitment on time without an approved change, or refusing to provide an accessible format without following this plan, is reported to the business unit head and the Head of Accessibility and Inclusion, and appears in the progress report. Retaliation against anyone who gives feedback is a breach of HR-POL-001 Code of Conduct and Ethics and may lead to corrective action under HR-POL-021 Employee Relations and Progressive Discipline Policy.

## 12. Related documents

- HR-POL-018 Workplace Accommodation and Accessibility Policy
- HR-POL-024 Diversity, Equity, Inclusion and Belonging Policy
- HR-POL-019 Recruitment and Selection Policy
- HR-POL-012 Learning and Development Policy (Accessibility and Human Rights training is repeated every 2 years)
- HR-POL-016 Employee Data Privacy Policy
- HR-POL-038 Business Travel and Expense Policy

## 13. Contacts

| Need | Contact |
| --- | --- |
| Feedback on the plan and accessible formats | accessibility@bank.example |
| Accommodation requests | accommodations@bank.example |
| General HR questions | HR Connect, 1-800-555-0142, hrconnect@bank.example (Monday to Friday 8:00 to 20:00 Eastern Time) |
| Confidential informal advice | Ombuds Office, ombuds@bank.example |

## 14. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.1 | 2025-01-01 | Plan period begins; commitments table with status added; progress report fixed at 1 June each year. |
| 1.0 | 2024-09-01 | Plan approved after consultation with employees with disabilities. |
