# Vacation and Paid Time Off Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-006 |
| Title | Vacation and Paid Time Off Policy |
| Document type | Policy |
| Version | 4.0 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-09-15 |
| Next review | 2027-09-15 |
| Policy owner | SVP Total Rewards |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Applies to | All Canadian and US employees (see Scope) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-010, HR-POL-007, FORM-HR-010 |

## 1. Purpose

This policy sets out how vacation is earned, requested, approved, carried over and paid out at the Bank. Vacation protects employee wellbeing and, through the mandatory block leave rule, is also a risk control for the Bank. Where applicable law gives a greater right, the law applies.

## 2. Scope and definitions

### 2.1 Scope

This policy applies to regular full-time, regular part-time, fixed-term and casual employees in Canada and the US. Contractors and agency workers are not covered. Employment categories are defined in HR-POL-014 Employment Status and Classification Policy.

### 2.2 Definitions

- **Vacation year:** the calendar year, 1 January to 31 December.
- **Completed service:** whole years of continuous service on 1 January of the vacation year.
- **Vacation day:** one scheduled working day (7.5 hours in Canada, 8 hours in the US for a full-time employee).
- **Block leave:** a period of at least 10 consecutive business days of vacation.
- **Personal day:** a separate paid day governed by HR-POL-007 Sick Leave and Personal Leave Policy.

## 3. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Employee | Plan and request vacation in MyHR, take the mandatory block, and keep a balance that can be used before year-end. |
| Manager | Respond to requests within 5 business days, balance team coverage fairly, and make sure every employee takes block leave. |
| HR Business Partner (HRBP) | Advises on blackout disputes and on office-attendance or coverage conflicts that a manager cannot resolve. |
| Payroll Services | Calculates accruals, advances, carryover and payouts. |
| Business unit head | Sets blackout periods and publishes them by 1 November for the following year. |
| Chief Compliance Officer | Audits block leave compliance in Capital Markets, Wealth Management and Finance. |

## 4. Entitlement and accrual

### 4.1 Annual entitlement

Entitlement is based on completed years of service at 1 January and is the same in Canada and the US.

| Completed service | Days per year (Canada and US) | Monthly accrual |
| --- | --- | --- |
| Less than 3 years | 15 | 1.25 |
| 3 to under 10 years | 20 | 1.67 |
| 10 to under 20 years | 25 | 2.08 |
| 20 years or more | 30 | 2.5 |

Vacation accrues monthly and is shown in MyHR. The tier applies for the whole calendar year; an employee who reaches a service anniversary mid-year moves to the new tier on the next 1 January.

### 4.2 New hires

New hires accrue monthly from the start date. The first-year entitlement is pro-rated by the days remaining in the calendar year and rounded up to the nearest half day. A new hire may request vacation from day 1 but may take it only after the first 3 months of service.

### 4.3 Part-time and casual employees

Regular part-time employees accrue vacation pro-rated by scheduled hours. Casual employees receive 6% vacation pay in lieu on every paycheque and have no vacation days. This 6% applies in Canada even where the law requires less.

### 4.4 Accrual during leaves

Vacation continues to accrue during paid sick days, short-term disability and the Bank-paid top-up period of a parental leave (HR-POL-008 Parental and Family Leave Policy). During a personal leave of absence, accrual stops after 30 days (HR-POL-007).

## 5. Requesting and approving vacation

### 5.1 Notice periods

Requests are made in MyHR.

| Length of request | Minimum notice |
| --- | --- |
| 5 or more days | 4 weeks |
| Fewer than 5 days | 5 business days |

The manager must respond within 5 business days. If the manager does not respond in that time, MyHR escalates the request to the manager's manager; silence is never deemed approval. Shorter notice may be approved at the manager's discretion.

### 5.2 Approval principles

Managers approve requests on the basis of business coverage, not personal preference. Where two requests conflict, the earlier submission is approved first. Employees who were not able to take a preferred period in the previous year should be given reasonable priority. A request already approved may be withdrawn by the Bank only for a documented operational emergency approved by a Director, and the Bank reimburses documented, non-refundable costs.

### 5.3 Cancellation

An employee may cancel approved vacation at least 2 business days before the start date. Vacation that is cancelled returns to the balance.

### 5.4 Blackout periods

Business units may set blackout periods when vacation is restricted. The standard blackouts are the last 2 weeks of December for some branch roles, and the fiscal year-end week for Capital Markets (the fiscal year ends on 31 October). Blackouts must be published in MyHR and apply only to roles named in the notice. Employees may not be refused all of their vacation in a year because of blackouts.

### 5.5 Statutory holidays

A statutory holiday that falls during vacation is not charged against the vacation balance. See HR-POL-010 Statutory Holidays Policy.

## 6. Mandatory block leave

Every employee must take at least 10 consecutive business days of vacation once per calendar year. This is a risk control that allows the Bank to detect irregularities that depend on an individual's continuous presence.

- Capital Markets, Wealth Management and Finance roles are audited by the Chief Compliance Officer's office.
- The block must be scheduled in MyHR by 30 June and completed by 31 December.
- During the block, employees in audited roles have their access to trading, ledger and client systems suspended, and they should not work.
- A statutory holiday inside the block does not break the 10 consecutive business days.
- An approved leave of 10 or more consecutive business days (for example parental leave) satisfies the requirement for that year.
- A manager who cannot release an employee for the block must obtain written approval from their VP and the Chief Compliance Officer for an alternative control, such as a documented rotation of duties.

## 7. Carryover, advances and forfeiture

### 7.1 Carryover

Up to 5 unused vacation days may be carried into the next calendar year and must be used by 31 March of that year. All other unused days are forfeited, except where the employee was on an approved leave that prevented use, or where the law requires payment. This rule has applied since version 4.0 (1 January 2026); under version 3.0 the limit was 3 days.

### 7.2 Vacation advance

With manager approval, an employee may take up to 5 days ahead of accrual. Any advance still outstanding when employment ends is recovered from final pay. Where law requires written consent for the deduction, Payroll Services obtains it before the advance is approved.

### 7.3 Payout

Vacation is not paid out during employment. On termination, unused earned vacation is paid in final pay in all Canadian provinces and territories and all US states. Final pay timing is set out in HR-POL-015 Resignation and Offboarding Policy.

## 8. Related paid days

- **Personal days:** 3 per calendar year, for any reason, with 24 hours' notice where possible. Minimum half day, no carryover, no payout, no certificate, pro-rated for new hires. The rules are in HR-POL-007.
- **Volunteer day:** 1 paid day per calendar year, owned by HR-POL-026 Bereavement, Jury Duty and Other Leaves Policy.
- **Floating days:** 2 Cultural and Religious Observance Days, owned by HR-POL-010.

## 9. Worked examples

### 9.1 Accrual for a new hire

A new hire in the Less than 3 years tier starts on 15 September 2026. 108 days remain in the calendar year. The pro-rated entitlement is 15 x 108 / 365 = 4.44 days, rounded up to 4.5 days. The employee may request vacation immediately and may take it from 15 December 2026, after 3 months of service.

### 9.2 Entitlement and service tier

An employee hired on 6 March 2016 has completed 9 years of service on 1 January 2026, so the 2026 entitlement is 20 days (accrual 1.67 per month). On 1 January 2027 the employee has completed 10 years and moves to 25 days.

### 9.3 Carryover

An employee with 20 days has taken 12 days by 31 December 2026, leaving 8 unused. Under this policy 5 days carry over and 3 are forfeited. If the employee uses only 2 of the carried-over days by 31 March 2027, the remaining 3 are forfeited on 1 April 2027. Under version 3.0 only 3 days would have carried over.

### 9.4 Part-time

A Canadian employee in the 3 to under 10 years tier works 3 days a week (22.5 of 37.5 hours, 60%). The annual entitlement is 20 x 60% = 12 days of 7.5 hours (90 hours).

## 10. Exceptions, consequences and contacts

Exceptions to this policy require approval of the SVP Total Rewards. Taking vacation without approval, or falsifying vacation records in Time Tracker, is a breach of attendance expectations and may lead to action under HR-POL-021 Employee Relations and Progressive Discipline Policy. Failure to take the mandatory block is escalated to the business unit head and, in audited roles, to the Chief Compliance Officer.

Questions: HR Connect, 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time, hrconnect@bank.example, or live chat in MyHR. Managers may call the Manager Hotline, 1-800-555-0143. Unpaid time away is requested on FORM-HR-010 Leave of Absence Request.

## 11. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 4.0 | 2026-01-01 | Carryover increased from 3 days to 5 days, still to be used by 31 March. Clarified block leave scheduling deadlines and escalation of unanswered requests. |
| 3.0 | 2024-01-01 | Introduced carryover of 3 days, to be used by 31 March. Added mandatory 10-day block leave audit for Capital Markets, Wealth Management and Finance. |
| 2.2 | 2022-01-01 | Previous version. Unused vacation was forfeited at year-end except where law required otherwise. |
