# Managing Director, Capital Markets

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1022 |
| Title | Managing Director, Capital Markets |
| Document type | Job description |
| Version | 2.1 |
| Status | Current |
| Effective date | 2026-01-12 |
| Last reviewed | 2026-10-05 |
| Next review | 2027-10-05 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-006, HR-FWK-001, HR-POL-029, HR-POL-031, HR-PLN-003, HR-SUP-003 |

## 1. Role summary

The Managing Director, Capital Markets is accountable for a major trading and markets business inside Capital Markets, including its revenue, risk, people and conduct. The role sets the business strategy with the Group Head, Capital Markets, allocates capital and risk appetite across desks, and represents the Bank with major institutional clients, counterparties and regulators. The Managing Director shapes the culture of the trading floor and is the senior owner of its control environment.

## 2. Key responsibilities

- Own the business plan, revenue and expense targets and return on capital for the business line.
- Set desk-level risk limits within the approved risk appetite and review utilization and breaches weekly.
- Lead the Senior Traders, heads of desks and sales leaders, and plan succession for critical roles (see HR-FWK-003 Talent Review and Succession Process).
- Build and maintain senior relationships with institutional clients, central banks, exchanges and counterparties.
- Ensure compliance with trading, conduct, personal-trading and communication-recording obligations across the business.
- Sponsor new-product and new-market proposals, and confirm operational readiness and control sign-off first.
- Partner with Risk, Finance, Compliance and Technology and Operations on business-wide priorities.
- Report results, risks and control issues to the Group Head and to senior governance committees.
- Make decisions on remuneration recommendations for the business, consistent with pay-for-performance principles.
- Represent the Bank at industry forums and in regulatory meetings as requested.

## 3. Qualifications

### 3.1 Required

- Bachelor's degree in finance, economics, mathematics or a related field.
- Typically 18 or more years of experience in capital markets, including at least 5 years leading a trading or markets business.
- A record of delivering results through market cycles while maintaining strong risk and conduct standards.
- Experience engaging with regulators and senior governance forums.

### 3.2 Preferred

- MBA or CFA designation.
- Experience across more than one region or product area.
- Bilingual English and French.

### 3.3 Licences and certifications

HR-POL-029 Licensing, Registration and Qualification Policy requires the supervisory securities registration for Canada and, in the US, the Series 7 and Series 63 examinations together with any other Series registration the role needs (Series 6, 65 or 66). The Bank pays the related exam, licence and registration fees. The role is a covered position for personal trading under HR-POL-032 Personal Trading and Restricted Lists Policy.

## 4. Competencies

Measured against HR-FWK-001 Competency and Leadership Model at the Enterprise Leader level:

- Judgement and Decision Quality
- Risk and Conduct Awareness
- Drive for Results
- Inclusive Leadership
- Developing Others
- Collaboration
- Adaptability

## 5. Compensation and classification

| Item | Value |
| --- | --- |
| Band | 9 (Senior Vice President) |
| Canada range | $240,000 to $360,000 CAD |
| US range | $235,000 to $355,000 USD |
| Incentive target | 45% of base salary (Annual Incentive Plan) |
| Overtime eligibility, Canada | No |
| FLSA classification, US | Exempt |
| Work arrangement | On-site (trading floor) |

Band 9 roles are subject to deferral of 50% of an Annual Incentive Plan payout above $100,000 and to clawback under HR-POL-031 Incentive Deferral and Clawback Policy, and are eligible for the Long-Term Incentive Plan at 100% of base salary (HR-PLN-003 Long-Term Incentive Plan Document). Band definitions are in HR-GDE-006 Job Architecture and Pay Bands Guide.

## 6. Working conditions and accessibility

This is an on-site role on the Capital Markets trading floor, with regular travel to clients and to Bank offices in Canada and the US under HR-POL-038 Business Travel and Expense Policy. The role is subject to the block leave audit and fiscal year-end vacation blackout in HR-SUP-003 Capital Markets Addendum. The Bank provides accommodation to the point of undue hardship; see HR-POL-018 Workplace Accommodation and Accessibility Policy.

## 7. Reporting line

Reports to: Group Head, Capital Markets. Direct reports: Senior Traders, heads of desks and sales leaders.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.1 | 2026-01-12 | Pay range wording aligned with pay transparency policy |
| 2.0 | 2025-03-01 | Added deferral, clawback and long-term incentive references |
| 1.0 | 2023-09-01 | First issue |
