# Electronic Monitoring and Right to Disconnect Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-033 |
| Title | Electronic Monitoring and Right to Disconnect Policy |
| Document type | Policy |
| Version | 2.0 |
| Status | Current |
| Effective date | 2025-11-01 |
| Last reviewed | 2026-09-08 |
| Next review | 2027-09-08 |
| Policy owner | Chief Information Security Officer |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-016, HR-POL-017, HR-POL-003, HR-POL-021, HR-POL-002, FORM-HR-129 |

## 1. Purpose

This policy tells employees exactly how the Bank monitors its systems, devices and premises, why it does so, who may see the results and how long they are kept. It also sets the Bank's right-to-disconnect rules, so that employees are not expected to answer work messages outside their working hours. Monitoring is disclosed, proportionate and never covert. Where applicable law gives a greater right, the law applies.

## 2. Scope

The policy applies to all employees in Canada and the US, and to contractors, agency workers, students and interns who use Bank systems, networks, devices or premises. The right-to-disconnect rules apply to employees only. Quebec employees receive this policy in French by default or on request. Monitoring of customers is outside this policy.

## 3. Definitions

| Term | Meaning |
| --- | --- |
| Electronic monitoring | Any technology the Bank uses to observe, record or analyse the use of Bank systems, devices, premises or communications by individuals. |
| Working hours | The hours in an employee's schedule (see HR-POL-003 Working Hours and Overtime Policy). Core hours for office-based staff are 10:00 to 15:00 local time. |
| Right to disconnect | The right not to be expected to read or answer work messages, calls or tasks outside working hours, except when on call. |
| On call | A period for which an employee is formally assigned to respond and receives the on-call allowance. |
| Urgent | An operational, security, client or market matter that cannot reasonably wait until the next working day. |
| Monitoring data | Logs, recordings and other records produced by the monitoring in section 5. |
| DPIA | Data Protection Impact Assessment (FORM-HR-092). |

## 4. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Chief Information Security Officer (CISO) | Owns this policy; approves monitoring tools with the Chief Privacy Officer; reports on monitoring annually to the HR Policy Committee. |
| Security Operations Centre (SOC) and Corporate Security | Operate the monitoring controls and access monitoring data only with a documented reason. |
| Chief Compliance Officer | Accesses communications and recordings for regulatory supervision and surveillance. |
| Chief Privacy Officer and Privacy Office | Approve every HR request for monitoring data; review the DPIA for each monitoring programme. |
| HR Operations | Issues this policy to new hires and to all employees after a change; keeps the FORM-HR-129 records. |
| Managers | Respect the right to disconnect, schedule meetings within the allowed window, and never ask for monitoring data directly. |
| Employees | Read the policy, acknowledge it on FORM-HR-129, and raise concerns promptly. |

## 5. Electronic monitoring

### 5.1 What the Bank monitors

| Monitoring | What it covers | Where it applies |
| --- | --- | --- |
| Email and messaging scanning | Automated scanning for malware, data loss and conduct risk | All Bank email and approved messaging tools |
| Web filtering | Blocking of unsafe or prohibited sites and logging of access | Bank networks and VPN |
| Endpoint security | Malware detection, device configuration and software inventory | Bank-issued devices and enrolled phones |
| Data-loss prevention | Detection of Confidential or Restricted data leaving approved locations | Email, web, removable media attempts |
| Badge and building access | Entry and exit records | Bank premises |
| Recorded telephone lines | Calls on recorded lines, announced at the start of the call | Branches, the contact centre and trading |
| VPN and application logs | Log-in times, locations, access to applications and records | Remote and on-site access |
| Vehicle telematics | Location and driving data | Fleet vehicles only |

### 5.2 What the Bank does not do

- No covert monitoring of any kind.
- No keystroke logging or screen capture to score productivity.
- No webcam or microphone monitoring in an employee's home.
- No tracking of personal devices beyond the mobile device management container described in HR-POL-017 IT Acceptable Use and Information Security Policy.
- No use of vehicle telematics for any vehicle other than a Bank fleet vehicle.

### 5.3 Purposes

Monitoring is used only for security, regulatory compliance, fraud prevention and safety. It is not used for routine performance management. Any new purpose requires a PIA (FORM-HR-091) and a DPIA (FORM-HR-092) under HR-POL-016 Employee Data Privacy Policy before it starts.

### 5.4 Access to monitoring data

Security and Compliance staff may open monitoring data only with a documented reason recorded in the access log. Requests from HR or from a manager need the written approval of the Privacy Office. For an investigation, HR-POL-017 also requires the approval of the VP Employee Relations and the Chief Privacy Officer. The Privacy Office decides a request within 5 business days, or within 1 business day if there is a safety risk. Access logs are reviewed quarterly.

### 5.5 Retention

| Data | Retention |
| --- | --- |
| Monitoring logs (email scanning, web, endpoint, badge, VPN, application, telematics) | 13 months |
| Call recordings, Capital Markets and Wealth Management | 7 years |
| Other call recordings (branches and contact centre) | 13 months |
| Data held for an open investigation or under a legal hold | Until released by Legal |

HR-REF-002 Employee Records Retention Schedule does not list monitoring logs or call recordings, and it keeps unlisted record types for 7 years unless the Privacy Office sets a different period in writing; the periods in the table above are those different periods and apply to monitoring data. Other records follow HR-REF-002.

## 6. Notice and acknowledgement

1. New hires receive this policy within 30 days of the start date, with the other onboarding documents (see HR-GDE-003 New Employee Onboarding Guide).
2. Every employee receives the updated policy within 30 days of any change. Where practicable, a new monitoring measure is announced at least 30 days before it starts.
3. Employees confirm they have read the policy by signing FORM-HR-129 Electronic Monitoring Acknowledgement in MyHR within the same 30-day period. Signing confirms that the employee has been told about the monitoring; it is not consent to anything beyond this policy.
4. Employees may ask to see personal information held about them, including monitoring data, using FORM-HR-090. The Privacy Office responds within 30 days.

## 7. Right to disconnect

### 7.1 The rule

An employee is not expected to read or answer messages, calls or tasks outside their working hours, and there is no penalty, in ratings, incentive, scheduling or discipline, for not responding. This applies to email, chat, text and phone. The only exception is an employee who is on call.

### 7.2 Meetings

Schedule meetings between 08:00 and 18:00 local time for every attendee, unless the matter is urgent. Where attendees are in different time zones, the organizer uses the local time of each attendee. The organizer of an urgent meeting outside this window records why in the invitation and gives as much notice as possible.

### 7.3 On call

On-call duty follows HR-POL-003 Working Hours and Overtime Policy: the allowance is $200 CAD or $150 USD per week and the call-out minimum is 3 hours' pay at the applicable rate. An on-call employee must respond within the response time in the on-call schedule.

### 7.4 Overtime-eligible employees

An overtime-eligible or non-exempt employee who agrees to respond to an urgent request outside working hours records that time in Time Tracker, and it is paid under HR-POL-003.

### 7.5 Leave and vacation

Managers do not contact employees on vacation, sick leave or other leave, except to arrange an emergency, and then only by one short message to the contact method the employee has chosen. Reporting a security incident to the SOC (HR-POL-017) is always permitted and is not a work message for this purpose.

## 8. Procedures and deadlines

| Step | Who | Deadline |
| --- | --- | --- |
| Issue the policy to a new hire | HR Operations | Within 30 days of the start date |
| Issue the updated policy after a change | HR Operations | Within 30 days of the change |
| Sign FORM-HR-129 | Employee | Within 30 days of receiving the policy |
| Approve or refuse an HR request for monitoring data | Privacy Office | 5 business days (1 business day for a safety risk) |
| Complete a PIA and DPIA for a new monitoring programme | System owner with the Privacy Office | PIA review within 15 business days; DPIA decision within 30 days |
| Respond to a concern about monitoring or disconnect | Privacy Office or HR Operations | Acknowledge within 2 business days |

## 9. Exceptions

- A monitoring measure not listed in section 5.1 may be used only after a DPIA is approved by the Privacy Governance Committee, and the employee notice is updated first.
- In an active security incident the CISO may extend logging temporarily within the categories in section 5.1, and records the reason and the end date.
- An urgent meeting outside 08:00 to 18:00 needs the organizer's manager to agree in advance.
- Local law may require different notice. The Privacy Office confirms the rule with Legal.

## 10. Worked examples

**A late message.** A manager sends a chat message at 21:40. The employee, who is not on call, reads it at 08:10 the next day and replies at 09:00. This is correct. The manager may not mention the timing in a performance conversation.

**A cross-time-zone meeting.** A team has members in Toronto (Eastern Time) and Vancouver (Pacific Time). The window of 08:00 to 18:00 local time for both locations is 11:00 to 18:00 Eastern, which is 08:00 to 15:00 Pacific. A 14:00 Eastern meeting fits. A 09:00 Eastern meeting does not (06:00 Pacific), unless the matter is urgent and the organizer records why.

**A request for browsing history.** A Director believes an employee is slow and asks Security for the employee's web history. Security refuses: performance is not a permitted purpose. If the Director suspects misconduct, the Director goes to the HRBP; an investigation may use monitoring data only with the approvals in section 5.4.

## 11. Consequences

Misuse of monitoring data, including looking at it without a documented reason, sharing it, or using it for a purpose not allowed here, is serious misconduct under HR-POL-021 Employee Relations and Progressive Discipline Policy and may lead to termination. A manager who penalizes an employee for not responding outside working hours, or who retaliates against someone who raised a concern, is in breach of this policy and of HR-POL-001 Code of Conduct and Ethics. An employee who disables or bypasses a monitoring control is subject to HR-POL-017.

## 12. Raising a concern

Employees may raise a concern with the Privacy Office (privacy@bank.example), HR Connect, the Ombuds Office (ombuds@bank.example) for confidential informal advice, or the Speak-Up Line (1-800-555-0177). Reports made in good faith are protected from retaliation.

## 13. Related documents

- HR-POL-016 Employee Data Privacy Policy
- HR-POL-017 IT Acceptable Use and Information Security Policy
- HR-POL-003 Working Hours and Overtime Policy
- HR-POL-002 Remote and Hybrid Work Policy
- HR-POL-021 Employee Relations and Progressive Discipline Policy
- FORM-HR-129 Electronic Monitoring Acknowledgement; FORM-HR-090, FORM-HR-091 and FORM-HR-092

## 14. Contacts

| Need | Contact |
| --- | --- |
| Questions about this policy | HR Connect, 1-800-555-0142, hrconnect@bank.example (Monday to Friday 8:00 to 20:00 Eastern Time) |
| Privacy and monitoring data | privacy@bank.example |
| Security incident or lost device | Security Operations Centre, 1-800-555-0155, soc@bank.example (24/7) |
| Managers | Manager Hotline, 1-800-555-0143 |

## 15. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2025-11-01 | Added the right-to-disconnect rules, the list of disclosed monitoring, the retention periods and the 30-day notice and acknowledgement process (FORM-HR-129). |
| 1.0 | 2022-04-01 | First issue of the electronic monitoring notice. |
