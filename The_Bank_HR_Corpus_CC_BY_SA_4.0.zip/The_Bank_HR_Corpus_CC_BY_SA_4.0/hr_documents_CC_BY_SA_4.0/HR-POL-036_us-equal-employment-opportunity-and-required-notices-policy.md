# US Equal Employment Opportunity and Required Notices Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-036 |
| Title | US Equal Employment Opportunity and Required Notices Policy |
| Document type | Policy |
| Version | 3.1 |
| Status | Current |
| Effective date | 2025-07-01 |
| Last reviewed | 2026-08-04 |
| Next review | 2027-08-04 |
| Policy owner | VP Employee Relations |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | Employees |
| Jurisdiction | US |
| Language | English |
| Related documents | HR-POL-018, HR-POL-008, HR-POL-005, HR-SUP-002, HR-GDE-003, HR-PRC-006 |

## 1. Purpose

This policy states the Bank's commitment to equal employment opportunity in the US and sets out the notices the Bank must give and display, the timelines for family and medical leave notices, and how employees raise concerns. It explains who must do what and by when. Where applicable law gives a greater right, the law applies.

## 2. Scope

The policy applies to all employees and applicants in the US, in every state, and to every employment decision: recruitment, hiring, pay, benefits, assignments, training, discipline, leave, accommodation and termination. Promotions and transfers are handled separately. Employees in Canada are covered by HR-POL-034 Employment Equity and Pay Equity Policy. State and local supplements add rules for particular locations; for California see HR-SUP-002 California Supplement.

## 3. Definitions

| Term | Meaning |
| --- | --- |
| Equal employment opportunity (EEO) | Employment decisions are made without discrimination on a protected characteristic. |
| Protected characteristic | A characteristic protected by federal, state or local law, for example race, colour, religion, sex (including pregnancy, sexual orientation and gender identity), national origin, age, disability, genetic information and military or veteran status. |
| Required notices | The posters and written notices that law requires the Bank to display or give to employees. |
| FMLA | The Family and Medical Leave Act. |
| Eligibility notice | The written notice telling an employee whether they are eligible for FMLA leave. |
| Designation notice | The written notice confirming whether leave is designated as FMLA leave. |
| Certification | A health care provider's statement of the need for leave for a serious health condition. |
| Interactive process | The conversation between the employee and the Bank to find a reasonable accommodation (see HR-POL-018 Workplace Accommodation and Accessibility Policy). |
| Retaliation | Adverse treatment of someone for raising a concern, taking part in an investigation, requesting accommodation or taking leave. |

## 4. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| VP Employee Relations | Owns this policy; decides serious complaints with Legal; reports to the HR Policy Committee annually. |
| Leaves team (HR Operations) | Issues FMLA notices and tracks the timelines. |
| Accommodation Specialist | Leads the interactive process. |
| HR Operations | Orders, posts and refreshes required notices; keeps the Form I-9 process (see HR-GDE-003 New Employee Onboarding Guide). |
| Branch managers | Keep the required postings visible and report any missing or damaged poster to HR Operations the same business day. |
| Managers | Pass any request for leave or accommodation to HR the same business day; do not retaliate. |
| Legal | Advises on federal, state and local requirements. |
| Employees | Raise concerns promptly, provide requested certification on time and treat colleagues with respect. |

## 5. Equal employment opportunity statement

The Bank is an equal opportunity employer. It does not discriminate against, harass or retaliate against any employee or applicant because of a protected characteristic. Decisions are based on skills, experience, performance and the Bank's values. The Bank provides reasonable accommodation unless it would cause undue hardship (see HR-POL-018), and complies with state and local laws that give greater protection. Harassment is also covered by HR-POL-005 Workplace Harassment and Violence Prevention Policy. Self-identification for EEO reporting is voluntary and is used only in aggregate (see HR-POL-024 Diversity, Equity, Inclusion and Belonging Policy).

## 6. Required notices

### 6.1 What must be posted

| Notice | Where posted |
| --- | --- |
| Federal EEO notice | Every branch and office; MyHR |
| FMLA notice | Every branch and office; MyHR |
| ADA and accommodation notice | Every branch and office; MyHR |
| Wage and hour notices (minimum wage, overtime and other state or federal pay rules) | Every branch and office; MyHR |
| Workers' compensation notice, with the claim contact | Every branch and office; MyHR |
| Other state and local notices | The relevant location and the state page in MyHR |

Postings must be in a place that employees and applicants can see easily, and are replaced when the law or the form changes. Employees who work remotely see the same notices in MyHR. Notices are available in an accessible format on request (see HR-POL-018).

### 6.2 Maintaining the notices

HR Operations checks every posting each quarter and refreshes the set within 10 business days of a legal change. Branch managers confirm each quarter, in writing to HR Operations, that all notices are in place. Missing notices are replaced within 2 business days of the report.

## 7. Family and medical leave notices

FMLA leave is described in HR-POL-008 Parental and Family Leave Policy. An employee is eligible with 12 months of service, 1,250 hours worked in the previous 12 months and 50 employees within 75 miles of the work location. The following notice timelines apply.

| Step | Who | Timeline |
| --- | --- | --- |
| Employee tells the manager or the Leaves team that a leave may be needed | Employee | As soon as practicable |
| Eligibility notice | Leaves team | Within 5 business days of learning that a leave may qualify |
| Request for certification | Leaves team | With the eligibility notice |
| Return of certification | Employee | Within 15 calendar days of the request |
| Designation notice | Leaves team | Within 5 business days of having enough information |
| Extension if the employee cannot meet the deadline despite diligent effort | Employee asks the Leaves team before the deadline | The Leaves team replies within 2 business days |

Certification contains only the facts law allows the Bank to ask for. Medical information is kept separately from the personnel file (see HR-POL-016 Employee Data Privacy Policy). Bank-paid parental leave and short-term disability may run at the same time as FMLA leave, and the Leaves team confirms the sequence in writing. State paid family leave programmes and state notice requirements also apply. Administrative steps are in HR-PRC-006 Leaves Administration Procedure.

## 8. Accommodation and the interactive process

A request for accommodation does not need to use a special word or form. The employee or the manager tells the Accommodation Specialist or accommodations@bank.example, and HR-POL-018 sets the timelines: acknowledgement within 2 business days and a decision within 10 business days of complete information, or 3 business days in urgent cases. The Pregnant Workers Fairness Act and state laws also apply and the more protective rule is used.

## 9. Employment eligibility verification

New hires complete Form I-9 within 3 business days of the start date (see HR-GDE-003). HR reviews the original documents in person or by an authorized representative. The Bank accepts any valid combination of documents the form allows and never specifies which documents an employee must present. Form I-9 is kept for 3 years after hire or 1 year after termination, whichever is later (see HR-REF-002 Employee Records Retention Schedule).

## 10. Raising a concern and protection from retaliation

Employees and applicants may raise a concern about discrimination, harassment, retaliation, a missing notice or an FMLA or accommodation problem with their manager, HRBP, HR Connect, the designated recipient in Employee Relations, the Ombuds Office (ombuds@bank.example) or the Speak-Up Line (1-800-555-0177, anonymous option). Employee Relations acknowledges a concern within 2 business days and starts interim measures within 5 business days where needed. Employees may also contact the federal EEO agency or a state or local agency at any time. Time limits for external complaints apply and HR can explain them on request.

Retaliation is prohibited and is itself a ground for discipline. Employees are protected when they raise a concern in good faith, take part in an investigation, request accommodation or take leave.

## 11. Exceptions

- Where a state or local law sets a different notice period or poster, the stricter rule applies.
- The Leaves team may extend the certification deadline once, for up to 7 calendar days, where the employee shows diligent effort.
- A branch temporarily closed for severe weather or an emergency is exempt from the quarterly posting confirmation for that quarter, and confirms within 5 business days of reopening.

## 12. Worked examples

**An FMLA request.** An employee in New Jersey tells her manager on Monday 2 March 2026 that she needs surgery in April. The manager informs the Leaves team the same day. The eligibility notice and certification request are due by Monday 9 March (5 business days). The employee has 15 calendar days from the request, so the certification is due by Tuesday 24 March. She returns it on Friday 20 March, and the designation notice is due within 5 business days, by Friday 27 March.

**A new hire.** An employee in Florida starts on Monday 1 June 2026. The employee completes Form I-9 with HR by Thursday 4 June (3 business days after the start date).

**A missing poster.** A branch manager notices that the wage and hour notice is missing on 14 July. The manager reports it to HR Operations that day. The replacement is due within 2 business days, by 16 July.

## 13. Consequences

Discrimination, harassment, retaliation, failure to pass on a leave or accommodation request, or failure to meet a notice deadline may lead to corrective action up to termination under HR-POL-021 Employee Relations and Progressive Discipline Policy. Managers are accountable for notices in their location.

## 14. Related documents

- HR-POL-018 Workplace Accommodation and Accessibility Policy
- HR-POL-008 Parental and Family Leave Policy
- HR-POL-005 Workplace Harassment and Violence Prevention Policy
- HR-POL-024 Diversity, Equity, Inclusion and Belonging Policy
- HR-SUP-002 California Supplement
- HR-GDE-003 New Employee Onboarding Guide
- HR-PRC-006 Leaves Administration Procedure

## 15. Contacts

| Need | Contact |
| --- | --- |
| Questions and leave notices | HR Connect, 1-800-555-0142, hrconnect@bank.example (Monday to Friday 8:00 to 20:00 Eastern Time) |
| Accommodation | accommodations@bank.example |
| Confidential informal advice | Ombuds Office, ombuds@bank.example |
| Anonymous reports | Speak-Up Line, 1-800-555-0177 (24 hours, 7 days) |

## 16. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 3.1 | 2025-07-01 | Set the 5-business-day timelines for eligibility and designation notices and the 15-calendar-day certification period. |
| 3.0 | 2024-01-01 | Added the quarterly posting confirmation and the remote-employee notice page in MyHR. |
