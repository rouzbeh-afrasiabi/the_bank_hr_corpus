# Substance Use and Fitness for Work Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-041 |
| Title | Substance Use and Fitness for Work Policy |
| Document type | Policy |
| Version | 2.2 |
| Status | Current |
| Effective date | 2025-05-01 |
| Last reviewed | 2026-06-02 |
| Next review | 2027-06-02 |
| Policy owner | Head of Workplace Safety |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-007, HR-POL-018, HR-POL-021, HR-POL-023, HR-POL-016, FORM-HR-130 |

## 1. Purpose

The Bank wants every employee to be able to work safely and to deal with customers, money and information with a clear mind. This policy sets the standard of fitness for work, explains what is and is not allowed in relation to alcohol, cannabis and other drugs, and describes how the Bank supports employees who have a dependency or other health issue. It treats substance use first as a health matter and applies discipline only where the standard is breached and no support route has been used. Where applicable law gives a greater right, the law applies.

## 2. Scope

The policy applies to all employees in Canada and the US while at work, on Bank premises, working from home, travelling for the Bank, driving a Bank vehicle, or attending a Bank-sponsored event. It applies at every band. Contractors and agency workers follow the standard of the site they work at and may be removed from site if they breach it.

## 3. Definitions

- **Impaired:** an employee's ability to work safely, to exercise judgement or to deal with customers is affected by alcohol, cannabis, an illegal drug, a prescription or over-the-counter medication, or any other substance.
- **Fit for work:** able to perform the duties of the role safely and effectively.
- **Safety-sensitive duties:** duties where impairment creates a serious risk of harm to the employee or others, for example driving a Bank vehicle, operating machinery or handling large cash movements alone.
- **Reasonable grounds:** specific, observable and documented signs that an employee may be impaired (see section 7).
- **Dependency:** a medical condition, including alcohol or drug dependency, recognized as a disability in law.
- **Wellspring Support Program:** the free, confidential employee and family assistance program, 1-800-555-0166, available 24 hours a day, 7 days a week.

## 4. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Employee | Reports for work fit; tells the manager if a medication affects safety (functional limits only); asks for help early |
| Manager | Watches for signs of impairment; acts on reasonable grounds; keeps the employee safe; reports to the HRBP the same business day |
| HRBP | Advises the manager, arranges support, keeps records confidential |
| Accommodation Specialist | Coordinates accommodation and graduated return under HR-POL-018 |
| Leaves team | Handles treatment leave under HR-POL-007 |
| VP Employee Relations | Approves any testing on reasonable grounds (section 7) |
| Head of Workplace Safety | Owns this policy and identifies safety-sensitive duties |
| Corporate Security | Assists in emergencies and with safe transport (1-800-555-0119, 24/7) |

## 5. The standard

### 5.1 Working impaired

No employee may work, or be at work, while impaired by alcohol, cannabis or any other drug. This includes prescription and over-the-counter medication that affects safety, and applies to legal substances (for example cannabis where the law permits it) in the same way as to illegal ones.

### 5.2 Possession and use at work

Possession, sale, sharing or use of drugs, including cannabis, on Bank premises, in Bank vehicles or while on duty is not allowed. The only exception is **moderate alcohol at an event approved by the business unit head**. At such events:

- attendance and drinking are always voluntary;
- non-alcoholic choices are always offered;
- managers must not pressure anyone to drink or comment on who does not;
- no one who has been drinking drives a Bank vehicle, and the organizer arranges safe transport;
- the Code of Conduct and the workplace harassment rules still apply.

### 5.3 Medication

Employees who take prescribed or over-the-counter medication that may affect their ability to work safely tell their manager **only that they have a limitation**, not the diagnosis or the medication. The manager may ask what adjustment is needed (for example, no driving), arranges it and keeps the information confidential. The employee may also go to the Accommodation Specialist directly. Using medication as prescribed is not a breach. Cannabis used as medicine is treated the same way, and the employee must still not be impaired at work.

## 6. No random testing

The Bank does **not** use random drug or alcohol testing. Testing is limited to the situations in section 7.

## 7. Reasonable grounds and testing

### 7.1 Reasonable grounds

A manager may act when there are observable signs such as slurred speech, the smell of alcohol or cannabis, unsteadiness, unusual behaviour, or an incident or near miss. Appearance, absence, or a medical condition alone is not reasonable grounds, and a manager must never guess at a diagnosis.

### 7.2 Immediate steps

1. The manager takes the employee to a private place and, where possible, has a second leader or the HRBP present as a witness.
2. The manager describes what was seen, listens to the employee's explanation and offers the employee a chance to say whether a medication or a medical condition is involved.
3. If the manager still has reasonable grounds, the manager tells the employee they cannot work for the rest of the shift.
4. The manager arranges **safe transport home**: a taxi or ride arranged and paid by the Bank, or a trusted person. **The employee is never allowed to drive.** If the employee refuses or the situation is unsafe, the manager calls Corporate Security, and 911 if there is danger.
5. The manager makes a written record of the signs on the same day.
6. The manager **reports to the HRBP the same business day**.

### 7.3 Testing

A test may be requested only for safety-sensitive duties, only on reasonable grounds, and only after the **VP Employee Relations approves** it in writing. Testing is done by a qualified third party and is limited to what is needed to show impairment now. Employees are told why, are offered a support person, and the result is held by the HRBP and not placed in the general personnel file (see HR-POL-016 Employee Data Privacy Policy). A refusal is not treated as an admission, but the employee remains unfit for safety-sensitive duties until fitness is shown.

## 8. Support and accommodation

An employee who tells the Bank about a dependency or a substance-related issue **before** any breach of this policy receives support, not discipline. The support includes:

- referral to the Wellspring Support Program (up to 8 counselling sessions per issue per calendar year for the employee and household members, free of charge);
- treatment leave using sick days and short-term disability as set out in HR-POL-007 Sick Leave and Personal Leave Policy, with a medical certificate on FORM-HR-011 stating only fitness and limits;
- accommodation to the point of undue hardship under HR-POL-018 Workplace Accommodation and Accessibility Policy, such as a schedule change for treatment, temporary non-safety-sensitive duties or a different location;
- a graduated return to work of up to 12 weeks.

The employee, or a manager with the employee's agreement, requests this support using FORM-HR-130 Fitness-for-Work Support Request, or by contacting HR Connect or the HRBP. HR acknowledges within 2 business days and the Accommodation Specialist makes contact within 5 business days. A dependency does not protect an employee from consequences for a serious breach of safety, but it is always considered.

## 9. Confidentiality

Information about substance use, treatment or testing is confidential. It is shared only with those who need it to arrange safety, support or accommodation, and is held with the other medical and accommodation records, not the general personnel file. Managers receive only functional limitations and expected duration. Colleagues are not told the reason for an absence.

## 10. Consequences

A **first positive screen does not in itself lead to termination.** The Bank first looks at the facts, any dependency, the duties the employee performs and the support available. Breaches are managed under HR-POL-021 Employee Relations and Progressive Discipline Policy, with ER involvement before any written warning. Serious breaches, such as driving a Bank vehicle while impaired, endangering others, or selling drugs on Bank premises, may skip steps. An employee who accepts a support plan and keeps to it is considered under the plan, not disciplined for the same incident. Retaliation against anyone for asking for help or reporting concerns is prohibited.

## 11. Worked examples

**Example 1: self-disclosure.** An employee tells her HRBP that she is struggling with alcohol and has not been impaired at work. The HRBP refers her to the Wellspring Support Program, she takes 4 weeks of sick days and short-term disability for treatment, and returns on a graduated schedule of up to 12 weeks. There is no discipline.

**Example 2: reasonable grounds.** A manager in an operations centre notices that a driver of a Bank vehicle smells of alcohol and is unsteady. He takes her to a private room with a second leader, records what he saw, arranges a ride home, reports to the HRBP the same business day and asks the VP Employee Relations whether to approve testing. She does not drive.

**Example 3: medication.** An employee starts a medication that makes him drowsy. He tells his manager only that he must not drive for two weeks. The manager moves his Bank-vehicle duties to a colleague, and no further information is asked.

**Example 4: office event.** A business unit holds an approved dinner with wine. Staff may choose not to drink, and the manager arranges safe rides for everyone who drinks.

## 12. Exceptions

There are no exceptions to the rule against working impaired. The Head of Workplace Safety may approve alcohol at a site event only through the business unit head's approval under section 5.2.

## 13. Related documents and contacts

Related: HR-POL-007 Sick Leave and Personal Leave Policy; HR-POL-018 Workplace Accommodation and Accessibility Policy; HR-POL-021 Employee Relations and Progressive Discipline Policy; HR-POL-023 Workplace Health, Safety and Wellness Policy; HR-POL-016 Employee Data Privacy Policy; FORM-HR-130 Fitness-for-Work Support Request. Contacts: Wellspring Support Program 1-800-555-0166 (24/7, confidential); HR Connect 1-800-555-0142 (Monday to Friday 8:00 to 20:00 Eastern Time), hrconnect@bank.example; Manager Hotline 1-800-555-0143; Corporate Security 1-800-555-0119 (24/7). In an emergency call 911 first.

## 14. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2023-05-01 | Replaced the previous alcohol and drug rule with a health-first fitness-for-work approach and ended random testing |
| 2.1 | 2024-05-01 | Added the reasonable-grounds procedure and VP Employee Relations approval for testing |
| 2.2 | 2025-05-01 | Added FORM-HR-130, the same-business-day report to the HRBP and the rule that a first positive screen does not in itself lead to termination |
