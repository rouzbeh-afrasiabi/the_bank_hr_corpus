# HR Service and Support Guide

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-GDE-004 |
| Title | HR Service and Support Guide |
| Document type | Guide |
| Version | 2.5 |
| Status | Current |
| Effective date | 2026-03-16 |
| Last reviewed | 2026-09-29 |
| Next review | 2027-09-29 |
| Policy owner | VP HR Operations |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Applies to | All Canadian and US employees and people managers (see Scope) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-010, HR-POL-016, HR-POL-018, HR-GDE-003, HR-GDE-005, HR-REF-001, HR-REF-002, HR-FAQ-001 |

## 1. Purpose

This guide explains how employees and managers get help from Human Resources: whom to contact, through which channel, how quickly to expect a response, how to escalate if a service level is missed, and which form to use for each request. It is the single owner of the HR service levels and of the catalogue of HR forms.

## 2. Scope

The guide applies to all employees in Canada and the US, including part-time, casual and fixed-term employees, and to people managers. Contractors and agency workers use their engagement contact and do not use HR Connect except for the Code of Conduct, IT acceptable use and mandatory training. Where applicable law gives a greater right, the law applies.

## 3. Contact directory

| Need | Contact | Hours |
| --- | --- | --- |
| General HR questions, pay, benefits, leave | HR Connect: 1-800-555-0142, hrconnect@bank.example, live chat in MyHR | Monday to Friday 8:00 to 20:00 Eastern Time; closed on Bank holidays |
| Manager questions | Manager Hotline: 1-800-555-0143 (managers only) | Same hours; response within 4 business hours |
| Ethical concerns and misconduct, anonymous option | Speak-Up Line (operated by Clearline): 1-800-555-0177, ethics@bank.example, Speak-Up page in MyHR | 24 hours a day, 7 days a week |
| Personal safety and workplace violence | 911 first, then Corporate Security: 1-800-555-0119 | 24/7 |
| IT and information security incidents | Security Operations Centre: 1-800-555-0155, soc@bank.example | 24/7 |
| Privacy questions, breaches and access requests | Privacy Office: privacy@bank.example | Business hours; breaches reported immediately |
| Accessibility feedback | Accessibility Office: accessibility@bank.example | Business hours |
| Accommodation requests | accommodations@bank.example, or HR Connect | Business hours |
| Informal, confidential, independent advice | Ombuds Office: ombuds@bank.example | Business hours |
| Counselling and support | Wellspring Support Program: 1-800-555-0166 (up to 8 sessions per issue per calendar year, free, for employees and household members) | 24/7, confidential |
| Retirement and savings accounts | Evergreen Retirement Services: 1-800-555-0188 | Per vendor hours |
| Insurance claims | Maplewood Benefits claims line: 1-800-555-0190 | Per vendor hours |

## 4. Service channels

### 4.1 MyHR self-service

MyHR is the employee and manager self-service portal. Employees update personal details, view pay statements (available 2 business days before the pay date), enrol in benefits, request vacation, access tax slips and start HR cases. Managers approve time, vacation and many requests in MyHR.

### 4.2 HR Connect

HR Connect is the Tier 1 contact centre. Agents answer by phone, live chat and email in English and French, and arrange an interpreter on request. HR Connect resolves most simple questions at first contact and creates a case when a specialist is needed.

### 4.3 HR Case Portal

The HR Case Portal, inside MyHR, is the preferred channel for anything that needs tracking, attachments or a decision. Every case receives a number and a priority.

### 4.4 Manager Hotline

The Manager Hotline connects people managers to advisers for situations such as attendance, performance, leave and conduct. A response is given within 4 business hours. The hotline gives guidance; decisions on discipline and termination remain with the manager, HRBP and Employee Relations (see HR-GDE-005 Manager's HR Procedures Guide).

### 4.5 HR Business Partners

Each business unit (Retail Banking, Commercial Banking, Wealth Management, Capital Markets, Technology and Operations, Corporate Functions) has an HR Business Partner (HRBP) who supports leaders on workforce matters, organizational change and escalated employee issues.

### 4.6 After hours and urgent matters

Outside HR Connect hours, employees should use the HR Case Portal for non-urgent matters, the Speak-Up Line for conduct concerns, Corporate Security for personal safety and the Security Operations Centre for lost devices or cyber incidents. A pay emergency raised after hours is logged in the HR Case Portal and the 4-business-hour clock starts when HR Connect next opens.

## 5. Priorities, service levels and tiers

### 5.1 Priority levels

| Priority | Definition | First response |
| --- | --- | --- |
| P1 Urgent | Missed pay, safety, harassment, lockout from pay or benefits | Within 4 business hours |
| P2 High | Time-sensitive matter with a deadline, such as a leave starting soon or a benefits enrolment cut-off | 1 business day |
| P3 Standard | Routine requests, corrections and questions needing research | 2 business days |
| P4 Low / information | General information, document requests and suggestions | 3 business days |

### 5.2 Tiers and resolution targets

| Tier | Who | Handles | Target |
| --- | --- | --- | --- |
| Tier 1 | HR Connect agent | First contact, simple questions, case creation, password and MyHR access help | Resolved at first contact where possible |
| Tier 2 | Specialist teams: Payroll Services, Benefits Administration, Leaves, Total Rewards, HR Operations | Transactions and technical questions | P3 resolution target 5 business days |
| Tier 3 | HRBP, Employee Relations, Legal, Privacy Office | Complex, sensitive, legal or conduct matters | 10 business days |

The first-response times in the priority table run in business days and hours, excluding Bank holidays and weekends. A case that changes priority restarts its clock from the time of the change.

## 6. Who handles what

| Topic | First contact | Handled by (tier) | Owning document |
| --- | --- | --- | --- |
| Missed or incorrect pay, direct deposit, tax withholding | HR Connect | Payroll Services (Tier 2) | HR-POL-009 |
| Benefits enrolment, claims, qualifying life events | HR Connect | Benefits Administration (Tier 2); Maplewood Benefits for claims | HR-GDE-001 |
| Pension and savings | HR Connect | Evergreen Retirement Services and Benefits Administration | HR-GDE-002 |
| Parental, medical and personal leaves, short-term and long-term disability | HR Connect | Leaves team (Tier 2) | HR-POL-007, HR-POL-008 |
| Vacation and attendance questions | Manager, HR Connect | HR Operations (Tier 2) | HR-POL-006, HR-POL-004 |
| Hybrid and remote work, temporary work from elsewhere | Manager | HR Operations; HRBP for exceptions | HR-POL-002 |
| Performance ratings disputes and improvement plans | Manager, HRBP | HRBP (Tier 3) | HR-POL-011, HR-POL-013 |
| Harassment, discipline and terminations | HRBP, Speak-Up Line | Employee Relations (Tier 3) | HR-POL-005, HR-POL-021, HR-POL-025 |
| Accommodation | accommodations@bank.example | Accommodation Specialist | HR-POL-018 |
| Privacy requests and breaches | privacy@bank.example | Privacy Office (Tier 3) | HR-POL-016 |
| Job offers, onboarding | Recruiter, HR Connect | HR Operations | HR-POL-019, HR-GDE-003 |
| Resignation, final pay, records of employment | HR Connect | HR Operations and Payroll Services | HR-POL-015 |

## 7. Using the HR Case Portal

### 7.1 Opening a case

1. Sign in to MyHR and select **HR Case Portal**.
2. Select **New case**, then choose the category (for example Pay, Benefits, Leave, Employee Relations, Privacy, Accessibility).
3. Describe the issue and the date by which you need a response. Do not include medical diagnoses, banking details or other sensitive information in the description; attach them as files only when asked.
4. Choose the suggested priority. The system sets P1 automatically for missed pay, safety and harassment categories.
5. Attach forms or documents (for example FORM-HR-021 for a payroll correction).
6. Submit. You receive a case number by email and a confirmation in MyHR.

### 7.2 Tracking and updating

The case status is shown as New, In progress, Waiting for you, Resolved or Closed. If the case is Waiting for you and no reply is received within 5 business days, it is resolved with a reminder; it can be reopened within 30 days. Add comments to the case rather than sending a new email so the history stays in one place.

### 7.3 Managers and delegates

Managers can open a case on behalf of an employee for matters in their authority and see the status of cases linked to their team, but cannot see confidential medical, accommodation, investigation or complaint information. An employee may nominate a delegate to open a case on their behalf in MyHR.

## 8. Escalation if a service level is missed

| Step | Who | When |
| --- | --- | --- |
| 1 | HR Operations manager | After 1 missed deadline (first response or resolution target) |
| 2 | VP HR Operations | If the matter is still open after step 1, or a second deadline is missed |
| 3 | Office of the CHRO | If the VP HR Operations has not resolved the matter |

Employees can request an escalation in the HR Case Portal by selecting **Escalate**, or through HR Connect. The Ombuds Office is always available, at any stage, for informal and confidential support.

## 9. Ombuds Office

The Ombuds Office is independent, confidential and informal. It listens, explains options and helps employees raise concerns, but it does not investigate, make decisions or keep formal case files for the Bank. Contact: ombuds@bank.example. Using the Ombuds Office does not stop any time limit in another process, so employees with a formal deadline (for example a rating dispute) should still observe it.

## 10. Languages and accessibility of services

HR Connect operates in English and French and provides an interpreter on request. Quebec employees receive HR documents and communications in French by default or on request; English versions are available. Alternative formats of HR documents are available on request (see HR-POL-018 Workplace Accommodation and Accessibility Policy).

## 11. Hours and holiday closures

HR Connect hours are Monday to Friday 8:00 to 20:00 Eastern Time, with live chat in MyHR in the same hours. HR Connect and the Manager Hotline are closed on Bank holidays. The Bank holidays in 2026 on which HR Connect is closed are shown below; the full holiday rules are in HR-POL-010 Statutory Holidays Policy.

| Date | Holiday | Observed in |
| --- | --- | --- |
| 2026-01-01 | New Year's Day | Canada and US |
| 2026-01-19 | Martin Luther King Jr. Day | US |
| 2026-02-16 | Family Day and equivalents; Presidents' Day | Canada (most provinces) and US |
| 2026-04-03 | Good Friday | Canada |
| 2026-05-18 | Victoria Day (National Patriots' Day in Quebec) | Canada |
| 2026-05-25 | Memorial Day | US |
| 2026-06-19 | Juneteenth | US |
| 2026-06-24 | Fête nationale du Québec | Quebec |
| 2026-07-01 | Canada Day | Canada |
| 2026-07-03 | Independence Day (observed) | US |
| 2026-08-03 | Civic Holiday and provincial equivalents | Canada (not Quebec) |
| 2026-09-07 | Labour Day and Labor Day | Canada and US |
| 2026-09-30 | National Day for Truth and Reconciliation | Canada |
| 2026-10-12 | Thanksgiving | Canada |
| 2026-11-11 | Remembrance Day and Veterans Day | Canada and US |
| 2026-11-26 | Thanksgiving | US |
| 2026-11-27 | Day after Thanksgiving | US |
| 2026-12-25 | Christmas Day | Canada and US |
| 2026-12-28 | Boxing Day (observed) | Canada |

The 24/7 lines (Speak-Up Line, Corporate Security, Security Operations Centre and Wellspring Support Program) stay open on holidays.

## 12. HR forms catalogue

Forms are found in MyHR under **Forms and documents**. The owning document explains when the form is required, who approves it and the deadlines. The catalogue lists each form once.

| Form ID | Form name | Purpose | Owning document |
| --- | --- | --- | --- |
| FORM-HR-010 | Leave of Absence Request | Request an unpaid personal leave of absence | HR-POL-007 Sick Leave and Personal Leave Policy |
| FORM-HR-011 | Medical Certificate and Fitness-to-Work | Provide a medical certificate or confirm fitness to return | HR-POL-007 Sick Leave and Personal Leave Policy |
| FORM-HR-012 | Parental Leave Notice and Top-Up Application | Give notice of parental leave and apply for the Bank top-up | HR-POL-008 Parental and Family Leave Policy |
| FORM-HR-013 | Family Caregiver Leave Request | Request caregiver, compassionate or family leave | HR-POL-008 Parental and Family Leave Policy |
| FORM-HR-020 | Overtime Pre-Approval and Time-in-Lieu Request | Pre-approve planned overtime or request time in lieu | HR-POL-003 Working Hours and Overtime Policy |
| FORM-HR-021 | Payroll Correction Request | Report a pay error for correction | HR-POL-009 Compensation and Payroll Policy |
| FORM-HR-022 | Direct Deposit and Tax Withholding Update | Change bank details, address or tax withholding | HR-POL-009 Compensation and Payroll Policy |
| FORM-HR-030 | Work Arrangement Request (Hybrid or Remote) | Request or record a hybrid or remote arrangement | HR-POL-002 Remote and Hybrid Work Policy |
| FORM-HR-031 | Temporary Work-from-Elsewhere Request | Request to work temporarily from another location | HR-POL-002 Remote and Hybrid Work Policy |
| FORM-HR-040 | Accommodation Request | Optional form to request workplace accommodation | HR-POL-018 Workplace Accommodation and Accessibility Policy |
| FORM-HR-041 | Medical Information Supplement for Accommodation | Provide functional limitations from a health care provider | HR-POL-018 Workplace Accommodation and Accessibility Policy |
| FORM-HR-050 | Harassment and Violence Complaint Intake | Report harassment or violence | HR-POL-005 Workplace Harassment and Violence Prevention Policy |
| FORM-HR-060 | Learning Approval and Tuition Reimbursement Claim | Seek pre-approval and claim tuition reimbursement | HR-POL-012 Learning and Development Policy |
| FORM-HR-061 | Professional Designation Reimbursement Request | Seek reimbursement of designation fees | HR-POL-012 Learning and Development Policy |
| FORM-HR-070 | Performance Improvement Plan | Record the written plan, goals and support | HR-POL-013 Performance Improvement Policy |
| FORM-HR-071 | Written Warning and Attendance Plan Template | Document a written warning or attendance plan | HR-POL-021 Employee Relations and Progressive Discipline Policy |
| FORM-HR-080 | Resignation Notice | Give written notice of resignation or retirement | HR-POL-015 Resignation and Offboarding Policy |
| FORM-HR-081 | Offboarding Checklist | Track handover, equipment, access and final steps | HR-POL-015 Resignation and Offboarding Policy |
| FORM-HR-082 | Exit Interview Questionnaire | Capture voluntary exit feedback | HR-POL-015 Resignation and Offboarding Policy |
| FORM-HR-090 | Personal Information Access Request | Ask for access to your personal information | HR-POL-016 Employee Data Privacy Policy |
| FORM-HR-091 | Privacy Impact Assessment | Assess privacy risk of an HR system, process or vendor | HR-POL-016 Employee Data Privacy Policy |
| FORM-HR-092 | Data Protection Impact Assessment | Assess high-risk processing of employee data | HR-POL-016 Employee Data Privacy Policy |
| FORM-HR-100 | Conflict of Interest Disclosure | Disclose a real or potential conflict | HR-POL-001 Code of Conduct and Ethics |
| FORM-HR-101 | Gift and Entertainment Disclosure | Seek approval for gifts above the limits | HR-POL-001 Code of Conduct and Ethics |
| FORM-HR-102 | Outside Business Activity Request | Request approval for outside work or an external board seat | HR-POL-001 Code of Conduct and Ethics |
| FORM-HR-111 | Consent to Pre-Employment Screening | Give consent before screening checks | HR-POL-020 Pre-Employment Screening Policy |
| FORM-HR-120 | Hardship Loan Application | Apply for an interest-free employee hardship loan | HR-POL-028 Staff Banking Privileges and Employee Loans Policy |
| FORM-HR-121 | Secondment Request | Request a secondment to another business unit | HR-POL-042 Secondment and Job Sharing Policy |
| FORM-HR-122 | Relocation Request and Approval | Request and approve a Bank-initiated relocation | HR-POL-039 Relocation and Global Mobility Policy |
| FORM-HR-123 | Licence and Registration Application | Apply for a required licence or registration | HR-POL-029 Licensing, Registration and Qualification Policy |
| FORM-HR-124 | Personal Trading Pre-Clearance Request | Obtain pre-clearance for a personal trade | HR-POL-032 Personal Trading and Restricted Lists Policy |
| FORM-HR-125 | Annual Personal Holdings Disclosure | Disclose personal holdings each year | HR-POL-032 Personal Trading and Restricted Lists Policy |
| FORM-HR-126 | Recognition Award Nomination | Nominate a colleague for an Excellence Award | HR-POL-043 Recognition and Awards Policy |
| FORM-HR-127 | Business Expense Report | Claim business travel and other expenses | HR-POL-038 Business Travel and Expense Policy |
| FORM-HR-128 | Job Sharing Request | Request a job-sharing arrangement | HR-POL-042 Secondment and Job Sharing Policy |
| FORM-HR-129 | Electronic Monitoring Acknowledgement | Acknowledge the electronic monitoring policy | HR-POL-033 Electronic Monitoring and Right to Disconnect Policy |
| FORM-HR-130 | Fitness-for-Work Support Request | Ask for support with a fitness-for-work concern | HR-POL-041 Substance Use and Fitness for Work Policy |

Form numbers are retired, not reused. A form that is not in this catalogue is not an official Bank HR form.

## 13. Privacy of HR cases

Information shared in an HR case is used only to resolve the request and is kept under the rules of HR-POL-016 Employee Data Privacy Policy and HR-REF-002 Employee Records Retention Schedule. Medical and accommodation information is held separately, and HR staff access to it is logged. Terms used in this guide are defined in HR-REF-001 HR Glossary.

## 14. Feedback and continuous improvement

After each case is resolved, the requester receives a two-question survey. The target is a satisfaction score of at least 90% and first-contact resolution of at least 70% at Tier 1. HR Operations publishes service-level results (first response and resolution within target, by priority) quarterly in MyHR. Compliments, complaints and suggestions about HR service can be sent to hrconnect@bank.example or submitted through the **Feedback** link in the HR Case Portal. Complaints are acknowledged within 2 business days and reviewed by the HR Operations manager.

## 15. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.5 | 2026-03-16 | Added the HR forms catalogue with owning documents, the Case Portal how-to and the 2026 holiday closure table. The catalogue now also lists forms 120 to 130. |
| 2.0 | 2024-09-01 | Introduced priorities P1 to P4, the three-tier model and the escalation path. |
| 1.0 | 2022-05-02 | Initial guide. |
