# How to record overtime and request time in lieu

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-033 |
| Title | How to record overtime and request time in lieu |
| Document type | How-to article |
| Version | 1.1 |
| Status | Current |
| Effective date | 2025-07-01 |
| Last reviewed | 2026-06-15 |
| Next review | 2027-06-15 |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-003, FORM-HR-020, HR-POL-010, HR-GDE-006, HR-POL-009 |

## 1. Short answer

Get overtime approved before you work it, record your actual start, end and meal times in Time Tracker by Friday 17:00 local time, and in Canada choose cash or time in lieu on FORM-HR-020.

## 2. Who this applies to

Overtime-eligible employees only: in Canada, non-managerial roles in Bands 1 to 4; in the US, employees classified non-exempt under the FLSA (generally Bands 1 to 3 and some Band 4). Exempt employees and Bands 5 and above record absences only. Time in lieu is Canada only; US non-exempt employees are paid overtime in cash. Your classification is in MyHR (see HR-GDE-006 Job Architecture and Pay Bands Guide).

## 3. Steps

1. **Get approval first.** Your manager pre-approves one-off overtime in MyHR > Time and Absence (Time Tracker). For planned or recurring overtime, submit FORM-HR-020 before the overtime is worked. Emergency overtime is approved by your manager by the next business day.
2. **Check the thresholds.** More than 8 overtime hours in a week also needs Director approval, and HR is notified. Scheduling beyond 12 hours a day or 48 hours a week needs VP approval and your written consent.
3. **Record your time** in Time Tracker: start, end and meal times.
4. **Choose how to be paid (Canada only).** Cash at 1.5x, or time in lieu: 1.5 hours banked per overtime hour, so 4 overtime hours bank 6 hours.
5. **Take banked time.** The bank is capped at 40 hours and must be taken within 3 months; unused time is paid out at the overtime rate at expiry.

## 4. Deadlines and rates

| Item | Rule |
| --- | --- |
| Time entry | Friday 17:00 local time |
| Manager approval | Monday 12:00 local time |
| Ontario, Quebec, other provinces, most US states | 1.5x after 40 hours a week |
| British Columbia, California | 1.5x after 8 hours a day and 40 a week; 2x after 12 hours a day |
| Alberta | 1.5x after 8 hours a day or 40 a week, whichever is greater |

Canada: hours between 37.5 and 40 are extra hours, paid at straight time or banked 1:1.

## 5. What happens next

Payroll Services pays overtime and expired balances on the regular pay date. Unapproved overtime is still paid, but repeated cases may be addressed under HR-POL-021 Employee Relations and Progressive Discipline Policy. Report pay errors on FORM-HR-021 through MyHR > HR Case Portal.

## 6. Common mistakes

- Working overtime before approval.
- Skipping FORM-HR-020 for recurring overtime.
- Leaving banked hours past 3 months.
- Expecting time in lieu in the US.
- Omitting meal times; falsifying time records is serious misconduct.

## 7. Who to call

Your manager first. HR Connect, 1-800-555-0142, hrconnect@bank.example. Managers: Manager Hotline, 1-800-555-0143.

## 8. Related documents

- HR-POL-003 Working Hours and Overtime Policy
- FORM-HR-020 Overtime Pre-Approval and Time-in-Lieu Request
- HR-POL-009 Compensation and Payroll Policy

## 9. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.1 | 2025-07-01 | Director approval threshold lowered from 10 to 8 overtime hours a week (HR-POL-003 version 4.2). |
| 1.0 | 2025-01-01 | First issue. |
