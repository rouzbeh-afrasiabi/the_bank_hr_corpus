# Employee Data Privacy Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-016 |
| Title | Employee Data Privacy Policy |
| Document type | Policy |
| Version | 4.0 |
| Status | Current |
| Effective date | 2026-02-01 |
| Last reviewed | 2026-09-01 |
| Next review | 2027-09-01 |
| Policy owner | Chief Privacy Officer |
| Approved by | Privacy Governance Committee and the Chief Human Resources Officer |
| Applies to | All Canadian and US employees, former employees and job applicants (see Scope) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-017, HR-POL-018, HR-POL-019, HR-POL-020, HR-REF-002, FORM-HR-090, FORM-HR-091, FORM-HR-092 |

## 1. Purpose

This policy explains how the Bank collects, uses, discloses, protects and retains the personal information of its employees, former employees and job applicants, and how people can see and challenge that information. It also sets the assessments required before HR systems, vendors or tools handle employee information, and the duties to report a privacy breach.

## 2. Scope

The policy applies to all personal information about employees, former employees, applicants, dependants and beneficiaries that the Bank handles in Canada and the US, in any format. It applies to HR, managers, Technology and Operations, Payroll Services, Benefits Administration, and to every vendor that handles that information for the Bank. Contractors and agency workers are covered for the information they handle. Where applicable law gives a greater right, the law applies.

Legal framework: PIPEDA, provincial private-sector privacy laws (including Quebec's Law 25 and the BC and Alberta PIPA) and US state laws (for example CCPA and CPRA). The Chief Privacy Officer is accountable for compliance.

## 3. Definitions

| Term | Meaning |
| --- | --- |
| Personal information | Information about an identifiable individual, including work and personal data. |
| Sensitive information | Health, disability, biometric, diversity self-identification, financial account, government identifier and similar data. |
| Privacy breach | Loss of, or unauthorized access to, use or disclosure of personal information. |
| PIA | Privacy Impact Assessment (FORM-HR-091). |
| DPIA | Data Protection Impact Assessment (FORM-HR-092). |
| System owner | The business leader accountable for an HR system, process, vendor or tool. |
| Privacy Office | The team led by the Chief Privacy Officer, privacy@bank.example. |

## 4. Principles

The Bank follows ten privacy principles.

| Principle | What it means for employee data |
| --- | --- |
| Accountability | The Chief Privacy Officer is accountable; every manager and HR employee is responsible for the information in their control. |
| Identifying purposes | The reason for collection is stated at or before collection. |
| Consent | Consent is obtained where required; it is not a condition of employment where the information is not needed. |
| Limiting collection | Only information needed for the stated purposes is collected. |
| Limiting use, disclosure and retention | Information is used only for the purpose collected, and kept only as long as in HR-REF-002 Employee Records Retention Schedule. |
| Accuracy | Information is kept accurate and up to date; employees correct their data in MyHR. |
| Safeguards | Controls fit the sensitivity of the data (see HR-POL-017 IT Acceptable Use and Information Security Policy). |
| Openness | This policy and the notice of collection are in MyHR. |
| Individual access | Employees may see and correct their information. |
| Challenging compliance | Concerns go to the Privacy Office; the Ombuds Office can advise informally. |

## 5. What information the Bank collects and why

| Category | Examples | Main purposes |
| --- | --- | --- |
| Identity and contact | Name, address, emergency contact, government ID, Social Insurance Number or US Social Security number | Employment, payroll, tax, legal compliance |
| Recruitment and screening | Application, references, background check results | Hiring and regulatory screening (HR-POL-019, HR-POL-020) |
| Pay and benefits | Bank account, salary, benefit enrolment, dependants, pension and retirement elections | Payroll, benefits, retirement plans |
| Performance and conduct | Goals, ratings, learning records, warnings, investigations | Management of employment |
| Health and accommodation | Medical certificates, functional limitations, leave information | Leave, disability benefits, accommodation (HR-POL-018) |
| Attendance and time | Time Tracker entries, leave records | Pay and scheduling |
| Technology | Log-in, device, network and communications data on Bank systems | Security, fraud prevention, regulatory obligations |
| Self-identification | Voluntary diversity data | Reporting and inclusion programs, only in aggregate |

The Bank does not use personal information for marketing, and does not sell it.

## 6. Consent and notice

Employees receive a notice of collection on hire, in English and in French for Quebec employees, and are told of material changes at least 30 days before they take effect, where practicable. Information needed to administer employment, comply with law or provide benefits does not need separate consent. Where consent is needed (for example for background checks, voluntary self-identification or sharing with a third party), it is recorded, specific and may be withdrawn, subject to legal and contractual limits. Withdrawal of a voluntary item has no effect on employment.

## 7. Access, correction and requests

An employee, former employee or applicant may ask to see their personal information and ask for corrections using FORM-HR-090 Personal Information Access Request, or by emailing privacy@bank.example. The following rules apply.

| Step | Rule |
| --- | --- |
| Identity check | The Privacy Office confirms identity before releasing information. |
| Response time | Within 30 days of a complete request. |
| Extension | Up to a further 30 days, with written notice to the requester and the reasons. |
| Cost | No fee for standard requests. |
| Exceptions | Information about other people, privileged legal advice, investigation information that is protected by law, or information where access could harm someone may be withheld, with an explanation. |
| Corrections | Accepted when shown to be inaccurate; otherwise a note of the disagreement is added. |

Employees can also see most of their own information directly in MyHR.

## 8. Safeguards and access to employee data

Access to HR systems is limited by role and logged. Employees' records are held in access-controlled systems, with encryption in transit and at rest, and are reviewed quarterly under HR-POL-017. Managers see only the information they need to manage their team. Canadian employee records are primarily stored in Canada.

### 8.1 Medical and accommodation information

Medical and accommodation information is held separately from the general personnel file, in a restricted file owned by the Leaves team and the Accommodation Specialist. Managers receive only functional limitations and expected duration, never diagnosis or treatment details (see HR-POL-018 Workplace Accommodation and Accessibility Policy). HR access to these files is logged and the logs are reviewed quarterly by the Privacy Office.

## 9. Privacy breaches

### 9.1 Reporting

Any employee who discovers or suspects a privacy breach (for example an email with employee data sent to the wrong person, a lost device, or unauthorized access to a file) must report it to the Privacy Office (privacy@bank.example) immediately and no later than 24 hours after discovery. Cyber incidents or a lost device must also be reported to the Security Operations Centre (1-800-555-0155) immediately and within 1 hour. Managers who are told of a breach forward it at once. Failure to report is a breach of this policy.

### 9.2 Response

The Privacy Office, with the CISO and Legal, contains the incident, assesses whether there is a real risk of significant harm, notifies the regulator and affected individuals as soon as feasible, and records every breach, including those that do not need notification, in the breach register. A review identifies root cause and corrective actions.

## 10. Impact assessments: PIA and DPIA

### 10.1 When they are required

A PIA is required before launching or materially changing any HR system, process, vendor or tool that collects, uses or discloses employee personal information. A DPIA is also required, in addition to the PIA, for high-risk processing such as:

- employee monitoring;
- biometrics;
- automated or AI-assisted decisions about employees;
- large-scale sensitive data (health, disability, biometric or diversity self-identification); or
- cross-border transfers of employee information.

### 10.2 Comparison

| Item | PIA (FORM-HR-091) | DPIA (FORM-HR-092) |
| --- | --- | --- |
| Applies when | Any new or materially changed HR system, process, vendor or tool that handles employee personal information | High-risk processing: monitoring, biometrics, automated or AI-assisted employee decisions, large-scale sensitive data, cross-border transfers |
| Completed by | The system owner | The system owner, with the Privacy Office |
| Reviewed by | Privacy Office within 15 business days | Privacy Office, CISO and Legal |
| Decision by | Privacy Office | Privacy Governance Committee within 30 days |
| Reassessment | Every 3 years or on material change | Annually |
| Extra conditions | Vendor and contract terms checked | A human makes the final decision on any employment outcome; documented safeguards for fairness and explainability |

Quebec requires a PIA before information is transferred outside Quebec; the Privacy Office completes this step with the system owner.

### 10.3 Timelines

A system may not go live without a decision. If a DPIA is required, the project plan must allow for the 30-day period.

## 11. Monitoring

The Bank monitors its own systems, networks and premises for security, fraud prevention, regulatory compliance and to protect people. Monitoring is disclosed to employees, is proportionate, and is never covert. Monitoring of employees requires a DPIA and a documented purpose. Details of what is monitored are in HR-POL-033 Electronic Monitoring and Right to Disconnect Policy. Monitoring data is accessed only by authorized security, compliance and investigation staff and is not used for routine performance management.

## 12. Artificial intelligence in HR

AI and automated tools may support HR work, but a human must make the final decision on any employment outcome, such as hiring, rating, discipline, pay or termination. AI screening tools may not be the sole basis for rejecting a candidate (see HR-POL-019 Recruitment and Selection Policy). Each AI-assisted HR use needs a DPIA. Employees must not put client or employee personal data into public AI tools; only Bank-approved AI tools may be used (see HR-POL-017). Employees may ask HR to explain how a tool contributed to a decision that affects them.

## 13. Cross-border transfers and Quebec

Employee information may be accessed from or stored in another country only where a DPIA is approved, contractual safeguards are in place, and the employee notice says so. Canadian employee records are primarily stored in Canada. For Quebec, a PIA must be completed before a transfer outside Quebec, and employees receive privacy communications in French by default or on request. The Privacy Office tracks the vendors and locations where employee data is processed.

## 14. Third parties and vendors

Vendors that handle employee information, including Maplewood Benefits, Evergreen Retirement Services, Wellspring Support Program and Clearline, are bound by written contracts that limit use, require safeguards and prompt breach notice, and allow audit. A PIA is completed before any new vendor is engaged or any vendor's scope is expanded. The Bank shares only the information the vendor needs. Disclosures to regulators, courts or police are made only where required by law and are reviewed by Legal and the Privacy Office.

## 15. Retention and destruction

Retention periods are set in HR-REF-002 Employee Records Retention Schedule, which the Chief Privacy Officer owns. Records are securely destroyed or anonymized at the end of the retention period unless a legal hold applies. Legal holds are issued by Legal and override destruction until released.

## 16. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Chief Privacy Officer | Accountable for the program; chairs the Privacy Governance Committee. |
| Privacy Office | Handles requests, breaches and PIA/DPIA reviews. |
| Privacy Governance Committee | Decides DPIAs and approves policy changes with the CHRO. |
| CISO | Reviews DPIAs and owns technical safeguards. |
| HR Operations, Payroll Services, Benefits Administration | Handle data according to this policy. |
| Managers | Use team data only for management needs, report breaches within 24 hours. |
| Employees | Keep their own data up to date, protect the data of others and complete the annual Privacy and Information Security Awareness training. |

## 17. Consequences

Breaches of this policy may lead to corrective action up to and including termination (see HR-POL-021 Employee Relations and Progressive Discipline Policy). Reports made in good faith are protected from retaliation. Employees may complain to the Privacy Office, the Speak-Up Line (1-800-555-0177) or a privacy regulator at any time.

## 18. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 4.0 | 2026-02-01 | Added the PIA and DPIA comparison, the AI in HR section and the Quebec transfer rule. |
| 3.0 | 2024-02-01 | Extended the policy to former employees and applicants; set the 24-hour breach reporting rule. |
| 2.0 | 2021-10-01 | Added vendor requirements and access request process. |
