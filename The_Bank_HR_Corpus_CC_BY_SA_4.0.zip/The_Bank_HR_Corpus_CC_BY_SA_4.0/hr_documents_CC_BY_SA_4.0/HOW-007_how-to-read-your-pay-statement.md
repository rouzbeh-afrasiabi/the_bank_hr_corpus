# How to read your pay statement

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-007 |
| Title | How to read your pay statement |
| Document type | How-to article |
| Version | 1.1 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-09-28 |
| Next review | 2027-09-28 |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-009, HR-POL-003, FORM-HR-021, HOW-008 |

## 1. The short answer

Open **MyHR > Pay > Pay Statements** from 2 business days before your pay date and check three things: pay period, earnings and deductions, and net pay.

## 2. Who this applies to

All employees in Canada and the US. Pay is biweekly in arrears (26 pay dates a year): Canada on Thursdays, US on Fridays. The pay period ends on the Saturday immediately before the pay date. Quebec employees can request the statement in French and will see Quebec Pension Plan and Quebec Parental Insurance Plan deductions.

## 3. Steps

1. Select **MyHR > Pay > Pay Statements** and choose the pay date. For the Canada pay date of 2026-03-05 (period ended Saturday 2026-02-28), the statement is posted on Tuesday 2026-03-03.
2. Check the **pay period** and your **pay date**.
3. Read the **earnings** section: base salary, plus any overtime, shift premium, on-call allowance or other additions.
4. Read the **deductions** section, which lists statutory items first, then benefit premiums, savings contributions and optional items.
5. Compare **net pay** with the deposit in your bank account on the pay date.
6. Check the **year-to-date** column against your expectations.

## 4. What the deductions are

| Type | Canada | US |
| --- | --- | --- |
| Income tax | Federal and provincial | Federal and state |
| Social programs | Canada Pension Plan or Quebec Pension Plan; Employment Insurance or Quebec Parental Insurance Plan | Social Security and Medicare |
| Benefits | Premiums, deducted monthly | Premiums, deducted each pay period |
| Savings | Pension and savings contributions | 401(k) contributions |
| Optional | Charitable giving | Charitable giving |

Garnishments, where a court order requires them, also appear. Hours and overtime come from the entries approved in Time Tracker (see HR-POL-003 Working Hours and Overtime Policy).

## 5. What happens next

If everything is correct, no action is needed. If something is wrong, act on the same day: use FORM-HR-021 Payroll Correction Request (see HOW-008). If you were paid too much, tell Payroll Services; failing to report a known overpayment is a breach of the Code of Conduct and Ethics.

## 6. Common mistakes

- Comparing net pay with the wrong pay date; US pay can move before a holiday (for example 2026-11-25 instead of 2026-11-27).
- Not checking after a change to tax forms, bank details or benefits.
- Ignoring a small error; amounts under $250 net are fixed on the next regular pay date, but only if you report them.

## 7. Who to call

HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, or live chat in MyHR. A missed pay is a P1 urgent case.

## 8. Related documents

- HR-POL-009 Compensation and Payroll Policy
- HR-POL-003 Working Hours and Overtime Policy
- FORM-HR-021 Payroll Correction Request
- HOW-008 How to report a payroll error

## 9. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.1 | 2026-03-01 | Aligned with HR-POL-009 version 7.2 (2026 pay dates and the $250 correction threshold). |
| 1.0 | 2025-03-01 | First edition. |
