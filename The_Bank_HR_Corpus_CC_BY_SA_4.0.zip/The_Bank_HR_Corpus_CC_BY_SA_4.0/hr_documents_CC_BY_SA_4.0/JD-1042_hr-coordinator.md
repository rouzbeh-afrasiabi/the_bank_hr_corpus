# HR Coordinator

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | JD-1042 |
| Title | HR Coordinator |
| Document type | Job description |
| Version | 1.2 |
| Status | Current |
| Effective date | 2026-03-01 |
| Last reviewed | 2026-08-25 |
| Next review | 2027-08-25 |
| Policy owner | VP HR Operations |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-GDE-003, HR-GDE-004, HR-GDE-006, HR-FWK-001, HR-POL-015, HR-POL-020 |

## 1. Role summary

The HR Coordinator provides administrative and process support to the HR Generalist and the business unit they serve. The coordinator prepares employment documents, runs onboarding and offboarding logistics, keeps employee records accurate in MyHR and manages case follow-up in the HR Case Portal. The role is Band 3 (Professional): it applies professional knowledge and works independently on assigned work. See HR-GDE-006 Job Architecture and Pay Bands Guide.

## 2. Key responsibilities

- Coordinate new-hire onboarding under HR-GDE-003 New Employee Onboarding Guide: confirm screening is complete, order equipment, schedule day-1 orientation and track the 30, 60 and 90-day check-ins.
- Prepare offer letters, employment verification letters and leave confirmation letters from approved templates.
- Process employment changes in MyHR, such as status, manager and location updates, with documented approvals.
- Support offboarding: acknowledge resignation notices (FORM-HR-080) within 2 business days, issue the offboarding checklist (FORM-HR-081) and confirm equipment return within 5 business days.
- Track probation end dates and notify managers before the end of month 3.
- Monitor assigned HR Case Portal cases against the service levels in HR-GDE-004 HR Service and Support Guide and chase owners before a deadline is missed.
- Maintain the accuracy and confidentiality of personnel files and follow the retention rules in HR-REF-002 Employee Records Retention Schedule.
- Prepare HR metrics such as headcount, turnover and training completion for the HR Generalist.
- Schedule interviews and support background-screening logistics under HR-POL-020 Pre-Employment Screening Policy.
- Answer first-line questions from managers and refer complex matters to the HR Generalist.

## 3. Qualifications

### 3.1 Required

- Post-secondary diploma or degree in human resources, business administration or a related field.
- Two to five years of HR, administrative or records experience.
- Accuracy with data entry and strong spreadsheet skills.
- Discretion with confidential information.

### 3.2 Preferred

- Experience with a human resources information system and case management tool.
- Familiarity with employment standards in Canada and the US.
- Progress toward a recognized HR designation; fees are covered under HR-POL-012 Learning and Development Policy.

## 4. Competencies

Competency names follow HR-FWK-001 Competency and Leadership Model (Practitioner level, Bands 3 to 4).

- Customer Obsession
- Collaboration
- Drive for Results
- Risk and Conduct Awareness
- Adaptability

## 5. Compensation and classification

| Item | Detail |
| --- | --- |
| Band | 3 (Professional) |
| Canada range | $56,000 to $84,000 CAD per year |
| US range | $55,000 to $82,000 USD per year |
| Incentive target | 5% of base salary (Annual Incentive Plan) |
| Overtime eligibility, Canada | Yes (non-managerial) |
| FLSA classification, US | Non-exempt |
| Work arrangement | Hybrid |

## 6. Working conditions and accessibility

Office-based and hybrid by default, with at least 3 days a week in the office; Tuesday and Thursday are anchor days (HR-POL-002 Remote and Hybrid Work Policy; FORM-HR-030). Start, end and meal times are recorded in Time Tracker, and overtime is pre-approved by the manager (HR-POL-003 Working Hours and Overtime Policy). The Bank provides accommodation to the point of undue hardship (HR-POL-018 Workplace Accommodation and Accessibility Policy).

## 7. Reporting line

Reports to the HR Generalist. The role has no direct reports.

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.2 | 2026-03-01 | Pay ranges aligned with the 2026 pay bands |
| 1.1 | 2025-06-01 | Added offboarding and probation tracking duties |
| 1.0 | 2025-01-01 | First issue |
