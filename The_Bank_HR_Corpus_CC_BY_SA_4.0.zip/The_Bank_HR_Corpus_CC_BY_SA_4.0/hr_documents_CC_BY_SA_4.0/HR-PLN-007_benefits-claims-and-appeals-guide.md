# Benefits Claims and Appeals Guide

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-PLN-007 |
| Title | Benefits Claims and Appeals Guide |
| Document type | Plan document |
| Version | 2.1 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-10-20 |
| Next review | 2027-10-20 |
| Policy owner | SVP Total Rewards |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-PLN-004, HR-PLN-005, HR-PLN-006, HR-GDE-001, HR-POL-007, HR-GDE-004, HR-POL-016 |

## 1. Purpose and scope

This guide sets out how a benefits claim is submitted, how it is decided, and how a claimant may appeal a decision that is wholly or partly unfavourable. It applies to the group health, dental, vision, life, accidental death, critical illness and wellness benefits described in HR-PLN-004 Group Benefits Booklet (Canada) and HR-GDE-001 Employee Benefits Guide, to the disability benefits owned by HR-POL-007 Sick Leave and Personal Leave Policy, to the US health and welfare plans administered by Maplewood Benefits, and to claims under the retirement plans in HR-PLN-005 Bank Savings and Pension Plan Text Summary (Canada) and HR-PLN-006 US 401(k) Savings Plan Summary Plan Description.

Where a group insurance contract or a formal plan document governs a particular claim and differs from this guide, the contract or plan document governs. Where applicable law gives a greater right or a shorter time limit, the law applies.

## 2. Definitions

- **Claim** means a request for a benefit, or for payment of a benefit, made in the way this guide requires.
- **Claimant** means an employee, dependant or beneficiary who makes a claim.
- **Adverse benefit determination** means a denial, reduction or termination of a benefit, or a failure to pay all or part of a benefit.
- **Urgent care claim** (US) means a claim for which waiting for the standard time frame could seriously jeopardize the claimant's life, health or ability to regain maximum function, as a physician with knowledge of the condition determines.
- **Pre-service claim** (US) means a claim for a benefit that requires approval before the care is received.
- **Post-service claim** means a claim for payment for care or expenses already incurred.
- **Business day** means a day other than a Saturday, Sunday or Bank holiday.
- **Benefits Appeals Committee** means the committee described in section 8.
- **Maplewood Benefits** means the insurance carrier and claims administrator in both countries.

## 3. Roles and responsibilities

The claimant submits a complete claim on time and appeals within the time limit. Maplewood Benefits decides claims, issues written notices and decides first-level appeals. Benefits Administration helps with enrolment and eligibility questions and forwards appeals received through MyHR the same business day. Evergreen Retirement Services decides retirement plan claims and first-level retirement plan appeals. The Benefits Appeals Committee decides second-level reviews. The Ombuds Office provides independent, confidential, informal help at any stage. The SVP Total Rewards owns this guide.

## 4. Submitting a claim

### 4.1 Time limit

A claim must be submitted within 12 months of the date of the expense or service. A claim submitted after 12 months is not payable unless law requires otherwise. Wellness spending account claims for a plan year must be submitted by 31 March of the following year, which for plan year 2026 is 31 March 2027. Disability claims follow the earlier application deadline in HR-POL-007.

### 4.2 How to submit

| Benefit | How to submit |
| --- | --- |
| Canadian health, dental, vision | Direct billing with the Maplewood Benefits card, or the Maplewood Benefits member portal linked from MyHR |
| US health, dental, vision | Show the card at the time of service; submit out-of-network claims through the member portal |
| HSA and flexible spending accounts (US) | The account administrator linked from MyHR |
| Life, accidental death, critical illness | Through Benefits Administration and Maplewood Benefits, with the documents in section 4.3 |
| Short-term and long-term disability | Through MyHR to Maplewood Benefits, as HR-POL-007 describes |
| Retirement plans | In writing through MyHR or to Evergreen Retirement Services, 1-800-555-0188 |

### 4.3 Documentation

A complete claim usually includes the claimant's name and certificate or member number, the date of service, an itemized receipt or invoice showing the provider, the service or drug and the amount, proof of payment where the claim is not direct-billed, and the explanation of benefits from any other plan. A life or accidental death claim also needs a certified death certificate and the claimant's identification. A critical illness claim needs a physician's statement of the diagnosis. Medical information is shared only as needed and is handled under HR-POL-016 Employee Data Privacy Policy.

### 4.4 Predetermination

For Canadian major dental work estimated above $500, request a predetermination before treatment. It is an estimate of what the Plan would pay and does not replace a claim.

## 5. Decisions on claims

### 5.1 Canada

Maplewood Benefits decides a Canadian claim within 30 days of receiving the complete claim. If more information is needed, the 30 days run from receipt of the information, and Maplewood Benefits tells the claimant in writing what is missing.

### 5.2 United States

| Type of claim | Decision time |
| --- | --- |
| Urgent care claim | 72 hours |
| Pre-service claim | 15 days |
| Post-service claim | 30 days |

If a claim is incomplete, the claimant is told what is missing, and the decision time is paused until the information is received. Maplewood Benefits may extend a time frame once where law permits, by written notice before the time frame ends, explaining the reason and the date by which a decision is expected.

### 5.3 Retirement plans

Evergreen Retirement Services decides a retirement plan claim within 30 days after receiving it, as HR-PLN-006 states for the US 401(k) plan. The same period applies to the Canadian Bank Savings and Pension Plan unless pension law requires a shorter one.

### 5.4 Notice of decision

A written notice of an adverse benefit determination states the specific reason, refers to the contract or plan provision on which the decision is based, describes any additional information that would change the result, explains the appeal process and the time limit, and names any internal rule or expert opinion that was relied on, which the claimant may request free of charge.

## 6. Common reasons for denial

| Reason | What to do |
| --- | --- |
| Claim submitted after 12 months | Appeal only if a legal or documented administrative exception applies |
| Service not covered or excluded (for example cosmetic treatment or experimental treatment) | Check the exclusions in HR-PLN-004; appeal with a physician's letter if you believe the service is medically necessary |
| Annual or lifetime maximum used up | Check the schedule of benefits and prior claims; no appeal is available if the maximum was correctly applied |
| Missing or illegible receipt | Resubmit with an itemized receipt |
| Other coverage not disclosed | Submit to the other plan first, then resubmit with its statement |
| Coverage not in force on the date of service | Confirm eligibility with Benefits Administration; appeal if a qualifying life event was reported on time |
| Out-of-network provider (US) | Check the coinsurance and out-of-pocket rules in HR-GDE-001 |
| Prior approval or predetermination not obtained | Ask for a retrospective review with the clinical record |
| Medical necessity not shown | Appeal with the treating provider's report |

## 7. First-level appeal

### 7.1 Who may appeal and when

A claimant may appeal an adverse benefit determination within 180 days of receiving the notice of the decision. The appeal may be made by the claimant or by an authorized representative named in writing.

### 7.2 How to appeal

Submit a written appeal through MyHR (Benefits, then Appeal a claim decision), by raising a case in the HR Case Portal, or by writing to Maplewood Benefits. State the claim, the decision being appealed and the reason it is wrong, and attach any new information. The claimant may ask for, and receive free of charge, copies of the documents relevant to the claim.

### 7.3 Review and decision

The first-level appeal is reviewed by a person at Maplewood Benefits who did not make the original decision and who is not that person's subordinate. For a decision based on medical judgement, the reviewer consults a qualified health professional who was not involved in the first decision. The reviewer takes into account all new information. The decision is issued within 30 days of receipt of the appeal, in writing, with reasons.

## 8. Second-level review by the Benefits Appeals Committee

### 8.1 Right to a second review

A claimant who is not satisfied with the first-level decision may request a second-level review by the Benefits Appeals Committee. The request is made in writing through MyHR or the HR Case Portal, with reasons and any further information.

### 8.2 The Committee

The Committee is chaired by a leader of Total Rewards designated by the SVP Total Rewards. Its members are a Legal representative, a member of Benefits Administration who was not involved in the claim, and, for medical matters, an independent health professional. No member may have been involved in the earlier decision.

### 8.3 Decision

The Committee reviews the complete file and decides within 30 days of receiving the request. Its decision is final within the Bank's internal process and is issued in writing with reasons, the claimant's remaining rights, and the contact details of the bodies in section 9.

## 9. External routes

### 9.1 United States

A US claimant may have the right to an independent external review of an adverse benefit determination that involves medical judgement, after the internal appeals in sections 7 and 8, or sooner where law permits. The decision notice explains how to request it and the time allowed. A US claimant under the retirement plan has the rights described in HR-PLN-006, including the right to bring a civil action after the internal review is complete.

### 9.2 Canada

A Canadian claimant may complain to the provincial insurance regulator, or to the pension regulator for a pension matter, after the Bank's internal process, and may also seek independent advice. The Ombuds Office, ombuds@bank.example, is independent and confidential and can help a claimant at any point, but it does not decide claims and cannot override Maplewood Benefits.

## 10. Disability claims

Short-term and long-term disability claims are decided by Maplewood Benefits, not by the Bank, on the terms in HR-POL-007 Sick Leave and Personal Leave Policy. The claimant applies through MyHR within the period HR-POL-007 states. A denial or termination of disability benefits may be appealed under sections 7 and 8, within 180 days. The claimant should send updated medical evidence, a statement from the treating provider describing functional limitations, and a description of the job. The Leaves team may help the claimant gather documents and coordinates payroll and return-to-work arrangements, but it does not decide medical eligibility. The Accommodation Specialist can assist if a graduated return to work is under discussion.

## 11. Time limits at a glance

| Step | Time |
| --- | --- |
| Submit a claim | Within 12 months of the expense date |
| Wellness spending account claim | By 31 March of the following year |
| Decision on a Canadian claim | 30 days |
| US decision: urgent / pre-service / post-service | 72 hours / 15 days / 30 days |
| Retirement plan claim decision | 30 days |
| First-level appeal | Within 180 days of the decision |
| First-level decision | 30 days |
| Second-level review decision | 30 days |

## 12. Confidentiality and non-retaliation

Claim and appeal files are confidential and are accessed only by those who need them. Claim information is not shared with a manager. An employee must not be penalized for making a claim or an appeal in good faith. Concerns about retaliation may be raised through the channels in HR-POL-022 Whistleblower and Speak-Up Policy. A claimant who knowingly gives false information may be subject to action under HR-POL-001 Code of Conduct and Ethics.

## 13. Help and contacts

| Need | Contact |
| --- | --- |
| Claim status, explanation of a decision | Maplewood Benefits claims line, 1-800-555-0190 |
| Eligibility, enrolment, premiums, how to appeal | HR Connect, 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time, hrconnect@bank.example |
| Retirement plan claims | Evergreen Retirement Services, 1-800-555-0188 |
| Independent, confidential, informal help | Ombuds Office, ombuds@bank.example |

Service levels for HR cases are in HR-GDE-004 HR Service and Support Guide.

## 14. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.1 | 2026-01-01 | Aligned time limits across Canada and the US; added retirement plan claims, common denial reasons and the second-level review |
| 2.0 | 2024-01-01 | Added the second-level review by the Benefits Appeals Committee |
