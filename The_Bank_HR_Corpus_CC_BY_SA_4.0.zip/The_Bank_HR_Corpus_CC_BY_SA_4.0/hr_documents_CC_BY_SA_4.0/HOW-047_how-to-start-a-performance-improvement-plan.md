# How to start a performance improvement plan

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-047 |
| Title | How to start a performance improvement plan |
| Document type | How-to article |
| Version | 1.1 |
| Status | Current |
| Effective date | 2025-06-01 |
| Last reviewed | 2026-07-14 |
| Next review | 2027-07-14 |
| Policy owner | VP Employee Relations |
| Audience | Managers |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-013, FORM-HR-070, HR-POL-018, HR-POL-021, HR-GDE-005 |

## 1. Short answer

Confirm a trigger, get your HR Business Partner (HRBP) to approve the written plan in FORM-HR-070 before you meet the employee, then hold the kickoff meeting within 10 business days of the trigger; the standard plan lasts 60 days with weekly check-ins.

## 2. Who this applies to

Managers of regular full-time and part-time employees and fixed-term employees of 6 months or more, after probation. Conduct problems such as dishonesty or harassment go to Employee Relations under HR-POL-021 Employee Relations and Progressive Discipline Policy and do not need a PIP.

## 3. Steps

1. Confirm a trigger: a year-end rating of Needs Improvement or Unsatisfactory, or documented sustained underperformance after at least one documented coaching conversation.
2. Check protected circumstances first. If a medical condition, family status or another protected ground may affect performance, ask the HRBP to involve the Accommodation Specialist (HR-POL-018). A PIP must never be retaliation for a complaint, an accommodation request, protected leave or a Speak-Up report.
3. Draft FORM-HR-070: gaps with examples, the measurable standard, targets and dates, the Bank's support, start and end dates, check-in time and the consequences.
4. Open MyHR > HR Case Portal > New case > Employee Relations, attach the draft and evidence, and send them to the HRBP at least 3 business days before the meeting.
5. Wait for HRBP approval. A 90-day plan also needs Employee Relations approval. Starting a PIP without HRBP approval breaches the policy.
6. Hold the kickoff meeting in private with the HRBP. The employee may bring a support person who is not legal counsel, may add comments within 5 business days, and is asked to sign to confirm receipt; signing does not mean agreement. Record a refusal.
7. Hold a 30-minute check-in every week, reschedule any missed one within 2 business days, and hold a mid-point review.
8. Hold the final review and issue the written outcome within 5 business days of the end date.

## 4. Deadlines

| Item | Deadline |
| --- | --- |
| Draft to HRBP | At least 3 business days before the meeting |
| Kickoff meeting | Within 10 business days of the trigger |
| Length | 60 days standard (30 to 90) |
| Extension | One, up to 30 days, approved by the HRBP |
| Final review | Within 5 business days of the end date |

## 5. What happens next

Success closes the plan and regular check-ins continue. Records leave the active file 12 months after successful completion. An unsuccessful plan moves to progressive discipline under HR-POL-021, and Employee Relations must approve any termination. A protected absence or approved leave of more than 5 consecutive business days pauses the plan. During the plan the employee is not eligible for a merit increase or an internal transfer.

## 6. Common mistakes

- Skipping the coaching conversation or the accommodation check.
- Setting vague or unrealistic targets for the employee's band and role.
- Promising an outcome, or sharing the plan with the team.

## 7. Who to call

Manager Hotline, 1-800-555-0143, Monday to Friday 8:00 to 20:00 Eastern Time (response within 4 business hours), and your HRBP. Employees can use the Wellspring Support Program, 1-800-555-0166.

## 8. Related documents

- HR-POL-013 Performance Improvement Policy
- FORM-HR-070 Performance Improvement Plan
- HR-GDE-005 Manager's HR Procedures Guide

## 9. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.1 | 2025-06-01 | Standard plan length reduced from 90 to 60 days (HR-POL-013 version 2.1). |
| 1.0 | 2025-02-03 | First edition. |
