# Leaves Administration Procedure

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-PRC-006 |
| Title | Leaves Administration Procedure |
| Document type | Procedure |
| Version | 3.0 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-09-15 |
| Next review | 2027-09-15 |
| Policy owner | SVP Total Rewards |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | HR only |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-007, HR-POL-008, HR-POL-036, HR-POL-018, HR-POL-016, HR-PRC-003, HR-PRC-007, FORM-HR-010, FORM-HR-011, FORM-HR-012, FORM-HR-013 |

## 1. Purpose

This procedure tells the Leaves team (Tier 2, HR Operations) how to take in, verify, record, pay and close leaves of absence. It implements HR-POL-007 Sick Leave and Personal Leave Policy and HR-POL-008 Parental and Family Leave Policy and uses the same numbers and timelines. It adds system actions, leave codes and checklists; it never changes what employees are entitled to.

## 2. Scope

The procedure covers sick leave and certificates, short-term and long-term disability, personal unpaid leave, Canadian parental and pregnancy leave with Bank top-up, US paid parental leave with FMLA, caregiver leaves, return to work and workers' compensation intake. Bereavement, jury duty and other leaves follow the same intake steps (HR-POL-026 Bereavement, Jury Duty and Other Leaves Policy). Where applicable law gives a greater right, the law applies.

## 3. Roles

| Role | Responsibility |
| --- | --- |
| Leaves team (Tier 2) | Verifies eligibility, sets leave codes, coordinates with Maplewood Benefits, issues notices, tracks return dates. |
| Payroll Services | Pays sick days, top-up and Bank-paid leave. |
| Benefits Administration | Maintains coverage during leave. |
| Accommodation Specialist | Coordinates graduated return to work (HR-PRC-007 Accommodation Case Management Procedure). |
| Maplewood Benefits | Decides disability claims; the Bank does not decide medical eligibility. |

## 4. Intake and eligibility

1. Open the leave case in the HR Case Portal from MyHR (case type Leave). HR Connect routes it to the Leaves team at Tier 2; first response follows the priority set in HR-GDE-004 HR Service and Support Guide.
2. Identify the leave type and the right form: FORM-HR-010 Leave of Absence Request (personal leave), FORM-HR-011 Medical Certificate and Fitness-to-Work, FORM-HR-012 Parental Leave Notice and Top-Up Application, FORM-HR-013 Family Caregiver Leave Request.
3. Verify eligibility: FMLA needs 12 months of service, 1,250 hours worked and 50 employees within 75 miles; the Canada top-up needs 6 months of continuous service; personal leave needs 2 years of service; US paid parental leave applies to any new parent (birth, adoption, foster).
4. Store medical documents in the restricted leave file, separate from the personnel file. Managers receive only functional limitations and expected duration, never a diagnosis (HR-POL-016 Employee Data Privacy Policy).
5. Tell the manager the dates and what coverage to plan, and no more.

### 4.1 Sick day entitlement

Canada 10 sick days and US 8 per calendar year, credited 1 January, pro-rated for new hires, minimum half day, no carryover.

## 5. Sick leave and certificates

1. Record the absence from Time Tracker or the manager's report. A certificate is required from the 4th consecutive working day, or where absences are adjacent to a holiday more than twice in 12 months with manager and HRBP agreement. In Quebec ask for evidence only after 3 consecutive days.
2. Send the request on FORM-HR-011 or accept an equivalent provider note. It is due within 5 business days of the request and goes to the Leaves team through MyHR, not to the manager. Personal days never need a certificate.
3. Check that the certificate shows functional limitations and expected duration only; if a diagnosis appears, restrict access.
4. Code the absence (section 8) and tell Payroll Services. After an absence of 5 or more days, remind the manager to hold the return-to-work conversation within 2 business days of the return.

## 6. Disability claims

### 6.1 Short-term disability

1. When an absence reaches 5 consecutive working days, tell the employee to apply to Maplewood Benefits through MyHR within 5 business days of going off work. The Maplewood Benefits claims line is 1-800-555-0190.
2. Sick days cover days 1 to 5 at 100% of base salary. If the sick-day balance runs out before day 5, the employee may use vacation or personal days or take the remaining days unpaid.
3. Short-term disability pays 100% of base salary for weeks 1 to 13 after the waiting period and 75% for weeks 14 to 26.
4. Do not give medical opinions. Maplewood Benefits decides the claim; record the decision date and approved dates.
5. Vacation continues to accrue during short-term disability.

### 6.2 Long-term disability

From week 27, long-term disability pays 66 2/3% of base salary to a maximum of $15,000 per month, to age 65, decided by Maplewood Benefits; the "own occupation" test applies for the first 24 months. Vacation stops accruing during long-term disability; service stays continuous. Tell Benefits Administration so that benefit continuation is set up (HR-GDE-001 Employee Benefits Guide).

### 6.3 Birth parents in the US

Medical recovery is paid under short-term disability for up to 6 weeks (vaginal birth) or 8 weeks (caesarean); confirm the sequence with the 12 weeks of paid parental leave in writing.

## 7. Parental, family and personal leave

### 7.1 Canada parental and pregnancy leave

1. Employee gives notice at least 4 weeks before the leave starts where possible, on FORM-HR-012. Pregnancy leave is up to 17 weeks (may start up to 13 weeks before the due date); parental leave must start within 78 weeks of the birth or placement; total job-protected leave is up to 18 months for birth parents.
2. Confirm 6 months of continuous service. Without it, the employee has the statutory leave but no Bank top-up.
3. Within 5 business days of a complete application, send the written confirmation of leave dates, top-up amount and return conditions.
4. Ask the employee to apply for Employment Insurance or, in Quebec, the Quebec Parental Insurance Plan, and to send the benefit notice within 5 business days of receiving it.
5. Set the top-up: birth parent 17 weeks; non-birth, adoptive and surrogacy-intended parents 8 weeks. The top-up is 100% of base salary minus the government benefit; in a week with no government benefit inside the top-up period, pay 100% of base salary. Adjust it if the benefit changes. The Bank cannot guarantee the government benefit.

### 7.2 US paid parental leave and FMLA

1. Verify FMLA eligibility. Send the FMLA eligibility notice within 5 business days of learning that a leave may qualify (HR-POL-036 US Equal Employment Opportunity and Required Notices Policy).
2. Ask for certification of a serious health condition where applicable; the employee has 15 calendar days to return it.
3. Send the designation notice within 5 business days.
4. Pay 12 weeks at 100% of base salary for any new parent, running together with FMLA and any state paid family leave program. Where a state program pays, the Bank pays the balance. An employee not eligible for FMLA still receives 12 weeks of Bank-paid leave and the role is held for that period.

### 7.3 Worked examples

| Case | Calculation | Result |
| --- | --- | --- |
| Canada birth parent, base $1,500 a week, illustrative government benefit $650 | $1,500 - $650 = $850 top-up for 17 weeks (8 weeks for a non-birth parent) | $14,450 total top-up; employee receives $1,500 a week |
| US employee, base $2,000 a week, illustrative state benefit $900 | $2,000 - $900 = $1,100 for 12 weeks | $13,200 Bank pay; total pay $24,000 |

### 7.4 Caregiver and personal leave

Caregiver leave is unpaid and job-protected, requested on FORM-HR-013 with a medical certificate where the law allows (limits are in HR-POL-008). For personal leave, receive FORM-HR-010 at least 30 days ahead where possible, route it to the Director and HRBP, and confirm the decision. Benefits continue only if the employee pays both the employee and Bank shares; vacation stops accruing after 30 days of leave.

### 7.5 Workers' compensation

The Leaves team files a workers' compensation claim within 3 business days of learning of a workplace injury (HR-POL-023 Workplace Health, Safety and Wellness Policy).

## 8. Leave codes and payroll interface

| Leave code | Meaning | Payroll action |
| --- | --- | --- |
| LV-SICK | Sick day | Pay 100% of base |
| LV-PERS | Personal day | Pay 100% of base |
| LV-DIS-S | Short-term disability | Pay per section 6.1 |
| LV-DIS-L | Long-term disability | Pay stops; carrier pays |
| LV-PAR-CA | Canada parental top-up | Pay top-up; receive government benefit notice |
| LV-PAR-US | US paid parental leave | Pay 100% (less state benefit) |
| LV-CARE | Caregiver leave | Unpaid |
| LV-UNP | Personal unpaid leave | Unpaid; benefits per election |

Send changes to Payroll Services before the payroll cut-off (17:00 Eastern Time, five business days before the pay date); later changes go to the next pay date (HR-PRC-003 Payroll Processing Calendar and Runbook). Bank-paid parental leave counts as earned salary for the Annual Incentive Plan; approved unpaid leave reduces it. Vacation accrues during short-term disability and the parental top-up period.

## 9. Return to work

1. Contact the employee 4 weeks before the planned return; the employee gives 4 weeks' notice of return. Where the employee asks to return earlier, confirm within 5 business days.
2. Return is to the same or a comparable role at the same pay band. Explain role changes before return.
3. A graduated return of up to 12 weeks after illness or injury is arranged with the Accommodation Specialist, manager and Leaves team. The employee is paid for hours worked; remaining hours are covered by sick days or disability benefits as Maplewood Benefits decides.
4. A phased return of up to 4 weeks at 80% of normal hours is available after parental leave, paid for hours worked.
5. Close the leave code, restore deductions and confirm coverage.

## 10. Checklist

- [ ] Eligibility checked and recorded.
- [ ] Confirmation sent within 5 business days of a complete application.
- [ ] Certificate stored in the restricted file; manager told functional limits only.
- [ ] Maplewood Benefits claim opened within 5 business days of going off work.
- [ ] FMLA eligibility and designation notices sent within 5 business days (US).
- [ ] Government benefit notice received and top-up set (Canada).
- [ ] Leave codes sent to Payroll Services before the cut-off.
- [ ] Return date confirmed; return-to-work conversation planned.

## 11. Escalation and contacts

Questions on eligibility or exceptions go to the HRBP; exceptions are approved by the SVP Total Rewards. For missed leave pay, use P1 (first response within 4 business hours). Employees call HR Connect at 1-800-555-0142.

## 12. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 3.0 | 2026-01-01 | Updated sick days to Canada 10 and US 8; refreshed the parental leave steps for HR-POL-008 version 5.1. |
| 2.0 | 2024-01-01 | Introduced leave codes and the Maplewood Benefits interface steps. |
