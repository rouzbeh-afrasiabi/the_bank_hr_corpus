# IT Acceptable Use and Information Security Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-017 |
| Title | IT Acceptable Use and Information Security Policy |
| Document type | Policy |
| Version | 8.1 |
| Status | Current |
| Effective date | 2026-04-01 |
| Last reviewed | 2026-10-12 |
| Next review | 2027-10-12 |
| Policy owner | Chief Information Security Officer |
| Approved by | Information Security Governance Committee and the Chief Human Resources Officer |
| Applies to | All Canadian and US employees, contractors and agency workers (see Scope) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-016, HR-POL-002, HR-POL-001, HR-POL-021, HR-POL-015, HR-GDE-003 |

## 1. Purpose

This policy sets the rules for using the Bank's technology, systems and information so that client, employee and Bank information stays confidential, accurate and available. It tells every user what is expected, what is allowed, what to report and what happens when the rules are broken.

## 2. Scope

The policy applies to all employees in Canada and the US, and to contractors, agency workers, students and interns who use Bank systems, networks, devices or information, whether in a Bank location, at home or while travelling. Contractors and agency workers are covered by this policy and by mandatory training even though other HR policies do not apply to them. Where applicable law gives a greater right, the law applies.

## 3. Definitions

| Term | Meaning |
| --- | --- |
| Bank-issued device | A laptop, phone, tablet or token owned and managed by the Bank. |
| BYOD | A personal phone enrolled in mobile device management for limited use. |
| MFA | Multi-factor authentication. |
| SOC | The Security Operations Centre. |
| Approved AI tool | An artificial intelligence tool that the CISO and the Privacy Office have approved in the Approved Technology Catalogue in MyHR. |
| Incident | A suspected or actual event that threatens the confidentiality, integrity or availability of Bank information or systems. |

## 4. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Chief Information Security Officer | Owns this policy, the security program and incident response. |
| Security Operations Centre | Monitors 24/7, receives incident reports, leads response. |
| Managers | Make sure their team completes training, approve access requests and report incidents. |
| System owners | Approve access, perform quarterly access reviews. |
| HR Operations | Triggers access changes at hire, transfer and exit (see HR-POL-015 Resignation and Offboarding Policy). |
| Chief Privacy Officer | Reviews AI tools and monitoring for privacy impact (see HR-POL-016 Employee Data Privacy Policy). |
| All users | Follow this policy, protect credentials and devices, and report incidents. |

## 5. Account security

### 5.1 Passwords and passphrases

- Use a password or passphrase of at least 14 characters.
- Use a different one for every system. Do not share credentials or write them down.
- Store credentials only in the Bank password manager.
- Change a credential only if compromise is suspected or the system requires it; routine periodic changes are not required.
- Never enter a Bank password on a non-Bank site.

### 5.2 Multi-factor authentication

MFA is required for all Bank systems, remote access, email and privileged accounts. Users set up MFA on day 1 (see HR-GDE-003 New Employee Onboarding Guide). Approving an MFA prompt that you did not start is an incident and must be reported.

### 5.3 Screen lock

Devices lock automatically after 10 minutes of inactivity, and after 5 minutes in branches. Lock the screen manually whenever you leave the device.

## 6. Information classification and handling

| Class | Definition | Examples | Handling rules |
| --- | --- | --- | --- |
| Public | Approved for release to the public | Published reports, job postings | No restrictions on sharing. |
| Internal | For Bank use; limited harm if disclosed | Policies, org charts, internal announcements | Share only within the Bank and with contracted parties. |
| Confidential | Harm if disclosed to unauthorized people | Employee personal information, client data, pay data, performance records | Bank-issued devices only; encrypted; share on a need-to-know basis. |
| Restricted | Serious harm if disclosed | Medical and accommodation files, investigation files, authentication secrets, material non-public information | Bank-issued devices only; access by named individuals; no printing unless approved; encrypted. |

Label documents and email with their classification. When in doubt treat information as Confidential and ask the Privacy Office or Information Security.

## 7. Devices

### 7.1 Bank-issued devices

Confidential and Restricted information may be accessed or stored only on Bank-issued devices. Do not install unapproved software, disable security tools or let another person use your device. Lost or stolen devices must be reported to the SOC immediately and no later than 1 hour after discovery.

### 7.2 Personal devices (BYOD)

A personal phone may be used for Bank email and calendar only, and only when enrolled in mobile device management. The Bank can remove its data from an enrolled phone, and wipes the Bank container when employment ends. Personal laptops and tablets may not be used for Bank information.

### 7.3 USB and removable media

USB storage is blocked. Exceptions need written approval from Information Security and a business owner, and the device must be encrypted and logged.

## 8. Cloud, collaboration and AI tools

### 8.1 Cloud services

Use only Bank-approved cloud storage and collaboration services. Personal cloud storage, personal email and unapproved file-sharing services must not be used for Bank information.

### 8.2 Approved AI tools (added in version 8.1)

Employees may use only approved AI tools for Bank work. No client or employee personal data, Confidential or Restricted information may be entered in a public AI tool. Employees remain responsible for the accuracy and appropriate use of AI-generated output and must not rely on it as the sole basis for a decision about a person (see HR-POL-016 and HR-POL-019 Recruitment and Selection Policy). Requests to add an AI tool go to Information Security and the Privacy Office, which assess the tool, including a DPIA where needed.

## 9. Remote and travel security

### 9.1 Working remotely

- The VPN must be on at all times when working remotely.
- Do not use public Wi-Fi without the VPN.
- Work in a private space where others cannot view or overhear Confidential information.
- Lock the screen whenever away.
- Follow the work-from-elsewhere limits in HR-POL-002 Remote and Hybrid Work Policy.

### 9.2 Travel

Employees travelling with Bank devices to countries on the restricted-country list must notify Corporate Security 10 business days ahead. Corporate Security may issue a loaner device and require that the usual device stays at home. Never leave devices unattended in vehicles, hotels or airports.

## 10. Phishing and social engineering

Report suspicious messages immediately with the **Report Phishing** button. Do not click links or open attachments from unknown senders, and verify unusual payment or data requests by phone using a known number. The Bank runs phishing simulations quarterly. Three failures in 12 months result in remedial training. Failing a simulation is not itself misconduct, but ignoring remedial training is.

## 11. Incident reporting

Report any suspected incident, including a lost device, a phishing click, malware, unauthorized access, or sending data to the wrong person, to the SOC (1-800-555-0155, soc@bank.example) immediately and no later than 1 hour after discovery. If the incident involves personal information, also notify the Privacy Office within 24 hours (see HR-POL-016). Do not investigate on your own or delete evidence. Reporting in good faith never leads to discipline by itself.

## 12. Access management

| Control | Requirement |
| --- | --- |
| Least privilege | Users receive only the access needed for their role. |
| Approval | Access is approved by the manager and the system owner; privileged access needs both. |
| Reviews | System owners review access quarterly and remove what is not needed. |
| Role changes | Access is reviewed within 5 business days of a role change. |
| Leavers | Access ends at 17:00 on the last day, immediately for involuntary exits. |
| Shared accounts | Not permitted except for approved service accounts. |

## 13. Monitoring

The Bank monitors its systems, networks, email, devices and premises for security, fraud prevention and regulatory compliance. Monitoring is disclosed in HR-POL-033 Electronic Monitoring and Right to Disconnect Policy (which lists what is monitored and requires the acknowledgement on FORM-HR-129), in this policy and in the notice of collection, is proportionate and is not covert. Monitoring data may be used in an investigation with approval of the VP Employee Relations and the Chief Privacy Officer. Employees should not expect privacy on Bank systems, except where the law protects it. Monitoring programs require a DPIA (see HR-POL-016).

## 14. Personal use

Incidental personal use of Bank systems is allowed if it is brief, does not interfere with work, does not break the law or the Code of Conduct (HR-POL-001 Code of Conduct and Ethics) and does not use significant resources. Prohibited uses include illegal activity, harassment, gambling, adult content, running a personal business, mining cryptocurrency and bypassing security controls. Social media use is covered by HR-POL-027 Social Media and External Communications Policy.

## 15. Training

All users complete Privacy and Information Security Awareness training in the Learning Hub within 30 days of hire and annually (annual window 1 August to 31 October). Late completion is escalated to the manager at 14 days and affects the incentive and rating "how" component at 30 days (see HR-POL-012 Learning and Development Policy). Role-based training applies to privileged users and developers.

## 16. Consequences

Breaches of this policy may lead to action under HR-POL-021 Employee Relations and Progressive Discipline Policy, up to and including termination, and may be reported to regulators or law enforcement. Deliberate bypassing of security controls, sharing credentials, copying data to unapproved locations and failing to report an incident promptly are treated as serious. Contractors may have their engagement ended.

## 17. Exceptions

Exceptions require written approval from the CISO, recorded with an expiry date no longer than 12 months, and a review by the Privacy Office where personal information is involved.

## 18. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 8.1 | 2026-04-01 | Added the approved-AI-tools clause (section 8.2). |
| 8.0 | 2025-04-01 | Previous version; annual review and update of the classification and device rules. |
