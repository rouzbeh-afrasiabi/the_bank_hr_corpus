# HR Policy Committee Minutes, 18 September 2025

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-GOV-002 |
| Title | HR Policy Committee Minutes, 18 September 2025 |
| Document type | Minutes |
| Version | 1.0 |
| Status | Current |
| Effective date | 2025-09-18 |
| Last reviewed | Not applicable |
| Next review | Not applicable |
| Policy owner | Office of the CHRO |
| Audience | HR leadership |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-002, HR-POL-006, HR-POL-007, HR-POL-008, HR-POL-012, HR-POL-013 |

Chair: Chief Human Resources Officer

Meeting: Thursday 18 September 2025, 13:00 to 15:00 Eastern Time, in person and by video conference.

## 1. Attendance and quorum

**Voting members present (9 of 9):** Chief Human Resources Officer (Chair), SVP Total Rewards, SVP Talent and Learning, VP Employee Relations, VP HR Operations, Chief Compliance Officer, Chief Privacy Officer, Head of Ethics Office, Head of Workplace Safety.

**Also present (non-voting):** Head of Accessibility and Inclusion; Head of Inclusion and Belonging; Committee Secretary (Office of the CHRO).

Quorum is 5 voting members including the Chair. Quorum was confirmed.

## 2. Agenda

1. Opening and minutes of the meeting of 8 May 2025 (HR-GOV-001)
2. Hybrid work: HR-POL-002 Remote and Hybrid Work Policy
3. Sick days: HR-POL-007 Sick Leave and Personal Leave Policy
4. Vacation carryover: HR-POL-006 Vacation and Paid Time Off Policy
5. Parental leave enhancement: HR-POL-008 Parental and Family Leave Policy
6. Tuition reimbursement cap: HR-POL-012 Learning and Development Policy
7. Performance improvement plan length: for the record
8. Any other business and close

## 3. Discussion

### 3.1 Hybrid minimum

The VP HR Operations proposed raising the hybrid minimum from 2 to 3 office days a week, with Tuesday and Thursday as anchor days and the third day chosen by each team. Supporters cited collaboration, onboarding and coaching needs. Two members were concerned about commuting burden and caregiving, and asked that the 12 office-attendance exception days per calendar year, with HRBP approval beyond that, be kept in the policy. Accommodation needs remain outside the 12 days.

### 3.2 Sick days

The SVP Total Rewards proposed increasing paid sick days from 8 to 10 in Canada and from 6 to 8 in the US, credited each 1 January. Personal days stay at 3 per calendar year. Members noted that the US increase keeps the Bank above state sick-leave laws.

### 3.3 Vacation carryover

The SVP Total Rewards proposed raising the carryover from 3 days to 5 days, to be used by 31 March. The Chief Compliance Officer confirmed that the mandatory 10-day block leave control is not affected.

### 3.4 Parental leave and tuition

The Committee considered the parental leave enhancement (non-birth, adoptive and surrogacy-intended parent top-up in Canada from 6 to 8 weeks; US paid parental leave from 8 to 12 weeks) and the tuition cap increase from $4,000 to $5,000 CAD per fiscal year, following the options paper requested at the meeting of 8 May 2025.

### 3.5 Performance improvement plans

The VP Employee Relations reminded members that the standard performance improvement plan length has been 60 days since 1 June 2025 (HR-POL-013 version 2.1, previously 90 days). No decision was required.

## 4. Decisions

| No. | Decision | Effective | Vote |
| --- | --- | --- | --- |
| D1 | Approved a hybrid minimum of 3 office days per week, with Tuesday and Thursday anchor days (HR-POL-002, version 3.0). | 2026-01-05 | For 7, Against 2, Abstain 0. Carried. |
| D2 | Approved paid sick days of 10 in Canada and 8 in the US (HR-POL-007, version 3.0). | 2026-01-01 | For 9, Against 0, Abstain 0. Carried. |
| D3 | Approved vacation carryover of up to 5 days, to be used by 31 March (HR-POL-006, version 4.0). | 2026-01-01 | For 8, Against 0, Abstain 1 (Chief Compliance Officer). Carried. |
| D4 | Approved the parental leave enhancement: Canada top-up of 8 weeks for non-birth, adoptive and surrogacy-intended parents; US paid parental leave of 12 weeks (HR-POL-008, version 5.1). | 2025-11-01 | For 9, Against 0, Abstain 0. Carried. |
| D5 | Approved the tuition reimbursement cap of $5,000 CAD and $5,250 USD per fiscal year (HR-POL-012, version 3.2). | 2025-11-01 | For 9, Against 0, Abstain 0. Carried. |

## 5. Items noted for the record

- The standard performance improvement plan length of 60 days has been in effect since 2025-06-01 (HR-POL-013).

## 6. Action items

| No. | Action | Owner | Due |
| --- | --- | --- | --- |
| A1 | Issue the employee memo on the hybrid change (HR-MEMO-2025-002) and update FORM-HR-030 for anchor days. | VP HR Operations | 2025-09-24 |
| A2 | Issue the employee memo on the tuition cap (HR-MEMO-2025-003). | SVP Talent and Learning | 2025-10-06 |
| A3 | Issue the employee memo on the parental leave enhancement (HR-MEMO-2025-004). | SVP Total Rewards | 2025-10-14 |
| A4 | Issue the employee memo on sick days (HR-MEMO-2025-005) and set the 1 January credits in Time Tracker. | SVP Total Rewards | 2025-10-20 |
| A5 | Issue the employee memo on vacation carryover (HR-MEMO-2025-006), replacing the earlier reminder (HR-MEMO-2024-001). | SVP Total Rewards | 2025-10-27 |

## 7. Close

The Chair thanked members and closed the meeting at 15:00.
