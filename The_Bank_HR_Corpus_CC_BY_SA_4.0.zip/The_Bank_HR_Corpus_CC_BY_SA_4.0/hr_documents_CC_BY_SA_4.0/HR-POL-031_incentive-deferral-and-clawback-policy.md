# Incentive Deferral and Clawback Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-031 |
| Title | Incentive Deferral and Clawback Policy |
| Document type | Policy |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-09-30 |
| Next review | 2027-09-30 |
| Policy owner | SVP Total Rewards |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-009, HR-PLN-001, HR-PLN-002, HR-PLN-003, HR-POL-030, HR-POL-021 |

## 1. Purpose

Incentive pay should reward results without encouraging excessive risk. This policy explains how part of a large Annual Incentive Plan (AIP) payout is deferred for senior employees and for employees whose decisions can materially affect the Bank's risk, and how the Bank may reduce or recover incentive pay after misconduct, a misstatement or a risk-management failure.

## 2. Scope

The policy applies to:

- all employees in **Band 7 and above**; and
- **Designated Material Risk Takers**, in any band, named by the Chief Risk Officer.

It applies to AIP payouts as set out in HR-PLN-001 Annual Incentive Plan Document. The clawback and malus provisions in sections 7 and 8 also apply, on the same principles, to incentive pay under HR-PLN-002 Advisor and Sales Incentive Plan Document and to awards under HR-PLN-003 Long-Term Incentive Plan Document. The AIP formula and eligibility are in HR-POL-009 Compensation and Payroll Policy and are not repeated here. Where applicable law gives a greater right, the law applies.

## 3. Definitions

| Term | Meaning |
| --- | --- |
| Deferral | Holding back part of an incentive payout, which is delivered later in share units, subject to vesting. |
| Share unit | A notional unit whose value follows the Bank's share price. It is settled after vesting. |
| Vesting | The date on which a deferred amount becomes the employee's to receive. |
| Designated Material Risk Taker | An employee named by the Chief Risk Officer because their activities can materially affect the Bank's risk profile. |
| Malus | Reduction or cancellation of an unvested deferred amount before it vests. |
| Clawback | Recovery of incentive pay that has already been paid or vested. |
| Misconduct | Fraud, dishonesty, a serious breach of the Code of Conduct and Ethics or of Bank policy, or a breach of law or regulation. |
| Board HR Committee | The committee of the Board of Directors responsible for human resources and compensation. |

## 4. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Chief Risk Officer | Names the Designated Material Risk Takers and reviews the list each year. |
| SVP Total Rewards | Owns the policy, calculates deferrals and tracks vesting. |
| Payroll Services | Pays the cash portion on the first pay date in February and handles tax withholding on delivery. |
| Chief Human Resources Officer (CHRO) | Recommends clawback and malus decisions to the Board HR Committee. |
| Board HR Committee | Decides clawback and malus. |
| VP Employee Relations and Chief Compliance Officer | Provide the facts about misconduct and conduct reviews (see HR-POL-030 Fit and Proper and Conduct Standards Policy). |

## 5. Deferral

### 5.1 When it applies

Deferral applies when the AIP payout for the fiscal year is **above $100,000**, in CAD for employees in Canada and in USD for employees in the US. It is the whole payout that is tested. A payout of exactly $100,000 or less is paid in cash in full.

### 5.2 How much is deferred

| Group | Share of the payout that is deferred |
| --- | --- |
| Band 7 and Band 8 | 40% |
| Band 9 | 50% |
| Designated Material Risk Takers (any band) | 50% |

The rest of the payout is paid in cash on the first pay date in February, as set out in HR-POL-009.

### 5.3 Vesting and delivery

- The deferred amount is converted to share units on the payment date.
- It vests in **three equal parts**, one third on each of the first, second and third anniversaries of the payment date.
- Each vested part is delivered in share units, with tax withheld through payroll where required.
- An employee must be on payroll on each vesting date, except as set out in section 6.

### 5.4 Designation of Material Risk Takers

The Chief Risk Officer confirms the list of Designated Material Risk Takers each year. The employee is told in writing, with the date from which the policy applies to them. Moving out of a designated role does not end the clawback period for pay already awarded.

## 6. Leaving the Bank

| Event | Treatment of unvested deferred amounts |
| --- | --- |
| Resignation | Forfeited |
| Retirement (age 55 with 10 years of service) | Kept, and vests on the original dates |
| Death | Kept, and paid to the estate according to the plan and the law |
| Involuntary termination | Follows the termination rules in HR-PLN-003 Long-Term Incentive Plan Document |
| Termination for cause | Forfeited |
| Approved leave of absence | Vesting continues |

Amounts that have vested remain subject to clawback in section 8.

## 7. Malus

The Bank may reduce or cancel unvested deferred amounts **at any time** if one of the grounds in section 8.1 applies. Malus can be partial or total.

## 8. Clawback

### 8.1 Grounds

The Bank may recover incentive pay when one of the following happens:

1. **Misconduct** by the employee, or by a person the employee supervised where the employee knew, or should have known, and did not act;
2. a **material misstatement** of the Bank's financial results or of the data used to decide the payout;
3. a **material risk-management failure** for which the employee was responsible or accountable.

### 8.2 Recovery period

| Group | Period after payment |
| --- | --- |
| Employees in Band 7 and above | Up to 3 years |
| Designated Material Risk Takers | Up to 5 years |

The period is measured from the date the incentive was paid. Recovery applies to the cash and to share units, vested or not.

### 8.3 Decision process

| Step | Action | Timing |
| --- | --- | --- |
| 1 | The Chief Compliance Officer or VP Employee Relations reports the facts to the CHRO. | When a ground may apply |
| 2 | The CHRO recommends malus or clawback and an amount to the Board HR Committee. | After review by Legal |
| 3 | The employee receives written notice of the proposal, with the facts and the amount. | Before any decision |
| 4 | The employee may respond in writing. | **15 business days** from receipt of the notice |
| 5 | The Board HR Committee decides, considering the response, and records its reasons. | After the response period |
| 6 | Written decision to the employee. | Within 10 business days of the decision |

### 8.4 Recovery methods

Recovery may be made by cancelling unvested amounts, by lump sum, by a repayment plan agreed with Payroll Services, or, where law permits, from other amounts owed. Deductions from pay follow the limits and consent rules in HR-POL-009 Compensation and Payroll Policy. Recovery takes account of taxes already paid, where the law allows.

## 9. Worked examples

1. **Band 8, above the threshold.** A Band 8 employee in Canada has base salary earned of $260,000, an AIP target of 30%, a funding factor of 1.2 and a rating of Exceeds Expectations (1.2). Payout = $260,000 x 0.30 x 1.2 x 1.2 = $112,320 CAD. Because it is above $100,000, 40% ($44,928) is deferred and $67,392 is paid in cash. The deferred amount vests at $14,976 a year. For the payout made on 2026-02-05, vesting dates are 2027-02-05, 2028-02-05 and 2029-02-05.
2. **Band 7, below the threshold.** A Band 7 employee has base salary earned of $200,000 and an AIP target of 20%. At the maximum funding factor (1.5) and an Outstanding rating (1.5), the payout is $90,000. It is below $100,000, so nothing is deferred.
3. **Band 9.** A Band 9 employee has base salary earned of $330,000, target 45%, funding factor 1.0 and a Meets Expectations rating. Payout = $148,500. Deferral is 50% = $74,250, vesting at $24,750 a year. Cash paid in February is $74,250.
4. **Material Risk Taker.** A Band 8 employee is a Designated Material Risk Taker and has a payout of $112,320. Deferral is 50% = $56,160, and the clawback period is 5 years instead of 3.
5. **Resignation.** The Band 8 employee in example 1 resigns after the first tranche has vested. The remaining two unvested tranches ($29,952) are forfeited. The vested tranche is still subject to clawback within the recovery period.
6. **Clawback.** A material misstatement is found 2 years after a payment. The Board HR Committee, on the CHRO's recommendation, proposes recovery. The employee has 15 business days to respond.

## 10. Exceptions

No exception may reduce the deferral percentages, the vesting schedule or the recovery periods. The Board HR Committee may decide not to apply malus or clawback, in whole or in part, where it finds it unfair in the circumstances, and must record its reasons.

## 11. Consequences and related rules

Misconduct that leads to clawback may also lead to action under HR-POL-021 Employee Relations and Progressive Discipline Policy. Clawback does not limit any other legal remedy. Questions about tax on deferred amounts should be addressed to a personal tax adviser.

## 12. Related documents and contacts

- HR-POL-009 Compensation and Payroll Policy
- HR-PLN-001 Annual Incentive Plan Document
- HR-PLN-002 Advisor and Sales Incentive Plan Document
- HR-PLN-003 Long-Term Incentive Plan Document
- HR-POL-030 Fit and Proper and Conduct Standards Policy
- HR-POL-021 Employee Relations and Progressive Discipline Policy
- Total Rewards questions: HR Connect, 1-800-555-0142, hrconnect@bank.example.

## 13. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-01-01 | Set the deferral threshold at $100,000, the 40% and 50% deferral rates, 3-year equal vesting in share units, the 3-year and 5-year clawback periods and the 15-business-day response period. |
| 1.0 | 2024-01-01 | First version. |
