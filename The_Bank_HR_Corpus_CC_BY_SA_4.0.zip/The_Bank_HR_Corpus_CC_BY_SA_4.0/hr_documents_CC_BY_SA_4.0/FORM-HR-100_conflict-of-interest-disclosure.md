# Conflict of Interest Disclosure

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | FORM-HR-100 |
| Title | Conflict of Interest Disclosure |
| Document type | Form |
| Version | 2.0 |
| Status | Current |
| Effective date | 2026-01-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | Head of Ethics Office |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-001, HR-POL-019, HR-POL-022, FORM-HR-101, FORM-HR-102, HOW-032 |

## 1. Purpose and when to use this form

Use this form to disclose an actual, potential or perceived conflict of interest: a personal, family, financial or outside interest that could influence, or appear to influence, your judgment on behalf of the Bank (HR-POL-001 Code of Conduct and Ethics). Examples include supervising or hiring a relative, approving a transaction for a business you own, or taking a personal benefit from a supplier.

## 2. Who completes it and who approves

You complete it. The Ethics Office reviews it and decides in writing how the conflict will be managed. Your manager is informed only as needed to carry out that decision.

## 3. Where and when to submit (deadline, channel, processing time)

Submit within 10 business days of becoming aware of the conflict, in MyHR (Ethics > Conflict of Interest) or by email to ethics@bank.example. Do not take part in the related decision until the Ethics Office tells you in writing how the conflict will be managed.

## 4. Form fields

| Field | Required | Notes |
| --- | --- | --- |
| Name, employee ID, band, manager | Yes | Pre-filled |
| Date you became aware | Yes | Starts the 10-business-day period |
| Type of conflict | Yes | Relative at the Bank, family or personal financial interest, outside business interest, supplier or client relationship, other |
| Description | Yes | Facts only |
| Other people or organizations involved | Yes | Include the relationship; a relative means a spouse or partner, child, parent, sibling, grandparent, grandchild, in-law, or anyone in your household |
| Decisions or duties affected | Yes | Approvals, hiring, supervision, transactions |
| Related Bank decisions pending | Yes | Dates if known |
| Proposed way to manage it | No | For example stepping back from a decision |
| Related outside activity or gift | No | See FORM-HR-102 and FORM-HR-101 |

## 5. Declarations and signatures

I confirm that this disclosure is complete and true, that I will not take part in the related decision until I receive the Ethics Office's written direction, and that I will update this form if the facts change. Signature and date: ____________.

## 6. What happens next

The Ethics Office acknowledges your disclosure and sends you written direction, which may be to take no action, to step back from certain decisions, to change a reporting line, or to end the interest. Disclosures are kept confidential and reviewed at your annual Code attestation, due by 31 October. Managers may not hire or directly supervise a relative (see HR-POL-019 Recruitment and Selection Policy). You may ask the Ombuds Office for informal advice at any time. Good-faith disclosure is protected from retaliation.

## 7. Related documents

- HR-POL-001 Code of Conduct and Ethics
- FORM-HR-102 Outside Business Activity Request
- FORM-HR-101 Gift and Entertainment Disclosure

## 8. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 2.0 | 2026-01-01 | Added relative definition and linked fields for outside activities and gifts. |
| 1.0 | 2022-01-01 | Initial form. |
