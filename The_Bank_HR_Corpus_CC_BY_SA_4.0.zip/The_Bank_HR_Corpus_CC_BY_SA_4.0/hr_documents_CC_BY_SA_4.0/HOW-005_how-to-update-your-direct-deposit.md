# How to update your direct deposit

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HOW-005 |
| Title | How to update your direct deposit |
| Document type | How-to article |
| Version | 1.0 |
| Status | Current |
| Effective date | 2025-09-01 |
| Last reviewed | 2026-07-15 |
| Next review | 2027-07-15 |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-009, FORM-HR-022, FORM-HR-021, HOW-008 |

## 1. The short answer

Complete FORM-HR-022 Direct Deposit and Tax Withholding Update in MyHR by 17:00 Eastern Time, five business days before the pay date you want the change to apply to.

## 2. Who this applies to

All employees in Canada (including Quebec) and the US. Pay is by direct deposit only, biweekly in arrears: Canadian employees are paid on Thursdays and US employees on Fridays. No manager approval is needed; Payroll Services verifies and processes the update.

## 3. Steps

1. Select **MyHR > Pay > Direct Deposit**, then **Update bank details** (FORM-HR-022, update type "Direct deposit").
2. Enter your account details. Canada: institution, transit and account numbers. US: routing and account numbers.
3. Choose the account type (chequing or savings). Your pay goes to one account unless you ask for a split.
4. Confirm the account is in your name and that the details are accurate, then sign electronically.
5. Check the **effective pay date** that MyHR shows after the cut-off check, and submit.
6. Watch MyHR for a confirmation request: Payroll Services may confirm the change with you before processing.

## 4. Deadlines to remember

The payroll cut-off is 17:00 Eastern Time, five business days before the pay date. A change received after the cut-off is processed on the next pay date. For example, for the Canada pay date of 2026-03-05 the cut-off is 17:00 Eastern Time on 2026-02-26.

## 5. What happens next

Payroll Services processes the update for the next eligible pay date. Your pay statement appears in MyHR 2 business days before the pay date (see HOW-007). Your Maplewood Benefits claim payments use the account in your Maplewood Benefits profile, so update that profile separately.

## 6. Common mistakes

- Submitting on the cut-off day itself or later, then closing the old account. Keep the old account open until the first deposit arrives in the new one.
- Typing the transit, routing or account number incorrectly.
- Using an account that is not in your name.
- Forgetting to update the Maplewood Benefits profile.

If a payment goes to the wrong account, raise a P1 case through FORM-HR-021 Payroll Correction Request in the HR Case Portal; the first response is within 4 business hours (see HOW-008).

## 7. Who to call

HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, or live chat in MyHR; English and French. Payroll Services is the Tier 2 team behind HR Connect.

## 8. Related documents

- HR-POL-009 Compensation and Payroll Policy
- FORM-HR-022 Direct Deposit and Tax Withholding Update
- FORM-HR-021 Payroll Correction Request
- HOW-008 How to report a payroll error

## 9. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.0 | 2025-09-01 | First edition, written for the combined MyHR form FORM-HR-022. |
