# Workplace Health, Safety and Wellness Policy

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-POL-023 |
| Title | Workplace Health, Safety and Wellness Policy |
| Document type | Policy |
| Version | 3.3 |
| Status | Current |
| Effective date | 2025-05-01 |
| Last reviewed | 2026-06-02 |
| Next review | 2027-06-02 |
| Policy owner | Head of Workplace Safety |
| Approved by | HR Policy Committee (chaired by the Chief Human Resources Officer) |
| Applies to | All Canadian and US employees (see Scope) |
| Audience | Employees |
| Jurisdiction | Canada and US |
| Language | English |
| Related documents | HR-POL-005, HR-POL-007, HR-POL-018, FORM-HR-011 |

## 1. Purpose

The Bank is committed to providing a safe and healthy workplace and to supporting the physical and mental wellbeing of every employee. This policy sets the health and safety rules, the wellness supports, and the duties of employees, managers and specialist teams. It complies with applicable occupational health and safety legislation in each province, territory and state. Where applicable law gives a greater right, the law applies.

## 2. Scope and definitions

### 2.1 Scope

The policy applies to all employees at Bank premises, branches, home offices and any place where they work for the Bank. Contractors and visitors must follow site safety rules.

### 2.2 Definitions

- **Incident:** any event that causes, or could have caused, injury, illness, damage or a threat to safety, including near misses.
- **Workplace injury:** an injury or illness arising out of or in the course of work.
- **Mental health first aider:** a trained employee volunteer who offers peer support and directs colleagues to professional help; they are not therapists.
- **Modified duties:** temporary changes to a role that allow an injured employee to work safely.

## 3. Roles and responsibilities

| Role | Responsibility |
| --- | --- |
| Employee | Work safely, report hazards and incidents, complete training, and follow emergency procedures. |
| Manager | Keep the work area safe, report incidents on the day, support return to work, and ensure no retaliation. |
| Head of Workplace Safety | Owns the policy, risk assessments, investigations, regulator reporting and training content. |
| Corporate Security | Responds to emergencies 24 hours a day, 7 days a week at 1-800-555-0119. |
| Leaves team | Files workers' compensation claims and coordinates return to work. |
| Accommodation Specialist | Plans modified duties and workplace adjustments (HR-POL-018 Workplace Accommodation and Accessibility Policy). |
| Workplace Health and Safety Committees | Inspect, advise and review incidents. |
| HR Business Partner (HRBP) | Supports managers and employees on health-related people issues. |

## 4. General health and safety requirements

### 4.1 Duties and rights

Every employee has the right to know about hazards, the right to participate in safety activities, and the right to refuse work that they reasonably believe is unsafe, as set out in applicable law. An employee who refuses unsafe work must tell the manager and Corporate Security immediately, and no discipline or retaliation will follow for a good-faith refusal.

### 4.2 Hazard reporting

Hazards and near misses are reported to the manager and entered in MyHR. The Head of Workplace Safety triages hazards within 2 business days and assigns an owner and deadline for the correction.

### 4.3 Training

The Workplace Health and Safety course is mandatory in the Learning Hub every year. New hires complete it within 30 days of their start date. Managers also complete additional safety training for leaders.

## 5. Emergency procedures

- **Emergency:** call 911 first, then Corporate Security on 1-800-555-0119.
- **Fire and evacuation:** every site has a posted evacuation plan, floor wardens and assembly points. Employees leave by the nearest safe exit, do not use elevators, and report to the assembly point. Fire drills are held twice a year at each site; participation is mandatory.
- **Medical emergency:** call 911, then Corporate Security, which dispatches the nearest trained first aider and the defibrillator. Sites have a first aid kit and certified first aiders in line with the law.
- **Shelter in place and lockdown:** follow the instructions given by Corporate Security through MyHR alerts, text messages and the intranet banner.
- **Severe weather and site closures:** see HR-POL-004 Attendance and Absenteeism Policy.

## 6. Branch safety

### 6.1 Daily routines

Branches follow two-person opening and closing procedures. Cash handling, vault access and alarm codes are controlled by the branch manager. Employees do not work alone in a branch after hours unless a lone-working check-in plan is in place.

### 6.2 Robbery protocol

During a robbery, every employee must:

1. comply with the demands calmly and do not resist;
2. activate the alarm only when it is safe to do so;
3. note descriptions and details, and not touch anything the robber touched;
4. call 911 after the robber has left, then Corporate Security;
5. keep the premises closed until police release them.

Following any robbery or threat, employees are offered immediate support from the Wellspring Support Program and a debrief within 24 hours. Violence and threats are also covered by HR-POL-005 Workplace Harassment and Violence Prevention Policy.

## 7. Injury and incident reporting

1. **Immediately:** the employee, or a colleague, reports the injury or incident to the manager and to Corporate Security.
2. **Within 24 hours:** the incident is entered in MyHR by the employee or the manager.
3. **Within 3 business days:** the Leaves team files the workers' compensation claim with the provincial or state authority, after learning of the injury. The employee must provide treatment details.
4. **Within 2 business days:** the Head of Workplace Safety opens an investigation for any lost-time injury, critical injury or serious near miss. The scene is preserved.

Where the law requires, the Head of Workplace Safety notifies the regulator of serious injuries. The employee is paid for the remainder of the shift on the day of injury. Reporting an injury never leads to retaliation. A time-loss claim does not reduce sick days; see HR-POL-007 Sick Leave and Personal Leave Policy for non-work-related illness.

## 8. Return to work

The Bank supports recovery and early, safe return to work. The Leaves team and the Accommodation Specialist build a written return-to-work plan with the employee, manager and treating provider, based on FORM-HR-011 Medical Certificate and Fitness-to-Work. Modified duties are available for up to 12 weeks. The plan states hours, duties, restrictions and review dates, and is reviewed at least every 2 weeks. The manager receives only functional limitations and expected duration. If a longer period is needed, accommodation under HR-POL-018 applies.

## 9. Wellness programs

### 9.1 Employee assistance

The Wellspring Support Program is free, confidential and available 24 hours a day, 7 days a week at 1-800-555-0166. It provides up to 8 counselling sessions per issue per calendar year for employees and members of their household. Use of the program is not reported to the Bank.

### 9.2 Mental health

The Bank promotes psychological safety. Mental health first aiders are available at major sites and are listed in MyHR. Managers receive training on recognising signs of distress and how to respond. Employees may use sick days for mental health care. Mental health practitioner coverage is described in HR-GDE-001 Employee Benefits Guide.

### 9.3 Wellness spending account

Each employee receives a wellness spending account of $500 CAD or $400 USD per calendar year, claimed by 31 March of the following year. Details are in the Employee Benefits Guide.

### 9.4 Ergonomics

An employee may request an ergonomic assessment through MyHR or HR Connect for an office, branch or home workstation. The assessment is completed within 30 days of the request. Recommended equipment is provided at no cost to the employee. Home office setup allowances are in HR-POL-002 Remote and Hybrid Work Policy.

## 10. Workplace Health and Safety Committees

Each Bank site with 20 or more employees has a Workplace Health and Safety Committee with equal numbers of employee and management members. The committee:

- meets at least quarterly and keeps minutes;
- performs a workplace inspection at least once a quarter;
- reviews incident reports and corrective actions;
- raises concerns with the Head of Workplace Safety, who responds within 15 business days.

Smaller sites designate a health and safety representative. The Head of Workplace Safety reports annually to the CHRO on injury rates and corrective actions.

## 11. Exceptions and consequences

Exceptions to safety rules are not allowed unless approved in writing by the Head of Workplace Safety. Violation of safety rules may lead to action under HR-POL-021 Employee Relations and Progressive Discipline Policy. Deliberately failing to report an injury is a breach of this policy.

## 12. Contacts

Emergency: 911, then Corporate Security, 1-800-555-0119 (24/7). Wellspring Support Program: 1-800-555-0166. HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time, hrconnect@bank.example. Managers: Manager Hotline 1-800-555-0143.

## 13. Change history

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 3.3 | 2025-05-01 | Clarified the workers' compensation claim deadline (3 business days) and added mental health first aiders and a debrief after robberies. |
| 3.2 | 2024-05-01 | Added ergonomic assessments for home workstations and fire drill frequency of twice a year. |
