# Comment signaler une absence

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

> **Document synthétique.** Contenu fictif produit pour des essais de recherche et de questions-réponses. Il ne constitue pas la politique d'une organisation réelle.

| Field | Value |
| --- | --- |
| Document ID | HOW-049 |
| Title | Comment signaler une absence |
| Document type | How-to article |
| Version | 1.0 |
| Status | Current |
| Effective date | 2025-04-01 |
| Last reviewed | 2026-09-10 |
| Next review | 2027-09-10 |
| Policy owner | VP Employee Relations |
| Audience | Employees |
| Jurisdiction | Quebec |
| Language | French |
| Related documents | HR-SUP-001, HR-POL-004, HR-POL-007, FORM-HR-011 |

## 1. Réponse courte

Joignez votre gestionnaire par téléphone ou par message avant le début de votre quart, ou au plus tard 30 minutes après si c'est impossible, puis inscrivez l'absence dans Time Tracker à votre retour. Au Québec, la Banque ne demande une preuve de l'absence qu'après 3 jours consécutifs d'absence.

## 2. À qui s'adresse cet article

Aux employés réguliers, à temps partiel et à durée déterminée dont le lieu de travail est le Québec, ainsi qu'aux employés occasionnels pour leurs quarts prévus.

## 3. Étapes

1. Avant le début de votre quart, appelez ou écrivez à votre gestionnaire; un courriel seul ne suffit pas le jour même. Les employés d'une succursale avisent aussi le directeur de la succursale.
2. Indiquez la durée prévue et, si possible, la date de retour, sans diagnostic.
3. Après 3 jours consécutifs d'absence, fournissez la preuve demandée : FORM-HR-011 ou une note équivalente d'un professionnel de la santé. Téléversez-la dans MyHR > Portail des cas RH (type de cas Congé) à l'intention de l'équipe des congés, pas de votre gestionnaire. Elle indique les limitations fonctionnelles et la durée prévue, jamais le diagnostic.
4. À votre retour, ouvrez MyHR > Temps et absences > Saisir une absence (Time Tracker) et inscrivez l'absence. Les jours de maladie payés sont de 10 par année civile, au minimum une demi-journée (jusqu'à 5 pour les soins d'un proche). Les 3 jours personnels n'exigent jamais de certificat.
5. Si l'absence peut dépasser 5 jours ouvrables consécutifs, demandez les prestations d'invalidité de courte durée à Maplewood Benefits par MyHR > Avantages sociaux > Demande d'invalidité.

## 4. Échéances

| Élément | Échéance |
| --- | --- |
| Signaler l'absence | Avant le début du quart, ou dans les 30 minutes suivantes |
| Preuve de l'absence (Québec) | Après 3 jours consécutifs, téléversée dans les 5 jours ouvrables suivant la demande |
| Invalidité de courte durée | Dans les 5 jours ouvrables suivant le début de l'absence du travail |
| Entretien de retour au travail | Dans les 2 jours ouvrables suivant le retour après 5 jours d'absence ou plus |

## 5. Et ensuite

Votre gestionnaire consigne l'absence. L'équipe des congés examine le certificat et ne transmet au gestionnaire que les limitations fonctionnelles et la durée prévue. Un retard de plus de 10 minutes sans avis est consigné; un examen des habitudes de présence commence après 3 retards en 30 jours, ou 4 occurrences ou 8 jours d'absence en 12 mois consécutifs, sans compter les absences protégées (congés approuvés, mesures d'adaptation, vacances, deuil). Il amorce une conversation, pas une mesure disciplinaire. Sans nouvelles pendant 3 jours consécutifs prévus à votre horaire, RH fait au moins 3 tentatives documentées pour vous joindre avant toute conclusion.

## 6. Erreurs fréquentes

- Envoyer un courriel seulement, le jour de l'absence, ou appeler plus de 30 minutes après le début du quart.
- Envoyer le certificat à votre gestionnaire ou y inscrire un diagnostic.
- Croire qu'un certificat est exigé dès le 4e jour : au Québec, la preuve peut être demandée après 3 jours consécutifs.
- Oublier Time Tracker ou tarder à demander l'invalidité de courte durée.

## 7. Personnes-ressources

RH Connect : 1-800-555-0142, du lundi au vendredi, de 8 h à 20 h (heure de l'Est), hrconnect@bank.example, clavardage dans MyHR. Maplewood Benefits : 1-800-555-0190. Programme de soutien Wellspring : 1-800-555-0166, 24 heures sur 24.

## 8. Documents connexes

- HR-SUP-001 Supplément pour le Québec
- HR-POL-004 Attendance and Absenteeism Policy
- HR-POL-007 Sick Leave and Personal Leave Policy

## 9. Historique des modifications

| Version | Effective date | Summary of change |
| --- | --- | --- |
| 1.0 | 2025-04-01 | Première version, conforme à HR-POL-004 version 3.1. |
