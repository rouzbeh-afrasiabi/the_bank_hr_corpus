# Summer Closures: 24 June, 1 July and 3 July 2026

> **Synthetic document.** Fictional content generated for retrieval and question-answering
> experiments. It is not the policy of any real organization.

| Field | Value |
| --- | --- |
| Document ID | HR-MEMO-2026-005 |
| Title | Summer Closures: 24 June, 1 July and 3 July 2026 |
| Document type | Memo |
| Version | 1.0 |
| Status | Current |
| Effective date | 2026-06-22 |
| Last reviewed | Not applicable |
| Next review | Not applicable |
| Policy owner | SVP Total Rewards |
| Audience | Employees |
| Jurisdiction | Quebec |
| Language | English |
| Related documents | HR-POL-010, HR-SUP-001, HR-GDE-004 |

**Three summer holidays in the next two weeks. French version available on request.**

**From:** SVP Total Rewards

**To:** All employees (Quebec employees for 24 June; Canada for 1 July; US for 3 July)

**Date:** 22 June 2026

**Subject:** Bank holiday closures, June and July 2026

## 1. What is changing

| Date | Holiday | Who |
| --- | --- | --- |
| Wednesday 24 June 2026 | Fête nationale du Québec | Quebec only |
| Wednesday 1 July 2026 | Canada Day | Canada |
| Friday 3 July 2026 | Independence Day, observed (the holiday falls on Saturday 4 July) | US |

HR Connect is closed on these days.

## 2. Who is affected

Employees in the locations shown. Regular full-time and part-time employees are eligible from day one. Part-time holiday pay is the average daily earnings over the previous 20 working days.

## 3. Effective date

The closures apply on the dates above.

## 4. What to do

1. If you must work a holiday, you receive regular holiday pay plus 1.5x for hours worked, or in Canada 1.5x time in lieu taken within 60 days (HR-POL-010).
2. An unexcused absence on the scheduled day before and after a holiday forfeits holiday pay.
3. Vacation booked over a holiday is not charged for the holiday.
4. Submit non-urgent questions in the HR Case Portal in MyHR.

## 5. Who to call

HR Connect: 1-800-555-0142, Monday to Friday 8:00 to 20:00 Eastern Time (closed on Bank holidays), hrconnect@bank.example, or live chat in MyHR. In an emergency, Corporate Security: 1-800-555-0119 (24/7).

## 6. Related documents

- HR-POL-010 Statutory Holidays Policy
- HR-SUP-001 Supplément pour le Québec
- HR-GDE-004 HR Service and Support Guide
